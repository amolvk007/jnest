package com.smartcity.util;

import org.apache.log4j.Logger;

public class LoggerUtil {
	private static final Logger LOGGER = Logger.getLogger(LoggerUtil.class);

	public static void logMessage (String message)
	{
		if(LOGGER.isInfoEnabled())
		{
			LOGGER.info(message);
		}
		else if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(message);
		}			
		
	}
}
