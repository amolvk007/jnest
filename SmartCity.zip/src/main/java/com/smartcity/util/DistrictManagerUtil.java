package com.smartcity.util;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.smartcity.dbbean.DistrictEntity;
import com.smartcity.dbbean.DistrictPresetEntity;
import com.smartcity.dbbean.EventPresetEntity;
import com.smartcity.jsonbean.Coordinates;
import com.smartcity.jsonbean.District;
import com.smartcity.jsonbean.DistrictDashboardData;
import com.smartcity.jsonbean.Gateway;
import com.smartcity.jsonbean.Pole;
import com.smartcity.jsonbean.Sensor;
import com.smartcity.jsonbean.UpdateDistrictPresetRequest;
import com.smartcity.jsonbean.s2c.S2CPresets;
import com.smartcity.jsonbean.s2c.S2CSendCommandToSensorsRequest;
import com.smartcity.jsonbean.s2c.S2CSendCommandToSensorsRequestData;
import com.smartcity.jsonbean.s2c.SensorInfo;

public class DistrictManagerUtil {

	public static DistrictEntity convertCreateDistrictRequestToDistrictEntity(District district) {
		StringBuilder districtCoordinates = new StringBuilder();
		Date date = new Date();

		for (Coordinates coordinates : district.getDistrictCoordinates()) {
			districtCoordinates.append(coordinates.getLatitude());
			districtCoordinates.append(",");
			districtCoordinates.append(coordinates.getLongitude());
			districtCoordinates.append("#");
		}

		DistrictEntity districtEntity = new DistrictEntity();
		districtEntity.setName(district.getDistrictName());
		districtEntity.setcoordinates(districtCoordinates.toString());

		districtEntity.setCreatedby(UserManagerUtil.getLoggedInUserName());
		districtEntity.setCreateddate(new Timestamp(date.getTime()));
		districtEntity.setModifiedby(UserManagerUtil.getLoggedInUserName());
		districtEntity.setModifiedDate(new Timestamp(date.getTime()));

		return districtEntity;
	}

	public static List<District> districtList(List<Object> districtEntityList) {

		List<District> districtList = new ArrayList<District>();
		LoggerUtil.logMessage("districtList::::::" + districtList.size());

		for (Object object : districtEntityList) {
			Object[] objArr = (Object[]) object;

			District district = new District();

			district.setDistrictId(objArr[0].toString());
			district.setDistrictName(objArr[1].toString());

			// List<Coordinates> coordinates =
			// getDistrictCoordinates(objArr[2].toString());
			// district.setDistrictCoordinates(coordinates);

			districtList.add(district);
		}

		return districtList;

	}

	public static DistrictDashboardData convertDistrictEntityToDistrictResponseList(DistrictEntity districtEntity) {

		DistrictDashboardData districtDashboardData = new DistrictDashboardData();

		districtDashboardData.setName(districtEntity.getName());
		districtDashboardData.setId(districtEntity.getId());
		String districtCoords = districtEntity.getcoordinates();
		List<Coordinates> dCoordsList = getDistrictCoordinates(districtCoords);
		districtDashboardData.setCoords(dCoordsList);

		int gatewaySize = districtEntity.getDistrictMappingEnity().size();
		List<Gateway> gatewayList = new ArrayList<Gateway>();

		for (int i = 0; i < gatewaySize; i++) {
			List<Pole> poleList = new ArrayList<Pole>();
			Gateway gateway = new Gateway();
			gateway.setId(districtEntity.getDistrictMappingEnity().get(i).getGateway().getId());
			gateway.setName(districtEntity.getDistrictMappingEnity().get(i).getGateway().getName());
			List<Coordinates> gwCoordsList = new ArrayList<Coordinates>();

			Coordinates gwCoords = new Coordinates();

			gateway.setFunctionalMode(districtEntity.getDistrictMappingEnity().get(i).getGateway().getStatus());
			// districtEntity.getGateways().get(i).getStatus();
			int poleSize = districtEntity.getDistrictMappingEnity().get(i).getGateway().getPoles().size();

			for (int j = 0; j < poleSize; j++) {
				List<Sensor> sensorList = new ArrayList<Sensor>();
				Pole pole = new Pole();
				pole.setId(districtEntity.getDistrictMappingEnity().get(i).getGateway().getPoles().get(j).getId());
				pole.setName(districtEntity.getDistrictMappingEnity().get(i).getGateway().getPoles().get(j).getName());
				pole.setIsGateway(districtEntity.getDistrictMappingEnity().get(i).getGateway().getPoles().get(j).getIsGateway());
				List<Coordinates> coordsList = new ArrayList<Coordinates>();
				Coordinates coords = new Coordinates();
				coords.setLatitude(
						districtEntity.getDistrictMappingEnity().get(i).getGateway().getPoles().get(j).getLat());
				coords.setLongitude(
						districtEntity.getDistrictMappingEnity().get(i).getGateway().getPoles().get(j).getLongi());
				coordsList.add(coords);
				pole.setCoords(coordsList);
				pole.setFunctionalMode(
						districtEntity.getDistrictMappingEnity().get(i).getGateway().getPoles().get(j).getStatus());
				// get sensor list for pole
				int sensorSize = districtEntity.getDistrictMappingEnity().get(i).getGateway().getPoles().get(j)
						.getPoleSensors().size();
				for (int k = 0; k < sensorSize; k++) {
					/*
					 * int
					 * PoleSensorsmapp=districtEntity.getDistrictMappingEnity().
					 * get(i).getGateway().getPoles().get(j).getPoleSensors().
					 * size(); districtEntity.getDistrictMappingEnity().get(i).
					 * getGateway().getPoles().get(j).getPoleSensors().size();
					 */
					Sensor sensor = new Sensor();
					sensor.setId(districtEntity.getDistrictMappingEnity().get(i).getGateway().getPoles().get(j)
							.getPoleSensors().get(k).getSensor().getId());
					sensor.setName(districtEntity.getDistrictMappingEnity().get(i).getGateway().getPoles().get(j)
							.getPoleSensors().get(k).getSensor().getName());
					sensorList.add(sensor);
				}
				pole.setSensors(sensorList);

				if (districtEntity.getDistrictMappingEnity().get(i).getGateway().getPoles().get(j)
						.getIsGateway() == 1) {
					gwCoords.setLatitude(
							districtEntity.getDistrictMappingEnity().get(i).getGateway().getPoles().get(j).getLat());
					gwCoords.setLongitude(
							districtEntity.getDistrictMappingEnity().get(i).getGateway().getPoles().get(j).getLongi());
					gwCoordsList.add(gwCoords);
					gateway.setCoords(gwCoordsList);
				}

				poleList.add(pole);
				gateway.setPoleList(poleList);

			}

			gatewayList.add(gateway);
			districtDashboardData.setGatewayList(gatewayList);
		}

		return districtDashboardData;
	}

	private static List<Coordinates> getDistrictCoordinates(String districtCoords) {
		List<Coordinates> coordsList = new ArrayList<Coordinates>();
		String tokens[] = districtCoords.toString().split("\\#");
		for (String token : tokens) {
			String coordsArray[] = token.split(",");
			Coordinates dCoords = new Coordinates();
			dCoords.setLatitude(coordsArray[0]);
			dCoords.setLongitude(coordsArray[1]);
			coordsList.add(dCoords);
		}
		return coordsList;
	}

	public static DistrictEntity convertDistrictPresetsToDistrictEntity(
			UpdateDistrictPresetRequest updateDistrictPresetRequest, DistrictEntity districtEntity,
			DistrictPresetEntity districtPresetEntity, EventPresetEntity eventPresetEntity) {
		eventPresetEntity.setAudio(updateDistrictPresetRequest.getAudio());
		eventPresetEntity.setBeaconlightcolor(updateDistrictPresetRequest.getBeaconLightColor());
		eventPresetEntity.setBeaconlightpreset(updateDistrictPresetRequest.getBeaconLightStatus());
		eventPresetEntity.setStreetlightintensity(updateDistrictPresetRequest.getIntensity());
		eventPresetEntity.setStreetlightpreset(updateDistrictPresetRequest.getStreetLightStatus());
		eventPresetEntity.setFloodlightpreset(updateDistrictPresetRequest.getFloodLightStatus());
		eventPresetEntity.setTextmessage(updateDistrictPresetRequest.getTextMessage());
		eventPresetEntity.setVolume(Double.valueOf(updateDistrictPresetRequest.getVolume()));
		eventPresetEntity.setThreshold(String.valueOf(updateDistrictPresetRequest.getThreshold()));
		eventPresetEntity.setDefaultEvent(false);
		districtPresetEntity.setEventPreset(eventPresetEntity);
		districtPresetEntity.setDistrict(districtEntity);

		districtEntity.setDistrictPresets(districtPresetEntity);
		return districtEntity;
	}

	public static S2CSendCommandToSensorsRequest convertToS2CSensorRequest(
			UpdateDistrictPresetRequest updateDistrictPresetRequest, List<Sensor> districtSensors) {
		LoggerUtil.logMessage("inside convertToS2CSensorRequest");
		// get all sensors for
		S2CSendCommandToSensorsRequest s2CSendCommandToSensorsRequest = new S2CSendCommandToSensorsRequest();
		s2CSendCommandToSensorsRequest.setLoginName(UserManagerUtil.getLoggedInUserName());
		s2CSendCommandToSensorsRequest.setSensorId(districtSensors.get(0).getId());
		// for data object
		// form S2CPresets
		List<S2CPresets> s2CPresetsList = new ArrayList<S2CPresets>();

		S2CPresets s2cPresets = new S2CPresets();
		s2cPresets.setPrestName("BeaconLightColor");
		s2cPresets.setPresetValue(updateDistrictPresetRequest.getBeaconLightColor());
		s2CPresetsList.add(s2cPresets);

		s2cPresets.setPrestName("BeaconLightStatus");
		s2cPresets.setPresetValue(updateDistrictPresetRequest.getBeaconLightStatus());
		s2CPresetsList.add(s2cPresets);

		s2cPresets.setPrestName("Audio");
		s2cPresets.setPresetValue(updateDistrictPresetRequest.getAudio());
		s2CPresetsList.add(s2cPresets);

		s2cPresets.setPrestName("Volume");
		s2cPresets.setPresetValue(updateDistrictPresetRequest.getVolume());
		s2CPresetsList.add(s2cPresets);

		s2cPresets.setPrestName("FloodLightStatus");
		s2cPresets.setPresetValue(updateDistrictPresetRequest.getFloodLightStatus());
		s2CPresetsList.add(s2cPresets);

		s2cPresets.setPrestName("Intensity");
		s2cPresets.setPresetValue(updateDistrictPresetRequest.getIntensity());
		s2CPresetsList.add(s2cPresets);

		s2cPresets.setPrestName("StreetLightStatus");
		s2cPresets.setPresetValue(updateDistrictPresetRequest.getStreetLightStatus());
		s2CPresetsList.add(s2cPresets);

		s2cPresets.setPrestName("TextMessage");
		s2cPresets.setPresetValue(updateDistrictPresetRequest.getTextMessage());
		s2CPresetsList.add(s2cPresets);

		s2cPresets.setPrestName("Threshold");
		s2cPresets.setPresetValue(updateDistrictPresetRequest.getThreshold());
		s2CPresetsList.add(s2cPresets);

		// form sensorInfo object
		List<SensorInfo> sensorInfoList = new ArrayList<SensorInfo>(districtSensors.size());
		for (Sensor distSensor : districtSensors) {
			// S2CPresets s2cPresets=new S2CPresets();
			SensorInfo sensorInfo = new SensorInfo();
			sensorInfo.setSensorId(distSensor.getId());
			sensorInfo.setS2CPresets(s2CPresetsList);
			sensorInfoList.add(sensorInfo);
		}

		// sensorInfo.setSensorId(sensorId);
		// sensorInfo.setS2CPresets(s2cPresets);

		S2CSendCommandToSensorsRequestData s2CSendCommandToSensorsRequestData = new S2CSendCommandToSensorsRequestData();
		s2CSendCommandToSensorsRequestData.setSensorInfo(sensorInfoList);
		s2CSendCommandToSensorsRequest.setData(s2CSendCommandToSensorsRequestData);
		return s2CSendCommandToSensorsRequest;
	}

}
