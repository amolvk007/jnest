/**
 * 
 */
package com.smartcity.util;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;

import com.smartcity.dbbean.EventPresetEntity;
import com.smartcity.dbbean.PoleEntity;
import com.smartcity.dbbean.PolePresetEntity;
import com.smartcity.dbbean.SensorEntity;
import com.smartcity.jsonbean.AudioSummary;
import com.smartcity.jsonbean.Coordinates;
import com.smartcity.jsonbean.CreatePoleRequest;
import com.smartcity.jsonbean.LightSummary;
import com.smartcity.jsonbean.Pole;
import com.smartcity.jsonbean.PoleList;
import com.smartcity.jsonbean.PoleSummary;
import com.smartcity.jsonbean.Sensor;
import com.smartcity.jsonbean.UpdatePoleDetailsRequest;
import com.smartcity.jsonbean.UpdatePolePresetRequest;
import com.smartcity.jsonbean.s2c.S2CPresets;
import com.smartcity.jsonbean.s2c.S2CSendCommandToSensorsRequest;
import com.smartcity.jsonbean.s2c.S2CSendCommandToSensorsRequestData;
import com.smartcity.jsonbean.s2c.SensorInfo;

/**
 * @author inrpande01
 *
 */
public class PoleManagerUtil {

	private static final Logger LOGGER = Logger.getLogger(PoleManagerUtil.class);

	public static List<Pole> poleList(List<PoleEntity> dbpoleslist) {

		List<Pole> polelist = new ArrayList<Pole>();
		List<Coordinates> coordinateslist = new ArrayList<Coordinates>();
		List<Sensor> sensorlist = new ArrayList<Sensor>();
		LOGGER.info("dbpoleslist::::::" + dbpoleslist.size());

		if (dbpoleslist.size() > 0) {
			for (PoleEntity dbpole : dbpoleslist) {
				Pole pole = new Pole();
				// Set Coordinates and Add to List
				Coordinates coordinates = new Coordinates();
				coordinates.setLatitude(dbpole.getLat());
				coordinates.setLongitude(dbpole.getLongi());
				coordinateslist.add(coordinates);
				pole.setCoords(coordinateslist);

				pole.setName(dbpole.getName());

				// Set Sensor List
				int sensorSize = dbpole.getPoleSensors().size();
				for (int i = 0; i < sensorSize; i++) {
					SensorEntity sensoeEntiry = dbpole.getPoleSensors().get(i).getSensor();
					Sensor sensor = new Sensor();
					sensor.setId(sensoeEntiry.getId());
					sensor.setName(sensoeEntiry.getName());
					sensor.setStatus(sensoeEntiry.getStatus());
					sensor.setThreshold(sensoeEntiry.getThreshold());
					sensorlist.add(sensor);
				}
				/*
				 * for (SensorEntity sensoeEntiry : dbpole.getSensors()) {
				 * 
				 * Sensor sensor = new Sensor();
				 * sensor.setId(sensoeEntiry.getId());
				 * sensor.setName(sensoeEntiry.getName());
				 * sensor.setStatus(sensoeEntiry.getStatus());
				 * sensor.setThreshold(sensoeEntiry.getThreshold());
				 * sensorlist.add(sensor); }
				 */ pole.setSensors(sensorlist);
				polelist.add(pole);
			}
		}
		LOGGER.info("Polelist" + polelist.size());
		return polelist;
	}

	public static Pole poleDetails(PoleEntity dbpoleEntity) {

		List<Coordinates> coordinateslist = new ArrayList<Coordinates>();
		List<Sensor> sensorlist = new ArrayList<Sensor>();
		Pole pole = new Pole();

		LOGGER.info("poleDetails::::::" + dbpoleEntity);
		if (dbpoleEntity != null) {
			// Set Coordinates and Add to List
			Coordinates coordinates = new Coordinates();
			coordinates.setLatitude(dbpoleEntity.getLat());
			coordinates.setLongitude(dbpoleEntity.getLongi());
			coordinateslist.add(coordinates);
			pole.setCoords(coordinateslist);
			pole.setName(dbpoleEntity.getName());

			// Set Sensor List

			int sensorSize = dbpoleEntity.getPoleSensors().size();
			for (int i = 0; i < sensorSize; i++) {
				SensorEntity sensoeEntiry = dbpoleEntity.getPoleSensors().get(i).getSensor();
				Sensor sensor = new Sensor();
				sensor.setId(sensoeEntiry.getId());
				sensor.setName(sensoeEntiry.getName());
				sensor.setStatus(sensoeEntiry.getStatus());
				sensor.setThreshold(sensoeEntiry.getThreshold());
				sensorlist.add(sensor);
			}

			/*
			 * for (SensorEntity sensoeEntiry : dbpoleEntity.getSensors()) {
			 * 
			 * Sensor sensor = new Sensor(); sensor.setId(sensoeEntiry.getId());
			 * sensor.setName(sensoeEntiry.getName());
			 * sensor.setStatus(sensoeEntiry.getStatus());
			 * sensor.setThreshold(sensoeEntiry.getThreshold());
			 * sensorlist.add(sensor); }
			 */
			pole.setSensors(sensorlist);
		}
		LOGGER.info("poleDetails::::::" + pole);
		return pole;
	}

	public static PoleSummary getPoleSummary(PoleEntity poleEntity) {
		PoleSummary poleSummary = new PoleSummary();
		if (poleSummary != null) {
			poleSummary.setPoleId(poleEntity.getId());
			poleSummary.setPoleName(poleEntity.getName());
			// poleSummary.setAlertThresholdLimit("40");// hardcoded
			poleSummary.setPoleLat(poleEntity.getLat());
			poleSummary.setPoleLongi(poleEntity.getLongi());
			poleSummary.setTotalSensors(String.valueOf(poleEntity.getPoleSensors().size()));

			LightSummary lightSummary = new LightSummary();
			AudioSummary audioSummary = new AudioSummary();
			PolePresetEntity polePresetEntity = poleEntity.getPolePresets();
			if (polePresetEntity != null) {
				lightSummary.setBeaconLightColor(polePresetEntity.getEventPreset().getBeaconlightcolor());
				lightSummary.setBeaconLightStatus(polePresetEntity.getEventPreset().getBeaconlightpreset());
				lightSummary.setFloodLight(polePresetEntity.getEventPreset().getFloodlightpreset());
				lightSummary.setIntensity(polePresetEntity.getEventPreset().getStreetlightintensity());
				lightSummary.setStreetLight(polePresetEntity.getEventPreset().getStreetlightpreset());
				audioSummary.setCurrentPlaylistName(polePresetEntity.getEventPreset().getAudio());
				audioSummary.setVolume(String.valueOf(polePresetEntity.getEventPreset().getVolume()));
				poleSummary.setAlertThresholdLimit(polePresetEntity.getEventPreset().getThreshold());
			}

			poleSummary.setLightSummary(lightSummary);
			poleSummary.setAudioSummary(audioSummary);

		}
		LOGGER.info("poleSummary::::::" + poleSummary);
		return poleSummary;
	}

	public static PoleEntity convertPoleRequesttoPoleEntity(CreatePoleRequest poleRequest) {
		LOGGER.info("Inside::::::convertPoleRequesttoPoleEntity");
		Date date = new Date();
		PoleEntity poleEntity = new PoleEntity();
		poleEntity.setName(poleRequest.getName());
		poleEntity.setLat(poleRequest.getLat());
		poleEntity.setLongi(poleRequest.getLongi());
		poleEntity.setStatus("Operational");
		poleEntity.setCreatedBy(UserManagerUtil.getLoggedInUserName());
		poleEntity.setCreatedDate(new Timestamp(date.getTime()));
		poleEntity.setModifiedBy(UserManagerUtil.getLoggedInUserName());
		poleEntity.setModifiedDate(new Timestamp(date.getTime()));
		// poleEntity.setIsGateway(poleRequest.getIsGateway());
		return poleEntity;
	}

	public static PoleEntity convertPoleUpdateRequestToPoleEntity(UpdatePoleDetailsRequest updatePoleDetailsRequest,
			PoleEntity poleEntity) {
		Date date = new Date();
		LOGGER.info("Inside convertPoleUpdateRequestToPoleEntity");
		if (updatePoleDetailsRequest.getName() != null)
			poleEntity.setName(updatePoleDetailsRequest.getName());
		if (updatePoleDetailsRequest.getLat() != null)
			poleEntity.setLat(updatePoleDetailsRequest.getLat());
		if (updatePoleDetailsRequest.getLongi() != null)
			poleEntity.setLongi(updatePoleDetailsRequest.getLongi());
		if (updatePoleDetailsRequest.getStatus() != null)
			poleEntity.setStatus(updatePoleDetailsRequest.getStatus());

		poleEntity.setModifiedBy(UserManagerUtil.getLoggedInUserName());
		poleEntity.setModifiedDate(new Timestamp(date.getTime()));

		return poleEntity;
	}

	public static List<PoleList> convertToPoleList(List<PoleEntity> poleEntities) {
		List<PoleList> poleList = new ArrayList<>(poleEntities.size());
		for (PoleEntity poleEntity : poleEntities) {
			PoleList pole = new PoleList();
			pole.setId(poleEntity.getId());
			pole.setLat(poleEntity.getLat());
			pole.setLongi(poleEntity.getLongi());
			pole.setName(poleEntity.getName());
			// pole.setIsGateway(poleEntity.getIsGateway());
			poleList.add(pole);
		}
		return poleList;
	}

	public static EventPresetEntity convertUpdateSensorPresetRequestToEventPresetEntity(
			EventPresetEntity eventPresetEntity, UpdatePolePresetRequest updatePolePresetRequest) {
		eventPresetEntity.setAudio(updatePolePresetRequest.getAudio());
		eventPresetEntity.setBeaconlightcolor(updatePolePresetRequest.getBeaconLightColor());
		eventPresetEntity.setBeaconlightpreset(updatePolePresetRequest.getBeaconLightStatus());
		eventPresetEntity.setStreetlightintensity(updatePolePresetRequest.getIntensity());
		eventPresetEntity.setStreetlightpreset(updatePolePresetRequest.getStreetLightStatus());
		eventPresetEntity.setFloodlightpreset(updatePolePresetRequest.getFloodLightStatus());
		eventPresetEntity.setTextmessage(updatePolePresetRequest.getTextMessage());
		eventPresetEntity.setVolume(Double.valueOf(updatePolePresetRequest.getVolume()));
		eventPresetEntity.setThreshold(String.valueOf(updatePolePresetRequest.getThreshold()));
		return eventPresetEntity;
	}

	public static EventPresetEntity convertCurrentPresetsToNewPresetEntity(EventPresetEntity dbPoleEventPresetEntity,
			EventPresetEntity eventPresetEntity) {
		dbPoleEventPresetEntity.setAudio(eventPresetEntity.getAudio());
		dbPoleEventPresetEntity.setBeaconlightcolor(eventPresetEntity.getBeaconlightcolor());
		dbPoleEventPresetEntity.setBeaconlightpreset(eventPresetEntity.getBeaconlightpreset());
		dbPoleEventPresetEntity.setStreetlightintensity(eventPresetEntity.getStreetlightintensity());
		dbPoleEventPresetEntity.setStreetlightpreset(eventPresetEntity.getStreetlightpreset());
		dbPoleEventPresetEntity.setFloodlightpreset(eventPresetEntity.getFloodlightpreset());
		dbPoleEventPresetEntity.setTextmessage(eventPresetEntity.getTextmessage());
		dbPoleEventPresetEntity.setVolume(Double.valueOf(eventPresetEntity.getVolume()));
		dbPoleEventPresetEntity.setThreshold(String.valueOf(eventPresetEntity.getThreshold()));
		dbPoleEventPresetEntity.setDefaultEvent(false);
		return dbPoleEventPresetEntity;
	}

	public static S2CSendCommandToSensorsRequest convertToS2CSensorRequest(
			UpdatePolePresetRequest updatePolePresetRequest, List<Sensor> poleSensors) {
		LOGGER.info("inside convertToS2CSensorRequest");
		// get all sensors for
		S2CSendCommandToSensorsRequest s2CSendCommandToSensorsRequest = new S2CSendCommandToSensorsRequest();
		s2CSendCommandToSensorsRequest.setLoginName(UserManagerUtil.getLoggedInUserName());
		s2CSendCommandToSensorsRequest.setSensorId(poleSensors.get(0).getId());
		// for data object
		// form S2CPresets
		List<S2CPresets> s2CPresetsList = new ArrayList<S2CPresets>();

		S2CPresets s2cPresets = new S2CPresets();
		s2cPresets.setPrestName("BeaconLightColor");
		s2cPresets.setPresetValue(updatePolePresetRequest.getBeaconLightColor());
		s2CPresetsList.add(s2cPresets);

		s2cPresets.setPrestName("BeaconLightStatus");
		s2cPresets.setPresetValue(updatePolePresetRequest.getBeaconLightStatus());
		s2CPresetsList.add(s2cPresets);

		s2cPresets.setPrestName("Audio");
		s2cPresets.setPresetValue(updatePolePresetRequest.getAudio());
		s2CPresetsList.add(s2cPresets);

		s2cPresets.setPrestName("Volume");
		s2cPresets.setPresetValue(updatePolePresetRequest.getVolume());
		s2CPresetsList.add(s2cPresets);

		s2cPresets.setPrestName("FloodLightStatus");
		s2cPresets.setPresetValue(updatePolePresetRequest.getFloodLightStatus());
		s2CPresetsList.add(s2cPresets);

		s2cPresets.setPrestName("Intensity");
		s2cPresets.setPresetValue(updatePolePresetRequest.getIntensity());
		s2CPresetsList.add(s2cPresets);

		s2cPresets.setPrestName("StreetLightStatus");
		s2cPresets.setPresetValue(updatePolePresetRequest.getStreetLightStatus());
		s2CPresetsList.add(s2cPresets);

		s2cPresets.setPrestName("TextMessage");
		s2cPresets.setPresetValue(updatePolePresetRequest.getTextMessage());
		s2CPresetsList.add(s2cPresets);

		s2cPresets.setPrestName("Threshold");
		s2cPresets.setPresetValue(updatePolePresetRequest.getThreshold());
		s2CPresetsList.add(s2cPresets);

		// form sensorInfo object
		List<SensorInfo> sensorInfoList = new ArrayList<SensorInfo>(poleSensors.size());
		for (Sensor gwSensor : poleSensors) {
			// S2CPresets s2cPresets=new S2CPresets();
			SensorInfo sensorInfo = new SensorInfo();
			sensorInfo.setSensorId(gwSensor.getId());
			sensorInfo.setS2CPresets(s2CPresetsList);
			sensorInfoList.add(sensorInfo);
		}

		// sensorInfo.setSensorId(sensorId);
		// sensorInfo.setS2CPresets(s2cPresets);

		S2CSendCommandToSensorsRequestData s2CSendCommandToSensorsRequestData = new S2CSendCommandToSensorsRequestData();
		s2CSendCommandToSensorsRequestData.setSensorInfo(sensorInfoList);
		s2CSendCommandToSensorsRequest.setData(s2CSendCommandToSensorsRequestData);
		return s2CSendCommandToSensorsRequest;
	}
}
