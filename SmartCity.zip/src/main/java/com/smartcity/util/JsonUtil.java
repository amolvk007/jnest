/**
 * 
 */
package com.smartcity.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author inrpande01
 *
 */
public class JsonUtil {
	private static final Logger LOGGER = Logger.getLogger(JsonUtil.class);

	@SuppressWarnings("unchecked")
	public static Map<String, String> parseJson(HttpServletRequest httpRequest) {
		Map<String, String> dataCollection = null;
		String line;
		try {
			StringBuilder buffer = new StringBuilder();
			BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(httpRequest.getInputStream()));
			while ((line = bufferedReader.readLine()) != null) {
				buffer.append(line);
			}
			LOGGER.info("JsonUtil::parseJson  Request Json::" + buffer.toString());

			dataCollection = new ObjectMapper().readValue(buffer.toString(),
					new TypeReference<HashMap<String, String>>() {
					});

		} catch (IOException e) {
			throw new com.smartcity.exception.SmartCityDBException("Invalid Json Format");
		}
		return dataCollection;
	}
}
