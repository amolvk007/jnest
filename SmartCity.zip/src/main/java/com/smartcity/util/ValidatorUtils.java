/**
 * 
 */
package com.smartcity.util;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import org.apache.log4j.Logger;

/**
 * @author inrpande01
 *
 *         This Class is capable to validate individual Field and Entity
 */
public class ValidatorUtils {
	private static final Logger LOGGER = Logger.getLogger(ValidatorUtils.class);

static	Map<String, String> fielsMap = new HashMap<String, String>();
	/**
	 * * @author inrpande01
	 * 
	 * @param paramName
	 *            name of the field to be validated
	 * @param param
	 *            value of paramName field
	 * @return boolean
	 */
	public static boolean validateField(String paramName, String param)
			throws com.smartcity.exception.InvalidInputException {
		
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("ValidatorUtils::::: validateField:: paramName" + paramName + " paramValue" + param);
		}
		fielsMap.clear();
		if ((param == null) || (param == "")) {
			fielsMap.put(paramName, "mandatory");
			throw new com.smartcity.exception.InvalidInputException(null, fielsMap);
			//throw new com.smartcity.exception.InvalidInputException(paramName, new String[] { paramName });
		}
		return true;
	}

	
	public static boolean validateFields(Map<String, String> paramNameValuePair)
			throws com.smartcity.exception.InvalidInputException {
		Set<String> keySet = paramNameValuePair.keySet();
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("ValidatorUtils::::: validateField:: parame" + paramNameValuePair);
		}
		fielsMap.clear();
		for(String param:keySet){
			String value = paramNameValuePair.get(param);
			if ((value == null) || (value.trim().length() == 0)) {
				fielsMap.put(param, "mandatory");
			}
		}
		if(fielsMap.size() > 0){
			throw new com.smartcity.exception.InvalidInputException(null, fielsMap);
		}
		return true;
	}
	
	
	/**
	 * * @author inrpande01
	 * 
	 * @param obj
	 *            Entity to be validated
	 * @return boolean
	 */
	public static boolean validateEntity(Object obj) throws com.smartcity.exception.InvalidInputException {
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("ValidatorUtils::::: isValidRequestFormat:: Object::" + obj);
		}


		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<Object>> constraintViolations = validator.validate(obj);

		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("ValidatorUtils::::: validateEntity:: constraintViolations::" + constraintViolations.size());
		}
		fielsMap.clear();
		if (constraintViolations != null && constraintViolations.size() > 0) {
			/*int index = 0;
			String[] object = new String[constraintViolations.size()];*/
			for (Iterator<ConstraintViolation<Object>> iterator = constraintViolations.iterator(); iterator
					.hasNext();) {
				ConstraintViolation<Object> cv = iterator.next();
				LOGGER.info("Property::::::::" + cv.getPropertyPath() + "  Value::" + cv.getMessage());
				fielsMap.put(cv.getPropertyPath() + "", cv.getMessage());
				/*object[index] = cv.getMessage();
				index++;*/
			}
			if (LOGGER.isInfoEnabled()) {
				LOGGER.info("ObjectLength::::::::" + fielsMap.size());
			}
			// throw new com.smartcity.exception.InvalidInputException(null,
			// object);
			throw new com.smartcity.exception.InvalidInputException(null, fielsMap);
		}
		return true;
	}

	/**
	 * * @author inrpande01
	 * @param <T>
	 * 
	 * @param paramName
	 *            name of the field to be validated
	 * @param param
	 *            value of paramName field
	 * @return boolean
	 */
	public static <T> boolean validateList(String paramName, List<T> list)
			throws com.smartcity.exception.InvalidInputException {
		
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("ValidatorUtils::::: validateField:: paramName" + paramName + " paramValue" + list);
		}
		fielsMap.clear();
		if ((list == null) || (list.size()<=0)) {
			fielsMap.put(paramName, "mandatory");
			throw new com.smartcity.exception.InvalidInputException(null, fielsMap);
			//throw new com.smartcity.exception.InvalidInputException(paramName, new String[] { paramName });
		}
		return true;
	}
}
