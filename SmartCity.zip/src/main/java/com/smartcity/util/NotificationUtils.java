/**
 * 
 */
package com.smartcity.util;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.security.core.context.SecurityContextHolder;

import com.smartcity.constant.SmartCityConstant;
import com.smartcity.dbbean.NotificationEntity;
import com.smartcity.jsonbean.EventLogResponse;
import com.smartcity.jsonbean.s2c.GatewayEventLogRequest;
import com.smartcity.jsonbean.s2c.GatewayEventRequest;

/**
 * @author inrpande01
 *
 *         This Class is capable to validate individual Field and Entity
 */
public class NotificationUtils {
	private static final Logger LOGGER = Logger.getLogger(NotificationUtils.class);

	/**
	 * * @author inrpande01
	 * 
	 * @param eventLog
	 *            object of EventLogRequest used to convert NotificationEntity Object
	 * @return NotificationEntity
	 */

	public static NotificationEntity EventLogRequestToNotificationEntity(GatewayEventLogRequest eventLog) {
		LOGGER.info("NotificationUtils:: EventLogToNotificationEntity::EventLog::" + eventLog);
		NotificationEntity notificationEntity = new NotificationEntity();

		try {
			notificationEntity.setGatewayId(eventLog.getGatewayId());
			notificationEntity.setException(eventLog.getException());
			notificationEntity.setExceptionClass(eventLog.getExceptionClass());
			notificationEntity.setExceptionMessage(eventLog.getExceptionMessage());
			notificationEntity.setFile(eventLog.getFile());
			notificationEntity.setLevel(eventLog.getLevel());
			notificationEntity.setLogEventTime(new Timestamp(eventLog.getLogEventTime()));
			notificationEntity.setMessage(eventLog.getMessage());
			notificationEntity.setCreatedDate(new Timestamp(new Date().getTime()));
			//notificationEntity.setCreatedBy((getLoggedInUserName() ));
			//notificationEntity.setModifiedBy(getLoggedInUserName());
			notificationEntity.setModifiedDate(new Timestamp(new Date().getTime()));
			notificationEntity.setNotificationType(SmartCityConstant.EXCEPTION);
		} catch (Exception e) {
			throw new com.smartcity.exception.InvalidInputException("mappingerror", new Object[] { "mappingerror" });
		}
		return notificationEntity;
	}
	
	
	/**
	 * * @author inrpande01
	 * 
	 * @param eventLog
	 *            object of EventLogRequest used to convert NotificationEntity Object
	 * @return NotificationEntity
	 */

	public static NotificationEntity gatewayEventRequestToNotificationEntity(GatewayEventRequest gatewayevent) {
		LOGGER.info("NotificationUtils:: GatewayEvenRequestToNotificationEntity::Gatewayevent::" + gatewayevent);
		NotificationEntity notificationEntity = new NotificationEntity();

		try {
			notificationEntity.setGatewayId(gatewayevent.getGatewayId());
			notificationEntity.setSensorId(gatewayevent.getSensorId());
			notificationEntity.setInformationId(gatewayevent.getInformationId());
			notificationEntity.setLogEventTime(new Timestamp(gatewayevent.getEventTimestamp()));
			notificationEntity.setMessage(gatewayevent.getEventMessage());
			notificationEntity.setCreatedDate(new Timestamp(new Date().getTime()));
			//notificationEntity.setCreatedBy((getLoggedInUserName() ));
			//notificationEntity.setModifiedBy(getLoggedInUserName());
			notificationEntity.setModifiedDate(new Timestamp(new Date().getTime()));
			notificationEntity.setNotificationType(SmartCityConstant.NOTIFICATION);
		} catch (Exception e) {
			throw new com.smartcity.exception.InvalidInputException("mappingerror", new Object[] { "mappingerror" });
		}
		return notificationEntity;
	}
	/**
	 * * @author inrpande01
	 * 
	 * @param notificationEntity
	 *            List of NotificationEntity  used to convert  List of EventLogResponse 
	 * @return List<EventLogResponse>
	 */

	public static List<EventLogResponse> NotificationEntityToEventLogResponseList(List<NotificationEntity>  notificationlist) {
		LOGGER.info("NotificationUtils:: NotificationEntityToEventLog::Notificationlist::" + notificationlist.size());
		 List<EventLogResponse> eventloglist= new ArrayList<EventLogResponse>();
		try {
			for(NotificationEntity notificationEntity:notificationlist){
				EventLogResponse eventLog = new EventLogResponse();
			eventLog.setNotificationId(notificationEntity.getId());
			eventLog.setGatewayId(notificationEntity.getGatewayId());
			eventLog.setException(notificationEntity.getException());
			eventLog.setExceptionClass(notificationEntity.getExceptionClass());
			eventLog.setExceptionMessage(notificationEntity.getExceptionMessage());
			eventLog.setFile(notificationEntity.getFile());
			eventLog.setLevel(notificationEntity.getLevel());
			eventLog.setLogEventTime((notificationEntity.getLogEventTime()+"").trim());
			eventLog.setMessage(notificationEntity.getMessage());
			eventLog.setCreatedBy(notificationEntity.getCreatedBy());
			eventLog.setCreatedDate(notificationEntity.getCreatedDate());
			eventLog.setModifiedBy(notificationEntity.getModifiedBy());
			eventLog.setModifiedDate(notificationEntity.getModifiedDate());
			eventloglist.add(eventLog);
			}
		} catch (Exception e) {
			throw new com.smartcity.exception.InvalidInputException("mappingerror", new Object[] { "mappingerror" });
		}
		return eventloglist;
	}
	
	public static String getLoggedInUserName() {
		return (String) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		// return user.getUserName();
	}
}
