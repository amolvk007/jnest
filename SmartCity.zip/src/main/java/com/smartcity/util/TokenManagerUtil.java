/**
 * 
 */
package com.smartcity.util;

import org.apache.log4j.Logger;

import com.smartcity.dbbean.SCToken;
import com.smartcity.jsonbean.TokenResponse;

/**
 * @author inrpande01
 *
 */
public class TokenManagerUtil {

	private static final Logger LOGGER = Logger.getLogger(TokenManagerUtil.class);

	public static TokenResponse SCTokenToTokenResponse(SCToken sCToken) {
		LOGGER.info("TokenManagerUtil:: RoleToScRoleEntity::role::" + sCToken);
		TokenResponse tokenResponse = new TokenResponse();
		try {
			tokenResponse.setToken(sCToken.getToken());
			tokenResponse.setUsername(sCToken.getUsername());
			tokenResponse.setCreatedDate(sCToken.getCreatedDate());
			return tokenResponse;
		} catch (Exception e) {
			throw new com.smartcity.exception.InvalidInputException("mappingerror", new Object[] { "mappingerror" });
		}
	}
}
