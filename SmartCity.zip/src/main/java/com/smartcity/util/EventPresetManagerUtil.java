package com.smartcity.util;

import javax.persistence.Column;

import org.apache.log4j.Logger;

import com.smartcity.dbbean.EventPresetEntity;
import com.smartcity.jsonbean.UpdateDistrictPresetRequest;
import com.smartcity.jsonbean.UpdateGatewayPresetRequest;
import com.smartcity.jsonbean.UpdatePolePresetRequest;
import com.smartcity.jsonbean.UpdateSensorPresetRequest;

public class EventPresetManagerUtil {
	private static final Logger LOGGER = Logger.getLogger(EventPresetManagerUtil.class);

	public static EventPresetEntity convertUpdatePolePresetRequestToPolePresetEntity(
			UpdatePolePresetRequest updatePolePresetRequest) {
		EventPresetEntity eventPresetEntity=new EventPresetEntity();
		eventPresetEntity.setName("Custom Pole Event");
		eventPresetEntity.setAudio(updatePolePresetRequest.getAudio());
		eventPresetEntity.setBeaconlightcolor(updatePolePresetRequest.getBeaconLightColor());
		eventPresetEntity.setBeaconlightpreset(updatePolePresetRequest.getBeaconLightStatus());
		eventPresetEntity.setStreetlightintensity(updatePolePresetRequest.getIntensity());
		eventPresetEntity.setStreetlightpreset(updatePolePresetRequest.getStreetLightStatus());		
		eventPresetEntity.setFloodlightpreset(updatePolePresetRequest.getFloodLightStatus());
		eventPresetEntity.setTextmessage(updatePolePresetRequest.getTextMessage());
		eventPresetEntity.setVolume(Double.valueOf(updatePolePresetRequest.getVolume()));		
		eventPresetEntity.setThreshold(String.valueOf(updatePolePresetRequest.getThreshold()));
		
		return eventPresetEntity;
	}

	public static EventPresetEntity convertUpdateGatewayPresetRequestToGatewayPresetEntity(
			UpdateGatewayPresetRequest updateGatewayPresetRequest) {
		EventPresetEntity eventPresetEntity=new EventPresetEntity();
		eventPresetEntity.setName("Custom Gateway Event");
		eventPresetEntity.setAudio(updateGatewayPresetRequest.getAudio());
		eventPresetEntity.setBeaconlightcolor(updateGatewayPresetRequest.getBeaconLightColor());
		eventPresetEntity.setBeaconlightpreset(updateGatewayPresetRequest.getBeaconLightStatus());
		eventPresetEntity.setStreetlightintensity(updateGatewayPresetRequest.getIntensity());
		eventPresetEntity.setStreetlightpreset(updateGatewayPresetRequest.getStreetLightStatus());		
		eventPresetEntity.setFloodlightpreset(updateGatewayPresetRequest.getFloodLightStatus());
		eventPresetEntity.setTextmessage(updateGatewayPresetRequest.getTextMessage());
		eventPresetEntity.setVolume(Double.valueOf(updateGatewayPresetRequest.getVolume()));		
		eventPresetEntity.setThreshold(String.valueOf(updateGatewayPresetRequest.getThreshold()));
		
		return eventPresetEntity;
	}

	public static EventPresetEntity convertUpdateDistrictPresetRequestToDistrictPresetEntity(
			UpdateDistrictPresetRequest updateDistrictPresetRequest) {
		EventPresetEntity eventPresetEntity=new EventPresetEntity();
		eventPresetEntity.setName("Custom District Event");
		eventPresetEntity.setAudio(updateDistrictPresetRequest.getAudio());
		eventPresetEntity.setBeaconlightcolor(updateDistrictPresetRequest.getBeaconLightColor());
		eventPresetEntity.setBeaconlightpreset(updateDistrictPresetRequest.getBeaconLightStatus());
		eventPresetEntity.setStreetlightintensity(updateDistrictPresetRequest.getIntensity());
		eventPresetEntity.setStreetlightpreset(updateDistrictPresetRequest.getStreetLightStatus());		
		eventPresetEntity.setFloodlightpreset(updateDistrictPresetRequest.getFloodLightStatus());
		eventPresetEntity.setTextmessage(updateDistrictPresetRequest.getTextMessage());
		eventPresetEntity.setVolume(Double.valueOf(updateDistrictPresetRequest.getVolume()));		
		eventPresetEntity.setThreshold(String.valueOf(updateDistrictPresetRequest.getThreshold()));
		
		return eventPresetEntity;
	}
	public static EventPresetEntity convertDefaultPreset(
			EventPresetEntity defaultEventPreset) {
		EventPresetEntity eventPresetEntity=new EventPresetEntity();
		eventPresetEntity.setAudio(defaultEventPreset.getAudio());
		eventPresetEntity.setBeaconlightcolor(defaultEventPreset.getBeaconlightcolor());
		eventPresetEntity.setBeaconlightpreset(defaultEventPreset.getBeaconlightpreset());
		eventPresetEntity.setStreetlightintensity(defaultEventPreset.getStreetlightintensity());
		eventPresetEntity.setStreetlightpreset(defaultEventPreset.getStreetlightpreset());		
		eventPresetEntity.setFloodlightpreset(defaultEventPreset.getFloodlightpreset());
		eventPresetEntity.setTextmessage(defaultEventPreset.getTextmessage());
		eventPresetEntity.setVolume(Double.valueOf(defaultEventPreset.getVolume()));		
		eventPresetEntity.setThreshold(String.valueOf(defaultEventPreset.getThreshold()));
		eventPresetEntity.setDefaultEvent(false);
		return eventPresetEntity;
	}

	public static EventPresetEntity convertUpdateSensorPresetRequestToPolePresetEntity(
			UpdateSensorPresetRequest updateSensorPresetRequest) {
		EventPresetEntity eventPresetEntity=new EventPresetEntity();
		eventPresetEntity.setName("Custom Sensor Event");
		eventPresetEntity.setAudio(updateSensorPresetRequest.getAudio());
		eventPresetEntity.setBeaconlightcolor(updateSensorPresetRequest.getBeaconLightColor());
		eventPresetEntity.setBeaconlightpreset(updateSensorPresetRequest.getBeaconLightStatus());
		eventPresetEntity.setStreetlightintensity(updateSensorPresetRequest.getIntensity());
		eventPresetEntity.setStreetlightpreset(updateSensorPresetRequest.getStreetLightStatus());		
		eventPresetEntity.setFloodlightpreset(updateSensorPresetRequest.getFloodLightStatus());
		eventPresetEntity.setTextmessage(updateSensorPresetRequest.getTextMessage());
		eventPresetEntity.setVolume(Double.valueOf(updateSensorPresetRequest.getVolume()));		
		eventPresetEntity.setThreshold(String.valueOf(updateSensorPresetRequest.getThreshold()));
		
		return eventPresetEntity;
	}
	
}
