/**
 * 
 */
package com.smartcity.util;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.smartcity.dbbean.EventPresetEntity;
import com.smartcity.dbbean.SensorClassEntity;
import com.smartcity.dbbean.SensorEntity;
import com.smartcity.dbbean.SensorPresetEntity;
import com.smartcity.jsonbean.CreateSensorRequest;
import com.smartcity.jsonbean.Sensor;
import com.smartcity.jsonbean.SensorClassList;
import com.smartcity.jsonbean.SensorList;
import com.smartcity.jsonbean.SensorTypeList;
import com.smartcity.jsonbean.UpdateSensorPresetRequest;
import com.smartcity.jsonbean.s2c.S2CSensorRequest;
import com.smartcity.jsonbean.s2c.S2CSensorType;

/**
 * @author inrpande01
 *
 */
public class SensorManagerUtil {

	private static final Logger LOGGER = Logger
			.getLogger(SensorManagerUtil.class);
	
	public static List<SensorTypeList> getSensorTypeList(List<S2CSensorType> sensorTypeList) {
		LOGGER.info("Inside getSensorTypeList");
		List<SensorTypeList> sensorTypes = new ArrayList<SensorTypeList>(sensorTypeList.size());
		
		for(S2CSensorType s2cSensorType : sensorTypeList) {
			SensorTypeList sensorType = new SensorTypeList();
			sensorType.setSensorTypeId(s2cSensorType.getSensorTypeId());
			sensorType.setSensorTypeName(s2cSensorType.getSensorType());
			sensorTypes.add(sensorType);
		}
		
		return sensorTypes;
	}

	public static S2CSensorRequest convertToS2CSensorRequest(CreateSensorRequest sensorRequest) {
		LOGGER.info("Inside convertToS2CSensorRequest");
		
		S2CSensorRequest s2cSensorRequest = new S2CSensorRequest();
		s2cSensorRequest.setSensorName(sensorRequest.getName());
		s2cSensorRequest.setSensorTypeId(sensorRequest.getSensorTypeId());
		s2cSensorRequest.setSerialNumber(sensorRequest.getSerialNumber());
		s2cSensorRequest.setConninfo(sensorRequest.getConnectioninfo());
		s2cSensorRequest.setConninfo1(sensorRequest.getConnectioninfo1());
		
		s2cSensorRequest.setMissionCritical("1");
		s2cSensorRequest.setFrequency("2");
		//s2cSensorRequest.setMake("smart_city");
		s2cSensorRequest.setMaxvalue("930");
		s2cSensorRequest.setMaxvaluehb("930");
		s2cSensorRequest.setMinvalue("0");
		s2cSensorRequest.setMinvaluehb("0");
		//s2cSensorRequest.setModel("simulator");
		
		return s2cSensorRequest;
	}

	public static SensorEntity convertToSensorEntity(CreateSensorRequest sensorRequest, String sensorId, SensorClassEntity sensorClassEntity) {
		LOGGER.info("Inside convertToSensorEntity");
		SensorEntity sensorEntity = new SensorEntity();
		sensorEntity.setId(sensorId);
		sensorEntity.setName(sensorRequest.getName());
		sensorEntity.setSensorClass(sensorClassEntity);
		return sensorEntity;
	}

	public static List<SensorClassList> getSensorClassList(List<SensorClassEntity> sensorClassLists) {
		LOGGER.info("Inside getSensorClassList");
		List<SensorClassList> sensorTypes = new ArrayList<SensorClassList>(sensorClassLists.size());
		
		for(SensorClassEntity sensorClassEntity : sensorClassLists) {
			SensorClassList sensorClass = new SensorClassList();
			sensorClass.setId(sensorClassEntity.getId());
			sensorClass.setName(sensorClassEntity.getName());
			sensorTypes.add(sensorClass);
		}
		
		return sensorTypes;
	}

	public static List<SensorList> convertToSensorList(List<SensorEntity> sensorEntities) {
		List<SensorList> sensorLists = new ArrayList<SensorList>(sensorEntities.size());
		
		for(SensorEntity sensorEntity : sensorEntities) {
			SensorList sensorList = new SensorList();
			
			if(sensorEntity.getSensorClass()!=null) {
				sensorList.setClassId(sensorEntity.getSensorClass().getId());
				sensorList.setClassName(sensorEntity.getSensorClass().getName());
			}
			sensorList.setId(sensorEntity.getId());
			sensorList.setName(sensorEntity.getName());
			if(sensorEntity.getPoleSensors()!=null && !(sensorEntity.getPoleSensors().isEmpty()))
			{
			if(sensorEntity.getPoleSensors().get(0).getPole()!=null) {
				sensorList.setPoleId(sensorEntity.getPoleSensors().get(0).getPole().getId());
				sensorList.setPoleName(sensorEntity.getPoleSensors().get(0).getPole().getName());
			} else {
				sensorList.setPoleId("");
				sensorList.setPoleName("");
			}
			
			}
			 else {
					sensorList.setPoleId("");
					sensorList.setPoleName("");
			 }
			sensorList.setStatus(sensorEntity.getStatus());
			sensorList.setThreshold(sensorEntity.getThreshold());
			
			sensorLists.add(sensorList);
		}
				
		return sensorLists;
	}
	
	public static Sensor convertSensorEntityToSensor(SensorEntity sensorEntity)
	{
		Sensor sensor=new Sensor();
		sensor.setId(sensorEntity.getId());
		sensor.setName(sensorEntity.getName());
		sensor.setStatus(sensorEntity.getStatus());
		sensor.setThreshold(sensorEntity.getThreshold());
		return sensor;
	}
	
	public static EventPresetEntity convertUpdateSensorPresetRequestToEventPresetEntity(
			EventPresetEntity eventPresetEntity, UpdateSensorPresetRequest updateSensorPresetRequest) {
		eventPresetEntity.setAudio(updateSensorPresetRequest.getAudio());
		eventPresetEntity.setBeaconlightcolor(updateSensorPresetRequest.getBeaconLightColor());
		eventPresetEntity.setBeaconlightpreset(updateSensorPresetRequest.getBeaconLightStatus());
		eventPresetEntity.setStreetlightintensity(updateSensorPresetRequest.getIntensity());
		eventPresetEntity.setStreetlightpreset(updateSensorPresetRequest.getStreetLightStatus());		
		eventPresetEntity.setFloodlightpreset(updateSensorPresetRequest.getFloodLightStatus());
		eventPresetEntity.setTextmessage(updateSensorPresetRequest.getTextMessage());
		eventPresetEntity.setVolume(Double.valueOf(updateSensorPresetRequest.getVolume()));		
		eventPresetEntity.setThreshold(String.valueOf(updateSensorPresetRequest.getThreshold()));
		return eventPresetEntity;
	}

	public static EventPresetEntity convertCurrentPresetsToNewPresetEntity(EventPresetEntity dbeventPresetEntity,
			EventPresetEntity eventPresetEntity) {
		dbeventPresetEntity.setAudio(eventPresetEntity.getAudio());
		dbeventPresetEntity.setBeaconlightcolor(eventPresetEntity.getBeaconlightcolor());
		dbeventPresetEntity.setBeaconlightpreset(eventPresetEntity.getBeaconlightpreset());
		dbeventPresetEntity.setStreetlightintensity(eventPresetEntity.getStreetlightintensity());
		dbeventPresetEntity.setStreetlightpreset(eventPresetEntity.getStreetlightpreset());		
		dbeventPresetEntity.setFloodlightpreset(eventPresetEntity.getFloodlightpreset());
		dbeventPresetEntity.setTextmessage(eventPresetEntity.getTextmessage());
		dbeventPresetEntity.setVolume(Double.valueOf(eventPresetEntity.getVolume()));		
		dbeventPresetEntity.setThreshold(String.valueOf(eventPresetEntity.getThreshold()));
		dbeventPresetEntity.setDefaultEvent(false);
			return dbeventPresetEntity;
	}
}
