package com.smartcity.util;

public final class DBQueryConstants {

	public static final String SQL_GET_DISTRICT_TOTAL_DIGITAL_SIGNAGE = "SELECT count(distinct s.ID) AS SensorCount, "
			+ "s.STATUS AS SensorStatus FROM GATEWAY g "
			+ "INNER JOIN DISTRICT d ON (g.DISTRICTID = d.ID) "
			+ "INNER JOIN POLE p ON (p.GATEWAYID = g.ID) "
			+ "INNER JOIN SENSOR s ON (s.POLEID = p.ID)	"
			+ "WHERE d.ID=:districtId "
			+ "AND s.CLASSID=:sensorClassId group by s.STATUS";
	
	public static final String SQL_GET_DISTRICT_TOTAL_GATEWAYS = "SELECT COUNT(*) "
			+ "AS totalGateways, d.NAME AS districtName, d.ID AS districtId FROM GATEWAY g "
			+ "INNER JOIN DISTRICT d ON (g.DISTRICTID = d.ID)"
			+ " where d.ID=:districtId";
	
	public static final String SQL_GET_DISTRICT_STREET_LIGHTS = "SELECT  p.STATUS as poleStatus,"
			+ " dgMapping.DISTRICTID as districtId, g.ID as GatewayID"
			+ " FROM DISTRICT_GATEWAY dgMapping"
			+ " INNER JOIN GATEWAY g ON (dgMapping.GATEWAYID = g.ID)"
			+ " INNER JOIN GATEWAY_POLE pg ON (pg.GATEWAYID = g.ID)"
			+ " INNER JOIN POLE p ON (pg.POLEID = p.ID)"
			+ " WHERE dgMapping.districtid=:districtId";	
	public static final String SQL_GET_DISTRICT_DETAILS = "SELECT eventPreset.beaconlightpreset AS beaconStatus,"
			+ " eventPreset.beaconlightcolor AS beaconColor,"
			+ " eventPreset.floodlightpreset AS floodLightStatus,"
			+ " eventPreset.streetlightpreset AS streetLightStatus,"
			+ " eventPreset.streetlightintensity AS lightIntensity,"
			+ " eventPreset.audio AS audioName, eventPreset.volume AS volume,"
			+ " eventPreset.textmessage AS warningMessage FROM DISTRICT_PRESET"
			+ " districtPreset INNER JOIN DISTRICT d ON (districtPreset.districtid = d.id )"
			+ " INNER JOIN EVENT_PRESET eventPreset ON ( districtPreset.presetid = eventPreset.id )"
			+ " WHERE d.id = :districtId";	
	
	public static final String SQL_GET_DISTRICT_SENSOR_DETAILS = "SELECT sc.NAME AS sensorType,"
			+ " eventPreset.BEACONLIGHTPRESET as beaconLight,"
			+ " eventPreset.FLOODLIGHTPRESET as floodLight FROM GATEWAY g INNER JOIN DISTRICT d ON (g.DISTRICTID = d.ID)"
			+ " INNER JOIN POLE p ON (p.GATEWAYID = g.ID) "
			+ " INNER JOIN SENSOR s ON (s.POLEID = p.ID)"
			+ " INNER JOIN SENSOR_CLASS sc ON s.CLASSID = sc.ID"
			+ " INNER JOIN SENSOR_PRESET sensorPreset ON (sensorPreset.sensorid = s.ID)"
			+ " INNER JOIN EVENT_PRESET eventPreset ON (sensorPreset.presetid = eventPreset.ID)"
			+ " where d.ID = :districtId and sc.NAME IN(:sensorNameList)";	

	public static final String SQL_GET_GATEWAY_STREET_LIGHTS ="select count(pole.status) as poleCount ,pole.status as poleStatus"
			+" from POLE pole INNER JOIN GATEWAY_POLE  pg ON pole.ID=pg.PoleId where pg.GatewayId= :gatewayId group by pole.status";
	
	public static final String SQL_GET_GATEWAY_BEACON ="SELECT count(pole.status) as poleCount ,pole.status as poleStatus,sensor.ClassId as classId,eventpreset.BEACONLIGHTPRESET  as beaconlightpreset "
			+ " FROM GATEWAY gw "
			+ " INNER JOIN POLE pole ON (pole.GATEWAYID = gw.ID) "
			+ " INNER JOIN SENSOR sensor  ON sensor.POLEID=pole.ID "
			+ " INNER JOIN SENSOR_PRESET sensorpreset  ON sensorpreset.SENSORID=sensor.ID"
			+ " INNER JOIN  EVENT_PRESET eventpreset ON sensorpreset.PRESETID=eventpreset.ID"
			+ " WHERE gw.ID=:gatewayId AND sensor.ClassId=:classId"
			+ " group by pole.status,eventpreset.BEACONLIGHTPRESET";
	
	public static final String SQL_GET_GATEWAY_FLOODLIGHT ="SELECT count(pole.status) as poleCount ,pole.status as poleStatus,sensor.ClassId as classId,eventpreset.FLOODLIGHTPRESET  as floodlightpreset "
			+ " FROM GATEWAY gw "
			+ " INNER JOIN POLE pole ON (pole.GATEWAYID = gw.ID) "
			+ " INNER JOIN SENSOR sensor  ON sensor.POLEID=pole.ID"
			+ " INNER JOIN SENSOR_PRESET sensorpreset  ON sensorpreset.SENSORID=sensor.ID"
			+ " INNER JOIN  EVENT_PRESET eventpreset ON sensorpreset.PRESETID=eventpreset.ID"
			+ " WHERE gw.ID=:gatewayId AND sensor.ClassId=:classId"
			+ " group by pole.status,eventpreset.FLOODLIGHTPRESET";
	
	public static final String SQL_GET_GATEWAY_SENSOR_TYPE_SUMMAY="SELECT count(distinct sensor.ID) as sensorCount ,sensor.status as sensorStatus FROM SENSOR sensor,GATEWAY gw "
			+ " INNER JOIN POLE pole ON pole.GATEWAYID = gw.ID WHERE gw.ID= :gatewayId"
			+ " and sensor.CLASSID=:classId"
			+ " group by sensor.status";
	
	public static final String SQL_GET_ORPHAN_GATEWAY="SELECT g.id as id,g.name as name FROM  GATEWAY g LEFT JOIN DISTRICT_GATEWAY dg ON g.ID = dg.GATEWAYID WHERE dg.ID IS NULL";
	public static final String SQL_GET_USERID_FROM_TOKEM = "select sc_user.ID as userId from SC_USER sc_user, SC_TOKEN sc_token where sc_user.USERNAME=sc_token.USERNAME "
			+ "	and sc_token.TOKEN= :token";
	public static final String SQL_GET_GATEWAY_POLEID = "SELECT gp.POLEID AS poleId FROM GATEWAY g "
			+ "INNER JOIN GATEWAY_POLE gp "
			+ "ON gp.GATEWAYID=g.ID "
			+ "WHERE g.ID =:gatewayId";
}
