/**
 * 
 */
package com.smartcity.util;

import java.nio.charset.StandardCharsets;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.security.core.context.SecurityContextHolder;

import com.smartcity.dbbean.SCUserEntity;
import com.smartcity.dbbean.SCUserRoleEntity;
import com.smartcity.dbbean.ScRoleEntity;
import com.smartcity.jsonbean.User;
import com.smartcity.jsonbean.UserList;
import com.smartcity.jsonbean.UserResponse;

/**
 * @author inrpande01
 *
 */
public class UserManagerUtil {

	private static final Logger LOGGER = Logger.getLogger(UserManagerUtil.class);

	
	public static SCUserEntity UserToScUserEntity(User user) {
		LOGGER.info("UserManagerUtil:: UserToScUserEntity::user::" + user);
		SCUserEntity ScUserEntity = new SCUserEntity();

		try {
			LOGGER.info("UserManagerUtil:: UserToScUserEntity::user:: Role:::" + user.getUserRole());

			ScUserEntity.setUsername(
					(((user.getUserName() != null) ? user.getUserName().toLowerCase() : user.getUserName())));
			ScUserEntity.setFirstname(
					(((user.getFirstName() != null) ? user.getFirstName().toLowerCase() : user.getFirstName())));
			ScUserEntity.setLastname(
					(((user.getLastName() != null) ? user.getLastName().toLowerCase() : user.getLastName())));
			ScUserEntity.setEmail((((user.getEmail() != null) ? user.getEmail().toLowerCase() : user.getEmail())));
			ScUserEntity.setPasswordsend(
					(((user.isPasswordSend() != null) ? user.isPasswordSend().toLowerCase() : user.isPasswordSend())));
			ScUserEntity
					.setPicpath((((user.getPicPath() != null) ? user.getPicPath().toLowerCase() : user.getPicPath())));
			if (user.getPassword() != null) {
				String userpassword = new String(org.apache.commons.codec.binary.Base64
						.encodeBase64(user.getPassword().getBytes(StandardCharsets.UTF_8)));
				ScUserEntity.setPassword(userpassword);
			}
			if (user.getUserId() != null) {
				ScUserEntity.setId(user.getUserId());
			}
				ScUserEntity.setCreatedDate(new Timestamp(new Date().getTime()));
				ScUserEntity.setCreatedBy(getLoggedInUserName());
			
		} catch (Exception e) {
			throw new com.smartcity.exception.InvalidInputException("mappingerror", new Object[] { "mappingerror" });
		}
		return ScUserEntity;
	}

	
	public static SCUserEntity updateUserToScUserEntity(SCUserEntity ScUserEntity,User user) {
		LOGGER.info("UserManagerUtil:: UserToScUserEntity::user::" + user);

		try {
			LOGGER.info("UserManagerUtil:: updateUserToScUserEntity::user:: Role:::" + user.getUserRole());

			ScUserEntity.setUsername(
					(((user.getUserName() != null) ? user.getUserName().toLowerCase() : user.getUserName())));
			ScUserEntity.setFirstname(
					(((user.getFirstName() != null) ? user.getFirstName().toLowerCase() : user.getFirstName())));
			ScUserEntity.setLastname(
					(((user.getLastName() != null) ? user.getLastName().toLowerCase() : user.getLastName())));
			ScUserEntity.setEmail((((user.getEmail() != null) ? user.getEmail().toLowerCase() : user.getEmail())));
			ScUserEntity.setPasswordsend(
					(((user.isPasswordSend() != null) ? user.isPasswordSend().toLowerCase() : user.isPasswordSend())));
			ScUserEntity
					.setPicpath((((user.getPicPath() != null) ? user.getPicPath().toLowerCase() : user.getPicPath())));
			if (user.getPassword() != null) {
				String userpassword = new String(org.apache.commons.codec.binary.Base64
						.encodeBase64(user.getPassword().getBytes(StandardCharsets.UTF_8)));
				ScUserEntity.setPassword(userpassword);
			}
			if (user.getUserId() != null) {
				ScUserEntity.setId(user.getUserId());
			}
				ScUserEntity.setModifiedBy(getLoggedInUserName());
				ScUserEntity.setModifiedDate(new Timestamp(new Date().getTime()));
			
		} catch (Exception e) {
			throw new com.smartcity.exception.InvalidInputException("mappingerror", new Object[] { "mappingerror" });
		}
		return ScUserEntity;
	}
	public static Set<ScRoleEntity> getScRoleEntity(ScRoleEntity userrole) {
		Set<ScRoleEntity> scRoleEntitySet = new HashSet<ScRoleEntity>();
		LOGGER.info("UserManagerUtil:: getScRoleEntity::user:: scRoleEntitySet:::" + scRoleEntitySet);
		scRoleEntitySet.add(userrole);
		return scRoleEntitySet;

	}
	public static List<UserResponse> userList(List<SCUserEntity> dbuserlist) {

		List<UserResponse> userlist = new ArrayList<UserResponse>();
		ScRoleEntity userRoles=null;
		LOGGER.info("userdbList::::::" + dbuserlist.size());
		try {
			if (dbuserlist.size() > 0) {

				for (SCUserEntity dbuser : dbuserlist) {
					UserResponse user = new UserResponse();
					user.setUsername(((dbuser.getUsername() != null) ? dbuser.getUsername().toLowerCase()
							: dbuser.getUsername()));
					user.setFirstName((dbuser.getFirstname() != null) ? dbuser.getFirstname().toLowerCase()
							: dbuser.getFirstname());
					user.setLastName(
							(dbuser.getLastname() != null) ? dbuser.getLastname().toLowerCase() : dbuser.getLastname());
					user.setEmail((dbuser.getEmail() != null) ? dbuser.getEmail().toLowerCase() : dbuser.getEmail());
					user.setUserId(dbuser.getId());
					Set<SCUserRoleEntity> sCUserRoleEntitySet=dbuser.getScUserRole();
					for(SCUserRoleEntity sCUserRoleEntity:sCUserRoleEntitySet){
						userRoles=	sCUserRoleEntity.getScRole();
					}
					if (userRoles != null) {
						LOGGER.info(" User Role:::" + userRoles.getName().replaceAll("ROLE_", ""));
						user.setRole(((userRoles.getName() != null) ? userRoles.getName().replaceAll("ROLE_", "")
								: userRoles.getName()));
					}
					userlist.add(user);
				}
			}
			LOGGER.info("userlist::::::" + userlist.size());
			return userlist;
		} catch (Exception e) {
			throw new com.smartcity.exception.InvalidInputException("mappingerror", new Object[] { "mappingerror" });
		}
	}
	public static UserResponse userDetails(SCUserEntity dbuser) {
		UserResponse user = new UserResponse();
		ScRoleEntity userRoles=null;
		try {
			user.setUsername(
					((dbuser.getUsername() != null) ? dbuser.getUsername().toLowerCase() : dbuser.getUsername()));
			user.setFirstName(
					(dbuser.getFirstname() != null) ? dbuser.getFirstname().toLowerCase() : dbuser.getFirstname());
			user.setLastName(
					(dbuser.getLastname() != null) ? dbuser.getLastname().toLowerCase() : dbuser.getLastname());
			user.setEmail((dbuser.getEmail() != null) ? dbuser.getEmail().toLowerCase() : dbuser.getEmail());
			user.setUserId(dbuser.getId());
			Set<SCUserRoleEntity> sCUserRoleEntitySet=dbuser.getScUserRole();
			for(SCUserRoleEntity sCUserRoleEntity:sCUserRoleEntitySet){
				userRoles=	sCUserRoleEntity.getScRole();
			}
			if (userRoles != null) {
				LOGGER.info(" User Role:::" + userRoles.getName().replaceAll("ROLE_", ""));
				user.setRole(((userRoles.getName() != null) ? userRoles.getName().replaceAll("ROLE_", "")
						: userRoles.getName()));
			}
			return user;
		} catch (Exception e) {
			throw new com.smartcity.exception.InvalidInputException("mappingerror", new Object[] { "mappingerror" });
		}
	}

	public static String getLoggedInUserName() {
		return (String) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		// return user.getUserName();
	}

	
	
	public static List<UserList> onlyUserList(List<SCUserEntity> dbuserlist) {
		List<UserList> userlist = new ArrayList<UserList>();
		LOGGER.info("userdbList::::::" + dbuserlist.size());
		try {
			if (dbuserlist.size() > 0) {

				for (SCUserEntity dbuser : dbuserlist) {
					UserList user = new UserList();
					user.setName((dbuser.getUsername() != null) ? dbuser.getUsername().toLowerCase()
							: dbuser.getUsername());
					user.setId(dbuser.getId());
					userlist.add(user);
				}
			}
			LOGGER.info("userlist::::::" + userlist.size());
			return userlist;
		} catch (Exception e) {
			throw new com.smartcity.exception.InvalidInputException("mappingerror", new Object[] { "mappingerror" });
		}
	}
	
}
