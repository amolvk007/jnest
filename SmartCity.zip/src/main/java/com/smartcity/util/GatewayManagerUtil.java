/**
 * 
 */
package com.smartcity.util;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.smartcity.dbbean.DistrictGatewayMappingEntity;
import com.smartcity.dbbean.EventPresetEntity;
import com.smartcity.dbbean.GatewayEntity;
import com.smartcity.dbbean.GatewayIOTEntity;
import com.smartcity.dbbean.GatewayPresetEntity;
import com.smartcity.dbbean.PoleEntity;
import com.smartcity.jsonbean.AudioSummary;
import com.smartcity.jsonbean.CreateGatewayRequest;
import com.smartcity.jsonbean.DigitalSignage;
import com.smartcity.jsonbean.GatewayList;
import com.smartcity.jsonbean.GatewayPoleAssociationList;
import com.smartcity.jsonbean.GatewaySummary;
import com.smartcity.jsonbean.GatewayType;
import com.smartcity.jsonbean.LightSummary;
import com.smartcity.jsonbean.Sensor;
import com.smartcity.jsonbean.UpdateGatewayPresetRequest;
import com.smartcity.jsonbean.s2c.S2CGatewayRequest;
import com.smartcity.jsonbean.s2c.S2CGatewayType;
import com.smartcity.jsonbean.s2c.S2CPresets;
import com.smartcity.jsonbean.s2c.S2CSendCommandToSensorsRequest;
import com.smartcity.jsonbean.s2c.S2CSendCommandToSensorsRequestData;
import com.smartcity.jsonbean.s2c.SensorInfo;

/**
 * @author inrpande01
 *
 */
public class GatewayManagerUtil {

	private static final Logger LOGGER = Logger
			.getLogger(GatewayManagerUtil.class);
	
	public static GatewaySummary getGatewaySummary(GatewayEntity gatewayEntity){
	
		
		GatewaySummary gatewaySummary= new GatewaySummary();
	if(gatewayEntity != null){
		DistrictGatewayMappingEntity districtGatewayMappingEntity=gatewayEntity.getGatewayMappingEntity();
		if(districtGatewayMappingEntity!=null)
		{
		gatewaySummary.setDistrictId(districtGatewayMappingEntity.getDistrict().getId());
		gatewaySummary.setDistrictName(districtGatewayMappingEntity.getDistrict().getName());
		}		
		else
		{
			gatewaySummary.setDistrictId("");
			gatewaySummary.setDistrictName("");
			
		}
		gatewaySummary.setGatewayId(gatewayEntity.getId());
		gatewaySummary.setGatewayName(gatewayEntity.getName());
		//gatewaySummary.setAlertThresholdLimit("40");//To Do remove hardcoded value
		/*GatewayIOTEntity gatewayIOTEntity=gatewayEntity.getGatewayIOTParameters();
		if(gatewayIOTEntity!=null)
		{
			gatewaySummary.setRam(gatewayIOTEntity.getRam());
			gatewaySummary.setWifi(gatewayIOTEntity.getWifi());
			gatewaySummary.setStorage(gatewayIOTEntity.getStorage());
			gatewaySummary.setBattery(gatewayIOTEntity.getBattery());
			gatewaySummary.setBluetooth(gatewayIOTEntity.getBluetooth());
			gatewaySummary.setSecurity(gatewayIOTEntity.getSecurity());
			gatewaySummary.setIp(gatewayIOTEntity.getIp());
			gatewaySummary.setNetwork(gatewayIOTEntity.getNetwork());
		}		*/
			
		LightSummary lightSummary = new LightSummary();
		AudioSummary audioSummary = new AudioSummary();
		GatewayPresetEntity gatewayPresetEntity=gatewayEntity.getGatewayPresets();
		if(gatewayPresetEntity!=null){
		gatewaySummary.setAlertThresholdLimit(gatewayPresetEntity.getEventPreset().getThreshold());
		lightSummary.setBeaconLightColor(gatewayPresetEntity.getEventPreset().getBeaconlightcolor());
		lightSummary.setBeaconLightStatus(gatewayPresetEntity.getEventPreset().getBeaconlightpreset());
		lightSummary.setFloodLight(gatewayPresetEntity.getEventPreset().getFloodlightpreset());
		lightSummary.setIntensity(gatewayPresetEntity.getEventPreset().getStreetlightintensity());
		lightSummary.setStreetLight(gatewayPresetEntity.getEventPreset().getStreetlightpreset());
		audioSummary.setCurrentPlaylistName(gatewayPresetEntity.getEventPreset().getAudio());
		audioSummary.setVolume(String.valueOf(gatewayPresetEntity.getEventPreset().getVolume()));
		}
		DigitalSignage digitalSignage = new DigitalSignage();
		digitalSignage.setTemperature("30");
		if(gatewayPresetEntity!=null){
		digitalSignage.setWarningMessage(gatewayPresetEntity.getEventPreset().getTextmessage());
		}
		else
		{
			digitalSignage.setWarningMessage("No Preset");
		}
				
		gatewaySummary.setLightSummary(lightSummary);
		gatewaySummary.setAudioSummary(audioSummary);
		gatewaySummary.setDigitalSignage(digitalSignage);
		
		//ends
		
	}	
	LOGGER.info("poleSummary::::::"+gatewaySummary);
	return gatewaySummary;
}

	public static List<GatewayType> getGatewayTypeList(List<S2CGatewayType> gatewayTypeList) {
		List<GatewayType> gatewayTypes = new ArrayList<GatewayType>(gatewayTypeList.size());
		
		for(S2CGatewayType s2cGatewayType : gatewayTypeList) {
			GatewayType gatewayType = new GatewayType();
			gatewayType.setGatewayTypeId(s2cGatewayType.getGatewayTypeId());
			gatewayType.setGatewayTypeName(s2cGatewayType.getMake()+"_"+s2cGatewayType.getModel());
			gatewayTypes.add(gatewayType);
		}
		
		return gatewayTypes;
	}

	public static S2CGatewayRequest convertToS2CGatewayRequest(CreateGatewayRequest gatewayRequest) {
		S2CGatewayRequest s2cGatewayRequest = new S2CGatewayRequest();
		s2cGatewayRequest.setGatewayName(gatewayRequest.getGatewayName());
		s2cGatewayRequest.setGatewayTypeId(gatewayRequest.getGatwayTypeId());
		s2cGatewayRequest.setProtocol(gatewayRequest.getProtocol());
		s2cGatewayRequest.setSerialNumber(gatewayRequest.getSerialNumber());
		return s2cGatewayRequest;
	}

	public static GatewayEntity convertToGatewayEntity(CreateGatewayRequest gatewayRequest, String gatewayId) {
		GatewayEntity gatewayEntity = new GatewayEntity();
		gatewayEntity.setId(gatewayId);
		gatewayEntity.setName(gatewayRequest.getGatewayName());
		gatewayEntity.setStatus("Operational");
		return gatewayEntity;
	}

	public static List<GatewayList> convertToGatewayList(List<GatewayEntity> gatewayEntities) {
		List<GatewayList> gatewayLists = new ArrayList<GatewayList>(gatewayEntities.size());
		
		for(GatewayEntity gatewayEntity : gatewayEntities) {
			GatewayList gatewayList = new GatewayList();
			DistrictGatewayMappingEntity districtGatewayMappingEntity=gatewayEntity.getGatewayMappingEntity();
			if(districtGatewayMappingEntity != null) {
				gatewayList.setDistrictId(districtGatewayMappingEntity.getDistrict().getId());
				gatewayList.setDistrictName(districtGatewayMappingEntity.getDistrict().getName());
			}
			gatewayList.setId(gatewayEntity.getId());
			
			for (PoleEntity pole : gatewayEntity.getPoles()) {
				if(pole.getIsGateway() == 1) {
					gatewayList.setLat(pole.getLat());
					gatewayList.setLongi(pole.getLongi());
					gatewayList.setPoleId(pole.getId());
					break;
				}
			}
			
			gatewayList.setName(gatewayEntity.getName());
			gatewayList.setStatus(gatewayEntity.getStatus());
			
			gatewayLists.add(gatewayList);
		}
		
		return gatewayLists;
	}

	public static List<GatewayPoleAssociationList> convertToGatewayPoleAssociationList(List<PoleEntity> poleEntities) {
		List<GatewayPoleAssociationList> gatewayPoleAssociationLists = new ArrayList<GatewayPoleAssociationList>();
		
		for(PoleEntity poleEntity : poleEntities) {
			if(poleEntity.getGateway()!=null) {
				GatewayPoleAssociationList gatewayPoleAssociationList = new GatewayPoleAssociationList();
				
				boolean alreadyAdded = false;
				for(GatewayPoleAssociationList gatewayPoleAssociation : gatewayPoleAssociationLists) {
					if(gatewayPoleAssociation.getGatewayId() == poleEntity.getGateway().getId()) {
						gatewayPoleAssociationList = gatewayPoleAssociation;
						alreadyAdded = true;
						break;
					}
				}
				
				if (poleEntity.getIsGateway() == 1) {
					gatewayPoleAssociationList.setPhysicalPoleName(poleEntity.getName());
					gatewayPoleAssociationList.setLat(poleEntity.getLat());
					gatewayPoleAssociationList.setLongi(poleEntity.getLongi());
				} 
				
				if(gatewayPoleAssociationList.getPoleName() == null) {
					gatewayPoleAssociationList.setPoleName(new ArrayList<String>());
				}
				gatewayPoleAssociationList.getPoleName().add(poleEntity.getName());
				
				if(!alreadyAdded) {
					gatewayPoleAssociationList.setGatewayId(poleEntity.getGateway().getId());
					gatewayPoleAssociationList.setGatewayName(poleEntity.getGateway().getName());
					if(poleEntity.getGateway().getGatewayMappingEntity()!=null) {
						gatewayPoleAssociationList.setDistrictName(poleEntity.getGateway().getGatewayMappingEntity().getDistrict().getName());
					}
					gatewayPoleAssociationLists.add(gatewayPoleAssociationList);
				}	
			}
		}
		
		return gatewayPoleAssociationLists;
	}

	public static GatewayEntity convertGatewayPresetsToGatewayEntity(
			UpdateGatewayPresetRequest updateGatewayPresetRequest, GatewayEntity gatewayEntity,
			GatewayPresetEntity gatewayPresetEntity, EventPresetEntity eventPresetEntity) {				
			eventPresetEntity.setAudio(updateGatewayPresetRequest.getAudio());
			eventPresetEntity.setBeaconlightcolor(updateGatewayPresetRequest.getBeaconLightColor());
			eventPresetEntity.setBeaconlightpreset(updateGatewayPresetRequest.getBeaconLightStatus());
			eventPresetEntity.setStreetlightintensity(updateGatewayPresetRequest.getIntensity());
			eventPresetEntity.setStreetlightpreset(updateGatewayPresetRequest.getStreetLightStatus());		
			eventPresetEntity.setFloodlightpreset(updateGatewayPresetRequest.getFloodLightStatus());
			eventPresetEntity.setTextmessage(updateGatewayPresetRequest.getTextMessage());
			eventPresetEntity.setVolume(Double.valueOf(updateGatewayPresetRequest.getVolume()));		
			eventPresetEntity.setThreshold(String.valueOf(updateGatewayPresetRequest.getThreshold()));
			eventPresetEntity.setDefaultEvent(false);
			
			gatewayPresetEntity.setEventPreset(eventPresetEntity);
			gatewayEntity.setGatewayPresets(gatewayPresetEntity);
			
			return gatewayEntity;
	}
	public static GatewayEntity convertCurrentPresetsToNewPresetEntity(GatewayEntity gatewayEntity,
			GatewayPresetEntity gatewayPresetEntity,EventPresetEntity gatewayEventPresetEntity, EventPresetEntity eventPresetEntity) {				
		gatewayEventPresetEntity.setAudio(eventPresetEntity.getAudio());
		gatewayEventPresetEntity.setBeaconlightcolor(eventPresetEntity.getBeaconlightcolor());
		gatewayEventPresetEntity.setBeaconlightpreset(eventPresetEntity.getBeaconlightpreset());
		gatewayEventPresetEntity.setStreetlightintensity(eventPresetEntity.getStreetlightintensity());
		gatewayEventPresetEntity.setStreetlightpreset(eventPresetEntity.getStreetlightpreset());		
		gatewayEventPresetEntity.setFloodlightpreset(eventPresetEntity.getFloodlightpreset());
		gatewayEventPresetEntity.setTextmessage(eventPresetEntity.getTextmessage());
		gatewayEventPresetEntity.setVolume(Double.valueOf(eventPresetEntity.getVolume()));		
		gatewayEventPresetEntity.setThreshold(String.valueOf(eventPresetEntity.getThreshold()));
		gatewayEventPresetEntity.setDefaultEvent(false);
			
			gatewayPresetEntity.setEventPreset(gatewayEventPresetEntity);
			gatewayEntity.setGatewayPresets(gatewayPresetEntity);
			
			return gatewayEntity;
	}

	public static S2CSendCommandToSensorsRequest convertToS2CSensorRequest(
			UpdateGatewayPresetRequest updateGatewayPresetRequest, List<Sensor> gatewaySensors) {
		LOGGER.info("inside convertToS2CSensorRequest");
		// get all sensors for
		S2CSendCommandToSensorsRequest s2CSendCommandToSensorsRequest = new S2CSendCommandToSensorsRequest();
		s2CSendCommandToSensorsRequest.setLoginName(UserManagerUtil.getLoggedInUserName());
		s2CSendCommandToSensorsRequest.setSensorId(gatewaySensors.get(0).getId());
		// for data object
		// form S2CPresets
		List<S2CPresets> s2CPresetsList = new ArrayList<S2CPresets>();

		S2CPresets s2cPresets = new S2CPresets();
		s2cPresets.setPrestName("BeaconLightColor");
		s2cPresets.setPresetValue(updateGatewayPresetRequest.getBeaconLightColor());
		s2CPresetsList.add(s2cPresets);

		s2cPresets.setPrestName("BeaconLightStatus");
		s2cPresets.setPresetValue(updateGatewayPresetRequest.getBeaconLightStatus());
		s2CPresetsList.add(s2cPresets);

		s2cPresets.setPrestName("Audio");
		s2cPresets.setPresetValue(updateGatewayPresetRequest.getAudio());
		s2CPresetsList.add(s2cPresets);

		s2cPresets.setPrestName("Volume");
		s2cPresets.setPresetValue(updateGatewayPresetRequest.getVolume());
		s2CPresetsList.add(s2cPresets);

		s2cPresets.setPrestName("FloodLightStatus");
		s2cPresets.setPresetValue(updateGatewayPresetRequest.getFloodLightStatus());
		s2CPresetsList.add(s2cPresets);

		s2cPresets.setPrestName("Intensity");
		s2cPresets.setPresetValue(updateGatewayPresetRequest.getIntensity());
		s2CPresetsList.add(s2cPresets);

		s2cPresets.setPrestName("StreetLightStatus");
		s2cPresets.setPresetValue(updateGatewayPresetRequest.getStreetLightStatus());
		s2CPresetsList.add(s2cPresets);

		s2cPresets.setPrestName("TextMessage");
		s2cPresets.setPresetValue(updateGatewayPresetRequest.getTextMessage());
		s2CPresetsList.add(s2cPresets);

		s2cPresets.setPrestName("Threshold");
		s2cPresets.setPresetValue(updateGatewayPresetRequest.getThreshold());
		s2CPresetsList.add(s2cPresets);

		// form sensorInfo object
		List<SensorInfo> sensorInfoList = new ArrayList<SensorInfo>(gatewaySensors.size());
		for (Sensor gwSensor : gatewaySensors) {
			// S2CPresets s2cPresets=new S2CPresets();
			SensorInfo sensorInfo = new SensorInfo();
			sensorInfo.setSensorId(gwSensor.getId());
			sensorInfo.setS2CPresets(s2CPresetsList);
			sensorInfoList.add(sensorInfo);
		}

		// sensorInfo.setSensorId(sensorId);
		// sensorInfo.setS2CPresets(s2cPresets);

		S2CSendCommandToSensorsRequestData s2CSendCommandToSensorsRequestData = new S2CSendCommandToSensorsRequestData();
		s2CSendCommandToSensorsRequestData.setSensorInfo(sensorInfoList);
		s2CSendCommandToSensorsRequest.setData(s2CSendCommandToSensorsRequestData);
		return s2CSendCommandToSensorsRequest;

	}
}
