package com.smartcity.util;

public class StringUtils {
	public static boolean isNotBlank(Object inputStr) {
		if (inputStr != null && inputStr.toString().trim().length() > 0) {
			return true;
		}
		return false;
	}
}
