/**
 * 
 */
package com.smartcity.util;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.smartcity.dbbean.ScRoleEntity;
import com.smartcity.jsonbean.Role;
import com.smartcity.jsonbean.RoleResponse;

/**
 * @author inrpande01
 *
 */
public class RoleManagerUtil {

	private static final Logger LOGGER = Logger.getLogger(RoleManagerUtil.class);

	public static ScRoleEntity RoleToScRoleEntity(Role role) {
		LOGGER.info("RoleManagerUtil:: RoleToScRoleEntity::role::" + role);
		ScRoleEntity scRoleEntity = new ScRoleEntity();

		try {
			scRoleEntity.setId(role.getId());
			scRoleEntity.setName(role.getRole());
			return scRoleEntity;
		} catch (Exception e) {
			throw new com.smartcity.exception.InvalidInputException("mappingerror", new Object[]{"mappingerror"});
		}
	}

	public static List<RoleResponse> getRoleList(List<ScRoleEntity>  ScRoleEntitylist) {
		List<RoleResponse> Rolelist = new ArrayList<RoleResponse>();
		LOGGER.info("RoleManagerUtil:: getRoleList:::" + ScRoleEntitylist);

		try {
			for (ScRoleEntity ScRoleEntity : ScRoleEntitylist) {
				RoleResponse role = new RoleResponse();
				role.setId(ScRoleEntity.getId());
				role.setRole(ScRoleEntity.getName().replaceAll("ROLE_", "").toLowerCase().trim());
				Rolelist.add(role);
			}

			return Rolelist;
		} catch (Exception e) {
			throw new com.smartcity.exception.InvalidInputException("mappingerror", new Object[]{"mappingerror"});
		}
	}
}
