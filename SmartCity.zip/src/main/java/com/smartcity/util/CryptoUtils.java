package com.smartcity.util;

import java.security.PrivateKey;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import javax.crypto.Cipher;

import org.apache.commons.codec.binary.Base64;
import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;

import com.google.protobuf.InvalidProtocolBufferException;
import com.smartcity.jsonbean.s2c.SensorDataPoint;
import com.smartcity.jsonbean.s2c.SensorRawData;

/**
 * VerizonUtils Class for Marshalling and Unmarshalling the data coming from
 * GatewayEntity to S2C and S2C to GatewayEntity
 */

public class CryptoUtils {

	private static final Logger LOGGER = Logger.getLogger(CryptoUtils.class);
	/**
	 * String to hold name of the encryption algorithm.
	 */
	public static final String ALGORITHM_LINUX = "RSA";
	public static final String ALGORITHM_ANDROID = "RSA/ECB/NoPadding";
	public static final String GATEWAY_OS_NAME = "Linux";

	/**
	 * @Description Method used to convert proto date to util date
	 * @param strDate
	 * @return oDateFormated
	 */
	private static String convertProtoDateToEpoch(String strDate) {
		boolean succeed = false;
		final SimpleDateFormat sdf2 = new SimpleDateFormat(
				"EEE MMM dd HH:mm:ss ZZZ yyyy");
		String oDateFormated = "";
		try {
			LOGGER.info("Sensor Protodate=" + strDate);
			Date date = sdf2.parse(strDate);
			DateTime datetime = new DateTime(date.getTime(),
					DateTimeZone.forID("UTC"));
			oDateFormated = String.valueOf(datetime.getMillis());
			LOGGER.info("Sensor Protodate =" + oDateFormated);
			succeed = true;
		} catch (NumberFormatException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}
		if (!succeed) {
			oDateFormated = strDate;
		}
		return oDateFormated;
	}

	/**
	 * @Description Method used to convert encrypted sensor data list to CDF
	 * @param encryptedDataCollection
	 * @param privateKey
	 * @return gateway
	 */
	public static List<SensorDataPoint> decryptData(List<SensorRawData> encryptedDataCollection,
			final PrivateKey privateKey) {
		final Base64 base64Decoder = new Base64();
		Cipher cipher = null;
		byte[] dectyptedText = null;
		byte[] bytes = null;
		LOGGER.info("Proto string encryptedDataCollection size -- "
				+ encryptedDataCollection.size());
		List<SensorDataPoint> dataUnitCollection = new ArrayList<SensorDataPoint>();
		for (SensorRawData gatewayEntity : encryptedDataCollection) {
			String osName = gatewayEntity.getOsName().trim();
			try {
				if (osName.equalsIgnoreCase(GATEWAY_OS_NAME))
					cipher = Cipher.getInstance(ALGORITHM_LINUX);
				else
					cipher = Cipher.getInstance(ALGORITHM_ANDROID);
				cipher.init(Cipher.DECRYPT_MODE, privateKey);
				bytes = base64Decoder.decode(gatewayEntity.getCdfData());
			} catch (Exception e) {
				LOGGER.error(
						"IllegalBlockSizeException in the convertEncreptedSensorDataListToCDF : ",
						e);
			}
			if (bytes == null || bytes.length == 0) {
				throw new NullPointerException(
						"Either Invalid Proto Buffer or No Data Found");
			}
			
			ProtoEncodeDecode.SensorData sensorData = null;
			try {
				sensorData = ProtoEncodeDecode.SensorData.parseFrom(bytes);
			} catch (InvalidProtocolBufferException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			String strDate = sensorData.getTimestamp();
			String dpValues = "";
			String dpNames = "";
			String dpUnites = "";
			ProtoEncodeDecode.SensorData.DataPointList actualSensorValues = sensorData
					.getDataPointList();
			int verticalCount = actualSensorValues.getDataPointCount();
			for (int vIndex = 0; vIndex < verticalCount; vIndex++) {
				try {
					dpNames = actualSensorValues.getDataPoint(vIndex).getDataPointName();
					dectyptedText = actualSensorValues.getDataPoint(vIndex).getDataPointValue().getBytes("ISO-8859-1");
					dpUnites = actualSensorValues.getDataPoint(vIndex).getUnit().toString();
					dpValues = new String(cipher.doFinal(dectyptedText),"ISO-8859-1");
				} catch (Exception e) {
					e.printStackTrace();
				}
				SensorDataPoint unitData = new SensorDataPoint();
				unitData.setValue(dpValues);
				unitData.setUnits(dpUnites);
				unitData.setName(dpNames);
				unitData.setReceiveTime(convertProtoDateToEpoch(strDate));
				dataUnitCollection.add(unitData);
			}
	 
			/*ProtoEncoderDecoder.SensorData mhealthReceived = null;
			try {
				mhealthReceived = ProtoEncoderDecoder.SensorData.parseFrom(bytes);
			} catch (InvalidProtocolBufferException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			String strDate = mhealthReceived.getTimestamp();
			String dpValues = "";
			String dpNames = "";
			String dpUnites = "";
			ProtoEncoderDecoder.SensorData.DataPointList measurement = mhealthReceived
					.getDataPointList();
			int verticalCount = measurement.getDataPointCount();
			for (int vIndex = 0; vIndex < verticalCount; vIndex++) {
				try {
					dpNames += measurement.getDataPoint(vIndex).getDataPointName();
					dectyptedText = measurement.getDataPoint(vIndex).getDataPointValue().getBytes("ISO-8859-1");
					dpUnites += measurement.getDataPoint(vIndex).getUnit().toString();
					dpValues += new String(cipher.doFinal(dectyptedText),"ISO-8859-1");
				} catch (Exception e) {
					e.printStackTrace();
				}
				SensorDataPoint unitData = new SensorDataPoint();
				unitData.setValue(dpValues);
				unitData.setUnits(dpUnites);
				unitData.setName(dpNames);
				unitData.setReceiveTime(convertProtoDateToEpoch(strDate));
				dataUnitCollection.add(unitData);
			}*/
		}
		LOGGER.info("Response Data " + dataUnitCollection);
		return dataUnitCollection;
	}

	/**
	 * @Description Method used to check whether given collection is empty
	 * @param collection
	 * @return boolean
	 */
	public static boolean isEmpty(Collection<?> collection) {
		return collection == null || collection.isEmpty();
	}

}