//package com.smartcity.schedule;
//
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.scheduling.annotation.EnableScheduling;
//
//@Configuration
//@EnableScheduling
//public class initGetSensorData {
//	
//	@Bean
//	public SensorData getSensorData()
//	{
//		return new SensorData();
//	}
//
//}
