package com.smartcity.schedule;

import org.springframework.stereotype.Component;

@Component("initGetSensorDataQuartz")
public class initGetSensorDataQuartz {
	public void getSensorData(){
	System.out.println("this is quartz jobbean using trigger");
	}
}
