//package com.smartcity.schedule;
//
//import org.springframework.scheduling.annotation.Scheduled;
//
//public class SensorData {
//	
//	@Scheduled(fixedRate=5000)
//	public void printMessage(){
//		System.out.println("this is scheduled task");
//	}
//
//}
