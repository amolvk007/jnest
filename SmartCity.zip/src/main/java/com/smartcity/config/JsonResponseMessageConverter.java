package com.smartcity.config;

import java.io.IOException;

import org.springframework.http.HttpInputMessage;
import org.springframework.http.HttpOutputMessage;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.http.converter.HttpMessageNotWritableException;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.smartcity.constant.SmartCityConstant;
import com.smartcity.jsonbean.ErrorMessage;
import com.smartcity.jsonbean.ResponseData;

public class JsonResponseMessageConverter extends MappingJackson2HttpMessageConverter {

	public JsonResponseMessageConverter() {
		super.getObjectMapper().setSerializationInclusion(Include.NON_EMPTY);
	}

	@Override
	protected Object readInternal(Class<?> clazz, HttpInputMessage inputMessage)
			throws IOException, HttpMessageNotReadableException {
		return super.readInternal(clazz, inputMessage);
	}

	@Override
	protected void writeInternal(Object arg0, HttpOutputMessage arg1)
			throws IOException, HttpMessageNotWritableException {
		ResponseData data = new ResponseData();
		data.setResponse(SmartCityConstant.SUCCESSRESPONSE);
		if(arg0 instanceof ErrorMessage){
			data.setResponse(SmartCityConstant.FAILRESPONSE);
			data.setErrorMessage(arg0);
		} else{
			data.setData(arg0);
		}
		super.writeInternal(data, arg1);
	}

}