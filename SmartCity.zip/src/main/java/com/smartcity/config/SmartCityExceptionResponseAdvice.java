package com.smartcity.config;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.log4j.Logger;
import org.hibernate.exception.ConstraintViolationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.smartcity.exception.ConstraintsViolationException;
import com.smartcity.exception.InvalidInputException;
import com.smartcity.exception.SmartCityDBException;
import com.smartcity.jsonbean.ErrorMessage;
import com.smartcity.jsonbean.ResponseData;

@ControllerAdvice
public class SmartCityExceptionResponseAdvice {

	private static final Logger LOGGER = Logger.getLogger(SmartCityExceptionResponseAdvice.class);

	@Autowired
	private MessageSource messageSource;
	Set<String> messageSet = new HashSet<String>();

	@ResponseStatus(value = HttpStatus.ACCEPTED)
	@ExceptionHandler(value = { DataIntegrityViolationException.class, ConstraintViolationException.class })
	@ResponseBody
	public ErrorMessage handleDBException(Throwable throwable) {
		LOGGER.error(throwable.getMessage(), throwable);
		ErrorMessage errorMessage = new ErrorMessage();
		// errorMessage.setCode(VerticalConstant.ERROR_CODE);
		// errorMessage.setMessage(messageSource.getMessage("DuplicateEntry",
		// null, Locale.ENGLISH));
		messageSet.clear();
		messageSet.add(throwable.getMessage());
		errorMessage.setErrors(messageSet);

		/*ResponseData data = new ResponseData();
		data.setErrorMessage(errorMessage);*/
		return errorMessage;
	}

	@ResponseStatus(value = HttpStatus.ACCEPTED)
	@ExceptionHandler(value = { SmartCityDBException.class, RuntimeException.class, Exception.class })
	@ResponseBody
	public ErrorMessage handleException(Throwable throwable) {
		LOGGER.error(throwable.getMessage(), throwable);
		ErrorMessage errorMessage = new ErrorMessage();
		messageSet.clear();
		messageSet.add(throwable.getMessage());
		errorMessage.setErrors(messageSet);

		/*ResponseData data = new ResponseData();
		data.setErrorMessage(errorMessage);*/
		return errorMessage;
	}

	@ResponseStatus(value = HttpStatus.ACCEPTED)
	@ExceptionHandler(InvalidInputException.class)
	@ResponseBody
	public ErrorMessage handleDBException(InvalidInputException throwable) {
		LOGGER.error(throwable.getMessage(), throwable);
		LOGGER.error("Error::::" + throwable.getObjectArray());
		ErrorMessage errorMessage = new ErrorMessage();

		messageSet.clear();
		if (throwable.getErrorCode() == null) {
			/*
			 * Object[] object = throwable.getObjectArray(); for (int i = 0; i <
			 * throwable.getObjectArray().length; i++) {
			 * 
			 * LOGGER.error("Error Message::::" + object[i]); LOGGER.error(
			 * "Error Message::::" + messageSource.getMessage((String)
			 * object[i], throwable.getObjectArray(), Locale.ENGLISH));
			 * messageSet .add(messageSource.getMessage((String) object[i],
			 * throwable.getObjectArray(), Locale.ENGLISH)); }
			 */
			Iterator<Entry<String, String>> entrysetIrrator = throwable.getMessageMap().entrySet().iterator();
			while (entrysetIrrator.hasNext()) {

				Entry<String, String> entrySet = entrysetIrrator.next();
				String propertyName = entrySet.getKey();
				String messageKey = entrySet.getValue();
				LOGGER.info("Property::::::::" + propertyName + "  Value::" + messageKey);
				String ErrorMessage = propertyName.toUpperCase() + " "
						+ messageSource.getMessage(messageKey, new Object[] { messageKey }, Locale.ENGLISH);
				LOGGER.error("Error Message::::" + ErrorMessage);
				messageSet.add(ErrorMessage);
			}

		} else {
			messageSet.add(
					messageSource.getMessage(throwable.getErrorCode(), throwable.getObjectArray(), Locale.ENGLISH));
		}
		errorMessage.setErrors(messageSet);
		/*ResponseData data = new ResponseData();
		data.setErrorMessage(errorMessage);*/
		return errorMessage;
	}

	@ResponseStatus(value = HttpStatus.ACCEPTED)
	@ExceptionHandler(ConstraintsViolationException.class)
	@ResponseBody
	public ErrorMessage handleDBConstraintException(ConstraintsViolationException constraintsViolationException) {
		LOGGER.error(constraintsViolationException.getMessage(), constraintsViolationException);
		LOGGER.error("Error::::" + constraintsViolationException.getObjectArray());
		ErrorMessage errorMessage = new ErrorMessage();

		messageSet.clear();
		messageSet.add(messageSource.getMessage(constraintsViolationException.getErrorCode(),
				constraintsViolationException.getObjectArray(), Locale.ENGLISH));
		errorMessage.setErrors(messageSet);
		/*ResponseData data = new ResponseData();
		data.setErrorMessage(errorMessage);*/
		return errorMessage;
	}
}