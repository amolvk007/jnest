package com.smartcity.constant;

public interface VideoNext {
	public static final String EVENT_PRIORITY = "VN_PRIORITY";
	public static final String EVENT_LIFESPAN = "VN_LIFESPAN";
	public static final String EVENT_SRC = "VN_SRC";
	public static final String EVENT_EVENTTYPE = "VN_EVENTTYPE";
	public static final String EVENT_TAG = "VN_TAG";
}
