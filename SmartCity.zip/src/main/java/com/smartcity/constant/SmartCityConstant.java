package com.smartcity.constant;

public class SmartCityConstant {

	public static final String SUCCESSRESPONSE = "0";
	public static final String BLANK_RESPONSE = "";
	public static final String ERROR_CODE ="500";
	public static final String SUCCESSCODE = "200";
	public static final String FAILRESPONSE = "1";
	public static final String INVALIDEINPUT = "202";
	public static final String EXCEPTION = "EXCEPTION";
	public static final String NOTIFICATION = "NOTIFICATION";
}
