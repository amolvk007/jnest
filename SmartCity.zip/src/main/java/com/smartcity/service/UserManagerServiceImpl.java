package com.smartcity.service;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.smartcity.common.RequestParameter;
import com.smartcity.dao.DistrictManagerDao;
import com.smartcity.dao.DistrictUserMappingDao;
import com.smartcity.dao.RoleManagerDao;
import com.smartcity.dao.UserManagerDao;
import com.smartcity.dao.UserRoleManagerDao;
import com.smartcity.dbbean.DistrictEntity;
import com.smartcity.dbbean.SCUserEntity;
import com.smartcity.dbbean.SCUserRoleEntity;
import com.smartcity.dbbean.ScRoleEntity;
import com.smartcity.exception.InvalidInputException;
import com.smartcity.jsonbean.DistrictUser;
import com.smartcity.jsonbean.DistrictUserAssociation;
import com.smartcity.jsonbean.DistrictUserDelete;
import com.smartcity.jsonbean.User;
import com.smartcity.jsonbean.UserDistrict;
import com.smartcity.jsonbean.UserId;
import com.smartcity.jsonbean.UserList;
import com.smartcity.jsonbean.UserResponse;
import com.smartcity.util.UserManagerUtil;

@Transactional
@Service
public class UserManagerServiceImpl implements UserManagerService {
	@Autowired
	UserManagerDao userManagerDao;

	@Autowired
	RoleManagerDao roleManagerDao;

	@Autowired
	DistrictManagerDao districtManagerDao;

	@Autowired
	DistrictUserMappingDao districtUserMappingDao;
	
	@Autowired
	UserRoleManagerDao userRoleManagerDao;

	private static final Logger LOGGER = Logger.getLogger(UserManagerServiceImpl.class);
	private List<String> roleId= new ArrayList<String>();
	@Override
	public List<UserResponse> getUsers() {
		List<SCUserEntity> ScUserEntitylist = userManagerDao.loadAll();
		return UserManagerUtil.userList(ScUserEntitylist);
	}

	@Override
	public String getUserDefaultDistrict(String userId) {
		String districtId = userManagerDao.getUserDefaultDistrict(userId);
		if (null == districtId) {
			throw new InvalidInputException("UserIdNotHavingAnyDefaultDistrict", new Object[] { userId });
		}
		return districtId;
	}

	@Override
	public UserResponse getUserByName(String username) {
		// TODO Auto-generated method stub

		SCUserEntity scUserEntity = userManagerDao.findByUserName(username);
		return UserManagerUtil.userDetails(scUserEntity);
	}

	@Override
	public Serializable addUser(User user) {
		SCUserEntity scUserEntity = UserManagerUtil.UserToScUserEntity(user);
		LOGGER.info("scRoleEntity ::::: " + scUserEntity);
		Serializable userid=	userManagerDao.insert(scUserEntity);
			return userid;
	}

	@Override
	public void updateUser(User user,SCUserEntity sCUserEntity) {
		SCUserEntity scUserEntity = UserManagerUtil.updateUserToScUserEntity(sCUserEntity,user);
		if ( user != null) {
			userManagerDao.saveUpdate(scUserEntity);
		}

	}

	@Override
	public void deleteUser(User user) {
		
		SCUserEntity scUserEntity = UserManagerUtil.UserToScUserEntity(user);
		if ( user != null) {
			userManagerDao.delete(scUserEntity);
		}

	}

	@Override
	public boolean isUserNameExist(User user) {
		SCUserEntity dbscUserEntity = userManagerDao.findByUserName(user.getUserName());
		if (null != dbscUserEntity) {
			throw new InvalidInputException("usernameexist", new Object[] { "usernameexist" });
		}
		return true;
	}

	@Override
	public boolean isUserIdExist(String userId) {
		SCUserEntity dbscUserEntity = userManagerDao.getObjectById(userId);
		if (null == dbscUserEntity) {
			throw new InvalidInputException("invalideUserId", new Object[] { "invalideUserId" });
		}
		return true;
	}

	@Override
	public String addUserDistrictAssociation(UserDistrict userDistrict) {

		String users = "";
		List<SCUserEntity> sCUserEntityList = new ArrayList<SCUserEntity>();
		List<DistrictEntity> districtEntityList = new ArrayList<DistrictEntity>();
		for (String Userid : userDistrict.getUserList()) {
			SCUserEntity sCUserEntity = userManagerDao.getObjectById(Userid);
			if (sCUserEntity == null) {
				throw new InvalidInputException("UserIdNotValid", new Object[] { Userid });
			}
			sCUserEntityList.add(sCUserEntity);

		}

		for (String districtId : userDistrict.getDistrictList()) {

			DistrictEntity districtEntity = districtManagerDao.getObjectById(districtId);
			if (districtEntity == null) {
				throw new InvalidInputException("DistrictIdNotValid", new Object[] { districtId });
			}
			districtEntityList.add(districtEntity);
		}
		if (sCUserEntityList.size() > 0 && districtEntityList.size() > 0) {
			users = this.districtUserMappingDao.addDistrictUserAssociation(userDistrict);
		} else {
			throw new InvalidInputException("InvalidInputException", new Object[] { "InvalidInputException" });

		}
		// update user to add add default district commenting below code as func
		// has been removed
		/*
		 * if(userDistrict.getDefaultDistrictId()!=null) {
		 * if(sCUserEntityList.size()>0) { DistrictEntity
		 * district=districtManagerDao.getObjectById(userDistrict.
		 * getDefaultDistrictId()); if(district==null) { throw new
		 * InvalidInputException("InvalidDefaultDistrict", new Object[] {
		 * userDistrict.getDefaultDistrictId() }); } for(SCUserEntity
		 * usr:sCUserEntityList) { usr.setDistrict(district);
		 * userManagerDao.update(usr); } } }
		 */
		return users;
	}

	@Override
	public void deleteDistrictUserAssociation(DistrictUserDelete districtUserDelete) {
		List<SCUserEntity> sCUserEntityList = new ArrayList<SCUserEntity>(districtUserDelete.getUserList().size());
		List<String> DistrictUserIdList = this.getDistrictUserAssociationIds(districtUserDelete.getUserList());
		if (DistrictUserIdList.size() > 0) {
			for (UserId user : districtUserDelete.getUserList()) {
				SCUserEntity sCUserEntity = userManagerDao.getObjectById(user.getUserId());
				if (null == sCUserEntity) {
					throw new InvalidInputException("invalideUserId", new Object[] { "invalideUserId" });
				} else {
					sCUserEntityList.add(sCUserEntity);
				}
			}
			this.districtUserMappingDao.deleteDistrictUserAssociation(districtUserDelete.getUserList());
		} else {
			throw new InvalidInputException("DistrictUserAssociationDoesNotExist",
					new Object[] { districtUserDelete.getUserList() });
		}
	}

	@Override
	public List<String> getDistrictUserAssociationIds(List<UserId> userIdList) {

		List<SCUserEntity> sCUserEntityList = new ArrayList<SCUserEntity>();
		for (UserId Userid : userIdList) {
			SCUserEntity sCUserEntity = userManagerDao.getObjectById(Userid.getUserId());
			if (sCUserEntity == null) {
				throw new InvalidInputException("UserIdNotValid", new Object[] { Userid });
			}
			sCUserEntityList.add(sCUserEntity);

		}

		return this.districtUserMappingDao.getDistrictUserAssociationIds(sCUserEntityList);
	}

	@Override
	public List<DistrictUserAssociation> getdistrictUserAssociationList() {

		LOGGER.info("Inside UserManagerServiceImpl method getdistrictUserAssociationList");
		List<DistrictUserAssociation> districtUserAssociationList = new ArrayList<DistrictUserAssociation>();
		districtUserAssociationList = this.userManagerDao.getdistrictUserAssociationList();

		return districtUserAssociationList;
	}

	@Override
	public List<DistrictUser> getdistrictUserList(String userId) {
		LOGGER.info("Inside UserManagerServiceImpl method getdistrictUserList");
		List<DistrictUser> districtUserList = new ArrayList<DistrictUser>();
		districtUserList = this.userManagerDao.getdistrictUserList(userId);

		return districtUserList;
	}

	@Override
	public List<UserResponse> getUsers(RequestParameter requestParameter,int page,int limit) {
		List<ScRoleEntity> loadAll= roleManagerDao.loadAll();
		roleId.clear();
		for(ScRoleEntity scRoleEntity:loadAll){
		if ((scRoleEntity.getName().equalsIgnoreCase("ROLE_SUPER"))) {
		
			roleId.add(scRoleEntity.getId());
		}
	}
		List<SCUserEntity>  ScUserEntitylist=	userManagerDao.getUsers(requestParameter,page,limit,roleId,true);
		return UserManagerUtil.userList(ScUserEntitylist);
	}

	@Override
	public boolean checkUserAccess(User user) {
		String loggedinuser = (String) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		SCUserEntity scUserEntity = userManagerDao.findByUserName(loggedinuser);
		String dbuserrole = null;
		//ScRoleEntity scRoleEntity	=roleManagerDao.getObjectById(user.getUserRole());
		for (SCUserRoleEntity loggedinUserrole : scUserEntity.getScUserRole()) {
			if (loggedinUserrole.getScRole() != null) {
				dbuserrole = loggedinUserrole.getScRole().getId();
			}
		}
		if ((user.getUserRole().equals("1")) && (dbuserrole.equals("1"))) {
			throw new InvalidInputException("adminaccessDenied", new Object[] { "adminaccessDenied" });
		}
		return true;
	}

	@Override
	public List<UserList> getOnlyUsers(RequestParameter requestParameter, int page, int limit) {
		List<ScRoleEntity> loadAll= roleManagerDao.loadAll();
		roleId.clear();
		for(ScRoleEntity scRoleEntity:loadAll){
		if ((scRoleEntity.getName().equalsIgnoreCase("ROLE_SUPER"))  || (scRoleEntity.getName().equalsIgnoreCase("ROLE_ADMIN"))) {
			roleId.add(scRoleEntity.getId());
		}
	}
		List<SCUserEntity>  ScUserEntitylist=	userManagerDao.getUsers(requestParameter,page,limit,roleId,false);
		return UserManagerUtil.onlyUserList(ScUserEntitylist);
	}

	@Override
	public SCUserEntity findByUserId(String userid) {
		// TODO Auto-generated method stub
		return userManagerDao.getObjectById(userid);
	}
}
