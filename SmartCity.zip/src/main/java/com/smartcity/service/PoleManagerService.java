package com.smartcity.service;

import java.util.List;

import com.smartcity.common.RequestParameter;
import com.smartcity.dbbean.EventPresetEntity;
import com.smartcity.dbbean.PoleEntity;
import com.smartcity.jsonbean.CreatePoleRequest;
import com.smartcity.jsonbean.DeletePoleRequestList;
import com.smartcity.jsonbean.Pole;
import com.smartcity.jsonbean.PoleList;
import com.smartcity.jsonbean.PoleSensor;
import com.smartcity.jsonbean.PoleSensorAssociationList;
import com.smartcity.jsonbean.PoleSummary;
import com.smartcity.jsonbean.UpdatePoleDetailsRequest;
import com.smartcity.jsonbean.UpdatePolePresetRequest;

public interface PoleManagerService {

	public Pole getPoleById(String districtId);

	public PoleSummary getPoleSummary(String poleId);

	public String createPole(CreatePoleRequest poleRequest);

	public void updatePole(UpdatePoleDetailsRequest updatePoleDetailsRequest, String poleId);

	public void deletePole(DeletePoleRequestList deletePoleRequestList);

	public boolean isPoleNameExist(String poleName);

	public boolean isPoleIdExist(String poleId);

	public List<PoleList> getPoleList(RequestParameter requestParameter, int page, int limit);

	public List<PoleList> getPoles();

	public List<Pole> getOrphanPoles();

	public String addPoleSensorAssociation(PoleSensor poleSensor) throws Exception;

	public void deletePoleSensorAssociation(DeletePoleRequestList deletePoleSensorAssociation) throws Exception;

	public List<PoleSensorAssociationList> getPoleSensorAssociationList(RequestParameter requestParameter, int page,
			int limit);

	/*
	 * this method will query event_prest to get event id of the matching values
	 * which user passes from front end if match will not found method will add
	 * a new entry in event_prest and return newly created id and update
	 * pole_preset with this newly created id
	 */
	public void updatePolePresets(UpdatePolePresetRequest updatePolePresetRequest);

	public boolean poleIdsExist(List<String> poleIdList);

	public boolean isPoleNameExist(String poleName, String poleId);
	
	void updateAllPolePresets(List<PoleEntity> PoleSensorList,EventPresetEntity eventPresetEntity );
	
	PoleEntity getPoleEntityById(String poleid);
	public void updatePolePresets(List<PoleEntity> PoleSensorList, EventPresetEntity eventPresetEntity) ;

}
