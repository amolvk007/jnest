package com.smartcity.service;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.security.PrivateKey;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.type.TypeFactory;
import com.smartcity.constant.SmartCityConstant;
import com.smartcity.jsonbean.Sensor;
import com.smartcity.jsonbean.s2c.CreateGatewayResponse;
import com.smartcity.jsonbean.s2c.CreateSensorResponse;
import com.smartcity.jsonbean.s2c.EncreptedDataCollection;
import com.smartcity.jsonbean.s2c.ErrorObject;
import com.smartcity.jsonbean.s2c.GatewayIOTDetails;
import com.smartcity.jsonbean.s2c.GatewayIOTDetailsRequest;
import com.smartcity.jsonbean.s2c.ResponseWrapper;
import com.smartcity.jsonbean.s2c.S2CAssociationResponse;
import com.smartcity.jsonbean.s2c.S2CGatewayRequest;
import com.smartcity.jsonbean.s2c.S2CGatewaySensorAssociationRequest;
import com.smartcity.jsonbean.s2c.S2CGatewayType;
import com.smartcity.jsonbean.s2c.S2CSendCommandToSensorsRequest;
import com.smartcity.jsonbean.s2c.S2CSensorRequest;
import com.smartcity.jsonbean.s2c.S2CSensorType;
import com.smartcity.jsonbean.s2c.SaveTokenRequest;
import com.smartcity.jsonbean.s2c.SensorDataPoint;
import com.smartcity.jsonbean.s2c.SensorRawData;
import com.smartcity.jsonbean.s2c.VerticalBundleRequest;
import com.smartcity.jsonbean.s2c.VerticalBundleResponse;
import com.smartcity.jsonbean.s2c.WanPolicyRequest;
import com.smartcity.util.CryptoUtils;

@Service
public class S2CAccessServiceImpl implements S2CAccessService {
	private Logger logger = Logger.getLogger(S2CAccessServiceImpl.class);

	@Value("${VERTICAL_BASE_URL}")
	private String VERTICAL_BASE_URL;

	@Value("${VERTICAL_USER}")
	private String VERTICAL_USER;

	@Value("${S2C_TOKEN}")
	private String S2C_TOKEN;

	@Value("${S2C_BASE_URL}")
	private String S2C_BASE_URL;

	@Value("${S2C_AUTH_URL}")
	private String S2C_AUTH_URL;

	@Value("${S2C_SENSOR_DATA_URL}")
	private String S2C_SENSOR_DATA_URL;

	@Value("${S2C_TOKEN_HEADER}")
	private String S2C_TOKEN_HEADER;

	@Value("${VERTICAL_TYPE}")
	private String VERTICAL_TYPE;

	@Value("${ENCRYPTION_KEY_PATH}")
	private String ENCRYPTION_KEY_PATH;

	@Value("${S2C_GATEWAY_TYPE_URL}")
	private String S2C_GATEWAY_TYPE_URL;

	@Value("${S2C_CREATE_GATEWAY_URL}")
	private String S2C_CREATE_GATEWAY_URL;

	@Value("${S2C_SENSOR_TYPE_URL}")
	private String S2C_SENSOR_TYPE_URL;

	@Value("${S2C_CREATE_SENSOR_URL}")
	private String S2C_CREATE_SENSOR_URL;

	@Value("${S2C_DELETE_GATEWAY_URL}")
	private String S2C_DELETE_GATEWAY_URL;

	@Value("${S2C_DELETE_SENSOR_URL}")
	private String S2C_DELETE_SENSOR_URL;

	@Value("${S2C_ADD_GATEWAY_SENSOR_URL}")
	private String S2C_ADD_GATEWAY_SENSOR_URL;

	@Value("${S2C_DEL_GATEWAY_SENSOR_URL}")
	private String S2C_DEL_GATEWAY_SENSOR_URL;

	@Value("${S2C_UPDATE_GATEWAY_URL}")
	private String S2C_UPDATE_GATEWAY_URL;

	@Value("${S2C_UPDATE_SENSOR_URL}")
	private String S2C_UPDATE_SENSOR_URL;

	@Value("${S2C_CREATE_GATEWAY_WAN_POLICY_URL}")
	private String S2C_CREATE_GATEWAY_WAN_POLICY_URL;
	
	@Value("${S2C_CREATE_GATEWAY_VERTICAL_BUNDLE}")
	private String S2C_CREATE_GATEWAY_VERTICAL_BUNDLE;
	
	@Value("${S2C_GET_ALL_VERTICAL_BUNDLE}")
	private String S2C_GET_ALL_VERTICAL_BUNDLE;
	
	@Value("${S2C_GATEWAY_VERTICAL_BUNDLE_ASSOCIATION}")
	private String S2C_UPDATE_GATEWAY_VERTICAL_BUNDLE;
	
	@Value("${S2C_SEND_COMMAND_TO_SENSORS_URL}")
	private String S2C_SEND_COMMAND_TO_SENSORS_URL;
	
	@Value("${S2C_GET_GATEWAY_IOT_DETAILS_URL}")
	private String S2C_GET_GATEWAY_IOT_DETAILS_URL;

	@Value("${S2C_SOFT_DEL_GATEWAY_URL}")
	private String S2C_SOFT_DEL_GATEWAY_URL;
	
	private ObjectMapper objectMapper = new ObjectMapper();

	@Override
	public List<SensorDataPoint> getSensorData(String sensorId, int retryCount) {
		logger.info("Inside getSensorData");

		List<SensorDataPoint> dataUnitCollection = new ArrayList<SensorDataPoint>();
		HttpEntity<String> requestEntity = new HttpEntity<String>(addHttpHeaders());
		RestTemplate restTemplate = new RestTemplate();
		String url = S2C_BASE_URL + S2C_SENSOR_DATA_URL;
		logger.info("S2C URL=" + url);
		ResponseEntity<ResponseWrapper> httpResponse = restTemplate.exchange(url, HttpMethod.GET, requestEntity,
				ResponseWrapper.class,VERTICAL_USER,sensorId);
		HttpStatus status = httpResponse.getStatusCode();
		if (status.toString().equals(SmartCityConstant.SUCCESSCODE)) {
			ResponseWrapper response = httpResponse.getBody();
			logger.debug("S2C sensor data response" + response);
			if (response.getResponse().equals(SmartCityConstant.SUCCESSRESPONSE)) {
				Object data = response.getData();
				if (data != null) {
					EncreptedDataCollection dataCollection = objectMapper.convertValue(data,
							EncreptedDataCollection.class);
					PrivateKey privateKey = getCipherPrivateKey();
					if (dataCollection != null && privateKey != null) {
						List<SensorRawData> rawDataList = dataCollection.getEncreptList();
						if(rawDataList != null && rawDataList.size() >0) {
							dataUnitCollection = CryptoUtils.decryptData(rawDataList, privateKey);
						}
					}
				}
			} else if (response.getResponse().equals(SmartCityConstant.FAILRESPONSE)) {
				logger.error("S2C Accesss Error");
				logger.error(response.getErrorMessage());
				checkAuth(response.getErrorMessage());
				if (retryCount > 0) {
					return getSensorData(sensorId, --retryCount);
				}
			}
		}
		return dataUnitCollection;
	}

	@Override
	public List<S2CGatewayType> getGatewayTypeList(int retryCount) throws Exception {
		logger.info("Inside getGatewayTypeList");
		HttpEntity<String> requestEntity = new HttpEntity<String>(addHttpHeaders());
		RestTemplate restTemplate = new RestTemplate();
		String url = S2C_BASE_URL + S2C_GATEWAY_TYPE_URL;
		logger.info("S2C URL=" + url);
		ResponseEntity<ResponseWrapper> httpResponse = restTemplate.exchange(url, HttpMethod.GET, requestEntity,
				ResponseWrapper.class, VERTICAL_TYPE);
		HttpStatus status = httpResponse.getStatusCode();
		List<S2CGatewayType> list = new ArrayList<S2CGatewayType>();
		if (status.toString().equals(SmartCityConstant.SUCCESSCODE)) {
			ResponseWrapper response = httpResponse.getBody();
			logger.debug("S2C gateway type list response" + response);
			if (response.getResponse().equals(SmartCityConstant.SUCCESSRESPONSE)) {
				Object data = response.getData();
				if (data != null) {
					ObjectMapper objectMapper = new ObjectMapper();
					try {
						ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
						String json = ow.writeValueAsString(data);
						list = objectMapper.readValue(json, TypeFactory.defaultInstance()
								.constructCollectionType(List.class, S2CGatewayType.class));
					} catch (JsonParseException e) {
						logger.error("JsonParseException" + e.getMessage());
					} catch (JsonMappingException e) {
						logger.error("JsonMappingException" + e.getMessage());
					} catch (IOException e) {
						logger.error("IOException" + e.getMessage());
					}
				}
			} else if (response.getResponse().equals(SmartCityConstant.FAILRESPONSE)) {
				logger.error(response.getErrorMessage());
				/*boolean error = checkAuth(response.getErrorMessage());
				if (error) {
					logger.error(httpResponse.toString());
					throw new Exception("S2C Error: " + httpResponse.getBody().getErrorMessage().toString());
				}*/
				checkAuth(response.getErrorMessage());
				if (retryCount > 0) {
					return getGatewayTypeList(--retryCount);
				} else {
					logger.error(httpResponse.toString());
					logger.error("3 attempt completed for request.");
					throw new Exception("S2C Error: " + httpResponse.getBody().getErrorMessage().toString());
				}
			}
		} else {
			logger.error(httpResponse.toString());
			throw new Exception("S2C Error: " + httpResponse.getBody().getErrorMessage().toString());
		}
		return list;
	}

	@Override
	public String createGateway(S2CGatewayRequest gatewayRequest, int retryCount) throws Exception {
		logger.info("Inside createGateway");

		String gatewayId = null;

		HttpEntity<S2CGatewayRequest> requestEntity = new HttpEntity<S2CGatewayRequest>(gatewayRequest,
				addHttpHeaders());

		logger.debug("S2CGatewayRequest =" + gatewayRequest);

		RestTemplate restTemplate = new RestTemplate();
		String url = S2C_BASE_URL + S2C_CREATE_GATEWAY_URL;
		logger.info("S2C URL=" + url);
		ResponseEntity<ResponseWrapper> httpResponse = restTemplate.exchange(url, HttpMethod.POST, requestEntity,
				ResponseWrapper.class, VERTICAL_TYPE);
		HttpStatus status = httpResponse.getStatusCode();
		if (status.toString().equals(SmartCityConstant.SUCCESSCODE)) {
			ResponseWrapper response = httpResponse.getBody();
			logger.debug("S2C create gateway response" + response);
			if (response.getResponse().equals(SmartCityConstant.SUCCESSRESPONSE)) {
				Object data = response.getData();
				logger.debug("Data object received -------->" + data.toString());
				if (data != null) {
					ObjectMapper objectMapper = new ObjectMapper();
					CreateGatewayResponse gateway = objectMapper.convertValue(data, CreateGatewayResponse.class);
					gatewayId = gateway.getGatewayId();
				}
			} else if (response.getResponse().equals(SmartCityConstant.FAILRESPONSE)) {
				logger.error(response.getErrorMessage());
				/*boolean error = checkAuth(response.getErrorMessage());
				if (error) {
					logger.error(httpResponse.toString());
					throw new Exception("S2C Error: " + httpResponse.getBody().getErrorMessage().toString());
				}*/
				checkAuth(response.getErrorMessage());
				if (retryCount > 0) {
					return createGateway(gatewayRequest, 0);
				} else {
					logger.error(httpResponse.toString());
					logger.error("3 attempt completed for request.");
					throw new Exception("S2C Error: " + httpResponse.getBody().getErrorMessage().toString());
				}
			}
		} else {
			logger.error(httpResponse.toString());
			throw new Exception("S2C Error: " + httpResponse.getBody().getErrorMessage().toString());
		}
		return gatewayId;
	}
	@Override
	public List<S2CSensorType> getSensorTypeList(int retryCount) throws Exception {
		logger.info("Inside getSensorTypeList");

		HttpEntity<String> requestEntity = new HttpEntity<String>(addHttpHeaders());
		RestTemplate restTemplate = new RestTemplate();
		String url = S2C_BASE_URL + S2C_SENSOR_TYPE_URL;
		logger.info("S2C URL=" + url);
		ResponseEntity<ResponseWrapper> httpResponse = restTemplate.exchange(url, HttpMethod.GET, requestEntity,
				ResponseWrapper.class, VERTICAL_TYPE);
		HttpStatus status = httpResponse.getStatusCode();
		List<S2CSensorType> list = new ArrayList<S2CSensorType>();
		if (status.toString().equals(SmartCityConstant.SUCCESSCODE)) {
			ResponseWrapper response = httpResponse.getBody();
			logger.debug("S2C sensor type list response" + response);
			if (response.getResponse().equals(SmartCityConstant.SUCCESSRESPONSE)) {
				Object data = response.getData();
				if (data != null) {
					ObjectMapper objectMapper = new ObjectMapper();
					try {
						ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
						String json = ow.writeValueAsString(data);
						list = objectMapper.readValue(json,
								TypeFactory.defaultInstance().constructCollectionType(List.class, S2CSensorType.class));
					} catch (JsonParseException e) {
						logger.error("JsonParseException" + e.getMessage());
					} catch (JsonMappingException e) {
						logger.error("JsonMappingException" + e.getMessage());
					} catch (IOException e) {
						logger.error("IOException" + e.getMessage());
					}
				}
			} else if (response.getResponse().equals(SmartCityConstant.FAILRESPONSE)) {
				logger.error(response.getErrorMessage());
				/*boolean error = checkAuth(response.getErrorMessage());
				if (error) {
					logger.error(httpResponse.toString());
					throw new Exception("S2C Error: " + httpResponse.getBody().getErrorMessage().toString());
				}*/
				checkAuth(response.getErrorMessage());
				if (retryCount > 0) {
					return getSensorTypeList(--retryCount);
				} else {
					logger.error(httpResponse.toString());
					logger.error("3 attempt completed for request.");
					throw new Exception("S2C Error: " + httpResponse.getBody().getErrorMessage().toString());
				}
			}
		} else {
			logger.error(httpResponse.toString());
			throw new Exception("S2C Error: " + httpResponse.getBody().getErrorMessage().toString());
		}
		return list;
	}

	@Override
	public String createSensor(S2CSensorRequest s2cSensorRequest, int retryCount) throws Exception {
		logger.info("Inside createSensor");

		String sensorId = null;
		s2cSensorRequest.setVerticalName(VERTICAL_TYPE);
		HttpEntity<S2CSensorRequest> requestEntity = new HttpEntity<S2CSensorRequest>(s2cSensorRequest,
				addHttpHeaders());

		logger.debug("S2CSensorRequest =" + s2cSensorRequest);

		RestTemplate restTemplate = new RestTemplate();
		String url = S2C_BASE_URL + S2C_CREATE_SENSOR_URL;
		logger.info("S2C URL=" + url);
		ResponseEntity<ResponseWrapper> httpResponse = restTemplate.exchange(url, HttpMethod.POST, requestEntity,
				ResponseWrapper.class, VERTICAL_TYPE);
		HttpStatus status = httpResponse.getStatusCode();
		if (status.toString().equals(SmartCityConstant.SUCCESSCODE)) {
			ResponseWrapper response = httpResponse.getBody();
			logger.debug("S2C create sensor response" + response);
			if (response.getResponse().equals(SmartCityConstant.SUCCESSRESPONSE)) {
				Object data = response.getData();
				logger.debug("Data object received -------->" + data.toString());
				if (data != null) {
					ObjectMapper objectMapper = new ObjectMapper();
					CreateSensorResponse sensor = objectMapper.convertValue(data, CreateSensorResponse.class);
					sensorId = sensor.getSensorId();
				}
				sensorId = s2cSensorRequest.getMake() + "_" + s2cSensorRequest.getModel() + "_"
						+ s2cSensorRequest.getSerialNumber();
			} else if (response.getResponse().equals(SmartCityConstant.FAILRESPONSE)) {
				logger.error(response.getErrorMessage());
				/*boolean error = checkAuth(response.getErrorMessage());
				if (error) {
					logger.error(httpResponse.toString());
					throw new Exception("S2C Error: " + httpResponse.getBody().getErrorMessage().toString());
				}*/
				checkAuth(response.getErrorMessage());
				if (retryCount > 0) {
					return createSensor(s2cSensorRequest, --retryCount);
				} else {
					logger.error(httpResponse.toString());
					logger.error("3 attempt completed for request.");
					throw new Exception("S2C Error: " + httpResponse.getBody().getErrorMessage().toString());
				}
			}
		} else {
			logger.error(httpResponse.toString());
			throw new Exception("S2C Error: " + httpResponse.getBody().getErrorMessage().toString());
		}
		return sensorId;
	}

	@Override
	public Boolean deleteGateway(String gatewayId, int retryCount) throws Exception {
		logger.info("Inside deleteGateway");
		Boolean isSuccessful = false;
		HttpEntity<Object> requestEntity = new HttpEntity<Object>(addHttpHeaders());
		RestTemplate restTemplate = new RestTemplate();
		//Commenting delete gateway approach as S2C 2.7 supports soft delete for gateway
		//String url = S2C_BASE_URL + S2C_DELETE_GATEWAY_URL;
		String url = S2C_BASE_URL + S2C_SOFT_DEL_GATEWAY_URL;
		logger.info("S2C URL=" + url);
		/*ResponseEntity<ResponseWrapper> httpResponse = restTemplate.exchange(url, HttpMethod.DELETE, requestEntity,
				ResponseWrapper.class, gatewayId);*/
		ResponseEntity<ResponseWrapper> httpResponse = restTemplate.exchange(url, HttpMethod.GET, requestEntity,
				ResponseWrapper.class, gatewayId);
		HttpStatus status = httpResponse.getStatusCode();
		if (status.toString().equals(SmartCityConstant.SUCCESSCODE)) {
			ResponseWrapper response = httpResponse.getBody();
			logger.debug("S2C delete gateway response" + response);
			// if
			// (response.getResponse().equals(SmartCityConstant.SUCCESSRESPONSE))
			// {
			isSuccessful = true;
			/*
			 * } else if
			 * (response.getResponse().equals(SmartCityConstant.FAILRESPONSE)) {
			 * logger.error("Token expired");
			 * logger.error(response.getErrorMessage());
			 * S2C_SESSION_DETAILS.remove(keyName); signIn(); retryCount++;
			 * if(retryCount<3) { deleteGateway(gatewayId); } }
			 */
			if (response.getResponse().equals(SmartCityConstant.FAILRESPONSE)) {
				logger.error(response.getErrorMessage());
				/*boolean error = checkAuth(response.getErrorMessage());
				if (error) {
					logger.error(httpResponse.toString());
					throw new Exception("S2C Error: " + httpResponse.getBody().getErrorMessage().toString());
				}*/
				checkAuth(response.getErrorMessage());
				if (retryCount > 0) {
					return deleteGateway(gatewayId, --retryCount);
				} else {
					logger.error(httpResponse.toString());
					logger.error("3 attempt completed for request.");
					throw new Exception("S2C Error: " + httpResponse.getBody().getErrorMessage().toString());
				}
			}
		} else {
			logger.error(httpResponse.toString());
			throw new Exception("S2C Error: " + httpResponse.getBody().getErrorMessage().toString());
		}
		return isSuccessful;
	}

	@Override
	public Boolean deleteSensor(String sensorId, int retryCount) throws Exception {
		logger.info("Inside deleteSensor");

		Boolean isSuccessful = false;

		HttpEntity<Object> requestEntity = new HttpEntity<Object>(addHttpHeaders());

		RestTemplate restTemplate = new RestTemplate();
		String url = S2C_BASE_URL + S2C_DELETE_SENSOR_URL;
		logger.info("S2C URL=" + url);
		ResponseEntity<ResponseWrapper> httpResponse = restTemplate.exchange(url, HttpMethod.DELETE, requestEntity,
				ResponseWrapper.class, sensorId);
		HttpStatus status = httpResponse.getStatusCode();
		if (status.toString().equals(SmartCityConstant.SUCCESSCODE)) {
			ResponseWrapper response = httpResponse.getBody();
			logger.debug("S2C delete sensor response" + response);
			if (response.getResponse().equals(SmartCityConstant.SUCCESSRESPONSE)) {
				isSuccessful = true;
			} else if (response.getResponse().equals(SmartCityConstant.FAILRESPONSE)) {
				logger.error(response.getErrorMessage());
				/*boolean error = checkAuth(response.getErrorMessage());
				if (error) {
					logger.error(httpResponse.toString());
					throw new Exception("S2C Error: " + httpResponse.getBody().getErrorMessage().toString());
				}*/
				checkAuth(response.getErrorMessage());
				if (retryCount > 0) {
					return deleteSensor(sensorId, --retryCount);
				} else {
					logger.error(httpResponse.toString());
					logger.error("3 attempt completed for request.");
					throw new Exception("S2C Error: " + httpResponse.getBody().getErrorMessage().toString());
				}
			}
		} else {
			logger.error(httpResponse.toString());
			throw new Exception("S2C Error: " + httpResponse.getBody().getErrorMessage().toString());
		}
		return isSuccessful;
	}

	@Override
	public Boolean associateGatewaySensors(String gatewayId, List<Sensor> sensors, int retryCount) throws Exception {
		logger.info("Inside associateGatewaySensors");

		List<S2CAssociationResponse> associationId = new ArrayList<S2CAssociationResponse>(sensors.size());
		List<S2CGatewaySensorAssociationRequest> s2cGatewaySensorAssociationRequests = new ArrayList<S2CGatewaySensorAssociationRequest>(
				sensors.size());
		for (Sensor sensor : sensors) {
			S2CGatewaySensorAssociationRequest s2cGatewaySensorAssociationRequest = new S2CGatewaySensorAssociationRequest();
			s2cGatewaySensorAssociationRequest.setGatewaymmstype(gatewayId);
			s2cGatewaySensorAssociationRequest.setSensormmtype(sensor.getId());
			s2cGatewaySensorAssociationRequest.setUsername(VERTICAL_USER);

			s2cGatewaySensorAssociationRequests.add(s2cGatewaySensorAssociationRequest);
		}

		Boolean isAdded = true;
		for (S2CGatewaySensorAssociationRequest s2cGatewaySensorAssociationRequest : s2cGatewaySensorAssociationRequests) {

			HttpEntity<S2CGatewaySensorAssociationRequest> requestEntity = new HttpEntity<S2CGatewaySensorAssociationRequest>(
					s2cGatewaySensorAssociationRequest, addHttpHeaders());

			logger.debug("S2CGatewaySensorAssociationRequest =" + requestEntity);

			RestTemplate restTemplate = new RestTemplate();
			String url = S2C_BASE_URL + S2C_ADD_GATEWAY_SENSOR_URL;
			logger.info("S2C URL=" + url);
			ResponseEntity<ResponseWrapper> httpResponse = restTemplate.exchange(url, HttpMethod.POST, requestEntity,
					ResponseWrapper.class, VERTICAL_TYPE);
			HttpStatus status = httpResponse.getStatusCode();
			String isSuccessful = "false";
			if (status.toString().equals(SmartCityConstant.SUCCESSCODE)) {
				ResponseWrapper response = httpResponse.getBody();
				logger.debug("S2C create gateway response" + response);
				if (response.getResponse().equals(SmartCityConstant.SUCCESSRESPONSE)) {
					isSuccessful = response.getData().toString();
				} else if (response.getResponse().equals(SmartCityConstant.FAILRESPONSE)) {
					isAdded = false;
					isSuccessful = "false";
					logger.error(response.getErrorMessage());
					/*boolean error = checkAuth(response.getErrorMessage());
					if (error) {
						logger.error(httpResponse.toString());
						throw new Exception("S2C Error: " + httpResponse.getBody().getErrorMessage().toString());
					}*/
					checkAuth(response.getErrorMessage());
					if (retryCount > 0) {
						return associateGatewaySensors(gatewayId, sensors, --retryCount);
					} else {
						logger.error(httpResponse.toString());
						logger.error("3 attempt completed for request.");
						throw new Exception("S2C Error: " + httpResponse.getBody().getErrorMessage().toString());
					}
				}
			} else {
				isAdded = false;
				logger.error(httpResponse.toString());
				throw new Exception("S2C Error: " + httpResponse.getBody().getErrorMessage().toString());
			}

			S2CAssociationResponse s2cAssociationResponse = new S2CAssociationResponse();
			s2cAssociationResponse.setGatewayId(gatewayId);
			s2cAssociationResponse.setSensorId(s2cGatewaySensorAssociationRequest.getSensormmtype());
			s2cAssociationResponse.setIsSuccessful(Boolean.valueOf(isSuccessful));

			associationId.add(s2cAssociationResponse);
		}
		return isAdded;
	}

	@Override
	public Boolean dessociateGatewaySensors(String gatewayId, List<Sensor> sensors, int retryCount) throws Exception {
		logger.info("Inside dessociateGatewaySensors");

		List<S2CAssociationResponse> associationId = new ArrayList<S2CAssociationResponse>(sensors.size());
		Boolean isDeleted = true;
		for (Sensor sensor : sensors) {

			HttpEntity<Object> requestEntity = new HttpEntity<Object>(addHttpHeaders());

			RestTemplate restTemplate = new RestTemplate();
			String url = S2C_BASE_URL + S2C_DEL_GATEWAY_SENSOR_URL;
			logger.info("S2C URL=" + url);
			ResponseEntity<ResponseWrapper> httpResponse = restTemplate.exchange(url, HttpMethod.DELETE, requestEntity,
					ResponseWrapper.class, VERTICAL_USER,gatewayId + "_" + sensor.getId() + "_" + VERTICAL_USER, gatewayId);
			HttpStatus status = httpResponse.getStatusCode();
			String isSuccessful = "false";
			if (status.toString().equals(SmartCityConstant.SUCCESSCODE)) {
				ResponseWrapper response = httpResponse.getBody();
				logger.debug("S2C create gateway response" + response);
				if (response.getResponse().equals(SmartCityConstant.SUCCESSRESPONSE)) {
					isSuccessful = response.getData().toString();
				} else if (response.getResponse().equals(SmartCityConstant.FAILRESPONSE)) {
					isDeleted = false;
					isSuccessful = "false";
					logger.error(response.getErrorMessage());
					/*boolean error = checkAuth(response.getErrorMessage());
					if (error) {
						logger.error(httpResponse.toString());
						throw new Exception("S2C Error: " + httpResponse.getBody().getErrorMessage().toString());
					}*/
					checkAuth(response.getErrorMessage());
					if (retryCount > 0) {
						return dessociateGatewaySensors(gatewayId, sensors, --retryCount);
					} else {
						logger.error(httpResponse.toString());
						logger.error("3 attempt completed for request.");
						throw new Exception("S2C Error: " + httpResponse.getBody().getErrorMessage().toString());
					}
				}

				S2CAssociationResponse s2cAssociationResponse = new S2CAssociationResponse();
				s2cAssociationResponse.setGatewayId(gatewayId);
				s2cAssociationResponse.setSensorId(sensor.getId());
				s2cAssociationResponse.setIsSuccessful(Boolean.valueOf(isSuccessful));

				associationId.add(s2cAssociationResponse);
			} else {
				isDeleted = false;
				logger.error(httpResponse.toString());
				throw new Exception("S2C Error: " + httpResponse.getBody().getErrorMessage().toString());
			}
		}
		return isDeleted;
	}

	@Override
	public Boolean updateGateway(String gatewayId, S2CGatewayRequest s2cGatewayRequest, int retryCount)
			throws Exception {
		logger.info("Inside updateGateway");

		HttpEntity<S2CGatewayRequest> requestEntity = new HttpEntity<S2CGatewayRequest>(s2cGatewayRequest,
				addHttpHeaders());

		logger.debug("S2CGatewayRequest =" + s2cGatewayRequest);

		RestTemplate restTemplate = new RestTemplate();
		String url = S2C_BASE_URL + S2C_UPDATE_GATEWAY_URL;
		logger.info("S2C URL=" + url);
		ResponseEntity<ResponseWrapper> httpResponse = restTemplate.exchange(url, HttpMethod.POST, requestEntity,
				ResponseWrapper.class, gatewayId);
		HttpStatus status = httpResponse.getStatusCode();
		Boolean isSuccessful = false;
		if (status.toString().equals(SmartCityConstant.SUCCESSCODE)) {
			ResponseWrapper response = httpResponse.getBody();
			logger.debug("S2C create gateway response" + response);
			if (response.getResponse().equals(SmartCityConstant.SUCCESSRESPONSE)) {
				isSuccessful = Boolean.valueOf(response.getData().toString());
			} else if (response.getResponse().equals(SmartCityConstant.FAILRESPONSE)) {
				logger.error(response.getErrorMessage());
				/*boolean error = checkAuth(response.getErrorMessage());
				if (error) {
					logger.error(httpResponse.toString());
					throw new Exception("S2C Error: " + httpResponse.getBody().getErrorMessage().toString());
				}*/
				checkAuth(response.getErrorMessage());
				if (retryCount > 0) {
					return updateGateway(gatewayId, s2cGatewayRequest, --retryCount);
				} else {
					logger.error(httpResponse.toString());
					logger.error("3 attempt completed for request.");
					throw new Exception("S2C Error: " + httpResponse.getBody().getErrorMessage().toString());
				}
			}
		} else {
			logger.error(httpResponse.toString());
			throw new Exception("S2C Error: " + httpResponse.getBody().getErrorMessage().toString());
		}
		return isSuccessful;
	}

	@Override
	public Boolean updateSensor(String sensorId, S2CSensorRequest s2cSensorRequest, int retryCount) throws Exception {
		logger.info("Inside updateSensor");

		HttpEntity<S2CSensorRequest> requestEntity = new HttpEntity<S2CSensorRequest>(s2cSensorRequest,
				addHttpHeaders());

		logger.debug("S2CSensorRequest =" + s2cSensorRequest);

		RestTemplate restTemplate = new RestTemplate();
		String url = S2C_BASE_URL + S2C_UPDATE_SENSOR_URL;
		logger.info("S2C URL=" + url);
		ResponseEntity<ResponseWrapper> httpResponse = restTemplate.exchange(url, HttpMethod.PUT, requestEntity,
				ResponseWrapper.class, sensorId);
		HttpStatus status = httpResponse.getStatusCode();
		Boolean isSuccessful = false;
		if (status.toString().equals(SmartCityConstant.SUCCESSCODE)) {
			ResponseWrapper response = httpResponse.getBody();
			logger.debug("S2C update sensor response" + response);
			if (response.getResponse().equals(SmartCityConstant.SUCCESSRESPONSE)) {
				isSuccessful = Boolean.valueOf(response.getData().toString());
			} else if (response.getResponse().equals(SmartCityConstant.FAILRESPONSE)) {
				logger.error(response.getErrorMessage());
				/*boolean error = checkAuth(response.getErrorMessage());
				if (error) {
					logger.error(httpResponse.toString());
					throw new Exception("S2C Error: " + httpResponse.getBody().getErrorMessage().toString());
				}*/
				checkAuth(response.getErrorMessage());
				if (retryCount > 0) {
					return updateSensor(sensorId, s2cSensorRequest, --retryCount);
				} else {
					logger.error(httpResponse.toString());
					logger.error("3 attempt completed for request.");
					throw new Exception("S2C Error: " + httpResponse.getBody().getErrorMessage().toString());
				}
			}
		} else {
			logger.error(httpResponse.toString());
			throw new Exception("S2C Error: " + httpResponse.getBody().getErrorMessage().toString());
		}
		return isSuccessful;
	}

	private boolean saveToken() {
		logger.info("Inside saveToken");
		String url = S2C_BASE_URL + S2C_AUTH_URL;
		logger.info("S2C URL=" + url);
		SaveTokenRequest saveTokenRequest = new SaveTokenRequest();
		saveTokenRequest.setLoginName(VERTICAL_USER);
		saveTokenRequest.setAuthToken(S2C_TOKEN);
		saveTokenRequest.setVerticalURL(VERTICAL_BASE_URL);

		HttpHeaders requestHeaders = new HttpHeaders();
		requestHeaders.set("Content-Type", "application/json");

		HttpEntity<SaveTokenRequest> requestEntity = new HttpEntity<SaveTokenRequest>(saveTokenRequest, requestHeaders);

		logger.debug("saveTokenRequest=" + saveTokenRequest);

		boolean saveTokenSuccessful = true;

		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<ResponseWrapper> httpResponse = restTemplate.exchange(url, HttpMethod.POST, requestEntity,
				ResponseWrapper.class);
		HttpStatus status = httpResponse.getStatusCode();
		if (status.toString().equals(SmartCityConstant.SUCCESSCODE)) {
			ResponseWrapper response = httpResponse.getBody();
			logger.debug("saveTokenRequest=" + response);
			if (!response.getResponse().equals(SmartCityConstant.SUCCESSRESPONSE)) {
				logger.error(response.getErrorMessage());
				saveTokenSuccessful = false;
			}
		} else {
			logger.error(httpResponse.getBody().getErrorMessage());
			saveTokenSuccessful = false;
		}
		return saveTokenSuccessful;

	}

	private PrivateKey getCipherPrivateKey() {
		PrivateKey privateKey = null;
		try {
			InputStream input = this.getClass().getClassLoader()
					.getResourceAsStream(MessageFormat.format(ENCRYPTION_KEY_PATH, File.separator));
			ObjectInputStream inputStream = new ObjectInputStream(input);
			privateKey = (PrivateKey) inputStream.readObject();
		} catch (IOException | ClassNotFoundException e) {
			logger.error("Cipher Key Deserialisation Error=", e);
		}
		return privateKey;
	}

	private boolean checkAuth(Object errorObj) {
		logger.info("Inside checkAuth");
		boolean authError = false;
		try {
			ErrorObject errorMesage = objectMapper.convertValue(errorObj, ErrorObject.class);
			if (errorMesage.getId().equalsIgnoreCase("UnauthorizedUser")) {
				authError = true;
				saveToken();
			} /*else {
				authError = true;
			}*/
		} catch (Throwable e) {
			logger.error("Error in checkAuth ", e);
		}
		return authError;
	}

	private HttpHeaders addHttpHeaders() {
		HttpHeaders requestHeaders = new HttpHeaders();
		requestHeaders.set("Content-Type", "application/json");
		requestHeaders.set(S2C_TOKEN_HEADER, S2C_TOKEN);
		return requestHeaders;
	}

	@Override
	public String createWanPolicy(WanPolicyRequest wanPolicyRequest) throws Exception {
		logger.info("Inside createWanPolicy");

		HttpEntity<WanPolicyRequest> requestEntity = new HttpEntity<WanPolicyRequest>(wanPolicyRequest,
				addHttpHeaders());

		logger.debug("S2CGatewayRequest =" + wanPolicyRequest);

		RestTemplate restTemplate = new RestTemplate();
		String url = S2C_BASE_URL + S2C_CREATE_GATEWAY_WAN_POLICY_URL;
		logger.info("S2C URL=" + url);
		ResponseEntity<ResponseWrapper> httpResponse = restTemplate.exchange(url, HttpMethod.POST, requestEntity,
				ResponseWrapper.class, VERTICAL_TYPE);
		HttpStatus status = httpResponse.getStatusCode();
		
		if (!(status.toString().equals(SmartCityConstant.SUCCESSCODE))) {
			ResponseWrapper response = httpResponse.getBody();
			logger.debug("saveTokenRequest=" + response);
			if (!(response.getResponse().equals(SmartCityConstant.SUCCESSRESPONSE))) {
				logger.error(response.getErrorMessage());
				throw new Exception("S2C Error: Error While Creating Wan Policy for Gateway::"+wanPolicyRequest+"::" + httpResponse.getBody().getErrorMessage().toString());
			}
		}
		return (status != null ? status.toString() : "200");
	}
	
	@Override
	public String createVreticalBundle(VerticalBundleRequest verticalBundleRequest) throws Exception {
		logger.info("Inside createWanPolicy");

		HttpEntity<VerticalBundleRequest> requestEntity = new HttpEntity<VerticalBundleRequest>(verticalBundleRequest,
				addHttpHeaders());

		logger.debug("S2CGatewayRequest =" + verticalBundleRequest);

		RestTemplate restTemplate = new RestTemplate();
		String url = S2C_BASE_URL + S2C_CREATE_GATEWAY_VERTICAL_BUNDLE;
		logger.info("S2C URL=" + url);
		ResponseEntity<ResponseWrapper> httpResponse = restTemplate.exchange(url, HttpMethod.POST, requestEntity,
				ResponseWrapper.class, VERTICAL_TYPE);
		HttpStatus status = httpResponse.getStatusCode();
		
		if (!(status.toString().equals(SmartCityConstant.SUCCESSCODE))) {
			ResponseWrapper response = httpResponse.getBody();
			logger.debug("saveTokenRequest=" + response);
			if (!(response.getResponse().equals(SmartCityConstant.SUCCESSRESPONSE))) {
				logger.error(response.getErrorMessage());
				throw new Exception("S2C Error: Error While Creating Vertical Bundle for Gateway::"+verticalBundleRequest+"::" + httpResponse.getBody().getErrorMessage().toString());
			}
		}
		return (status != null ? status.toString() : "200");
	}
	
	

	@Override
	public List<VerticalBundleResponse> getSmartCityVerticalBundles() throws Exception {
		logger.info("Inside getGatewayTypeList");
		HttpEntity<String> requestEntity = new HttpEntity<String>(addHttpHeaders());
		RestTemplate restTemplate = new RestTemplate();
		String url = S2C_BASE_URL + S2C_GET_ALL_VERTICAL_BUNDLE;
		logger.info("S2C URL=" + url);
		ResponseEntity<ResponseWrapper> httpResponse = restTemplate.exchange(url, HttpMethod.GET, requestEntity,
				ResponseWrapper.class, VERTICAL_TYPE);
		HttpStatus status = httpResponse.getStatusCode();
		List<VerticalBundleResponse> list = new ArrayList<VerticalBundleResponse>();
		if (status.toString().equals(SmartCityConstant.SUCCESSCODE)) {
			ResponseWrapper response = httpResponse.getBody();
			logger.debug("S2C gateway type list response" + response);
			if (response.getResponse().equals(SmartCityConstant.SUCCESSRESPONSE)) {
				Object data = response.getData();
				if (data != null) {
					ObjectMapper objectMapper = new ObjectMapper();
					try {
						ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
						String json = ow.writeValueAsString(data);
						list = objectMapper.readValue(json, TypeFactory.defaultInstance()
								.constructCollectionType(List.class, VerticalBundleResponse.class));
					} catch (JsonParseException e) {
						logger.error("JsonParseException" + e.getMessage());
					} catch (JsonMappingException e) {
						logger.error("JsonMappingException" + e.getMessage());
					} catch (IOException e) {
						logger.error("IOException" + e.getMessage());
					}
				}
			} else if (response.getResponse().equals(SmartCityConstant.FAILRESPONSE)) {
				logger.error(response.getErrorMessage());
				/*boolean error = checkAuth(response.getErrorMessage());
				if (error) {
					logger.error(httpResponse.toString());
					throw new Exception("S2C Error: " + httpResponse.getBody().getErrorMessage().toString());
				}*/
				checkAuth(response.getErrorMessage());
				throw new Exception("S2C Error: " + httpResponse.getBody().getErrorMessage().toString());	
			}
		} else {
			logger.error(httpResponse.toString());
			throw new Exception("S2C Error: " + httpResponse.getBody().getErrorMessage().toString());
		}
		return list;
	}

	@Override
	public String assocaiteVerticalBundleGateway(String verticalBundleId, List<String> gatewayList) throws Exception {
		logger.info("Inside createWanPolicy");

		HttpEntity<List<String>> requestEntity = new HttpEntity<List<String>>(gatewayList,addHttpHeaders());

		logger.debug("S2CGatewayRequest =" + gatewayList);

		RestTemplate restTemplate = new RestTemplate();
		String url = S2C_BASE_URL + S2C_UPDATE_GATEWAY_VERTICAL_BUNDLE;
		logger.info("S2C URL=" + url);
		ResponseEntity<ResponseWrapper> httpResponse = restTemplate.exchange(url, HttpMethod.POST, requestEntity,
				ResponseWrapper.class, verticalBundleId);
		HttpStatus status = httpResponse.getStatusCode();
		
		if (!(status.toString().equals(SmartCityConstant.SUCCESSCODE))) {
			ResponseWrapper response = httpResponse.getBody();
			logger.debug("saveTokenRequest=" + response);
			if (!(response.getResponse().equals(SmartCityConstant.SUCCESSRESPONSE))) {
				logger.error(response.getErrorMessage());
				throw new Exception("S2C Error: Error While Updating Vertical Bundle for Gateway::"+gatewayList+"::" + httpResponse.getBody().getErrorMessage().toString());
			}
		}
		return (status != null ? status.toString() : "200");
	}

	@Override
	public String sendCommandToSensors(S2CSendCommandToSensorsRequest s2cSendCommandToSensorsRequest) {
		logger.info("Inside :: sendCommandToSensors");
		String response = null;
		
		HttpEntity<S2CSendCommandToSensorsRequest> requestEntity = new HttpEntity<S2CSendCommandToSensorsRequest>(s2cSendCommandToSensorsRequest,
				addHttpHeaders());
		logger.debug("s2cSendCommandToSensorsRequest =" + s2cSendCommandToSensorsRequest);
		RestTemplate restTemplate = new RestTemplate();
		String url = S2C_BASE_URL + S2C_SEND_COMMAND_TO_SENSORS_URL;
		logger.info("S2C command URL=" + url);

		ResponseEntity<ResponseWrapper> httpResponse = restTemplate.exchange(url, HttpMethod.POST, requestEntity,
				ResponseWrapper.class, VERTICAL_TYPE);
		HttpStatus status = httpResponse.getStatusCode();
		
		logger.info("S2C status=" + status);
		if (status.toString().equals(SmartCityConstant.SUCCESSCODE)) {
			response=status.toString();
		}
		else
		{
			response=httpResponse.getBody().getErrorMessage().toString();
			
		}
		return response;
	}
	@Override
	public List<GatewayIOTDetails> getGatewayIOTDetails(String gatewayId){
		logger.info("Inside :: getGatewayIOTDetails");
		 List<GatewayIOTDetails> GatewayIOTDetailsList=null;
		 HttpEntity<String> requestEntity = new HttpEntity<String>(addHttpHeaders());
			RestTemplate restTemplate = new RestTemplate();
			String url = S2C_BASE_URL + S2C_SENSOR_DATA_URL;
			logger.info("S2C URL=" + url);
			ResponseEntity<ResponseWrapper> httpResponse = restTemplate.exchange(url, HttpMethod.GET, requestEntity,
					ResponseWrapper.class,VERTICAL_TYPE,gatewayId);
			
		 	HttpStatus status = httpResponse.getStatusCode();
			if (status.toString().equals(SmartCityConstant.SUCCESSCODE)) {
				ResponseWrapper response = httpResponse.getBody();
				logger.debug("S2C sensor data response" + response);
				Object data = response.getData();
				if (data != null) {
					ObjectMapper objectMapper = new ObjectMapper();
					try {
						ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
						String json = ow.writeValueAsString(data);
						GatewayIOTDetailsList = objectMapper.readValue(json, TypeFactory.defaultInstance()
								.constructCollectionType(List.class, GatewayIOTDetails.class));
					} catch (JsonParseException e) {
						logger.error("JsonParseException" + e.getMessage());
					} catch (JsonMappingException e) {
						logger.error("JsonMappingException" + e.getMessage());
					} catch (IOException e) {
						logger.error("IOException" + e.getMessage());
					}
				}
			}
		return GatewayIOTDetailsList;
	}
}
