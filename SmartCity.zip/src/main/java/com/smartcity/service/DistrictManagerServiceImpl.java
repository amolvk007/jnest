package com.smartcity.service;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.smartcity.common.RequestParameter;
import com.smartcity.dao.DistrictGatewayMappingDao;
import com.smartcity.dao.DistrictManagerDao;
import com.smartcity.dao.DistrictPresetDao;
import com.smartcity.dao.EventPresetDao;
import com.smartcity.dao.GatewayManagerDao;
import com.smartcity.dao.PoleManagerDao;
import com.smartcity.dbbean.DistrictEntity;
import com.smartcity.dbbean.DistrictGatewayMappingEntity;
import com.smartcity.dbbean.DistrictPresetEntity;
import com.smartcity.dbbean.EventPresetEntity;
import com.smartcity.exception.InvalidInputException;
import com.smartcity.exception.SmartCityDBException;
import com.smartcity.jsonbean.AllGatewayList;
import com.smartcity.jsonbean.Coordinates;
import com.smartcity.jsonbean.District;
import com.smartcity.jsonbean.DistrictDashboardData;
import com.smartcity.jsonbean.DistrictGateway;
import com.smartcity.jsonbean.DistrictGatewayAssociation;
import com.smartcity.jsonbean.DistrictId;
import com.smartcity.jsonbean.DistrictList;
import com.smartcity.jsonbean.DistrictSummary;
import com.smartcity.jsonbean.Gateway;
import com.smartcity.jsonbean.Sensor;
import com.smartcity.jsonbean.UpdateDistrictPresetRequest;
import com.smartcity.jsonbean.s2c.S2CSendCommandToSensorsRequest;
import com.smartcity.util.DistrictManagerUtil;
import com.smartcity.util.EventPresetManagerUtil;
import com.smartcity.util.LoggerUtil;
import com.smartcity.util.UserManagerUtil;

@Service
@Transactional
public class DistrictManagerServiceImpl implements DistrictManagerService {

	@Autowired
	private EventPresetDao eventPresetDao;

	@Autowired
	private GatewayManagerDao gatewayManagerDao;

	@Autowired
	private SensorManagerService sensorManagerService;

	@Autowired
	private PoleManagerDao poleManagerDao;

	@Autowired
	private DistrictManagerDao districtManagerDao;

	@Autowired
	private DistrictGatewayMappingDao districtGatewayMappingDao;

	@Autowired
	private UserManagerService userManagerService;

	@Autowired
	private MessageSource messageSource;

	@Autowired
	private DistrictPresetDao districtPresetDao;

	@Autowired
	private GatewayManagerService gatewayManagerService;

	@Autowired
	private S2CAccessService s2cAccessService;

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void addDistrictGatewayAssociation(DistrictGateway districtGateway) {

		boolean districtExist = this.districtManagerDao.isDistrictExist(districtGateway.getDistrictId());
		if (districtExist) {

			this.districtGatewayMappingDao.addDistrictGatewayAssociation(districtGateway);

		} else {
			throw new com.smartcity.exception.SmartCityDBException(
					"District " + districtGateway.getDistrictId() + " doesnt exist");
		}

	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public List<Gateway> getDistrictGateways(String districtId) {
		List<Gateway> gatewayIds = null;
		boolean districtExist = this.districtManagerDao.isDistrictExist(districtId);
		if (districtExist) {
			gatewayIds = this.districtGatewayMappingDao.getDistrictGateways(districtId);
			if (gatewayIds.size() == 0) {
				throw new SmartCityDBException(
						messageSource.getMessage("datanotfound", new Object[] { "datanotfound" }, Locale.ENGLISH));
			}
		} else {
			throw new com.smartcity.exception.SmartCityDBException("District " + districtId + " doesnt exist");
		}

		return gatewayIds;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public List<DistrictList> getDistricts(RequestParameter requestParameter, int page, int recordsPerPage) {

		LoggerUtil.logMessage("Inside DistrictManagerServiceImpl");
		

		List<DistrictList> districtList = this.districtManagerDao.getDistricts(requestParameter, page, recordsPerPage);
		if (districtList.size() == 0) {
			throw new SmartCityDBException(
					messageSource.getMessage("datanotfound", new Object[] { "datanotfound" }, Locale.ENGLISH));

		}

		return districtList;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public List<DistrictGatewayAssociation> getDistrictGatewayList(RequestParameter requestParameter, int page,
			int recordsPerPage) {

		LoggerUtil.logMessage("Inside DistrictManagerServiceImpl");
		
		List<DistrictGatewayAssociation> districtGatewayDetails = null;
		districtGatewayDetails = this.districtManagerDao.getDistrictGatewayList(requestParameter, page, recordsPerPage);

		if (districtGatewayDetails.size() == 0) {
			throw new SmartCityDBException(
					messageSource.getMessage("datanotfound", new Object[] { "datanotfound" }, Locale.ENGLISH));

		}
		return districtGatewayDetails;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public DistrictId createCustomDistrict(District district) {
		boolean districtExist = this.districtManagerDao.isDistrictNameExist(district.getDistrictName());
		DistrictId districId = null;

		if (!districtExist) {
			DistrictEntity districtEntity = DistrictManagerUtil.convertCreateDistrictRequestToDistrictEntity(district);
			districId = this.districtManagerDao.createCustomDistrict(districtEntity);
			if (districId != null && !districId.getDistrictId().equalsIgnoreCase("")) {

				EventPresetEntity defaultPresetEvent = this.eventPresetDao.getDefaultPresetEventEntity();
				EventPresetEntity newPresetEvent = EventPresetManagerUtil.convertDefaultPreset(defaultPresetEvent);

				newPresetEvent.setName("District event");

				String eventPresetId = (String) this.eventPresetDao.insert(newPresetEvent);

				String presetId = this.districtPresetDao.addDefaultDistrictPreset(districId.getDistrictId(),
						eventPresetDao.getObjectById(eventPresetId));

			}
		} else {
			throw new com.smartcity.exception.SmartCityDBException(
					"District " + district.getDistrictName() + " already exist");
		}
		return districId;
	}

	private DistrictEntity updateDistrictEntity(DistrictEntity districtEntity, District district) {

		StringBuilder districtCoordinates = new StringBuilder();
		boolean districtExist = false;
		Date date = new Date();

		if (!districtEntity.getName().equalsIgnoreCase(district.getDistrictName())) {
			districtExist = this.districtManagerDao.isDistrictNameExist(district.getDistrictName());

		}
		if (!districtExist) {
			if (district.getDistrictCoordinates() != null) {
				for (Coordinates coordinates : district.getDistrictCoordinates()) {
					districtCoordinates.append(coordinates.getLatitude());
					districtCoordinates.append(",");
					districtCoordinates.append(coordinates.getLongitude());
					districtCoordinates.append("#");
				}
			}

			districtEntity.setName(district.getDistrictName());
			districtEntity.setcoordinates(districtCoordinates.toString());
			districtEntity.setModifiedby(UserManagerUtil.getLoggedInUserName());
			districtEntity.setModifiedDate(new Timestamp(date.getTime()));
		} else {
			throw new com.smartcity.exception.SmartCityDBException(
					"District " + district.getDistrictName() + " already exist");
		}
		return districtEntity;

	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public DistrictId updateCustomDistrict(District district, String id) {
		boolean districtExist = this.districtManagerDao.isDistrictExist(id);
		DistrictId districId = new DistrictId();
		Date date = new Date();

		if (districtExist) {
			DistrictEntity modifedDistrictEntity = this.districtManagerDao.updateCustomDistrict(district, id);
			modifedDistrictEntity = updateDistrictEntity(modifedDistrictEntity, district);
			modifedDistrictEntity.setModifiedby(UserManagerUtil.getLoggedInUserName());
			modifedDistrictEntity.setModifiedDate(new Timestamp(date.getTime()));
			districId.setDistrictId(modifedDistrictEntity.getId());

		} else {
			throw new com.smartcity.exception.SmartCityDBException("District " + id + " doesnt exist");
		}

		return districId;

	}

	/**
	 * {@inheritDoc}
	 */
	public String deleteDistricts(List<DistrictId> districtIds) {
		String message = null;
		// TODO : Add check for existence of each district
		// boolean districtExist = this.districtManagerDao.isDistrictExist(id);
		List<String> districtIdList = new ArrayList<String>();
		for (DistrictId districtId : districtIds) {
			districtIdList.add(districtId.getDistrictId());
		}
		message = this.districtManagerDao.deleteDistricts(districtIdList);

		return message;

	}

	/**
	 * {@inheritDoc}
	 */
	public String deleteDistrictGatewayMapping(List<DistrictId> districtIds) {
		String message = null;
		// TODO : Add check for existence of each district
		// boolean districtExist = this.districtManagerDao.isDistrictExist(id);
		List<String> districtIdList = new ArrayList<String>();
		for (DistrictId districtId : districtIds) {
			districtIdList.add(districtId.getDistrictId());
		}
		message = this.districtGatewayMappingDao.deleteDistrictMapping(districtIdList);

		return message;

	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public DistrictSummary getDistrictSummary(String districtId) {

		DistrictSummary districtsummaryDAO = new DistrictSummary();

		boolean districtExist = this.districtManagerDao.isDistrictExist(districtId);

		if (districtExist) {
			districtsummaryDAO = this.districtManagerDao.getDistrictSummary(districtId);
			DistrictEntity distEntity = this.districtManagerDao.getObjectById(districtId);
			EventPresetEntity eventPreset = this.eventPresetDao
					.getObjectById(distEntity.getDistrictPresets().getEventPreset().getId());
			districtsummaryDAO.setAlertThresholdLimit(eventPreset.getThreshold());
		} else {
			throw new com.smartcity.exception.SmartCityDBException("District " + districtId + " doesnt exist");

		}
		return districtsummaryDAO;

	}

	/**
	 * districtId Method will return list of {@link DistrictDashboardData} by
	 * 
	 * @param districtId
	 * @author akhaware
	 */
	@Override
	public List<DistrictDashboardData> getDistrictDashboardData(String districtId, String userId) {
		LoggerUtil.logMessage("Inside getDistrictDashboardDataTest ");
		
		/*
		 * if(null==districtId){
		 * districtId=userManagerService.getUserDefaultDistrict(userId); }
		 */
		if (null == districtId || districtId.equals("")) {
			throw new com.smartcity.exception.InvalidInputException("DistrictIdNotValid", new Object[] { districtId });
		}
		List<DistrictDashboardData> districtDashboardDataList = new ArrayList<DistrictDashboardData>();
		// List<DistrictDashboardData> districtDataList=new
		// ArrayList<DistrictDashboardData>();

		DistrictDashboardData districtDashboardData = new DistrictDashboardData();
		DistrictEntity districtEntity = this.districtManagerDao.getObjectById(districtId);
		if (districtEntity == null) {
			throw new com.smartcity.exception.InvalidInputException("DistrictIdNotValid", new Object[] { districtId });
		}

		districtDashboardData = DistrictManagerUtil.convertDistrictEntityToDistrictResponseList(districtEntity);
		districtDashboardDataList.add(districtDashboardData);
		// Get all district names for the user
		// districtDataList=districtManagerDao.getDistrictDashboardDetails(districtId,
		// userId);
		/*
		 * for(DistrictDashboardData Districtobj: districtDataList){
		 * districtDashboardDataList.add(Districtobj); }
		 */
		// LOGGER.info("DistrictEntityList="+DistrictEntityList);
		return districtDashboardDataList;
	}

	@Override
	public List<DistrictList> getDistricts() {
		List<DistrictList> districts = new ArrayList<DistrictList>();
		districts = this.districtManagerDao.getDistricts();
		return districts;
	}

	@Override
	public void updateDistrictPresets(UpdateDistrictPresetRequest updateDistrictPresetRequest) {
		boolean sensorExists = false;
		DistrictEntity districtEntity = districtManagerDao.getObjectById(updateDistrictPresetRequest.getDistrictId());
		if (null == districtEntity) {
			throw new InvalidInputException("invalidDistrictId",
					new Object[] { updateDistrictPresetRequest.getDistrictId() });
		}
		// set presets on S2C starts
		// get gateways for district
		List<AllGatewayList> gateways = gatewayManagerDao
				.getGatewaysForDistrict(updateDistrictPresetRequest.getDistrictId());

		if (null == gateways || gateways.size()<1) {
			throw new InvalidInputException("DISTRICTGATEWAYASSOCIATION_NOT_FOUND",
					new Object[] { updateDistrictPresetRequest.getDistrictId() });
		}

		//
		for (AllGatewayList gateway : gateways) {
			// get sensors for gateway
			List<Sensor> districtSensors = sensorManagerService.getSensorsForGateway(gateway.getId());
			if (null != districtSensors && districtSensors.size() > 0) {
				S2CSendCommandToSensorsRequest s2CSendCommandToSensorsRequest = DistrictManagerUtil
						.convertToS2CSensorRequest(updateDistrictPresetRequest, districtSensors);
				// System.out.println("s2CSendCommandToSensorsRequest="+s2CSendCommandToSensorsRequest);
				String response = s2cAccessService.sendCommandToSensors(s2CSendCommandToSensorsRequest);
				if (!response.equals("200")) {
					throw new InvalidInputException(response, new Object[] { response });
				} else {
					sensorExists = true;
				}
			}
		}
		if (!sensorExists) {
			throw new InvalidInputException("DISTRICTSENSORASSOCIATION_NOT_FOUND",
					new Object[] { updateDistrictPresetRequest.getDistrictId() });
		}

		// get existing preset
		DistrictPresetEntity districtPresetEntity = districtEntity.getDistrictPresets();
		if (districtPresetEntity != null && sensorExists) {
			EventPresetEntity eventPresetEntity = this.eventPresetDao.getObjectById(districtPresetEntity.getPresetId());
			districtEntity = DistrictManagerUtil.convertDistrictPresetsToDistrictEntity(updateDistrictPresetRequest,
					districtEntity, districtPresetEntity, eventPresetEntity);
			this.districtManagerDao.saveUpdate(districtEntity);

			// Set Gateway Preset
			List<DistrictGatewayMappingEntity> districtGatewayMappingList = districtEntity.getDistrictMappingEnity();
			if (districtGatewayMappingList != null && !districtGatewayMappingList.isEmpty()) {
				this.gatewayManagerService.updateGatewayListPreset(districtGatewayMappingList, eventPresetEntity);
			}
		} else {
			throw new SmartCityDBException("Default Preset for district not found");

		}

	}
}
