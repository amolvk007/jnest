package com.smartcity.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.smartcity.common.RequestParameter;
import com.smartcity.dao.EventPresetDao;
import com.smartcity.dao.PoleManagerDao;
import com.smartcity.dao.PolePresetManagerDao;
import com.smartcity.dao.PoleSensorMappingDao;
import com.smartcity.dao.SensorManagerDao;
import com.smartcity.dbbean.EventPresetEntity;
import com.smartcity.dbbean.GatewayEntity;
import com.smartcity.dbbean.PoleEntity;
import com.smartcity.dbbean.PolePresetEntity;
import com.smartcity.dbbean.PoleSensorEntity;
import com.smartcity.dbbean.SensorEntity;
import com.smartcity.exception.InvalidInputException;
import com.smartcity.exception.SmartCityDBException;
import com.smartcity.jsonbean.CreatePoleRequest;
import com.smartcity.jsonbean.DeletePoleRequest;
import com.smartcity.jsonbean.DeletePoleRequestList;
import com.smartcity.jsonbean.DigitalSignage;
import com.smartcity.jsonbean.Pole;
import com.smartcity.jsonbean.PoleList;
import com.smartcity.jsonbean.PoleSensor;
import com.smartcity.jsonbean.PoleSensorAssociationList;
import com.smartcity.jsonbean.PoleSummary;
import com.smartcity.jsonbean.Sensor;
import com.smartcity.jsonbean.UpdatePoleDetailsRequest;
import com.smartcity.jsonbean.UpdatePolePresetRequest;
import com.smartcity.jsonbean.s2c.S2CSendCommandToSensorsRequest;
import com.smartcity.util.PoleManagerUtil;
import com.smartcity.util.SensorManagerUtil;

@Transactional
@Service
public class PoleManagerServiceImpl implements PoleManagerService {

	private static final Logger LOGGER = Logger.getLogger(PoleManagerServiceImpl.class);

	@Autowired
	private PoleManagerDao poleManagerDao;

	@Autowired
	private SensorManagerDao sensorManagerDao;

	@Autowired
	private SensorManagerService sensorManagerService;

	@Autowired
	private S2CAccessService s2cAccessService;

	@Autowired
	private PoleSensorMappingDao poleSensorMappingDao;

	@Autowired
	private EventPresetDao eventPresetDao;

	@Autowired
	PolePresetManagerDao polePresetManagerDao;

	@Override
	public Pole getPoleById(String poleid) {
		// TODO Auto-generated method stub
		LOGGER.info("Inside getPoleById:: PoleManagerServiceImpl");
		PoleEntity poleEntity = this.poleManagerDao.getObjectById(poleid);
		if (poleEntity == null) {
			throw new InvalidInputException("PoleIdNotValid", new Object[] { poleid });
		}		
		return PoleManagerUtil.poleDetails(poleEntity);
	}

	@Override
	public PoleSummary getPoleSummary(String poleId) {
		LOGGER.info("Inside getPoleSummary:: PoleManagerServiceImpl");
		PoleSummary poleSummary = new PoleSummary();
		PoleEntity poleEntity = this.poleManagerDao.getObjectById(poleId);
		if (poleEntity == null) {
			throw new InvalidInputException("PoleIdNotValid", new Object[] { poleId });
		}		
		DigitalSignage digitalSignage = null;
		PolePresetEntity polePresetEntity = poleEntity.getPolePresets();
		if (polePresetEntity == null) {
			throw new InvalidInputException("nopoleprestexists", new Object[] { poleId });
		}
		digitalSignage = setDigitalSignageDetails(polePresetEntity.getEventPreset().getTextmessage());
		poleSummary = PoleManagerUtil.getPoleSummary(poleEntity);
		poleSummary.setDigitalSignage(digitalSignage);
		return poleSummary;
	}

	private DigitalSignage setDigitalSignageDetails(String textmessage) {
		DigitalSignage digitalSignage = new DigitalSignage();
		digitalSignage.setWarningMessage(textmessage);
		return digitalSignage;
	}

	@Override
	public String createPole(CreatePoleRequest poleRequest) {
		LOGGER.info("Inside createPole:: PoleManagerServiceImpl");		
		PoleEntity poleEntity = PoleManagerUtil.convertPoleRequesttoPoleEntity(poleRequest);
		return (String) this.poleManagerDao.insert(poleEntity);				
	}

	@Override
	public void updatePole(final UpdatePoleDetailsRequest updatePoleDetailsRequest, String poleId) {
		LOGGER.info("Inside updatePole:: PoleManagerServiceImpl");
		PoleEntity poleEntity = poleManagerDao.getObjectById(poleId);		
		if (poleEntity == null) {
			throw new InvalidInputException("PoleIdNotValid", new Object[] { poleId });
		}
		poleEntity = PoleManagerUtil.convertPoleUpdateRequestToPoleEntity(updatePoleDetailsRequest, poleEntity);
		poleManagerDao.saveUpdate(poleEntity);
	}

	@Override
	public void deletePole(DeletePoleRequestList deletePoleRequestList) {
		LOGGER.info("Inside deletePole:: PoleManagerServiceImpl");		
		for (DeletePoleRequest pole : deletePoleRequestList.getPoleList()) {
			PoleEntity poleEntity = poleManagerDao.getObjectById(pole.getPoleId());
			if (poleEntity.getGateway() != null) {
				throw new InvalidInputException("polegatewayexist", new Object[] { "polegatewayexist" });
			}
			if (!(poleEntity.getPoleSensors().isEmpty())) {
				throw new InvalidInputException("polesensorexist", new Object[] { "polesensorexist" });
			}
			poleManagerDao.delete(poleEntity);
		}
	}

	@Override
	public boolean isPoleNameExist(String poleName) {
		LOGGER.info("Inside isPoleNameExist:: PoleManagerServiceImpl");
		PoleEntity poleEntity = poleManagerDao.findByPoleName(poleName);
		if (null != poleEntity) {
			throw new InvalidInputException("polenameexist", new Object[] { "polenameexist" });
		}
		return true;
	}

	@Override
	public boolean isPoleNameExist(String poleName, String poleId) {
		LOGGER.info("Inside isPoleNameExist:: PoleManagerServiceImpl");
		PoleEntity poleEntity = poleManagerDao.findByPoleName(poleName, poleId);
		if (null != poleEntity) {
			throw new InvalidInputException("polenameexist", new Object[] { "polenameexist" });
		}
		return true;
	}

	@Override
	public boolean isPoleIdExist(String poleId) {
		LOGGER.info("Inside isPoleIdExist:: PoleManagerServiceImpl");
		PoleEntity poleEntity = poleManagerDao.getObjectById(poleId);
		if (null == poleEntity) {
			throw new InvalidInputException("invalidPoleId", new Object[] { poleId });
		}
		return true;
	}

	@Override
	public List<PoleList> getPoleList(RequestParameter requestParameter, int page, int limit) {
		LOGGER.info("Inside getPoleList:: PoleManagerServiceImpl");
		List<PoleList> poleLists = poleManagerDao.getPoleList(requestParameter, page, limit);
		return poleLists;
	}

	@Override
	public List<PoleList> getPoles() {
		LOGGER.info("Inside getPoles:: PoleManagerServiceImpl");
		List<PoleList> poleLists = poleManagerDao.getPoles();
		return poleLists;
	}

	@Override
	public List<Pole> getOrphanPoles() {
		LOGGER.info("Inside getOrphanPoles:: PoleManagerServiceImpl");
		List<Pole> poles = poleManagerDao.getOrphanPoles();
		return poles;
	}

	@Override
	public String addPoleSensorAssociation(PoleSensor poleSensor) throws Exception {
		LOGGER.info("Inside addPoleSensorAssociation:: PoleManagerServiceImpl");
		List<Sensor> newSesorList = new ArrayList<Sensor>();
		List<SensorEntity> sensorEntityList = new ArrayList<SensorEntity>();
		boolean isSuccessful = false;
		String poleSensorId = "";
		
		PoleEntity poleEntity = poleManagerDao.getObjectById(poleSensor.getPoleId());
		if (null == poleEntity) {
			throw new InvalidInputException("invalidPoleId", new Object[] { poleSensor.getPoleId() });
		}
		/* Formulating new pole sensor association list*/
		for (String sensorId : poleSensor.getSensorIdList()) {
			SensorEntity sensorEntity = sensorManagerDao.getObjectById(sensorId);
			if (null == sensorEntity) {
				throw new InvalidInputException("invalidSensorId", new Object[] { poleSensor.getSensorIdList() });
			}
			/* Omitting existing pole sensor from request */ 
			if(this.isSesnorAssociatedWithPole(sensorId,poleEntity.getPoleSensors())) continue;
			
			sensorEntityList.add(sensorEntity);
			Sensor sensor = SensorManagerUtil.convertSensorEntityToSensor(sensorEntity);
			newSesorList.add(sensor);
		}
		
		GatewayEntity gatewayEntity = poleEntity.getGateway();
		List<Sensor> existingSensorList =sensorManagerDao.getPoleSensors(poleEntity.getId());
		/* Removing sensor from delete request if they are in new association list */
		List<Sensor> deleteSensorList = this.filterDeleteSensorAssosicationList(existingSensorList, poleSensor);
		if (gatewayEntity != null) {
			isSuccessful = deleteSensorList.size() > 0 ? s2cAccessService.dessociateGatewaySensors(poleEntity.getGateway().getId(), deleteSensorList,1) : true;
		} else {
			isSuccessful = true;
		}
		
		if(isSuccessful){
			/* Omitting already existed associations */
			if(deleteSensorList.size() > 0) {
				this.deletePoleSensorAssociation(deleteSensorList);
			}
			if (gatewayEntity != null) {
				isSuccessful = newSesorList.size() > 0 ? s2cAccessService.associateGatewaySensors(poleEntity.getGateway().getId(), newSesorList, 1) : true;
			} else {
				isSuccessful = true;
			}
		}
		
		if (isSuccessful) {
			poleEntity = poleManagerDao.getObjectById(poleSensor.getPoleId());
			poleSensorId = poleSensorMappingDao.addPoleSensorAssociation(poleEntity, sensorEntityList);

		} else {
			throw new InvalidInputException("s2cerrorinassociation", new Object[] { "s2cerrorinassociation" });

		}
		return poleSensorId;
	}

	@Override
	public void deletePoleSensorAssociation(DeletePoleRequestList deletePoleRequestList) throws Exception {
		LOGGER.info("Inside deletePoleSensorAssociation:: PoleManagerServiceImpl");
		for (DeletePoleRequest pole : deletePoleRequestList.getPoleList()) {
			PoleEntity poleEntity = poleManagerDao.getObjectById(pole.getPoleId());
			Boolean isSuccessful = false;
			if (null == poleEntity) {
				throw new InvalidInputException("invalidPoleId", new Object[] { pole.getPoleId() });
			}
			GatewayEntity gatewayEntity = poleEntity.getGateway();
			if (null == gatewayEntity) {
				// sensorManagerDao.removeSensorsFromPole(poleEntity);
				poleSensorMappingDao.deletePoleSensorAssociation(poleEntity);
				isSuccessful = true;
			} else if (gatewayEntity != null) {
				String gatewayId = poleEntity.getGateway().getId();
				List<Sensor> sensors = new ArrayList<Sensor>();
				sensors.addAll(sensorManagerDao.getPoleSensors(pole.getPoleId()));
				isSuccessful = s2cAccessService.dessociateGatewaySensors(gatewayId, sensors, 1);
				isSuccessful = true;
				if (isSuccessful) {
					poleSensorMappingDao.deletePoleSensorAssociation(poleEntity);

				}

			}
		}

	}

	@Override
	public List<PoleSensorAssociationList> getPoleSensorAssociationList(RequestParameter requestParameter, int page,
			int limit) {
		LOGGER.info("Inside getPoleSensorAssociationList:: PoleManagerServiceImpl");
		List<PoleSensorAssociationList> poleSensorAssociationList = new ArrayList<PoleSensorAssociationList>();
		poleSensorAssociationList = poleSensorMappingDao.getPoleSensorAssociationList(requestParameter, page, limit);
		return poleSensorAssociationList;
	}

	@SuppressWarnings("unused")
	@Override
	public void updatePolePresets(UpdatePolePresetRequest updatePolePresetRequest) {
		LOGGER.info("Inside updatePolePresets:: PoleManagerServiceImpl");
		PoleEntity poleEntity = poleManagerDao.getObjectById(updatePolePresetRequest.getPoleId());
		boolean sensorExists = false;
		if (null == poleEntity) {
			throw new InvalidInputException("invalidPoleId", new Object[] { updatePolePresetRequest.getPoleId() });
		}
		List<Sensor> poleSensors = sensorManagerService.getPoleSensors(updatePolePresetRequest.getPoleId());
		if (null != poleSensors && poleSensors.size() > 0) {
			S2CSendCommandToSensorsRequest s2CSendCommandToSensorsRequest = PoleManagerUtil
					.convertToS2CSensorRequest(updatePolePresetRequest, poleSensors);
			String response = s2cAccessService.sendCommandToSensors(s2CSendCommandToSensorsRequest);
			if (!response.equals("200")) {
				throw new InvalidInputException(response, new Object[] { response });
			} else {
				sensorExists = true;
			}
		}
		if (!sensorExists) {
			throw new InvalidInputException("POLESENSORASSOCIATION_NOT_FOUND",
					new Object[] { updatePolePresetRequest.getPoleId() });
		}
		// get preset id from event_preset for user settings if not avilable
		// then create one
		PolePresetEntity polepresetEntity = poleEntity.getPolePresets();
		if (null == polepresetEntity) {

			throw new InvalidInputException("polepresetEntityNotExist",
					new Object[] { poleEntity.getId(), poleEntity.getName() });
		}
		PolePresetEntity polePresetEntity = polePresetManagerDao.getPolePresetByPoleId(poleEntity.getId());
		if (polePresetEntity != null) {
			EventPresetEntity eventPresetEntity = PoleManagerUtil.convertUpdateSensorPresetRequestToEventPresetEntity(
					polePresetEntity.getEventPreset(), updatePolePresetRequest);
			polePresetEntity.setEventPreset(eventPresetEntity);
			polePresetEntity.setPole(poleEntity);
			this.polePresetManagerDao.saveUpdate(polePresetEntity);
			if (poleEntity.getPoleSensors().size() > 0) {
				sensorManagerService.updateAllSensorPresets(poleEntity.getPoleSensors(), eventPresetEntity);
			}
		} else {
			throw new SmartCityDBException("Default Preset for pole not found");

		}

	}

	@Override
	public boolean poleIdsExist(List<String> poleIdList) {
		LOGGER.info("Inside poleIdsExist:: PoleManagerServiceImpl");
		for (String poleId : poleIdList) {
			if (isPoleIdExist(poleId))
				continue;
		}
		return true;
	}

	@Override
	public void updatePolePresets(List<PoleEntity> poleSensorList, EventPresetEntity eventPresetEntity) {
		LOGGER.info("Inside updatePolePresets:: PoleManagerServiceImpl");
		for(PoleEntity poleEntity:poleSensorList ){
			PolePresetEntity polePresetEntity = polePresetManagerDao.getPolePresetByPoleId(poleEntity.getId());
			if(polePresetEntity!=null)
			{
				EventPresetEntity newEventPresetEntity=PoleManagerUtil.convertCurrentPresetsToNewPresetEntity(polePresetEntity.getEventPreset(),
						eventPresetEntity);
				polePresetEntity.setEventPreset(newEventPresetEntity);
				polePresetEntity.setPole(poleEntity);
				this.polePresetManagerDao.saveUpdate(polePresetEntity);
			}
			}
	}
	@Override
	public void updateAllPolePresets(List<PoleEntity> poleSensorList, EventPresetEntity eventPresetEntity) {
		LOGGER.info("Inside updateAllPolePresets:: PoleManagerServiceImpl");
		for(PoleEntity poleEntity:poleSensorList ){
			PolePresetEntity polePresetEntity = polePresetManagerDao.getPolePresetByPoleId(poleEntity.getId());
			if(polePresetEntity!=null)
			{
				EventPresetEntity newEventPresetEntity=PoleManagerUtil.convertCurrentPresetsToNewPresetEntity(polePresetEntity.getEventPreset(),
					eventPresetEntity);
				polePresetEntity.setEventPreset(newEventPresetEntity);
				polePresetEntity.setPole(poleEntity);
				this.polePresetManagerDao.saveUpdate(polePresetEntity);
				if (poleEntity.getPoleSensors().size() > 0) {
					sensorManagerService.updateAllSensorPresets(poleEntity.getPoleSensors(),eventPresetEntity );
				}
			}
		}
	}


	@Override
	public PoleEntity getPoleEntityById(String poleid) {
		LOGGER.info("Inside getPoleEntityById:: PoleManagerServiceImpl");
		return poleManagerDao.getObjectById(poleid);
	}
	
	/**
	 * @param sensorId
	 * @param poleSensorEnties
	 * @return
	 */
	public boolean isSesnorAssociatedWithPole(String sensorId, List<PoleSensorEntity> poleSensorEnties) {
		LOGGER.info("Inside isSesnorAssociatedWithPole:: PoleManagerServiceImpl");
		if (poleSensorEnties != null && sensorId != null)
			for (PoleSensorEntity poleSensorEntity : poleSensorEnties) {
				if (sensorId.equalsIgnoreCase(poleSensorEntity.getSensor().getId())) {
					return true;
				}
			}
		return false;
	}
	
	/**
	 * @param existingPoleSensor
	 * @param newPoleSensor
	 * @return
	 */
	public List<Sensor> filterDeleteSensorAssosicationList(List<Sensor> existingPoleSensor, PoleSensor newPoleSensor) {
		LOGGER.info("Inside filterDeleteSensorAssosicationList:: PoleManagerServiceImpl");
		List<Sensor> newList = new ArrayList<Sensor>();
		boolean flag = true;
		for (Sensor existingSensor : existingPoleSensor) {
			flag = true;
			for (String id : newPoleSensor.getSensorIdList()) {
				if (id.equalsIgnoreCase(existingSensor.getId())) {
					flag = false;
					break;
				}
			}
			if(flag){
				newList.add(existingSensor);
			}
		}
		return newList;
	}
	
	/**
	 * @param newSesorList
	 */
	public void deletePoleSensorAssociation(List<Sensor> newSesorList){
		LOGGER.info("Inside deletePoleSensorAssociation:: PoleManagerServiceImpl");
		List<String> idList = new ArrayList<String>();
		for(Sensor sensor : newSesorList){
			idList.add(sensor.getId());
		}
		
		if(idList.size() > 0){
			poleSensorMappingDao.deletePoleSensorAssociation(idList);	
		}
	}
}
