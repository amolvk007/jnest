/**
 * 
 */
package com.smartcity.service;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AccountStatusUserDetailsChecker;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.smartcity.dao.UserManagerDao;
import com.smartcity.dbbean.SCUserEntity;
import com.smartcity.dbbean.SCUserRoleEntity;
import com.smartcity.dbbean.ScRoleEntity;
import com.smartcity.exception.AuthenticationAndAuthrizationException;

/**
 * @author inrpande01
 *
 */
@Service
public class UserService implements UserDetailsService {

	@Autowired
	private UserManagerDao userDaoImpl;
	
/*	public UserService(UserManagerDao userDaoImpl) {
		super();
		this.userDaoImpl = userDaoImpl;
	}*/

	public UserService() {
	
	}

	private static final Logger LOGGER = Logger
			.getLogger(UserService.class); 
	
	 private final AccountStatusUserDetailsChecker detailsChecker = new AccountStatusUserDetailsChecker();
	    private final HashMap<String, User> userMap = new HashMap<String, User>();
	 
	    @SuppressWarnings("unused")
		@Override
	    public final UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
	    	LOGGER.info("UserService::: loadUserByUsername");
	    //	final User user = userMap.get(username);
	    	
	        final UserDetails user =loadUserByUsernamedb(username);
	        LOGGER.info("UserService::: loadUserByUsername"+user.getUsername());
	        if (user == null) {
	        	throw new AuthenticationAndAuthrizationException("usernotfound", new String[] { "usernotfound" });
	        }
	        detailsChecker.check(user);
	        return user;
	    }
	 
	    public void addUser(User user) {
	        userMap.put(user.getUsername(), user);
	    }

	    
	   
	public User loadUserByUsernamedb(final String username) 
				throws UsernameNotFoundException {
		 
			SCUserEntity user = userDaoImpl.findByUserName(username);
			   if (user == null) {
		            throw new UsernameNotFoundException("user not found");
		        }
			System.out.println(" User Name::::"+user.getUsername()+"   User Pwd::"+user.getPassword());
			
			Set<SCUserRoleEntity> userroleset=	user.getScUserRole();
			Set<ScRoleEntity> userRoles= new HashSet<ScRoleEntity>();
			for(SCUserRoleEntity sCUserRoleEntity :userroleset){
				;
				userRoles.add(sCUserRoleEntity.getScRole());
			}
				Set<GrantedAuthority> authorities = 
		                                      buildUserAuthority(userRoles);
		 
				return buildUserForAuthentication(user, authorities);
		 
			}
		
		
		// Converts com.st.model.User user to
			// org.springframework.security.core.userdetails.User
			private User buildUserForAuthentication(SCUserEntity user, 
				Set<GrantedAuthority> authorities) {
				return new User(user.getUsername(), user.getPassword(), 
					true, true, true, true, authorities);
			}
		 
			
		/*	private User buildUserForAuthentication(com.smartcity.dbbean.UserEntity user, 
					List<GrantedAuthority> authorities) {
					return new User(user.getUsername(), user.getPassword(), 
						user.isEnabled(), true, true, true, authorities);
				}*/
			 
/*			private List<GrantedAuthority> buildUserAuthority(Set<UserRole> userRoles) {
		 
				Set<GrantedAuthority> setAuths = new HashSet<GrantedAuthority>();
		 
				// Build user's authorities
				for (UserRole userRole : userRoles) {
					setAuths.add(new SimpleGrantedAuthority(userRole.getRole()));
					
				}
		 
				List<GrantedAuthority> Result = new ArrayList<GrantedAuthority>(setAuths);
				for(GrantedAuthority grantedAuthority:Result){
					System.out.println("getAuthority::::"+grantedAuthority.getAuthority());
				}
				return Result;
			}
			*/
			
			private Set<GrantedAuthority> buildUserAuthority(Set<ScRoleEntity> userRoles) {
				 
				Set<GrantedAuthority> setAuths = new HashSet<GrantedAuthority>();
		 
				for(ScRoleEntity entity:userRoles)
				{
					setAuths.add(new SimpleGrantedAuthority(entity.getName()));
				}
			
			/*	List<GrantedAuthority> Result = new ArrayList<GrantedAuthority>(setAuths);
				for(GrantedAuthority grantedAuthority:Result){
					System.out.println("getAuthority::::"+grantedAuthority.getAuthority());
				}*/
				return setAuths;
			}
			
			
}
