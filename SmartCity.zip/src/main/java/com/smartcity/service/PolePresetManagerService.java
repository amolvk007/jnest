package com.smartcity.service;

public interface PolePresetManagerService {
	
	public void createPolePreset(String polePresetEntity);
}
