package com.smartcity.service;

import java.io.Serializable;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.smartcity.common.RequestParameter;
import com.smartcity.dao.NotificationManagerDao;
import com.smartcity.dbbean.NotificationEntity;
import com.smartcity.jsonbean.EventLogResponse;
import com.smartcity.jsonbean.s2c.GatewayEventLogRequest;
import com.smartcity.jsonbean.s2c.GatewayEventRequest;
import com.smartcity.util.NotificationUtils;

@Transactional
@Service
public class NotificationManagerServiceImpl implements NotificationManagerService {

	@Autowired
	NotificationManagerDao notificationManagerDao;
	
	@Override
	public Serializable saveNotification(GatewayEventRequest gatewayEventRequest) {
		return notificationManagerDao.insert(NotificationUtils.gatewayEventRequestToNotificationEntity(gatewayEventRequest));
		
	}

	@Override
	public List<EventLogResponse> getNotifications(RequestParameter requestParameter, int page, int limit) {

		List<NotificationEntity>  notificationlist=notificationManagerDao.getNotifications(requestParameter, page, limit);
		
		return NotificationUtils.NotificationEntityToEventLogResponseList(notificationlist);
	}

	@Override
	public Serializable saveExceptionNotification(GatewayEventLogRequest gatewayEventLogRequest) {
		return notificationManagerDao.insert(NotificationUtils.EventLogRequestToNotificationEntity(gatewayEventLogRequest));
	}


}
