package com.smartcity.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.smartcity.dao.EventPresetDao;
import com.smartcity.dao.SensorManagerDao;
import com.smartcity.dao.SensorPresetManagerDao;
import com.smartcity.dbbean.EventPresetEntity;
import com.smartcity.dbbean.SensorEntity;
import com.smartcity.dbbean.SensorPresetEntity;
import com.smartcity.util.EventPresetManagerUtil;

@Transactional
@Service
public class SensorPresetManagerServiceImpl implements SensorPresetManagerService {

	
	@Autowired
	SensorPresetManagerDao sensorPresetManagerDao;
	
	@Autowired
	EventPresetDao eventPresetDao;
	
	@Autowired
	SensorManagerDao sensorManagerDao;

	@Override
	public String createSensorPreset(String sensorid) {
		EventPresetEntity defaultEventPresetEntity = eventPresetDao.getDefaultPresetEventEntity();
		EventPresetEntity newEventPresetEntity=	EventPresetManagerUtil.convertDefaultPreset(defaultEventPresetEntity);
		newEventPresetEntity.setName("Sensor  Event");
		String eventid=(String) eventPresetDao.insert(newEventPresetEntity);
		SensorEntity sensorEntity=sensorManagerDao.getObjectById(sensorid);
		EventPresetEntity EventPresetEntity=eventPresetDao.getObjectById(eventid);
		SensorPresetEntity sensorPresetEntity= new SensorPresetEntity();
		sensorPresetEntity.setEventPreset(EventPresetEntity);
		sensorPresetEntity.setSensor(sensorEntity);
		return (String) sensorPresetManagerDao.insert(sensorPresetEntity);
	}



}
