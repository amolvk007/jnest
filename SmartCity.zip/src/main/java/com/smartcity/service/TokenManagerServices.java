/**
 * 
 */
package com.smartcity.service;

import com.smartcity.dbbean.SCToken;

/**
 * @author inrpande01
 *
 */
public interface TokenManagerServices {
	public SCToken getToken(String token);
	public SCToken generateToken(String username);
	void  deleteToken(String username);
	SCToken getTokenByUserName(String username);
}
