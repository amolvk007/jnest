package com.smartcity.service;

import java.io.Serializable;
import java.util.List;

import com.smartcity.common.RequestParameter;
import com.smartcity.dbbean.SCUserEntity;
import com.smartcity.jsonbean.DistrictUser;
import com.smartcity.jsonbean.DistrictUserAssociation;
import com.smartcity.jsonbean.DistrictUserDelete;
import com.smartcity.jsonbean.User;
import com.smartcity.jsonbean.UserDistrict;
import com.smartcity.jsonbean.UserId;
import com.smartcity.jsonbean.UserList;
import com.smartcity.jsonbean.UserResponse;

public interface UserManagerService {
	List<UserResponse> getUsers();

	String getUserDefaultDistrict(String userId);

	UserResponse getUserByName(String userId);

	Serializable addUser(User user);

	void updateUser(User user,SCUserEntity sCUserEntity);

	void deleteUser(User user);

	boolean isUserNameExist(User user);

	boolean isUserIdExist(String userId);

	String addUserDistrictAssociation(UserDistrict userDistrict);

	void deleteDistrictUserAssociation(DistrictUserDelete districtUserDelete);

	List<String> getDistrictUserAssociationIds(List<UserId> userIdList);

	List<DistrictUserAssociation> getdistrictUserAssociationList();

	List<DistrictUser> getdistrictUserList(String userId);
	
	List<UserList> getOnlyUsers(RequestParameter RequestParameter,int page,int limit);
	
	List<UserResponse> getUsers(RequestParameter RequestParameter,int page,int limit);
	boolean checkUserAccess(User user);
	SCUserEntity findByUserId(String userid);
}
