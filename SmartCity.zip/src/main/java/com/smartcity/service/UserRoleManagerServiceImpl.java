package com.smartcity.service;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.smartcity.common.RequestParameter;
import com.smartcity.dao.DistrictManagerDao;
import com.smartcity.dao.DistrictUserMappingDao;
import com.smartcity.dao.RoleManagerDao;
import com.smartcity.dao.UserManagerDao;
import com.smartcity.dao.UserRoleManagerDao;
import com.smartcity.dbbean.DistrictEntity;
import com.smartcity.dbbean.SCUserEntity;
import com.smartcity.dbbean.SCUserRoleEntity;
import com.smartcity.dbbean.ScRoleEntity;
import com.smartcity.exception.InvalidInputException;
import com.smartcity.jsonbean.DistrictId;
import com.smartcity.jsonbean.DistrictUser;
import com.smartcity.jsonbean.DistrictUserAssociation;
import com.smartcity.jsonbean.DistrictUserDelete;
import com.smartcity.jsonbean.User;
import com.smartcity.jsonbean.UserDistrict;
import com.smartcity.jsonbean.UserId;
import com.smartcity.jsonbean.UserResponse;
import com.smartcity.util.UserManagerUtil;

@Transactional
@Service
public class UserRoleManagerServiceImpl implements UserRoleManagerService {

	
	@Autowired
	UserRoleManagerDao userRoleManagerDao;

	private static final Logger LOGGER = Logger.getLogger(UserRoleManagerServiceImpl.class);

	@Override
	public Serializable addUserRoleAssociation(SCUserRoleEntity sCUserRoleEntity) {
		// TODO Auto-generated method stub
		return userRoleManagerDao.insert(sCUserRoleEntity);
	}

	@Override
	public void updateUserRoleAssociation(SCUserRoleEntity sCUserRoleEntity) {
		userRoleManagerDao.update(sCUserRoleEntity);
		
	}

	@Override
	public void deleteUserRoleAssociation(SCUserRoleEntity sCUserRoleEntity) {
		userRoleManagerDao.deleteUserRoleAssociation(sCUserRoleEntity);
	}

	@Override
	public SCUserRoleEntity findByUserId(String userid) {
		// TODO Auto-generated method stub
		return userRoleManagerDao.findByUserId(userid);
	}

}
