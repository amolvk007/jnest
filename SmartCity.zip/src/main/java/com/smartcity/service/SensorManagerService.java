package com.smartcity.service;

import java.util.List;
import java.util.Map;

import com.smartcity.dbbean.EventPresetEntity;
import com.smartcity.dbbean.PoleSensorEntity;
import com.smartcity.dbbean.SensorEntity;
import com.smartcity.jsonbean.CreateSensorRequest;
import com.smartcity.jsonbean.Sensor;
import com.smartcity.jsonbean.SensorClassList;
import com.smartcity.jsonbean.SensorData;
import com.smartcity.jsonbean.SensorList;
import com.smartcity.jsonbean.SensorTypeList;
import com.smartcity.jsonbean.UpdateSensorPresetRequest;
import com.smartcity.jsonbean.s2c.S2CSensorType;

public interface SensorManagerService {

	public SensorData getSensorData(String sensorId);

	public List<SensorTypeList> getSensorTypeList() throws Exception;

	public String createSensor(CreateSensorRequest sensorRequest) throws Exception;

	public List<SensorClassList> getSensorClassList();

	public List<SensorList> getSensorList();

	public Map<String, List<String>> deleteSensor(List<String> sensorIds) throws Exception;

	public List<Sensor> getOrphanSensors();

	public List<Sensor> getPoleSensors(String poleId);
	
	public Boolean updateSensor(String sensorId, CreateSensorRequest sensorRequest) throws Exception;

	public SensorList getSensorDetails(String sensorId);

	public boolean isSensorIdExist(String sensorId);
	
	public String getSensorName(String sensorId); 
	
	void updateSensorPresets(UpdateSensorPresetRequest updateSensorPresetRequest); 
	
	void updateAllSensorPresets(List<PoleSensorEntity> PoleSensorList,EventPresetEntity eventPresetEntity );

	List<S2CSensorType> getS2CSensorTypeList() throws Exception;

	List<Sensor> getSensorsForDistrict(String districtId);
	
	List<Sensor> getSensorsForGateway(String gatewayId);
	
}
