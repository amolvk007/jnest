package com.smartcity.service;

import java.io.Serializable;

import org.apache.log4j.Logger;

import com.smartcity.jsonbean.s2c.GatewayStatusRequest;
import com.smartcity.rest.S2CGatewaySatusWebService;

public interface GatewayStatusService {
	
	Serializable saveGatewayStatus(GatewayStatusRequest gatewayStatusRequest);

}
