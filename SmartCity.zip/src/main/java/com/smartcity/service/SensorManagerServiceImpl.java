package com.smartcity.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.smartcity.dao.EventPresetDao;
import com.smartcity.dao.SensorClassManagerDao;
import com.smartcity.dao.SensorManagerDao;
import com.smartcity.dao.SensorPresetManagerDao;
import com.smartcity.dbbean.EventPresetEntity;
import com.smartcity.dbbean.GatewayEntity;
import com.smartcity.dbbean.PoleSensorEntity;
import com.smartcity.dbbean.SensorClassEntity;
import com.smartcity.dbbean.SensorEntity;
import com.smartcity.dbbean.SensorPresetEntity;
import com.smartcity.exception.InvalidInputException;
import com.smartcity.jsonbean.CreateSensorRequest;
import com.smartcity.jsonbean.Sensor;
import com.smartcity.jsonbean.SensorClassList;
import com.smartcity.jsonbean.SensorData;
import com.smartcity.jsonbean.SensorList;
import com.smartcity.jsonbean.SensorTypeList;
import com.smartcity.jsonbean.UpdateSensorPresetRequest;
import com.smartcity.jsonbean.s2c.S2CSensorRequest;
import com.smartcity.jsonbean.s2c.S2CSensorType;
import com.smartcity.jsonbean.s2c.SensorDataPoint;
import com.smartcity.util.SensorManagerUtil;

@Transactional
@Service
public class SensorManagerServiceImpl implements SensorManagerService {

	private static final Logger LOGGER = Logger.getLogger(SensorManagerServiceImpl.class);
	@Autowired
	private SensorManagerDao sensorManagerDao;

	@Autowired
	private SensorClassManagerDao sensorClassManagerDao;

	@Autowired
	private S2CAccessService s2cAccessService;

	@Autowired
	EventPresetDao eventPresetDao;

	@Autowired
	SensorPresetManagerDao sensorPresetManagerDao;

	@Override
	public SensorData getSensorData(String sensorId) {
		LOGGER.info("SensorManagerServiceImpl:::: getSensorDetailsById:::: sensorid::" + sensorId);

		SensorData sensorData = new SensorData();
		sensorData.setHumidity("Not Available");
		sensorData.setLight("Not Available");
		sensorData.setTemperature("Not Available");
		sensorData.setSensorName(getSensorName(sensorId));
		sensorData.setSensorId(sensorId);
		// Need to make call actual api to get sensor data
		List<SensorDataPoint> dataUnitCollection = s2cAccessService.getSensorData(sensorId, 1);
		if (dataUnitCollection.size() > 0) {
			for (SensorDataPoint unit : dataUnitCollection) {
				LOGGER.info("Sensor Data Unit Name=" + unit.getName());
				LOGGER.info("Sensor Data Unit Value=" + unit.getValue());
				if (unit.getName().trim().equalsIgnoreCase("humidity")) {
					sensorData.setHumidity(unit.getValue());
				} else if (unit.getName().trim().equalsIgnoreCase("light")) {
					sensorData.setLight(unit.getValue());
				}else if (unit.getName().trim().equalsIgnoreCase("temperature")) {
					sensorData.setTemperature(unit.getValue());
				}
				sensorData.setReceiveTime(unit.getReceiveTime());
			}
		} else {
			throw new com.smartcity.exception.InvalidInputException("datanotfound", new Object[] { "datanotfound" });
		}
		return sensorData;
	}

	@Override
	public List<SensorClassList> getSensorClassList() {
		List<SensorClassEntity> sensorClassLists = sensorClassManagerDao.loadAll();
		List<SensorClassList> finalSensorTypeList = SensorManagerUtil.getSensorClassList(sensorClassLists);

		return finalSensorTypeList;
	}

	@Override
	public List<SensorTypeList> getSensorTypeList() throws Exception {
		List<S2CSensorType> sensorTypeList = s2cAccessService.getSensorTypeList(1);
		List<SensorTypeList> finalSensorTypeList = new ArrayList<SensorTypeList>();
		if(!sensorTypeList.isEmpty()){
			finalSensorTypeList = SensorManagerUtil.getSensorTypeList(sensorTypeList);
		} else {
			throw new Exception("Sensor type not registered with S2C for SmartCity Vertical.");
		}
		return finalSensorTypeList;
	}
	
	@Override
	public List<S2CSensorType> getS2CSensorTypeList() throws Exception {
		List<S2CSensorType> sensorTypeList = s2cAccessService.getSensorTypeList(1);
		if(sensorTypeList.isEmpty()){
			throw new Exception("Sensor type not registered with S2C for SmartCity Vertical.");
		} 
		return sensorTypeList;
	}

	@Override
	public String createSensor(CreateSensorRequest sensorRequest) throws Exception {
		List<S2CSensorType> sensorTypeLists = getS2CSensorTypeList();
		String make = "";
		String model = "";
		for(S2CSensorType s2cSensorType : sensorTypeLists) {
			if(s2cSensorType.getSensorTypeId().equals(sensorRequest.getSensorTypeId())) {
				make = s2cSensorType.getMake();
				model = s2cSensorType.getModel();
			}
		}
		S2CSensorRequest s2cSensorRequest = SensorManagerUtil.convertToS2CSensorRequest(sensorRequest);
		s2cSensorRequest.setMake(make);
		s2cSensorRequest.setModel(model);
		String sensorId = s2cAccessService.createSensor(s2cSensorRequest, 1);
		if(sensorId!=null) {
			SensorClassEntity sensorClassEntity = sensorClassManagerDao.getObjectById("1000");
			SensorEntity sensorEntity = SensorManagerUtil.convertToSensorEntity(sensorRequest, sensorId, null);
			sensorEntity.setSensorClass(sensorClassEntity);
			sensorManagerDao.insert(sensorEntity);
		} else {
			throw new Exception("Error while creating new sensor");
		}
		return sensorId;
	}

	@Override
	public List<SensorList> getSensorList() {
		List<SensorEntity> sensorEntities = sensorManagerDao.loadAll();
		List<SensorList> sensorLists = SensorManagerUtil.convertToSensorList(sensorEntities);
		return sensorLists;
	}

	@Override
	public Map<String, List<String>> deleteSensor(List<String> sensorIds) throws Exception {
		List<String> failedSensorIds = new ArrayList<String>();
		List<String> successSensorIds = new ArrayList<String>();
		for(String sensorId : sensorIds) {
			SensorEntity sensorEntity = sensorManagerDao.getObjectById(sensorId);
			
			if(sensorEntity.getPoleSensors() == null || sensorEntity.getPoleSensors().isEmpty()) {
				Boolean isSuccessful = s2cAccessService.deleteSensor(sensorId,1);
				if(isSuccessful) {
					sensorManagerDao.delete(sensorId);
					successSensorIds.add(sensorId);
				}
			} else {
				failedSensorIds.add(sensorId);
			}
		}
		Map<String, List<String>> result = new HashMap<String, List<String>>();
		result.put("fail", failedSensorIds);
		result.put("pass", successSensorIds);
		return result;
	}

	@Override
	public List<Sensor> getOrphanSensors() {
		List<Sensor> orphanSensorList = sensorManagerDao.getOrphanSensors();
		return orphanSensorList;
	}

	@Override
	public List<Sensor> getPoleSensors(String poleId) {
		List<Sensor> poleSensorsList = sensorManagerDao.getPoleSensors(poleId);
		return poleSensorsList;
	}

	@Override
	public Boolean updateSensor(String sensorId, CreateSensorRequest sensorRequest) throws Exception {
		S2CSensorRequest s2csensorRequest = SensorManagerUtil.convertToS2CSensorRequest(sensorRequest);
		Boolean isSuccessful = s2cAccessService.updateSensor(sensorId, s2csensorRequest, 1);

		if (isSuccessful) {
			// SensorClassEntity sensorClassEntity =
			// sensorClassManagerDao.getObjectById(sensorRequest.getSensorClassId());
			SensorEntity sensorEntity = SensorManagerUtil.convertToSensorEntity(sensorRequest, sensorId, null);
			sensorManagerDao.update(sensorEntity);
		}  else {
			throw new Exception("Error while updating sensor with id: "+sensorId);
		}

		return isSuccessful;
	}

	@Override
	public SensorList getSensorDetails(String sensorId) {
		final SensorEntity sensorEntity = sensorManagerDao.getObjectById(sensorId);
		List<SensorList> sensorLists = SensorManagerUtil.convertToSensorList(new ArrayList<SensorEntity>() {
			{
				add(sensorEntity);
			}
		});
		return sensorLists.get(0);
	}

	@Override
	public boolean isSensorIdExist(String sensorId) {
		SensorEntity sensorEntity = sensorManagerDao.getObjectById(sensorId);
		if (null == sensorEntity) {
			throw new InvalidInputException("invalidSensorId", new Object[] { sensorId });
		}
		return true;
	}

	@Override
	public String getSensorName(String sensorId) {
		SensorEntity sensorEntity = sensorManagerDao.getObjectById(sensorId);
		if (null == sensorEntity) {
			throw new InvalidInputException("invalidSensorId", new Object[] { sensorId });
		}
		return sensorEntity.getName();
	}

	@Override
	public void updateSensorPresets(UpdateSensorPresetRequest updateSensorPresetRequest) {
		// TODO Auto-generated method stub
		EventPresetEntity eventPreset =null;
		SensorEntity sensorEntity = sensorManagerDao.getObjectById(updateSensorPresetRequest.getSensorId());
		if (null == sensorEntity) {
			throw new InvalidInputException("invalidSensorId",
					new Object[] { updateSensorPresetRequest.getSensorId() });
		}
		
		// get preset id from event_preset for user settings if not avilable
		// then create one
		SensorPresetEntity sensorPresetEntity = sensorEntity.getSensorPresets();
		if (null == sensorPresetEntity) {

			throw new InvalidInputException("sensorpresetEntityNotExist",
					new Object[] { sensorEntity.getId(), sensorEntity.getName() });
		}
		SensorPresetEntity dbsensorPresetEntity = sensorPresetManagerDao.getSensorPresetEntityBySensorId(sensorEntity.getId());
		
		if(dbsensorPresetEntity!=null)
		{		
			eventPreset = SensorManagerUtil
					.convertUpdateSensorPresetRequestToEventPresetEntity(dbsensorPresetEntity.getEventPreset(), updateSensorPresetRequest);
			sensorPresetEntity.setEventPreset(eventPreset);
			sensorPresetEntity.setSensor(sensorEntity);
			sensorPresetManagerDao.saveUpdate(sensorPresetEntity);
		}
	}


	@Override
	public void updateAllSensorPresets(List<PoleSensorEntity> poleSensorList, EventPresetEntity eventPresetEntity) {
		
		for(PoleSensorEntity poleSensorEntity:poleSensorList){
			SensorEntity  sensorEntity =poleSensorEntity.getSensor();
			EventPresetEntity newEventPresetEntity=SensorManagerUtil.convertCurrentPresetsToNewPresetEntity(sensorEntity.getSensorPresets().getEventPreset(),
					eventPresetEntity);
			SensorPresetEntity dbsensorPresetEntity = sensorPresetManagerDao.getSensorPresetEntityBySensorId(sensorEntity.getId());
			dbsensorPresetEntity.setEventPreset(newEventPresetEntity);
			dbsensorPresetEntity.setSensor(sensorEntity);
			this.sensorPresetManagerDao.saveUpdate(dbsensorPresetEntity);
		}
		
	}
	
	@Override
	public List<Sensor> getSensorsForDistrict(String districId) {
		List<Sensor> sensorList = sensorManagerDao.getSensorsForDistrict(districId);
		return sensorList;
	}

	@Override
	public List<Sensor> getSensorsForGateway(String gatewayId) {
		List<Sensor> sensorList = sensorManagerDao.getSensorsForGateway(gatewayId);
		return sensorList;
	}
}
