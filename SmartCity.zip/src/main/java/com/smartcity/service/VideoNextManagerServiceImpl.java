package com.smartcity.service;

import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.logging.Level;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.smartcity.constant.VideoNext;
import com.smartcity.exception.SmartCityRuntimeException;
import com.smartcity.jsonbean.videonext.Event;
import com.smartcity.jsonbean.videonext.UTC;
import com.videonext.stratus.sdk2.ELog.ELogSvcRequestor;
import com.videonext.stratus.sdk2.ELog.eventlogsvc.protocol.EVENTRESPONSEType;
import com.videonext.stratus.sdk2.ELog.eventlogsvc.protocol.EVENTType;
import com.videonext.stratus.sdk2.ELog.eventlogsvc.protocol.FILTERType;
import com.videonext.stratus.sdk2.ELog.eventlogsvc.protocol.OPTIONType;
import com.videonext.stratus.sdk2.ELog.eventlogsvc.protocol.OUTPUTOPTIONSType;
import com.videonext.stratus.sdk2.ELog.eventlogsvc.protocol.PAGEBREAKType;
import com.videonext.stratus.sdk2.ELog.eventlogsvc.protocol.StOptname;
import com.videonext.stratus.sdk2.ELog.eventlogsvc.protocol.StOptvalue;
import com.videonext.stratus.sdk2.ELog.eventlogsvc.protocol.StSort;
import com.videonext.stratus.sdk2.ELog.eventlogsvc.protocol.T3ConditionParam;
import com.videonext.stratus.sdk2.ELog.eventlogsvc.protocol.T3Conditions;
import com.videonext.stratus.sdk2.session.Session;

@Service
@Transactional
public class VideoNextManagerServiceImpl implements VideoNextManagerService {

	private static final Logger LOGGER = Logger.getLogger(DistrictManagerService.class);

	@Value("${VN_HOST}")
	private String VN_HOST;

	@Value("${VN_USER}")
	private String VN_USER;

	@Value("${VN_PWD}")
	private String VN_PWD;

	@Value("${VN_PROTOCOL}")
	private String VN_PROTOCOL;

	@Autowired
	private MessageSource messageSource;

	@Autowired
    private ServletContext context;
    
	@Override
	public List<Event> getEventLog(int page, int limit){
		LOGGER.info("Inside getEventLog page=" + page + " limit=" + limit);
		List<Event> eventList = new ArrayList<Event>();
		try {
			Session session = Session.getSession();
			session.setLogger(Level.INFO);
			session.setTrustAll(true);
			session.openSession(VN_HOST, VN_USER, VN_PWD, VN_PROTOCOL);

			FILTERType filter = new FILTERType();
			T3ConditionParam value = new T3ConditionParam();
			value.setValue("125");
			T3Conditions condition = T3Conditions.EQ;
			value.setCondition(condition);
			filter.setObjid(value);

			PAGEBREAKType pagebreak = new PAGEBREAKType();
			pagebreak.setPAGESIZE(limit);
			pagebreak.setSORT(StSort.EVENTID);
			pagebreak.setSORTASC(false);

			OUTPUTOPTIONSType options = new OUTPUTOPTIONSType();
			List<OPTIONType> optionList = options.getOPTION();
			optionList.add(ELogSvcRequestor.createOption(StOptname.PROPERTIES, StOptvalue.TRUE));
			optionList.add(ELogSvcRequestor.createOption(StOptname.TIMEFORMAT, StOptvalue.UTC));

			EVENTRESPONSEType eventResponse;
			pagebreak.setPAGE(page);
			eventResponse = ELogSvcRequestor.getEvents(filter, pagebreak, options);

			Event event = null;
			UTC utc = null;
			for (EVENTType eventType : eventResponse.getEVENTS().getEVENT()) {
				eventList.add(event = new Event());
				event.setUtc(utc = new UTC());
				event.setId(eventType.getID());
				event.setObjid(eventType.getOBJID());
				event.setSrc(getEventDisplayMessage(VideoNext.EVENT_SRC,eventType.getSRC()));
				event.setState(eventType.getSTATE());
				event.setPriority(getEventDisplayMessage(VideoNext.EVENT_PRIORITY,eventType.getPRIORITY()));
				event.setLifespan(getEventDisplayMessage(VideoNext.EVENT_LIFESPAN,eventType.getLIFESPAN()));
				event.setMessage(eventType.getMESSAGE());
				event.setEventtype(getEventDisplayMessage(VideoNext.EVENT_EVENTTYPE,eventType.getEVENTTYPE()));
				event.setNote(eventType.getNOTE());
				event.setTag(eventType.getTAG());
				if (eventType.getUTC() != null) {
					utc.setFrom(eventType.getUTC().getFROM());
					utc.setTo(eventType.getUTC().getTO());
					utc.setUpdated(eventType.getUTC().getUPDATED());
					utc.setWhen(eventType.getUTC().getWHEN());
				}
			}
		} catch (Throwable e) {
			LOGGER.error("Error in accessing event log", e);
			throw new SmartCityRuntimeException(e);
		}
		return eventList;
	}

	@Override
	public void getVideFootageStream(int objectId, String fromDate, String toDate, HttpServletResponse response){
		LOGGER.info("Inside getVideFootageStream objectId=" + objectId + " fromDate="+ fromDate + " toDate="+toDate);
		try{
			/*Session session = Session.getSession();
			session.setLogger(Level.INFO);
			session.setTrustAll(true);
			session.openSession(VN_HOST, VN_USER, VN_PWD, VN_PROTOCOL);
			DateTime start = DateTime.parse(fromDate);
			DateTime end = DateTime.parse(toDate);
			
			AuthStream authStream = AuthMngRs.getAuth(objectId, StreamType.ARCHIVE, start.getMillis()/1000, end.getMillis()/1000, false);
			String footageURL = authStream.getUrl() + "&authorizationid=" + authStream.getAuthid();
			LOGGER.info("footageURL=" + footageURL);*/
			//String user = (String) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			String footageFile = context.getRealPath("/resources/footage/demo_footage.mov");
			LOGGER.info("footage path=" + context.getRealPath(footageFile));
			//this.exportFootageIntoFile(footageURL,footageFile);
			OutputStream outStrem = null;
			InputStream inputStream = null;
			try {
				response.setContentType("video/mp4");
				outStrem = response.getOutputStream();
				inputStream = new FileInputStream(footageFile);
				int n = 0;
				byte[] buffer = new byte[4096];
				while (-1 != (n = inputStream.read(buffer))) {
					outStrem.write(buffer, 0, n);
				}
			    outStrem.flush();
			} finally {
				if(inputStream !=null) inputStream.close();
				if(outStrem !=null) outStrem.close();
			}

		} catch (Throwable e) {
			LOGGER.error("Error in accessing event log", e);
			throw new SmartCityRuntimeException(e);
		}
	}

	private int getPortFromURL(String paramString, int paramInt) {
		String str1 = null;
		int i = paramString.indexOf("//");
		if (i < 0)
			return paramInt;
		str1 = paramString.substring(i + 2);
		i = str1.indexOf("/");
		if (i < 0)
			return paramInt;
		str1 = str1.substring(0, i);

		i = str1.indexOf(58);
		if (i < 0) {
			return paramInt;
		}

		String str2 = str1.substring(i + 1).trim();
		try {
			return Integer.parseInt(str2);
		} catch (NumberFormatException localNumberFormatException) {
		}
		return paramInt;
	}

	private String getHostFromURL(String paramString) {
		String str = null;
		int i = paramString.indexOf("//");
		if (i < 0)
			return "";
		str = paramString.substring(i + 2);
		i = str.indexOf("/");
		if (i < 0)
			return "";
		str = str.substring(0, i);

		i = str.indexOf(58);
		if (i < 0) {
			return str;
		}

		return str.substring(0, i);
	}
	
	private void exportFootageIntoFile(String footageURL, String tagetFootageFile) throws IOException{
		RandomAccessFile localRandomAccessFile = null;
		DataInputStream socketDataInputStream = null;
		OutputStream socketOutputStream = null;
		boolean downloadCompleted = false;
		
		try {
			String reposityHost = getHostFromURL(footageURL);
			LOGGER.info("Footage reposityHost=" + reposityHost);
			int i = getPortFromURL(footageURL, 8554);
			Socket localSocket = new Socket(reposityHost, i);
			socketDataInputStream = new DataInputStream(localSocket.getInputStream());
			socketOutputStream = localSocket.getOutputStream();
			LOGGER.info("Connected to reposity host " + reposityHost + ":" + i);
			String command = "XEXPORT " + footageURL + " RTSP/1.0\r\nCSeq: 1\r\n\r\n";
			LOGGER.info("Request >>> " + command);
			socketOutputStream.write(command.getBytes());
			String commandResponse = socketDataInputStream.readLine();
			LOGGER.info("Response <<< " + commandResponse);
			if (!(commandResponse.contains("RTSP/1.0 200"))) {
				localSocket.close();
				throw new IOException("Request failed. Server returns: " + commandResponse);
			}
			int j = 0;
			String signResponse = null;
			LOGGER.info("*** checking signing information ***");
			while (true) {
				signResponse = socketDataInputStream.readLine();
				LOGGER.info(" Response >> " + signResponse);
				if (signResponse == null)
					break;
				if (((String) signResponse).length() == 0) {
					break;
				}
				if (((String) signResponse).contains("X-Signed: yes")) {
					j = 1;
				}

			}
			byte[] localObject = new byte[262144];
			String contentType = null;
			int contentlength = -1;
			// int l = 0;
			int progress = 0;
			long seekOffset = 0L;
			// long l2 = 0L;
			Pattern contentTypePattern = Pattern.compile("^Content-Type: (.+)");
			Pattern contentLengthPatterrn = Pattern.compile("^Content-Length: (.+)");
			Pattern progressPattern = Pattern.compile("^X-Progress: (.+)%");
			Pattern seekPattern = Pattern.compile("^X-Seek: (.+)");
			String str4 = null;
			localRandomAccessFile = new RandomAccessFile(tagetFootageFile, "rw");
			while ((str4 = socketDataInputStream.readLine()) != null) {
				LOGGER.info("response>> " + str4);
				Matcher localMatcher;
				if ((localMatcher = contentTypePattern.matcher(str4)).find()) {
					contentType = localMatcher.group(1);
					LOGGER.info("contentType=" + contentType);
				} else if ((localMatcher = contentLengthPatterrn.matcher(str4)).find()) {
					contentlength = Integer.parseInt(localMatcher.group(1));
					LOGGER.info("contentlength=" + contentlength);
				} else if ((localMatcher = progressPattern.matcher(str4)).find()) {
					progress = Integer.parseInt(localMatcher.group(1));
					LOGGER.info("progress=" + progress);
				} else if ((localMatcher = seekPattern.matcher(str4)).find()) {
					seekOffset = Long.parseLong(localMatcher.group(1));
					LOGGER.info("seekOffset=" + seekOffset);
				}

				if ((str4.length() == 0) && (contentlength >= 0)) {
					if ((contentlength == 0) && (progress == 100)) {
						downloadCompleted = true;
						if ((j != 0) && (((localObject[4] != 100) || (localObject[5] != 115) || (localObject[6] != 105)
								|| (localObject[7] != 103)))) {
							throw new IOException(
									"Digital signature is missing in the movie. Please contact your system administrator");
						}
					}

					int i2 = 0;
					while (i2 < contentlength) {
						int i3 = socketDataInputStream.read(localObject, i2, contentlength - i2);
						LOGGER.info(i3 + " bytes loaded");
						if (i3 <= 0) {
							System.out.println("ERROR ret <= 0");
							throw new IOException("Read data from network failed");
						}

						i2 += i3;
					}

					if (!(contentType.equalsIgnoreCase("video/quicktime"))) {
						LOGGER.info("ERROR: content type is " + contentType);
						LOGGER.info(new String(localObject));
						throw new IOException("Export failed due server issues");
					}

					if (seekOffset != 0L) {
						LOGGER.info("Moving offset to>>" + seekOffset);
						localRandomAccessFile.seek(seekOffset);
						seekOffset = 0L;
					}

					LOGGER.info("Writing Content [" + localObject + "], contentlength=" + contentlength
							+ " into outputstream");
					localRandomAccessFile.write(localObject, 0, contentlength);

					contentlength = -1;
				}

			}
			if (downloadCompleted) {
				LOGGER.info("Downloaded successfully");
			} else {
				LOGGER.info("Download failed");
			}
		} finally {
			if (localRandomAccessFile != null)
				localRandomAccessFile.close();
			if (socketDataInputStream != null)
				socketDataInputStream.close();
			if (socketOutputStream != null)
				socketOutputStream.close();
		}
	}

	private <T> String getEventDisplayMessage(String type, int input) {
		String displayMsg = input+ "";
		switch (type) {
			case VideoNext.EVENT_SRC:
				displayMsg = messageSource.getMessage(VideoNext.EVENT_SRC + "_" + input, new Object[] {}, type,
						Locale.ENGLISH);
				break;
			case VideoNext.EVENT_PRIORITY:
				displayMsg = messageSource.getMessage(VideoNext.EVENT_PRIORITY + "_" + input, new Object[] {},
						type, Locale.ENGLISH);
				break;
			case VideoNext.EVENT_LIFESPAN:
				displayMsg = messageSource.getMessage(VideoNext.EVENT_LIFESPAN + "_" + input, new Object[] {},
						type, Locale.ENGLISH);
				break;
			case VideoNext.EVENT_EVENTTYPE:
				displayMsg = messageSource.getMessage(VideoNext.EVENT_EVENTTYPE + "_" + input, new Object[] {},
						type, Locale.ENGLISH);
				break;
		}
		return displayMsg;
	}
}
