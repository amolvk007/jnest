package com.smartcity.service;

import java.io.Serializable;
import java.util.List;

import com.smartcity.jsonbean.User;
import com.smartcity.jsonbean.UserResponse;
import com.smartcity.jsonbean.Role;
import com.smartcity.jsonbean.RoleResponse;

public interface RoleManagerService {
	List<RoleResponse> getRole();
	Serializable addRole(Role role);
	void updateRole(Role role);
	void deleteRole(Role role);
	boolean isRoleExist(Role role) ;
}
