package com.smartcity.service;

public interface SensorPresetManagerService {
	
	public String createSensorPreset(String sensorid);
}
