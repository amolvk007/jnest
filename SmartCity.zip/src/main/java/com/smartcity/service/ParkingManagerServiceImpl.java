package com.smartcity.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.smartcity.jsonbean.ParkingLotDetails;

@Service
public class ParkingManagerServiceImpl implements ParkingManagerService	{

	@Override
	public List<ParkingLotDetails> getParkingLotDetails(String districtId) {

		List<ParkingLotDetails> parkingLotDetailsList = new ArrayList<ParkingLotDetails>(); 
		ParkingLotDetails parkingLotDetails = new ParkingLotDetails();		
		parkingLotDetails.setLotName("Lot A");
		parkingLotDetails.setAvailability("55");
		
		ParkingLotDetails parkingLotDetails2 = new ParkingLotDetails();		
		parkingLotDetails2.setLotName("Lot B");
		parkingLotDetails2.setAvailability("90");
	
		ParkingLotDetails parkingLotDetails3 = new ParkingLotDetails();		
		parkingLotDetails3.setLotName("Lot C");
		parkingLotDetails3.setAvailability("67");
	
		parkingLotDetailsList.add(parkingLotDetails);
		parkingLotDetailsList.add(parkingLotDetails2);
		parkingLotDetailsList.add(parkingLotDetails3);

		return parkingLotDetailsList;
	}

}
