package com.smartcity.service;

import java.io.Serializable;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.smartcity.dao.RoleManagerDao;
import com.smartcity.dbbean.ScRoleEntity;
import com.smartcity.exception.InvalidInputException;
import com.smartcity.jsonbean.Role;
import com.smartcity.jsonbean.RoleResponse;
import com.smartcity.util.RoleManagerUtil;

@Transactional
@Service
public class RoleManagerServiceImpl implements RoleManagerService {

	@Autowired
	RoleManagerDao roleManagerDao;

	@Override
	public List<RoleResponse> getRole() {
		List<ScRoleEntity> rolelist = roleManagerDao.loadAll();
		return RoleManagerUtil.getRoleList(rolelist);
	}

	@Override
	public Serializable addRole(Role role) {
		ScRoleEntity scRoleEntity = RoleManagerUtil.RoleToScRoleEntity(role);
		return roleManagerDao.insert(scRoleEntity);
	}

	@Override
	public void updateRole(Role role) {
		ScRoleEntity scRoleEntity = RoleManagerUtil.RoleToScRoleEntity(role);
		roleManagerDao.update(scRoleEntity);
	}

	@Override
	public void deleteRole(Role role) {
		ScRoleEntity scRoleEntity = RoleManagerUtil.RoleToScRoleEntity(role);
		roleManagerDao.delete(scRoleEntity);
	}

	@Override
	public boolean isRoleExist(Role role) {
		ScRoleEntity dbscRoleEntity = roleManagerDao.getObjectById(role.getId());
		if (null == dbscRoleEntity) {
			throw new InvalidInputException("invalideRoleId", new Object[] { "invalideRoleId" });
		}
		return true;
	}

}
