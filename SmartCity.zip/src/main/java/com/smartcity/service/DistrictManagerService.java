package com.smartcity.service;

import java.util.List;

import com.smartcity.common.RequestParameter;
import com.smartcity.jsonbean.District;
import com.smartcity.jsonbean.DistrictDashboardData;
import com.smartcity.jsonbean.DistrictGateway;
import com.smartcity.jsonbean.DistrictGatewayAssociation;
import com.smartcity.jsonbean.DistrictId;
import com.smartcity.jsonbean.DistrictList;
import com.smartcity.jsonbean.DistrictSummary;
import com.smartcity.jsonbean.Gateway;
import com.smartcity.jsonbean.UpdateDistrictPresetRequest;

public interface DistrictManagerService {

	/**
	 * Return list of District and gateways associated with district each
	 * 
	 * @param requestParameter Request parameter including sorting and filtering
	 * @param page page number
	 * @param recordePerPage page size for records
	 * @return List of District and gateways associated with District
	 */
	public List<DistrictList> getDistricts(RequestParameter requestParameter, int page, int recordsPerPage);
	
	/**
	 * Returns district Summary
	 * 
	 * @param districtId
	 * @return district summary
	 */
	public DistrictSummary getDistrictSummary(String districtId);
	/**
	 * @param districtId Unique district Id
	 * @param userId Unique user id
	 * @return Returns district summary
	 */
	public List<DistrictDashboardData> getDistrictDashboardData(String districtId, String userId);
	/**
	 * Creates district with name and coordinates
	 * 
	 * @param district details
	 * @return newly generated district id
	 */
	public DistrictId createCustomDistrict(District district);
	
	
	/**
	 * Update district with name and coordinates.
	 * 
	 * @param district details
	 * @param id District ID
	 * @return districtId Id of the updated district
	 */
	public DistrictId updateCustomDistrict(District district, String id);
	
	/**
	 * Delete district details.
	 * 
	 * @param districtIds list of district Ids
	 * @return districtId Id of the updated district
	 */
	public String deleteDistricts(List<DistrictId> districtIds);
	
	/**
	 * Get district gateways
	 * 
	 * @return List of gateway Id's associated with District
	 */
	public List<Gateway> getDistrictGateways(String districtId);

	/**
	 * @param districtGateway Associated gateway list for district ID
	 */
	public void addDistrictGatewayAssociation(DistrictGateway districtGateway);
	
	/**
	 * @param districtIds List of districtIds
	 * @return Custom message
	 */
	public String deleteDistrictGatewayMapping(List<DistrictId> districtIds);

	/**
	 * Return list of District and gateways associated with district each
	 * 
	 * @param requestParameter Request parameter including sorting and filtering
	 * @param page page number
	 * @param recordePerPage page size for records
	 * @return List of District and gateways associated with District
	 */
	public List<DistrictGatewayAssociation> getDistrictGatewayList(RequestParameter requestParameter, int page, int recordsPerPage);

	/**
	 * @return List of districts
	 */
	public List<DistrictList> getDistricts();

	/**
	 * @param updateDistrictPresetRequest Preset details
	 */
	public void updateDistrictPresets(UpdateDistrictPresetRequest updateDistrictPresetRequest);

}
