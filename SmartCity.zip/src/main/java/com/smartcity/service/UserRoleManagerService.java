package com.smartcity.service;

import java.io.Serializable;

import com.smartcity.dbbean.SCUserRoleEntity;

public interface UserRoleManagerService {
	

	Serializable addUserRoleAssociation(SCUserRoleEntity sCUserRoleEntity);

	void updateUserRoleAssociation(SCUserRoleEntity sCUserRoleEntity);

	void deleteUserRoleAssociation(SCUserRoleEntity sCUserRoleEntity);
	
	SCUserRoleEntity findByUserId(String userid);
}
