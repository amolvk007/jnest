package com.smartcity.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.smartcity.dao.EventPresetDao;
import com.smartcity.dao.PoleManagerDao;
import com.smartcity.dao.PolePresetManagerDao;
import com.smartcity.dbbean.EventPresetEntity;
import com.smartcity.dbbean.PoleEntity;
import com.smartcity.dbbean.PolePresetEntity;
import com.smartcity.dbbean.PoleSensorEntity;
import com.smartcity.dbbean.SensorEntity;
import com.smartcity.dbbean.SensorPresetEntity;
import com.smartcity.util.EventPresetManagerUtil;

@Transactional
@Service
public class PolePresetManagerServiceImpl implements PolePresetManagerService {

	
	@Autowired
	private SensorManagerService sensorManagerService;
	
	@Autowired
	PolePresetManagerDao polePresetManagerDao;
	
	@Autowired
	EventPresetDao eventPresetDao;
	
	@Autowired
	PoleManagerDao poleManagerDao;

	@Override
	public void createPolePreset(String poleid) {
		EventPresetEntity defaultEventPresetEntity = eventPresetDao.getDefaultPresetEventEntity();
		EventPresetEntity newEventPresetEntity=	EventPresetManagerUtil.convertDefaultPreset(defaultEventPresetEntity);
		newEventPresetEntity.setName("Pole  Event");
		String eventid=(String) eventPresetDao.insert(newEventPresetEntity);
		PoleEntity poleEntity=poleManagerDao.getObjectById(poleid);
		EventPresetEntity eventPresetEntity=eventPresetDao.getObjectById(eventid);
		PolePresetEntity polePresetEntity= new PolePresetEntity();
		polePresetEntity.setEventPreset(eventPresetEntity);
		polePresetEntity.setPole(poleEntity);
		String polervrntid=(String) polePresetManagerDao.insert(polePresetEntity);
		if((polervrntid != null ) && (poleEntity.getPoleSensors().size()>0)){
			sensorManagerService.updateAllSensorPresets(poleEntity.getPoleSensors(), eventPresetEntity);
		}
	}

}
