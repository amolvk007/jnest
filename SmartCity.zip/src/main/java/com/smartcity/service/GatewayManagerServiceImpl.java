package com.smartcity.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.smartcity.dao.DistrictManagerDao;
import com.smartcity.dao.EventPresetDao;
import com.smartcity.dao.GatewayManagerDao;
import com.smartcity.dao.GatewayPresetDao;
import com.smartcity.dao.PoleManagerDao;
import com.smartcity.dao.PoleSensorMappingDao;
import com.smartcity.dao.SensorManagerDao;
import com.smartcity.dbbean.DistrictGatewayMappingEntity;
import com.smartcity.dbbean.EventPresetEntity;
import com.smartcity.dbbean.GatewayEntity;
import com.smartcity.dbbean.GatewayIOTEntity;
import com.smartcity.dbbean.GatewayPresetEntity;
import com.smartcity.dbbean.PoleEntity;
import com.smartcity.dbbean.PoleSensorEntity;
import com.smartcity.exception.InvalidInputException;
import com.smartcity.exception.SmartCityDBException;
import com.smartcity.jsonbean.AllGatewayList;
import com.smartcity.jsonbean.CreateGatewayRequest;
import com.smartcity.jsonbean.GatewayList;
import com.smartcity.jsonbean.GatewayPoleAssociationList;
import com.smartcity.jsonbean.GatewayPoleAssociationRequest;
import com.smartcity.jsonbean.GatewaySummary;
import com.smartcity.jsonbean.GatewayType;
import com.smartcity.jsonbean.Pole;
import com.smartcity.jsonbean.Sensor;
import com.smartcity.jsonbean.StreetLightSummary;
import com.smartcity.jsonbean.UpdateGatewayPresetRequest;
//import com.smartcity.jsonbean.s2c.GatewayIOTDetails;
import com.smartcity.jsonbean.s2c.GatewayIOTDetailsRequest;
import com.smartcity.jsonbean.s2c.S2CGatewayRequest;
import com.smartcity.jsonbean.s2c.S2CGatewayType;
import com.smartcity.jsonbean.s2c.S2CSendCommandToSensorsRequest;
import com.smartcity.jsonbean.s2c.VerticalBundleRequest;
import com.smartcity.jsonbean.s2c.WanPolicyRequest;
import com.smartcity.util.EventPresetManagerUtil;
import com.smartcity.util.GatewayManagerUtil;

@Service
@Transactional
public class GatewayManagerServiceImpl implements GatewayManagerService {
	private static final Logger LOGGER = Logger.getLogger(GatewayManagerServiceImpl.class);

	@Autowired
	private EventPresetDao eventPresetDao;
	
	@Autowired
	private GatewayManagerDao gatewayManagerDao;
	
	@Autowired
	private DistrictManagerDao districtManagerDao;
	
	@Autowired
	private SensorManagerService sensorManagerService;
	
	@Autowired
	private PoleManagerDao poleManagerDao;
	
	@Autowired
	private SensorManagerDao sensorManagerDao;
	
	@Autowired
	private GatewayPresetDao gatewayPresetDao;
	
	@Autowired
	private S2CAccessService s2cAccessService;
	
	@Autowired PoleManagerService poleManagerService;

	@Autowired
	PoleSensorMappingDao poleSensorMappingDao;
	@Override
	public GatewaySummary getGatewaySummary(String gatewayId) {
		LOGGER.info("In getPoleById::::: Pole Id::" + gatewayId);
		GatewaySummary gatewaySummary = new GatewaySummary();
		GatewayEntity gatewayEntity = this.gatewayManagerDao.getObjectById(gatewayId);
		if (gatewayEntity == null) {
			throw new InvalidInputException("GatewayIdNotValid", new Object[] { gatewayId });
		}
		LOGGER.info("In getGateway::::: getGatewaySummary :::" + gatewayEntity);
		gatewaySummary = GatewayManagerUtil.getGatewaySummary(gatewayEntity);
		//
		//get GatewayIOT parameters from s2c anu
		GatewayIOTDetailsRequest gatewayIOTDetailsRequest=new GatewayIOTDetailsRequest();
		List<String>gateways=new ArrayList<String>(1);
		gateways.add(gatewayId);
		gatewayIOTDetailsRequest.setGatewayIds(gateways);
		//uncomment below code for s2c 2.5
		
	/*	List<GatewayIOTDetails> gatewayIOTDetails=s2cAccessService.getGatewayIOTDetails(gatewayId);
		//set GatewayIOTDetails to gatewaySummary
		
		if(gatewayIOTDetails!=null && gatewayIOTDetails.size()>0)
		{
			gatewaySummary.setRam(gatewayIOTDetails.get(0).getTotalRAM());
			gatewaySummary.setWifi(gatewayIOTDetails.get(0).getWiFi());
			gatewaySummary.setStorage(gatewayIOTDetails.get(0).getTotalStorage());
			gatewaySummary.setBattery(gatewayIOTDetails.get(0).getBattery());
			gatewaySummary.setBluetooth(gatewayIOTDetails.get(0).getBluetooth());
			gatewaySummary.setSecurity("Dummy"); //To DO dummy when get s2c value
			gatewaySummary.setIp(gatewayIOTDetails.get(0).getGatewayIP());
			gatewaySummary.setNetwork(gatewayIOTDetails.get(0).getEthernet());
		}		
	*/	
		
		//Remove below code when s2c 2.5 is integrated
		
		gatewaySummary.setRam("20%");
		gatewaySummary.setWifi("ON");
		gatewaySummary.setStorage("25%");
		gatewaySummary.setBattery("70%");
		gatewaySummary.setBluetooth("OFF");
		gatewaySummary.setSecurity("VSP");
		gatewaySummary.setIp("10.22.121.36");
		gatewaySummary.setNetwork("3G");
		
		// get streetlight
		StreetLightSummary streetLights = gatewayManagerDao.getStreetLightSummaryByGateway(gatewayId);
		gatewaySummary.setStreetLights(streetLights);
		return gatewaySummary;
	}

	@Override
	public List<GatewayType> getGatewayTypeList() throws Exception {
		List<S2CGatewayType> gatewayTypeList = s2cAccessService.getGatewayTypeList(1);
		List<GatewayType> finalGatewayTypeList = new ArrayList<GatewayType>();
		if(!gatewayTypeList.isEmpty()) {
			finalGatewayTypeList = GatewayManagerUtil.getGatewayTypeList(gatewayTypeList);
		}  else {
			throw new Exception("Gateway type not registered with S2C for SmartCity Vertical.");
		}
		
		return finalGatewayTypeList;
	}

	@Override
	public String createGateway(CreateGatewayRequest gatewayRequest) throws Exception {
		
		boolean gatewayNameExist = this.gatewayManagerDao.isGatewayNameExist(gatewayRequest.getGatewayName());
		String gatewayId = null;
		
		if (!gatewayNameExist)
		{
			S2CGatewayRequest s2cGatewayRequest = GatewayManagerUtil.convertToS2CGatewayRequest(gatewayRequest);
			gatewayId = s2cAccessService.createGateway(s2cGatewayRequest,1);
			if(gatewayId!=null) {			
				GatewayEntity gatewayEntity = GatewayManagerUtil.convertToGatewayEntity(gatewayRequest, gatewayId);
				String gwId =(String) gatewayManagerDao.insert(gatewayEntity);
				if(gwId!=null && !gwId.equalsIgnoreCase(""))
				{
					
					EventPresetEntity defaultPresetEvent = this.eventPresetDao.getDefaultPresetEventEntity();
					EventPresetEntity newPresetEvent = EventPresetManagerUtil
							.convertDefaultPreset(defaultPresetEvent);
					
					newPresetEvent.setName("Gateway event");
					
					String eventPresetId = (String)this.eventPresetDao.insert(newPresetEvent);				
				
					String presetId = this.gatewayPresetDao.addDefaultGatewayPreset(gatewayId,eventPresetDao.getObjectById(eventPresetId));
				}
			} else {
				throw new Exception("Error while creating new gateway");
			}
		}
		else {
			throw new com.smartcity.exception.SmartCityDBException(
					"Gateway name " + gatewayRequest.getGatewayName() + " already exist");
		}
		
		return gatewayId;
	}

	@Override
	public List<GatewayList> getGatewayList() {
		List<GatewayEntity> gatewayEntities = gatewayManagerDao.loadAll();
		List<GatewayList> gatewayLists = GatewayManagerUtil.convertToGatewayList(gatewayEntities);
		return gatewayLists;
	}
	@Override
	public Map<String, List<String>> deleteGateway(List<String> gatewayIds) throws Exception {
		List<String> failedGatewayIds = new ArrayList<String>();
		List<String> successGatewayIds = new ArrayList<String>();
		for(String gatewayId : gatewayIds) {
			GatewayEntity gatewayEntity = gatewayManagerDao.getObjectById(gatewayId);
			
			if((gatewayEntity.getPoles()==null || gatewayEntity.getPoles().size()==0) && gatewayEntity.getGatewayMappingEntity()==null) {
				Boolean isSuccessful = s2cAccessService.deleteGateway(gatewayId,1);
				if(isSuccessful) {
					String presetid = gatewayEntity.getGatewayPresets().getId();
					gatewayPresetDao.delete(presetid);
					
					gatewayManagerDao.delete(gatewayId);
					successGatewayIds.add(gatewayId);
				}
			} else {
				failedGatewayIds.add(gatewayId);
			}
		}
		Map<String, List<String>> result = new HashMap<String, List<String>>();
		result.put("fail", failedGatewayIds);
		result.put("pass", successGatewayIds);
		return result;
	}

	@Override
	public void associatePoles(GatewayPoleAssociationRequest gatewayPoleAssociationRequest) throws Exception {
		GatewayEntity gatewayEntity = gatewayManagerDao.getObjectById(gatewayPoleAssociationRequest.getGatewayId());
		
		List<Pole> poles = poleManagerDao.getGatewayPoles(gatewayPoleAssociationRequest.getGatewayId());
		List<Sensor> sensors = new ArrayList<Sensor>();
		List<String> poleIdToDelete = new ArrayList<String>();
		for(Pole pole : poles) {
			if(isPoleIdExist(pole.getId(), gatewayPoleAssociationRequest.getPoleIdList())){
				continue;
			}
			poleIdToDelete.add(pole.getId());
			sensors.addAll(sensorManagerDao.getPoleSensors(pole.getId()));
		}
		
		boolean isSuccessful = sensors.size() > 0 ? s2cAccessService.dessociateGatewaySensors(gatewayPoleAssociationRequest.getGatewayId(), sensors,1) : true;
		
		if(isSuccessful) {
			poleManagerDao.dessociatePoles(gatewayEntity, poleIdToDelete);
			sensors.clear();
			for(String poleId : gatewayPoleAssociationRequest.getPoleIdList()) {
				if(isPoleExist(poleId,poles)){
					continue;
				}
				sensors.addAll(sensorManagerDao.getPoleSensors(poleId));
			}
			
			isSuccessful = s2cAccessService.associateGatewaySensors(gatewayPoleAssociationRequest.getGatewayId(), sensors,1);
			isSuccessful=true;
			if(isSuccessful) {
				poleManagerDao.associatePoles(gatewayEntity, gatewayPoleAssociationRequest.getPoleIdList());
				
				PoleEntity pole = poleManagerDao.getObjectById(gatewayPoleAssociationRequest.getPhysicalPoleId());
				if(pole!=null) {
					pole.setIsGateway((byte) 1);
					poleManagerDao.update(pole);
				}

			} else {
				throw new Exception("Error while associating sensors to gateway from S2C in associate poles");
			}
		} else {
			throw new Exception("Error while associating sensors to gateway from S2C in associate poles");
		}
	}

	@Override
	public void dessociatePoles(GatewayPoleAssociationRequest gatewayPoleAssociationRequest) throws Exception {
		GatewayEntity gatewayEntity = gatewayManagerDao.getObjectById(gatewayPoleAssociationRequest.getGatewayId());
		
		List<Sensor> sensors = new ArrayList<Sensor>();
		for(String poleId : gatewayPoleAssociationRequest.getPoleIdList()) {
			sensors.addAll(sensorManagerDao.getPoleSensors(poleId));
		}
		
		Boolean isSuccessful = s2cAccessService.dessociateGatewaySensors(gatewayPoleAssociationRequest.getGatewayId(), sensors,1);
		
		if(isSuccessful) {
			poleManagerDao.dessociatePoles(gatewayEntity, gatewayPoleAssociationRequest.getPoleIdList());
		} else {
			throw new Exception("Error while dessociating sensors to gateway from S2C in associate poles");
		}
	}

	@Override
	public List<GatewayPoleAssociationList> getGatewayPoleAssociationList() {
		List<PoleEntity> poleEntities = poleManagerDao.loadAll();
		List<GatewayPoleAssociationList> gatewayPoleAssociationLists = GatewayManagerUtil.convertToGatewayPoleAssociationList(poleEntities);
		return gatewayPoleAssociationLists;
	}

	@Override
	public Boolean updateGateway(String gatewayId, CreateGatewayRequest gatewayRequest) throws Exception {
		S2CGatewayRequest s2cGatewayRequest = GatewayManagerUtil.convertToS2CGatewayRequest(gatewayRequest);
		Boolean isSuccessful = s2cAccessService.updateGateway(gatewayId, s2cGatewayRequest,1);
		
		if(isSuccessful) {
			GatewayEntity gatewayEntity = GatewayManagerUtil.convertToGatewayEntity(gatewayRequest, gatewayId);
			gatewayManagerDao.update(gatewayEntity);
		} else {
			throw new Exception("Error while updating gateway");
		}
		
		return isSuccessful;		
	}

	@Override
	public GatewayList getGatewayDetails(String gatewayId) {
		final GatewayEntity gatewayEntity = gatewayManagerDao.getObjectById(gatewayId);
		List<GatewayList> gatewayLists = GatewayManagerUtil.convertToGatewayList(new ArrayList<GatewayEntity>() {{add(gatewayEntity);}});
		return gatewayLists.get(0);
	}
	
	@Override
	public List<AllGatewayList> getGateways() {
		List<AllGatewayList> gatewayLists = gatewayManagerDao.getGateways();
		return gatewayLists;
	}
	
	@Override
	public List<Pole> getGatewayPoles(String gatewayId) {
		List<Pole> poles = poleManagerDao.getGatewayPoles(gatewayId);
		return poles;
	}

	@Override
	public void UpdateGatewayPoleAssociation(GatewayPoleAssociationRequest gatewayPoleAssociationRequest) throws Exception {
		GatewayEntity gatewayEntity = gatewayManagerDao.getObjectById(gatewayPoleAssociationRequest.getGatewayId());
		
		List<Pole> poles = poleManagerDao.getGatewayPoles(gatewayPoleAssociationRequest.getGatewayId());
		List<Sensor> sensors = new ArrayList<Sensor>();
		for(Pole pole : poles) {
			sensors.addAll(sensorManagerDao.getPoleSensors(pole.getId()));
		}
		
		Boolean isSuccessful = s2cAccessService.dessociateGatewaySensors(gatewayPoleAssociationRequest.getGatewayId(), sensors,1);
		
		if(isSuccessful) {
			poleManagerDao.dessociatePoles(gatewayEntity, gatewayPoleAssociationRequest.getPoleIdList());
			
			for(String poleId : gatewayPoleAssociationRequest.getPoleIdList()) {
				sensors.addAll(sensorManagerDao.getPoleSensors(poleId));
			}
			
			isSuccessful = s2cAccessService.associateGatewaySensors(gatewayPoleAssociationRequest.getGatewayId(), sensors,1);
			if(isSuccessful) {
				poleManagerDao.associatePoles(gatewayEntity, gatewayPoleAssociationRequest.getPoleIdList());
				
				if(gatewayPoleAssociationRequest.getPhysicalPoleId()!=null) {
					PoleEntity pole = poleManagerDao.getObjectById(gatewayPoleAssociationRequest.getPhysicalPoleId());
					if(pole!=null) {
						pole.setIsGateway((byte) 1);
						poleManagerDao.update(pole);
					}
				}
			} else {
				throw new Exception("Error while associating sensors to gateway from S2C in associate poles");
			}
		} else {
			throw new Exception("Error while associating sensors to gateway from S2C in associate poles");
		}
	}
	
	@Override
	public List<GatewayList> getOrphanGateways() {
		List<GatewayList> gatewayLists = gatewayManagerDao.getOrphanGateways();
		return gatewayLists;
	}

	@Override
	public boolean isGatewayIdExist(String gatewayId) {
		GatewayEntity gatewayEntity = gatewayManagerDao.getObjectById(gatewayId);
		if (null == gatewayEntity) {
			throw new InvalidInputException("GatewayIdNotValid", new Object[] { gatewayId });
		}
		return true;
	}

	@Override
	public Map<String, List<String>> dessociateGatewaysPoles(List<String> gatewayIds) throws Exception {
		List<String> failedGatewayIds = new ArrayList<String>();
		List<String> successGatewayIds = new ArrayList<String>();
		for (String gatewayId : gatewayIds) {
			GatewayEntity gatewayEntity = gatewayManagerDao.getObjectById(gatewayId);

			List<PoleEntity> poles = gatewayEntity.getPoles();

			List<Sensor> sensors = new ArrayList<Sensor>();
			for (PoleEntity pole : poles) {
				sensors.addAll(sensorManagerDao.getPoleSensors(pole.getId()));
			}

			Boolean isSuccessful = s2cAccessService.dessociateGatewaySensors(gatewayId, sensors, 1);

			if (isSuccessful) {
				poleManagerDao.dessociateGatewaysPoles(gatewayEntity, poles);
				successGatewayIds.add(gatewayId);
			} else {
				failedGatewayIds.add(gatewayId);
			}
		}
		Map<String, List<String>> result = new HashMap<String, List<String>>();
		result.put("fail", failedGatewayIds);
		result.put("pass", successGatewayIds);
		return result;
	}

	@Override
	public void updateGatewayListPreset(List<DistrictGatewayMappingEntity> districtGatewayMapping, EventPresetEntity eventPresetEntity )
	{
		if(null!=districtGatewayMapping && !districtGatewayMapping.isEmpty())
		{
			//update gateway-prest for  Gateway under District
			for(DistrictGatewayMappingEntity disGwMapp : districtGatewayMapping)	
			{
				GatewayEntity gatewayEntity=disGwMapp.getGateway();
				GatewayPresetEntity gatewayPresetEntity=gatewayEntity.getGatewayPresets();
				EventPresetEntity gatewayEventPresetEntity=gatewayPresetEntity.getEventPreset();
				// adding new preset
				gatewayEntity=GatewayManagerUtil.convertCurrentPresetsToNewPresetEntity(gatewayEntity, gatewayPresetEntity,gatewayEventPresetEntity, eventPresetEntity);
				this.gatewayManagerDao.saveUpdate(gatewayEntity);
				//update pole-preset for poles under Gateway				
				List<PoleEntity> poleList = gatewayEntity.getPoles();				
				if(poleList!=null && !poleList.isEmpty())
				{
					this.poleManagerService.updateAllPolePresets(poleList, eventPresetEntity);
				}
			
			}
			
		
		}
	}
	@Override
	public void updateGatewayPresets(UpdateGatewayPresetRequest updateGatewayPresetRequest) {
		boolean sensorExists = false;
		GatewayEntity gatewayEntity=gatewayManagerDao.getObjectById(updateGatewayPresetRequest.getGatewayId());
		if (null == gatewayEntity) {
			throw new SmartCityDBException("", new Object[] { updateGatewayPresetRequest.getGatewayId() });
		}
		GatewayPresetEntity gatewayPresetEntity = null;
		EventPresetEntity eventPresetEntity = null;	

		gatewayPresetEntity = gatewayEntity.getGatewayPresets();
		
		List<Sensor> gatewaySensors=sensorManagerService.getSensorsForGateway(updateGatewayPresetRequest.getGatewayId());
		if (null != gatewaySensors && gatewaySensors.size() > 0) {
		S2CSendCommandToSensorsRequest s2CSendCommandToSensorsRequest = GatewayManagerUtil.convertToS2CSensorRequest(updateGatewayPresetRequest, gatewaySensors);
		String response = s2cAccessService.sendCommandToSensors(s2CSendCommandToSensorsRequest);
		if (!response.equals("200")) {
			throw new InvalidInputException(response, new Object[] { response });
		} else {
			sensorExists = true;
		}
	}
		if (!sensorExists) {
			throw new InvalidInputException("GATEWAYSENSORASSOCIATION_NOT_FOUND",
					new Object[] { updateGatewayPresetRequest.getGatewayId() });
		}
		if(gatewayPresetEntity!=null)
		{
			eventPresetEntity= this.eventPresetDao.getObjectById(gatewayPresetEntity.getPresetId());		
			
			// adding new preset
			gatewayEntity=GatewayManagerUtil.convertGatewayPresetsToGatewayEntity(updateGatewayPresetRequest,gatewayEntity, gatewayPresetEntity, eventPresetEntity);
	
			
			this.gatewayManagerDao.saveUpdate(gatewayEntity);
			
			//update pole-prest for poles under Gateway
			List<PoleEntity> poleList = gatewayEntity.getPoles();				
			if(poleList!=null && !poleList.isEmpty())
			{
				this.poleManagerService.updateAllPolePresets(poleList, eventPresetEntity);
			}
		}
		else
		{
			throw new SmartCityDBException("Default Preset for gateway not found");

		}
		
	
	}

	@Override
	public String createWanPolicy(WanPolicyRequest wanPolicyRequest) throws Exception {
		return s2cAccessService.createWanPolicy(wanPolicyRequest);
	}

	@Override
	public GatewayEntity getObjectById(String gatewayid) {
		return this.gatewayManagerDao.getObjectById(gatewayid);
	}

	@Override
	public List<PoleSensorEntity> getPoleSensorEntityById(PoleEntity poleEntity,GatewayEntity gwEntity){
		return poleSensorMappingDao.poleSensorAssociationList(poleEntity,gwEntity);
	}

	@Override
	public String createVreticalBundle(VerticalBundleRequest verticalBundleRequest) throws Exception {
		return s2cAccessService.createVreticalBundle(verticalBundleRequest);
	}

	@Override
	public String assocaiteVerticalBundleGateway(String verticalBundleId, List<String> gatewayList) throws Exception {
		// TODO Auto-generated method stub
		return s2cAccessService.assocaiteVerticalBundleGateway(verticalBundleId, gatewayList);
	}

	public boolean isPoleIdExist(String poleId, List<String> poleIdList){
		if(poleId != null && poleIdList !=null){
			for(String id : poleIdList){
				if(poleId.equalsIgnoreCase(id)){
					return true;
				}
			}
		}
		return false;
	}
	
	public boolean isPoleExist(String poleId, List<Pole> poleList){
		if(poleId != null && poleList !=null){
			for(Pole pole : poleList){
				if(poleId.equalsIgnoreCase(pole.getId())){
					return true;
				}
			}
		}
		return false;
	}
}
