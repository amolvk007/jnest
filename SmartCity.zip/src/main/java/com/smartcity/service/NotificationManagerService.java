package com.smartcity.service;

import java.io.Serializable;
import java.util.List;

import com.smartcity.common.RequestParameter;
import com.smartcity.jsonbean.EventLogResponse;
import com.smartcity.jsonbean.s2c.GatewayEventLogRequest;
import com.smartcity.jsonbean.s2c.GatewayEventRequest;

public interface NotificationManagerService {

	Serializable saveNotification(GatewayEventRequest gatewayEventRequest);
	
	Serializable saveExceptionNotification(GatewayEventLogRequest eventLog);

	List<EventLogResponse> getNotifications(RequestParameter RequestParameter, int page, int limit);
}
