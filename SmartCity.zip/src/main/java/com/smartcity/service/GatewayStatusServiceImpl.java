package com.smartcity.service;

import java.io.Serializable;
import java.util.Locale;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;

import com.smartcity.dao.GatewayManagerDao;
import com.smartcity.dao.GatewayPresetDao;
import com.smartcity.dbbean.GatewayEntity;
import com.smartcity.jsonbean.s2c.GatewayStatusRequest;

@Transactional
@Service
public class GatewayStatusServiceImpl implements GatewayStatusService {
	private static final Logger LOGGER = Logger.getLogger(GatewayStatusServiceImpl.class);
	
	@Autowired GatewayManagerDao gatewayManagerDao;
	
	@Autowired
	private MessageSource messageSource;
	
	@Override
	public Serializable saveGatewayStatus(GatewayStatusRequest gatewayStatusRequest) {
		// update status of gateways in Gateway entity
		String result=null;
		GatewayEntity gatewayEntity= gatewayManagerDao.getObjectById(gatewayStatusRequest.getGatewayId());
		if(null==gatewayEntity)
		{
			throw new com.smartcity.exception.InvalidInputException("NOSUCHGATEWAYEXIST", new Object[] { gatewayStatusRequest.getGatewayId() });
		}
		gatewayEntity.setStatus(gatewayStatusRequest.getStatus());
		gatewayManagerDao.saveUpdate(gatewayEntity);
		result=messageSource.getMessage("GATEWAYSTAUSUPDATED", new Object[] {gatewayStatusRequest.getGatewayId() }, Locale.ENGLISH);
		return result;
	}
	

}
