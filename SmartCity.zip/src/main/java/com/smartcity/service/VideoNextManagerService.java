package com.smartcity.service;

import java.util.List;

import javax.servlet.http.HttpServletResponse;

import com.smartcity.jsonbean.videonext.Event;

public interface VideoNextManagerService {
	public List<Event> getEventLog(int page, int limit);
	public void getVideFootageStream(int objectId, String fromDate, String toDate, HttpServletResponse response);
}
