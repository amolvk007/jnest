/**
 * 
 */
package com.smartcity.service;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import java.util.UUID;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.smartcity.dao.TokenManagerDao;
import com.smartcity.dao.TokenManagerDaoImpl;
import com.smartcity.dbbean.SCToken;

/**
 * @author inrpande01
 *
 */
@Service
@Transactional
public class TokenManagerServiceImpl implements TokenManagerServices {

	@Autowired
	private TokenManagerDao tokenDao;

	private static final Logger LOGGER = Logger.getLogger(TokenManagerDaoImpl.class);

	// private static final Logger logger =
	// LoggerFactory.getLogger(MyTokenService.class);
	// private static final Cache restApiAuthTokenCache =
	// CacheManager.getInstance().getCache("restApiAuthTokenCache");
	// private static final Cache restApiAuthTokenCache =
	// CacheManager.getInstance().getCache("ehcache");

	public static final int FIVE_MINUTE_IN_MILISECONDS = 5 * 60 * 1000;

	/*
	 * @Scheduled(fixedRate = HALF_AN_HOUR_IN_MILLISECONDS) public void
	 * evictExpiredTokens() { // logger.info("Evicting expired tokens"); //
	 * restApiAuthTokenCache.evictExpiredElements(); }
	 */

	/*
	 * public void evictExpiredTokens(String Token) { // logger.info(
	 * "Evicting expired tokens"); restApiAuthTokenCache.evictExpiredElements();
	 * 
	 * token.remove(Token) }
	 */

	public String generateNewToken() {

		return UUID.randomUUID().toString();
	}

	@Override
	public SCToken getToken(String token) {
		// TODO Auto-generated method stub
		LOGGER.info("MyTokenService:::getToken:::: ");
		return tokenDao.findToken(token);
	}

	@Override
	public SCToken generateToken(String username) {
		SCToken gentoken = new SCToken();
		gentoken.setToken(generateNewToken());
		gentoken.setUsername(username);
		gentoken.setCreatedDate(new Timestamp(new Date().getTime() + FIVE_MINUTE_IN_MILISECONDS));
		Serializable genid = tokenDao.saveToken(gentoken);
		if (genid != null) {
			return gentoken;
		}
		return null;
	}

	@Override
	public void deleteToken(String username) {
		tokenDao.deleteToken(username);
	}

	@Override
	public SCToken getTokenByUserName(String username) {
		return tokenDao.getTokenByUserName(username);
	}

}
