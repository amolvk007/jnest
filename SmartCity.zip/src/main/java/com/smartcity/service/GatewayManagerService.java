package com.smartcity.service;

import java.util.List;
import java.util.Map;

import com.smartcity.dbbean.DistrictGatewayMappingEntity;
import com.smartcity.dbbean.EventPresetEntity;
import com.smartcity.dbbean.GatewayEntity;
import com.smartcity.dbbean.PoleEntity;
import com.smartcity.dbbean.PoleSensorEntity;
import com.smartcity.jsonbean.AllGatewayList;
import com.smartcity.jsonbean.CreateGatewayRequest;
import com.smartcity.jsonbean.GatewayList;
import com.smartcity.jsonbean.GatewayPoleAssociationList;
import com.smartcity.jsonbean.GatewayPoleAssociationRequest;
import com.smartcity.jsonbean.GatewaySummary;
import com.smartcity.jsonbean.GatewayType;
import com.smartcity.jsonbean.Pole;
import com.smartcity.jsonbean.UpdateGatewayPresetRequest;
import com.smartcity.jsonbean.s2c.VerticalBundleRequest;
import com.smartcity.jsonbean.s2c.WanPolicyRequest;

public interface GatewayManagerService {
	public GatewaySummary getGatewaySummary(String gatewayId);

	public List<GatewayType> getGatewayTypeList() throws Exception;

	public String createGateway(CreateGatewayRequest gatewayRequest) throws Exception;

	public List<GatewayList> getGatewayList();

	public Map<String, List<String>> deleteGateway(List<String> gatewayIds) throws Exception;

	public void associatePoles(GatewayPoleAssociationRequest gatewayPoleAssociationRequest) throws Exception;

	public void dessociatePoles(GatewayPoleAssociationRequest gatewayPoleAssociationRequest) throws Exception;

	public List<GatewayPoleAssociationList> getGatewayPoleAssociationList();

	public Boolean updateGateway(String gatewayId, CreateGatewayRequest gatewayRequest) throws Exception;

	public GatewayList getGatewayDetails(String gatewayId);
	
	public List<AllGatewayList> getGateways();

	public void UpdateGatewayPoleAssociation(GatewayPoleAssociationRequest gatewayPoleAssociationRequest) throws Exception;
	
	public List<Pole> getGatewayPoles(String gatewayId);
	
	public List<GatewayList> getOrphanGateways();

	public boolean isGatewayIdExist(String gatewayId);

	public Map<String, List<String>> dessociateGatewaysPoles(List<String> gatewayIds) throws Exception;

	public void updateGatewayPresets(UpdateGatewayPresetRequest updateGatewayPresetRequest);

	public void updateGatewayListPreset(List<DistrictGatewayMappingEntity> districtGatewayMapping, EventPresetEntity eventPresetEntity);

	String createWanPolicy(WanPolicyRequest  wanPolicyRequest)throws Exception;
	
	GatewayEntity  getObjectById(String gatewayid);
	
	List<PoleSensorEntity> getPoleSensorEntityById(PoleEntity poleEntity, GatewayEntity gwEntity);
	String createVreticalBundle(VerticalBundleRequest verticalBundleRequest) throws Exception;
	String assocaiteVerticalBundleGateway(String verticalBundleId, List<String> gatewayList) throws Exception;
}
