package com.smartcity.service;

import java.util.List;

import com.smartcity.jsonbean.ParkingLotDetails;

public interface ParkingManagerService {

	public List<ParkingLotDetails> getParkingLotDetails(String districtId);
}
