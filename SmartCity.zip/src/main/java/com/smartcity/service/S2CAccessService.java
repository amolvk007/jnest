package com.smartcity.service;

import java.util.List;
import java.util.concurrent.Future;

import com.smartcity.jsonbean.Sensor;
import com.smartcity.jsonbean.s2c.GatewayIOTDetails;
import com.smartcity.jsonbean.s2c.S2CGatewayRequest;
import com.smartcity.jsonbean.s2c.S2CGatewayType;
import com.smartcity.jsonbean.s2c.S2CSendCommandToSensorsRequest;
import com.smartcity.jsonbean.s2c.S2CSensorRequest;
import com.smartcity.jsonbean.s2c.S2CSensorType;
import com.smartcity.jsonbean.s2c.SensorDataPoint;
import com.smartcity.jsonbean.s2c.VerticalBundleRequest;
import com.smartcity.jsonbean.s2c.VerticalBundleResponse;
import com.smartcity.jsonbean.s2c.WanPolicyRequest;

public interface S2CAccessService {
	public List<SensorDataPoint> getSensorData(String sensorId, int retryCount);

	public List<S2CGatewayType> getGatewayTypeList(int retryCount) throws Exception;

	public String createGateway(S2CGatewayRequest gatewayRequest,int retryCount) throws Exception;

	public List<S2CSensorType> getSensorTypeList(int retryCount) throws Exception;

	public String createSensor(S2CSensorRequest s2cSensorRequest, int retryCount) throws Exception;

	public Boolean deleteGateway(String gatewayId, int retryCount) throws Exception;

	public Boolean deleteSensor(String sensorId, int retryCount) throws Exception;

	public Boolean associateGatewaySensors(String gatewayId, List<Sensor> sensors, int retryCount) throws Exception;

	public Boolean dessociateGatewaySensors(String gatewayId, List<Sensor> sensors, int retryCount) throws Exception;

	public Boolean updateGateway(String gatewayId, S2CGatewayRequest s2cGatewayRequest, int retryCount) throws Exception;

	public Boolean updateSensor(String sensorId, S2CSensorRequest s2cSensorRequest, int retryCount) throws Exception;
	
	public String createWanPolicy(WanPolicyRequest  wanPolicyRequest)throws Exception;
	
	public String createVreticalBundle(VerticalBundleRequest verticalBundleRequest) throws Exception;
	
	public List<VerticalBundleResponse> getSmartCityVerticalBundles() throws Exception ;
	 
	public String assocaiteVerticalBundleGateway(String verticalBundleId, List<String> gatewayList) throws Exception;

	public String sendCommandToSensors(S2CSendCommandToSensorsRequest s2cSendCommandToSensorsRequest);

	public List<GatewayIOTDetails> getGatewayIOTDetails(String gatewayId);
}
