package com.smartcity.dao;

import org.springframework.stereotype.Repository;

import com.smartcity.dbbean.SensorClassEntity;

@Repository
public class SensorClassManagerDaoImpl extends AbstractDAOImpl<SensorClassEntity> implements SensorClassManagerDao {

	public SensorClassManagerDaoImpl() {
		super(SensorClassEntity.class);
	}

}
