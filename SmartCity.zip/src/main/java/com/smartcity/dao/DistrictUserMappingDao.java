package com.smartcity.dao;

import java.util.List;

import com.smartcity.dbbean.DistrictEntity;
import com.smartcity.dbbean.DistrictUserEntity;
import com.smartcity.dbbean.SCUserEntity;
import com.smartcity.jsonbean.UserDistrict;
import com.smartcity.jsonbean.UserId;

public interface DistrictUserMappingDao extends AbstractDAO<DistrictUserEntity> {

	void deleteDistrictUserAssociation(List<UserId> userIdList);

	List<String> getDistrictUserAssociationIds(List<SCUserEntity> sCUserEntity);

	String addDistrictUserAssociation(UserDistrict userDistrict);

}
