package com.smartcity.dao;

import org.springframework.stereotype.Repository;

import com.smartcity.dbbean.DistrictPresetEntity;
import com.smartcity.dbbean.EventPresetEntity;
import com.smartcity.util.LoggerUtil;

@Repository
public class DistrictPresetDaoImpl extends AbstractDAOImpl<DistrictPresetEntity>implements DistrictPresetDao {


	public DistrictPresetDaoImpl() {

		super(DistrictPresetEntity.class);
	}

	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public String addDefaultDistrictPreset(String districtId,EventPresetEntity defaultEvent) {

		String presetId = null;
		DistrictPresetEntity districtPresetEntity = new DistrictPresetEntity();
		try {
			
			districtPresetEntity.setDistrictId(districtId);
			districtPresetEntity.setPresetId(defaultEvent.getId());

			presetId = (String) insert(districtPresetEntity);

		} catch (Exception e) {
			LoggerUtil.logMessage("Inside getDistricts : Exception " + e.getLocalizedMessage());
		}
		return presetId;
	}	
	

}
