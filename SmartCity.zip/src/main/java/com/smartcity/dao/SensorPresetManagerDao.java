package com.smartcity.dao;

import com.smartcity.dbbean.SensorPresetEntity;

public interface SensorPresetManagerDao extends AbstractDAO<SensorPresetEntity> {

	SensorPresetEntity getSensorPresetEntityBySensorId(String senosrid);
}
