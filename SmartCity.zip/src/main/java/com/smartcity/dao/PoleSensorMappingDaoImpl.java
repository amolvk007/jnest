package com.smartcity.dao;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.smartcity.common.RequestParameter;
import com.smartcity.dbbean.EventPresetEntity;
import com.smartcity.dbbean.GatewayEntity;
import com.smartcity.dbbean.PoleEntity;
import com.smartcity.dbbean.PoleSensorEntity;
import com.smartcity.dbbean.SensorEntity;
import com.smartcity.dbbean.SensorPresetEntity;
import com.smartcity.exception.SmartCityDBException;
import com.smartcity.jsonbean.PoleSensorAssociationList;
import com.smartcity.util.SensorManagerUtil;
import com.smartcity.util.UserManagerUtil;

@Repository
public class PoleSensorMappingDaoImpl extends AbstractDAOImpl<PoleSensorEntity>implements PoleSensorMappingDao {

	private static final Logger LOGGER = Logger.getLogger(PoleSensorMappingDaoImpl.class);

	@Autowired
	SensorPresetManagerDao sensorPresetManagerDao;

	public PoleSensorMappingDaoImpl() {

		super(PoleSensorEntity.class);

	}

	public List<PoleSensorAssociationList> getPoleSensorAssociationList(RequestParameter reqParam, int page, int limt) {
		LOGGER.info("Inside PoleSensorMappingDaoImpl : getPoleSensorAssociationList()");
		Session session = getSession();
		String filterValue = "";
		String sortBy = "";
		if (null != reqParam.getFilter() && (reqParam.getFilter() != "")) {
			filterValue = reqParam.getFilter();
		}
		if ((reqParam.getSortBy() != null) && (reqParam.getSortBy() != "")) {
			if (reqParam.getSortBy().equalsIgnoreCase("name")) {
				sortBy = "poleName";
			} else if (reqParam.getSortBy().equalsIgnoreCase("createdDate")) {
				sortBy = "polesensorEntity.createddate";
			}
			if (reqParam.getSortBy().equalsIgnoreCase("modifiedDate")) {
				sortBy = "polesensorEntity.modifiedDate";
			}
		}
		List<PoleSensorAssociationList> poleSensorAssociationList = new ArrayList<PoleSensorAssociationList>();
		try {
			Criteria criteria = session.createCriteria(PoleSensorEntity.class, "polesensorEntity");
			criteria.createAlias("polesensorEntity.pole", "pole");
			if (filterValue != "") {
				criteria.add(Restrictions.like("pole.name", "%" + filterValue + "%"));
			}
			ProjectionList proList = Projections.projectionList();
			proList.add(Projections.distinct(Projections.property("pole.id").as("poleId")));
			proList.add(Projections.property("pole.name").as("poleName"));
			proList.add(Projections.property("pole.lat").as("poleLat"));
			proList.add(Projections.property("pole.longi").as("poleLongi"));
			proList.add(Projections.property("polesensorEntity.createddate").as("createdDate"));
			criteria.setProjection(proList);
			criteria.setResultTransformer(Transformers.aliasToBean(PoleSensorAssociationList.class));
			// code for sort by request
			criteria.setFirstResult((page - 1) * limt);
			criteria.setMaxResults(limt);
			if (sortBy != "") {
				String sortOrder = reqParam.getSortOrder();
				if ("desc".equalsIgnoreCase(sortOrder)) {
					criteria.addOrder(Order.desc(sortBy).ignoreCase());
				} else {
					criteria.addOrder(Order.asc(sortBy).ignoreCase());
				}
			} else {
				criteria.addOrder(Order.desc("polesensorEntity.createddate").ignoreCase());
			}
			poleSensorAssociationList = criteria.list();
			for (PoleSensorAssociationList poleSensorAssociation : poleSensorAssociationList) {
				poleSensorAssociation.setSensorName(getSensorNames(poleSensorAssociation.getPoleId()));
			}
		} catch (Exception e) {
			throw new SmartCityDBException(e.getMessage(), e);
		} finally {
			closeSession(session);

		}
		return poleSensorAssociationList;
	}

	private List<String> getSensorNames(String poleId) {

		Session session = getSession();
		List<String> poleSensorList = new ArrayList<String>();
		try {
			Criteria criteria = session.createCriteria(SensorEntity.class, "sensorEntity");
			criteria.createAlias("sensorEntity.poleSensors", "poleSensors");
			criteria.createAlias("poleSensors.pole", "pole");
			criteria.add(Restrictions.eq("pole.id", poleId));
			ProjectionList projList = Projections.projectionList();
			projList.add(Projections.property("sensorEntity.name").as("name"));
			criteria.setProjection(projList);
			criteria.addOrder(Order.asc(("name")));
			poleSensorList = criteria.list();

		} catch (Exception e) {
			throw new SmartCityDBException(e.getMessage(), e);
		} finally {
			closeSession(session);

		}
		return poleSensorList;
	}

	@Override
	public void deletePoleSensorAssociation(PoleEntity poleEntity) {
		LOGGER.info("Inside PoleSensorMappingDaoImpl : deletePoleSensorAssociation()");

		Session session = getSession();
		try {

			List<PoleSensorEntity> mappingEnity = new ArrayList<PoleSensorEntity>();
			Criteria criteria = session.createCriteria(PoleSensorEntity.class, "poleSensorEntity");
			criteria.add(Restrictions.eq("poleSensorEntity.pole", poleEntity));
			mappingEnity = criteria.list();
			delete(mappingEnity);

		} catch (Exception e) {
			throw new SmartCityDBException(e.getMessage(), e);
		} finally {
			closeSession(session);
		}

	}
	
	@Override
	public void deletePoleSensorAssociation(List<String> sensorIdList) {
		LOGGER.info("Inside PoleSensorMappingDaoImpl : deletePoleSensorAssociation()");
		Session session = getSession();
		try {
			Query query = session.createQuery("DELETE FROM PoleSensorEntity poleSensor where poleSensor.sensor.id in (:idList)");
			query.setParameterList("idList", sensorIdList);
			query.executeUpdate();
		} catch (Exception e) {
			throw new SmartCityDBException(e.getMessage(), e);
		} finally {
			closeSession(session);
		}
	}

	@Override
	public String addPoleSensorAssociation(PoleEntity poleEntity, List<SensorEntity> sensorEntityList) {

		Date date = new Date();
		String poleSensorid = "";
		//this.deletePoleSensorAssociation(poleEntity);
		for (SensorEntity sensorEntity : sensorEntityList) {
			PoleSensorEntity poleSensorEntity = new PoleSensorEntity();

			poleSensorEntity.setCreatedby(UserManagerUtil.getLoggedInUserName());
			poleSensorEntity.setCreateddate(new Timestamp(date.getTime()));
			poleSensorEntity.setModifiedby(UserManagerUtil.getLoggedInUserName());
			poleSensorEntity.setModifiedDate(new Timestamp(date.getTime()));
			poleSensorEntity.setPole(poleEntity);
			poleSensorEntity.setSensor(sensorEntity);
			if (poleSensorid == "") {
				poleSensorid = (String) insert(poleSensorEntity);
			} else {
				poleSensorid = poleSensorid + "," + (String) insert(poleSensorEntity);
			}

			// Code to update pole preset to sensor preset
			SensorEntity entity = poleSensorEntity.getSensor();
			EventPresetEntity newEventPresetEntity = SensorManagerUtil.convertCurrentPresetsToNewPresetEntity(
					entity.getSensorPresets().getEventPreset(), poleEntity.getPolePresets().getEventPreset());
			SensorPresetEntity dbsensorPresetEntity = sensorPresetManagerDao
					.getSensorPresetEntityBySensorId(entity.getId());
			dbsensorPresetEntity.setEventPreset(newEventPresetEntity);
			dbsensorPresetEntity.setSensor(entity);
			sensorPresetManagerDao.saveUpdate(dbsensorPresetEntity);

		}
		return poleSensorid;

	}
	
	@Override
	public List<PoleSensorEntity> poleSensorAssociationList(PoleEntity poleEntity,GatewayEntity geEntity)
	{
		Session session = getSession();
		List<PoleSensorEntity> mappingEnity = new ArrayList<PoleSensorEntity>();

		try {

			Criteria criteria = session.createCriteria(PoleSensorEntity.class, "poleSensorEntity");
			criteria.add(Restrictions.eq("poleSensorEntity.pole", poleEntity));
			mappingEnity = criteria.list();
			
			for(PoleSensorEntity poleSensorEntity:mappingEnity){
				SensorEntity  sensorEntity =poleSensorEntity.getSensor();
				EventPresetEntity newEventPresetEntity=SensorManagerUtil.convertCurrentPresetsToNewPresetEntity(sensorEntity.getSensorPresets().getEventPreset(),
						geEntity.getGatewayPresets().getEventPreset());
				SensorPresetEntity dbsensorPresetEntity = sensorPresetManagerDao.getSensorPresetEntityBySensorId(sensorEntity.getId());
				dbsensorPresetEntity.setEventPreset(newEventPresetEntity);
				dbsensorPresetEntity.setSensor(sensorEntity);
				this.sensorPresetManagerDao.saveUpdate(dbsensorPresetEntity);
			}
			
			
		} catch (Exception e) {
			throw new SmartCityDBException(e.getMessage(), e);
		}
		return mappingEnity;
	}


}
