package com.smartcity.dao;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;

import com.smartcity.common.RequestParameter;

/**
 * Interface defines  generic method used in Hibernate database opetations.
 *@author akhaware
 * @param <T>
 */
public interface AbstractDAO<T> {

	/**
	 * Method save object data into database and returns its new ID.
	 * @param object
	 * @return {@link Serializable}
	 */
	public Serializable insert(T object);
	
	/**
	 * Method save given collection of objects data into database.
	 * @param collection
	 */
	public void insert(Collection<T> collection);
	
	/**
	 * Method update object data into database.
	 * @param object
	 */
	public void update(T object);
	
	/**
	 * Method update given collection of objects data into database.
	 * @param collection
	 */
	public void update(Collection<T> collection);
	
	/**
	 * Method to delete given collection of objects from database.
	 * @param collection
	 */
	public void delete(List<T> collection);	

	/**
	 * Method removes object data from database.
	 * @param object
	 */
	public void delete(Serializable id);
	
	/**
	 * Method removes object data from database.
	 * @param object
	 */
	public void delete(T object);
	
	/**
	 * Method returns object for given ID.
	 * @param id
	 * @return {@link Object}
	 */
	public T getObjectById(Serializable id);
	
	/**
	 * method will return all list associated entity 
	 * @param collection
	 * @return {@link List}
	 */
	public List<T> loadAll();	
	
	
	/**
	 * Method create the session and return it.
	 * @return {@link Session}
	 */
	public Session getSession();
	
	/**
	 * Method returnc Criteria for its assocaited entity.
	 * @param session
	 * @return {@link Criteria}
	 */
	public Criteria getCriteria(Session session);
	
	/**
	 * Method close the given Session.
	 * @param session
	 */
	public void closeSession(Session session);

	public void saveUpdate(T object);

	/**
	 * Return criteria sent with pagination, sorting and filter applied.
	 * 
	 * @param criteria Existing criteria
	 * @param requestParameter Sort and filter request parameter
	 * @param page Page number
	 * @param recordsPerPage Page limit
	 * @param sortColumnName Sort column name
	 * @param entityColumName Name of the enity column name
	 * @param filterType Column name on which filter needs to apply.
	 * @return Modified criteria with above changes
	 */
	public Criteria applySortFilterPagination(Criteria criteria,RequestParameter requestParameter, int page, int recordsPerPage,String sortColumnName,String entityColumName, String filterType);

}