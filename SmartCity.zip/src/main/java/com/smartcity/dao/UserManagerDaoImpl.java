package com.smartcity.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Property;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StringType;
import org.hibernate.type.Type;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.smartcity.common.RequestParameter;
import com.smartcity.dbbean.DistrictUserEntity;
import com.smartcity.dbbean.SCUserEntity;
import com.smartcity.dbbean.SCUserRoleEntity;
import com.smartcity.jsonbean.DistrictUser;
import com.smartcity.jsonbean.DistrictUserAssociation;
import com.smartcity.util.DBQueryConstants;

@Repository
public class UserManagerDaoImpl extends AbstractDAOImpl<SCUserEntity>implements UserManagerDao {

	private static final Logger LOGGER = Logger.getLogger(UserManagerDaoImpl.class);

	public UserManagerDaoImpl() {
		super(SCUserEntity.class);
	}

	@Autowired
	RoleManagerDao roleManagerDao;

	@Override
	public String getUserDefaultDistrict(String userId) {
		LOGGER.info("Inside getUserDefaultDistrict");
		String districtId = "";
		Session session = getSession();

		Criteria criteria = session.createCriteria(SCUserEntity.class, "scuserentity");
		criteria.createAlias("scuserentity.district", "defaultdistrict");
		criteria.add(Restrictions.eq("scuserentity.id", userId));
		ProjectionList p1 = Projections.projectionList();
		p1.add(Projections.property("defaultdistrict.id"));
		criteria.setProjection(p1);
		List<Object> dataObject = criteria.list();
		for (Object obj : dataObject) {
			districtId = (String) dataObject.get(0);
			String districtEntityId = (String) criteria.list().get(0);
		}

		return districtId;
	}

	@SuppressWarnings("unchecked")
	@Override
	public SCUserEntity findByUserName(String username) {
		// TODO Auto-generated method stub

		LOGGER.info("username :::::" + username);

		List<SCUserEntity> users = new ArrayList<SCUserEntity>();
		Session session = getSession();

		users = session.createQuery("from SCUserEntity where username=:username").setParameter("username", username)
				.list();
		LOGGER.info("List Size:::::" + users.size());

		if (users.size() > 0) {
			return users.get(0);
		} else {
			return null;
		}
	}

	@Override
	public String getUserIdFromToken(String token) {
		LOGGER.info("token :::::" + token);
		String userId = "";
		Session session = getSession();
		Query query = session.createSQLQuery(DBQueryConstants.SQL_GET_USERID_FROM_TOKEM)
				.addScalar("userId", StringType.INSTANCE).setParameter("token", token);
		List<Object> userList = query.list();
		if (!userList.isEmpty()) {
			userId = (String) userList.get(0);
		}
		// TODO Auto-generated method stub
		return userId;
	}

	@Override
	public List<DistrictUserAssociation> getdistrictUserAssociationList() {

		LOGGER.info("Inside UsertManagerDaoImpl : getdistrictUserAssociationList()");

		Session session = getSession();
		List<DistrictUserAssociation> districtUserAssociationList = new ArrayList<DistrictUserAssociation>();

		try {

			Criteria criteria = session.createCriteria(SCUserEntity.class, "userEntity");
			criteria.createAlias("userEntity.scUserRole", "scuserRole");
			criteria.createAlias("scuserRole.scRole", "scrole");
			criteria.add(Restrictions.eq("scrole.name", "ROLE_USER"));
			// criteria.createAlias("userEntity.DistrictUserEntity",
			// "districtuser", JoinType.LEFT_OUTER_JOIN);
			ProjectionList proList = Projections.projectionList();
			proList.add(Projections.property("userEntity.id").as("userId"));
			proList.add(Projections.property("userEntity.username").as("userName"));
			// proList.add(Projections.property("district.name").as("defaultDistrict"));
			criteria.setProjection(proList);

			criteria.setResultTransformer(Transformers.aliasToBean(DistrictUserAssociation.class));
			criteria.addOrder(Order.desc("userEntity.createdDate").ignoreCase());

			districtUserAssociationList = criteria.list();

			for (DistrictUserAssociation districtUserAssociation : districtUserAssociationList) {
				districtUserAssociation.setDistrictName(getDistricts(districtUserAssociation.getUserId()));

			}

		} catch (Exception e) {
			LOGGER.info("Inside getDistricts : Exception " + e.getLocalizedMessage());

		} finally {
			closeSession(session);
		}
		return districtUserAssociationList;

	}

	private List<String> getDistricts(String userId) {
		Session session = getSession();

		List<String> districtNames = new ArrayList<String>();
		Criteria mappingCriteria = session.createCriteria(DistrictUserEntity.class, "districtuserMappingEntity");
		mappingCriteria.createAlias("districtuserMappingEntity.district", "districtEntity");
		mappingCriteria.add(Restrictions.eq("districtuserMappingEntity.userId", userId));
		ProjectionList proList = Projections.projectionList();
		proList.add(Projections.property("districtEntity.name"));
		mappingCriteria.setProjection(proList);

		districtNames = mappingCriteria.list();
		return districtNames;
	}

	@Override
	public List<DistrictUser> getdistrictUserList(String userId) {
		LOGGER.info("Inside dao : getdistrictUserList ");
		Session session = getSession();
		List<DistrictUser> districtUserList = new ArrayList<DistrictUser>();
		Criteria mappingCriteria = session.createCriteria(DistrictUserEntity.class, "districtuserMappingEntity");
		mappingCriteria.createAlias("districtuserMappingEntity.district", "districtEntity");
		mappingCriteria.add(Restrictions.eq("districtuserMappingEntity.userId", userId));
		ProjectionList proList = Projections.projectionList();
		proList.add(Projections.property("districtEntity.id").as("id"));
		proList.add(Projections.property("districtEntity.name").as("name"));
		mappingCriteria.setProjection(proList);
		mappingCriteria.addOrder(Order.asc("districtEntity.name").ignoreCase());
		mappingCriteria.setResultTransformer(Transformers.aliasToBean(DistrictUser.class));
		districtUserList = mappingCriteria.list();
		return districtUserList;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<SCUserEntity> getUsers(RequestParameter reqParam, int page, int limit, List<String> roleId,boolean flag) {
		List<SCUserEntity> UsersList = new ArrayList<>();
		Session session = getSession();
		String filter = "GLOBLE";
		String sortOrder = "DESC";
		String sortBy = "createdDate";
		try {

			DetachedCriteria subquery = DetachedCriteria.forClass(SCUserRoleEntity.class, "ur")
					.add(Restrictions.in("ur.roleId", roleId)).setProjection(Projections.property("ur.userId"));
			Criteria criteria = session.createCriteria(SCUserEntity.class, "u");
			criteria.add(Property.forName("u.id").notIn(subquery));
			if ((reqParam != null) && (null != reqParam.getFilter() && (reqParam.getFilter() != ""))
					&& (null != reqParam.getColumnName() && (reqParam.getColumnName() != ""))) {
				sortOrder = reqParam.getSortOrder();
				sortBy = reqParam.getSortBy();
				filter = (reqParam.getColumnName() != null ? reqParam.getColumnName() : "USERNAME").toUpperCase();
				Map<String, Type> ParameterTypes = session.enableFilter(filter).getFilterDefinition()
						.getParameterTypes();
				Set<Entry<String, Type>> entrySet = ParameterTypes.entrySet();
				for (Entry<String, Type> entry : entrySet) {
					if (entry.getKey().equalsIgnoreCase((reqParam.getColumnName()))) {
						session.enableFilter(filter).setParameter(entry.getKey(), reqParam.getFilter());
					}
				}
			}
			if ("desc".equalsIgnoreCase(sortOrder)) {
				criteria.addOrder(Order.desc(sortBy).ignoreCase());
			} else {
				criteria.addOrder(Order.asc(sortBy).ignoreCase());
			}
			if (flag) {
				// code for sort by request
				criteria.setFirstResult((page - 1) * limit);
				criteria.setMaxResults(limit);
			}
			UsersList = criteria.list();
			session.disableFilter(filter);
			if (UsersList.size() <= 0) {
				throw new com.smartcity.exception.InvalidInputException("datanotfound",
						new Object[] { "datanotfound" });
			}

		} finally {
			closeSession(session);
		}
		return UsersList;
	}

}
