package com.smartcity.dao;

import java.util.List;

import com.smartcity.dbbean.SensorEntity;
import com.smartcity.jsonbean.Sensor;

public interface SensorManagerDao extends AbstractDAO<SensorEntity>{

	List<Sensor> getOrphanSensors();

	List<Sensor> getPoleSensors(String poleId);

	List<Sensor> getSensorsForDistrict(String districtId);

	List<Sensor> getSensorsForGateway(String gatewayId);
}
