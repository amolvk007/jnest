package com.smartcity.dao;

public interface ParkingManagerDao {

}
