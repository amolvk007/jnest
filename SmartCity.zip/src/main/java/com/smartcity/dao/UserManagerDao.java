package com.smartcity.dao;

import java.util.List;

import com.smartcity.common.RequestParameter;
import com.smartcity.dbbean.SCUserEntity;
import com.smartcity.jsonbean.DistrictUser;
import com.smartcity.jsonbean.DistrictUserAssociation;

public interface UserManagerDao extends AbstractDAO<SCUserEntity> {

	String getUserDefaultDistrict(String userId);
	SCUserEntity findByUserName(String username);
	String getUserIdFromToken(String token);
	List<DistrictUserAssociation> getdistrictUserAssociationList();
	List<DistrictUser> getdistrictUserList(String userId);
	List<SCUserEntity> getUsers(RequestParameter requestParameter,int page,int limit,List<String> roleId,boolean flag);
}
