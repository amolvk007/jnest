package com.smartcity.dao;


import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.smartcity.dbbean.EventPresetEntity;
import com.smartcity.dbbean.GatewayPresetEntity;

@Repository
public class GatewayPresetDaoImpl extends AbstractDAOImpl<GatewayPresetEntity>implements GatewayPresetDao {

	private static final Logger LOGGER = Logger.getLogger(DistrictPresetDaoImpl.class);

	public GatewayPresetDaoImpl() {

		super(GatewayPresetEntity.class);
	}

	

	@Override
	public String addDefaultGatewayPreset(String gatewayId,EventPresetEntity defaultPreset ) {

		GatewayPresetEntity gatewayPresetEntity = new GatewayPresetEntity();
		String presetId = null;
		try {
			gatewayPresetEntity.setGatewayId(gatewayId);
			gatewayPresetEntity.setPresetId(defaultPreset.getId());

			presetId = (String) insert(gatewayPresetEntity);

		} catch (Exception e) {
			LOGGER.info("Inside getDistricts : Exception " + e.getLocalizedMessage());
		}
		return presetId;
	}
	


}
