package com.smartcity.dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.hibernate.type.IntegerType;
import org.hibernate.type.StringType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.smartcity.dbbean.EventPresetEntity;
import com.smartcity.dbbean.GatewayEntity;
import com.smartcity.dbbean.PoleEntity;
import com.smartcity.exception.SmartCityDBException;
import com.smartcity.jsonbean.AllGatewayList;
import com.smartcity.jsonbean.BeaconSummary;
import com.smartcity.jsonbean.DigitalSignageSummary;
import com.smartcity.jsonbean.FloodLights;
import com.smartcity.jsonbean.GatewayList;
import com.smartcity.jsonbean.PoleList;
import com.smartcity.jsonbean.StreetLightSummary;
import com.smartcity.service.PoleManagerService;
import com.smartcity.util.DBQueryConstants;
@Repository
public class GatewayManagerDaoImpl extends AbstractDAOImpl<GatewayEntity> implements GatewayManagerDao {

	private static final Logger LOGGER = Logger.getLogger(GatewayManagerDaoImpl.class);

	@Autowired
	PoleManagerService poleManagerService;
	
	@Autowired
	private PoleManagerDao poleManagerDao;
	
	
	protected GatewayManagerDaoImpl() {
		super(GatewayEntity.class);
		
	}

	@Override
	public StreetLightSummary getStreetLightSummaryByGateway(String gatewayId) {
		StreetLightSummary streetLights = new StreetLightSummary();
		 int totalPoles=0;
		 int operationalPoles=0;
		 int nonOperationalPoles=0;
		Session session = getSession();
		Query poleStatusQuery = session
				.createSQLQuery(DBQueryConstants.SQL_GET_GATEWAY_STREET_LIGHTS)
				.addScalar("poleCount", IntegerType.INSTANCE)
				.addScalar("poleStatus", StringType.INSTANCE)	
				.setParameter("gatewayId", gatewayId);
		List<Object> PoleStatusList = poleStatusQuery.list();	
		for ( Object obj : PoleStatusList ) {
			Object[] subDataArray = (Object[]) obj;
			if ( subDataArray[0] != null ) {
				if(subDataArray[1].toString().equalsIgnoreCase("Operational"))
				{
					operationalPoles=(int) subDataArray[0];
					//streetLights.setOperational( String.valueOf(subDataArray[0]));	
				}
			}
			
			if ( subDataArray[0] != null ) {
				if(subDataArray[1].toString().equalsIgnoreCase("NonOperational"))
				{
					nonOperationalPoles=(int) subDataArray[0];
					//streetLights.setNonOperational( String.valueOf(subDataArray[0]));	
				}
			}
			
		}
		totalPoles=operationalPoles+nonOperationalPoles;
		streetLights.setNonOperational(String.valueOf(nonOperationalPoles));
		streetLights.setOperational(String.valueOf(operationalPoles));
		streetLights.setTotal(String.valueOf(totalPoles));
		return streetLights;
	}

	@Override
	public BeaconSummary getBeaconSummaryByGateway(String gatewayId) {
		BeaconSummary beaconSummary=new BeaconSummary();
		
		 int totalBeaconPoles=0;
		 int onPoles=0;
		 int offPoles=0;
		Session session = getSession();
		Query poleStatusQuery = session
				.createSQLQuery(DBQueryConstants.SQL_GET_GATEWAY_BEACON)
				.addScalar("poleCount", IntegerType.INSTANCE)
				.addScalar("poleStatus", StringType.INSTANCE)
				.addScalar("classId", StringType.INSTANCE)
				.addScalar("beaconlightpreset", StringType.INSTANCE)				
				.setParameter("gatewayId", gatewayId)
				.setParameter("classId", "1000");
		List<Object> PoleStatusList = poleStatusQuery.list();	
		for ( Object obj : PoleStatusList ) {
			Object[] subDataArray = (Object[]) obj;
			if ( subDataArray[0] != null ) {
				if(subDataArray[3].toString().equalsIgnoreCase("ON"))
				{
					onPoles=(int) subDataArray[0];
					//streetLights.setOperational( String.valueOf(subDataArray[0]));	
				}
			}
			
			if ( subDataArray[0] != null ) {
				if(subDataArray[3].toString().equalsIgnoreCase("OFF"))
				{
					offPoles=(int) subDataArray[0];
					//streetLights.setNonOperational( String.valueOf(subDataArray[0]));	
				}
			}
			
		}
		totalBeaconPoles=onPoles+offPoles;
		beaconSummary.setNonOperational(String.valueOf(offPoles));
		beaconSummary.setOperational(String.valueOf(onPoles));
		beaconSummary.setTotalBeacon(String.valueOf(totalBeaconPoles));
		
		return beaconSummary;
	}

	@Override
	public FloodLights getFloodLightSummaryByGateway(String gatewayId) {
		FloodLights floodLights=new FloodLights();
		 int totalPoles=0;
		 int onPoles=0;
		 int offPoles=0;
		Session session = getSession();
		Query poleStatusQuery = session
				.createSQLQuery(DBQueryConstants.SQL_GET_GATEWAY_FLOODLIGHT)
				.addScalar("poleCount", IntegerType.INSTANCE)
				.addScalar("poleStatus", StringType.INSTANCE)
				.addScalar("classId", StringType.INSTANCE)
				.addScalar("floodlightpreset", StringType.INSTANCE)				
				.setParameter("gatewayId", gatewayId)
				.setParameter("classId", "2000");
		List<Object> PoleStatusList = poleStatusQuery.list();	
		for ( Object obj : PoleStatusList ) {
			Object[] subDataArray = (Object[]) obj;
			if ( subDataArray[0] != null ) {
				if(subDataArray[3].toString().equalsIgnoreCase("ON"))
				{
					onPoles=(int) subDataArray[0];
					//streetLights.setOperational( String.valueOf(subDataArray[0]));	
				}
			}
			
			if ( subDataArray[0] != null ) {
				if(subDataArray[3].toString().equalsIgnoreCase("OFF"))
				{
					offPoles=(int) subDataArray[0];
					//streetLights.setNonOperational( String.valueOf(subDataArray[0]));	
				}
			}
			
		}
		totalPoles=onPoles+offPoles;
		floodLights.setOff(String.valueOf(offPoles));
		floodLights.setOn(String.valueOf(onPoles));
		floodLights.setTotalFloodLights(String.valueOf(totalPoles));
		
		return floodLights;
	}

	@Override
	public DigitalSignageSummary getdigitalSignageSummary(String gatewayId) {
		DigitalSignageSummary digitalSignageSummary=new DigitalSignageSummary();
		int totalSensors=0;
		 int onSensors=0;
		 int offSensors=0;
		Session session = getSession();
		Query poleStatusQuery = session
				.createSQLQuery(DBQueryConstants.SQL_GET_GATEWAY_SENSOR_TYPE_SUMMAY)
				.addScalar("sensorCount", IntegerType.INSTANCE)
				.addScalar("sensorStatus", StringType.INSTANCE)	
				.setParameter("gatewayId", gatewayId)
				.setParameter("classId", "4000");
		List<Object> sensorStatusList = poleStatusQuery.list();	
		for ( Object obj : sensorStatusList ) {
			Object[] subDataArray = (Object[]) obj;
			if ( subDataArray[0] != null ) {
				if(subDataArray[1].toString().equalsIgnoreCase("Operational"))
				{
					onSensors=(int) subDataArray[0];					
				}
			}
			
			if ( subDataArray[0] != null ) {
				if(subDataArray[1].toString().equalsIgnoreCase("NonOperational"))
				{
					offSensors=(int) subDataArray[0];					
				}
			}
			
		}
		totalSensors=onSensors+offSensors;
		digitalSignageSummary.setOff(String.valueOf(offSensors));
		digitalSignageSummary.setOn(String.valueOf(onSensors));
		digitalSignageSummary.setTotal(String.valueOf(totalSensors));
		return digitalSignageSummary;
	}
	
	@Override
	public List<AllGatewayList> getGateways() {
		Session session = getSession();
		List<AllGatewayList> poleList = new ArrayList<AllGatewayList>();
		try {
			Criteria criteria = session.createCriteria(GatewayEntity.class, "gatewayEntity");
			ProjectionList projectionList = Projections.projectionList();
			projectionList.add(Projections.property("gatewayEntity.id").as("id"));
			projectionList.add(Projections.property("gatewayEntity.name").as("name"));
			criteria.setProjection(projectionList);
			criteria.addOrder(Order.asc(("name")));
			criteria.setResultTransformer(Transformers.aliasToBean(PoleList.class));
			poleList = criteria.list();
		} catch (Exception e) {
			throw new SmartCityDBException(e.getMessage(), e);
		} finally {
			closeSession(session);
		}
		return poleList;
	}

	@Override
	public List<GatewayList> getOrphanGateways() {
		Session session = getSession();
		List<GatewayList> orphanGatewayList = new ArrayList<GatewayList>();
		try {
			
			Query poleStatusQuery = session
					.createSQLQuery(DBQueryConstants.SQL_GET_ORPHAN_GATEWAY)
					.addScalar("id", StringType.INSTANCE)
					.addScalar("name", StringType.INSTANCE)
					.setResultTransformer(Transformers.aliasToBean(GatewayList.class));
			orphanGatewayList = poleStatusQuery.list();
		} catch (Exception e) {
			throw new SmartCityDBException(e.getMessage(), e);
		} finally {
			closeSession(session);
		}
		return orphanGatewayList;
	}
	
	@Override
	public List<String> updatePolePresets(String gatewayId)
	{
		Session session = getSession();
		Query poleStatusQuery = session
				.createSQLQuery(DBQueryConstants.SQL_GET_GATEWAY_POLEID)
				.addScalar("poleId", StringType.INSTANCE)
				.setParameter("gatewayId", gatewayId);
		
		List<String> poleList = poleStatusQuery.list();	
		
		/*GatewayEntity gwEntity =getObjectById(gatewayId);
		EventPresetEntity eventPresetEntity = gwEntity.getGatewayPresets().getEventPreset();
		List<PoleEntity> poleEntityList = new ArrayList<PoleEntity>();			

		for (String string : poleList) {
			
			PoleEntity pole = poleManagerDao.getObjectById(string);
			poleEntityList.add(pole);
		}
		
		if(poleList!=null && !poleList.isEmpty())
		{
			this.poleManagerService.updateAllPolePresets(poleEntityList, eventPresetEntity);
		}*/
		
		return poleList;

	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean isGatewayNameExist(String gatewayName) {
		Session session = getSession();
		gatewayName = gatewayName.trim();

		try {
			Criteria criteria = session.createCriteria(GatewayEntity.class, "gatewwayEntity");
			criteria.add(Restrictions.eq("gatewwayEntity.name", gatewayName));
			ProjectionList proList = Projections.projectionList();
			proList.add(Projections.property("gatewwayEntity.name"));
			criteria.setProjection(proList);

			String gatewayEntityName = (String) criteria.list().get(0);
			gatewayEntityName = gatewayEntityName.trim();
			if (gatewayEntityName.equalsIgnoreCase(gatewayName)) {
				return true;

			} else {
				return false;
			}
		} catch (Exception e) {
			LOGGER.info("Inside getDistricts : Exception " + e.getLocalizedMessage());

			return false;

		}
	}

	@Override
	public List<AllGatewayList> getGatewaysForDistrict(String districtId) {
		Session session = getSession();
		List<AllGatewayList> gatewayList = new ArrayList<AllGatewayList>();
		try {
			Criteria criteria = session.createCriteria(GatewayEntity.class, "gatewayEntity");
			criteria.createAlias("gatewayEntity.gatewayMappingEntity", "gatewayMapping");
			criteria.add(Restrictions.eq("gatewayMapping.districtId", districtId));
			ProjectionList projectionList = Projections.projectionList();
			projectionList.add(Projections.property("gatewayEntity.id").as("id"));
			projectionList.add(Projections.property("gatewayEntity.name").as("name"));
			criteria.setProjection(projectionList);
			criteria.addOrder(Order.asc(("name")));
			criteria.setResultTransformer(Transformers.aliasToBean(AllGatewayList.class));
			gatewayList = criteria.list();
		} catch (Exception e) {
			throw new SmartCityDBException(e.getMessage(), e);
		} finally {
			closeSession(session);
		}
		return gatewayList;
	}
	
}

