package com.smartcity.dao;

import org.hibernate.Session;
import org.springframework.stereotype.Repository;

import com.smartcity.dbbean.SensorPresetEntity;

@Repository
public class SensorPresetManagerDaoImpl extends AbstractDAOImpl<SensorPresetEntity>implements SensorPresetManagerDao {



	public SensorPresetManagerDaoImpl() {
		super(SensorPresetEntity.class);
	}

	@Override
	public SensorPresetEntity getSensorPresetEntityBySensorId(String senosrid) {
		Session session = getSession();
		SensorPresetEntity sensorPresetEntity = (SensorPresetEntity) session.createQuery("from SensorPresetEntity sp where sp.sensor.id=:sensorid")
				.setParameter("sensorid", senosrid).uniqueResult();
		return sensorPresetEntity;
	}


}
