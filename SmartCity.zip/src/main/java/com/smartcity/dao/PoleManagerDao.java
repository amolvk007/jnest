package com.smartcity.dao;

import java.util.List;

import com.smartcity.common.RequestParameter;
import com.smartcity.dbbean.GatewayEntity;
import com.smartcity.dbbean.PoleEntity;
import com.smartcity.jsonbean.Pole;
import com.smartcity.jsonbean.PoleList;

public interface PoleManagerDao extends AbstractDAO<PoleEntity> {

	void associatePoles(GatewayEntity gatewayEntity, List<String> poleIdList);

	PoleEntity findByPoleName(String name);

	boolean getPoles(String poleId);

	List<PoleList> getPoleList(RequestParameter requestParameter, int page, int limit);

	void dessociatePoles(GatewayEntity gatewayEntity, List<String> poleIdList);

	List<PoleList> getPoles();
	
	List<Pole> getOrphanPoles();

	List<Pole> getGatewayPoles(String gatewayId);

	void dessociateGatewaysPoles(GatewayEntity gatewayEntity, List<PoleEntity> poles);

	PoleEntity findByPoleName(String name, String poleId);

}
