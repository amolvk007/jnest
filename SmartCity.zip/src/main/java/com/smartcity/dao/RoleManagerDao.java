/**
 * 
 */
package com.smartcity.dao;

import java.util.List;

import com.smartcity.dbbean.ScRoleEntity;

/**
 * @author inrpande01
 *
 */
public interface RoleManagerDao  extends AbstractDAO<ScRoleEntity>  {

}
