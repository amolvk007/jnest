package com.smartcity.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StringType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.smartcity.common.RequestParameter;
import com.smartcity.dbbean.DistrictEntity;
import com.smartcity.dbbean.DistrictGatewayMappingEntity;
import com.smartcity.dbbean.SCUserEntity;
import com.smartcity.dbbean.SCUserRoleEntity;
import com.smartcity.exception.InvalidInputException;
import com.smartcity.jsonbean.AudioSummary;
import com.smartcity.jsonbean.DigitalSignage;
import com.smartcity.jsonbean.District;
import com.smartcity.jsonbean.DistrictDashboardData;
import com.smartcity.jsonbean.DistrictDetails;
import com.smartcity.jsonbean.DistrictGatewayAssociation;
import com.smartcity.jsonbean.DistrictId;
import com.smartcity.jsonbean.DistrictList;
import com.smartcity.jsonbean.DistrictPoleStatus;
import com.smartcity.jsonbean.DistrictSummary;
import com.smartcity.jsonbean.LightSummary;
import com.smartcity.jsonbean.StreetLightSummary;
import com.smartcity.util.DBQueryConstants;
import com.smartcity.util.LoggerUtil;
import com.smartcity.util.UserManagerUtil;

@Repository
@SuppressWarnings("unchecked")
public class DistrictManagerDaoImpl extends AbstractDAOImpl<DistrictEntity>implements DistrictManagerDao {

	@Autowired
	UserManagerDao userManagerDao;
	public DistrictManagerDaoImpl() {
		super(DistrictEntity.class);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public DistrictId createCustomDistrict(DistrictEntity districtEntity) {

		DistrictId districtId = new DistrictId();
		try {
			districtId.setDistrictId((String) insert(districtEntity));
		} catch (Exception e) {
			LoggerUtil.logMessage("Inside getDistricts : Exception " + e.getLocalizedMessage());
		}
		return districtId;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public DistrictEntity updateCustomDistrict(District district, String id)
	{
		DistrictEntity districtEntity = null;
		try {
			
			districtEntity = getObjectById(id);
			//update(districtEntity);
			
		} catch (Exception e) {
			LoggerUtil.logMessage("Inside getDistricts : Exception " + e.getLocalizedMessage());
		}
		return districtEntity;
		
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String deleteDistricts(List<String> districtIds) {
		
		Session session = getSession();
		String message =null;
		List<DistrictEntity> districtEntityList = null;

		
			Criteria criteria = session.createCriteria(DistrictEntity.class, "districtEntity");
			criteria.add(Restrictions.in("districtEntity.id", districtIds));
		
			districtEntityList = criteria.list();
			for(DistrictEntity districtEntity:districtEntityList){
				if(!districtEntity.getDistrictUsers().isEmpty())
				{
					
						throw new InvalidInputException("DistrictUserExist", new Object[] { "DistrictUserExist" });	
					
				}
				if(!districtEntity.getDistrictMappingEnity().isEmpty())
				{
					throw new InvalidInputException("DistrictGatewayExist", new Object[] { "DistrictGatewayExist" });
				}
			}
			delete(districtEntityList);
			if(districtEntityList.size()==0)
			{
				message = "Failed to delete district data"; 

			}
			else
			{
				message = "Requested district data is deleted successfully"; 

			}
		
		
		
		
		
		return message;
	}
	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean isDistrictNameExist(String districtName) {
		Session session = getSession();
		districtName = districtName.trim();

		try {
			Criteria criteria = session.createCriteria(DistrictEntity.class, "districtEntity");
			criteria.add(Restrictions.eq("districtEntity.name", districtName));
			ProjectionList proList = Projections.projectionList();
			proList.add(Projections.property("districtEntity.name"));
			criteria.setProjection(proList);

			String districtEntityId = (String) criteria.list().get(0);
			districtEntityId = districtEntityId.trim();
			if (districtEntityId.equalsIgnoreCase(districtName)) {
				return true;

			} else {
				return false;
			}
		} catch (Exception e) {
			LoggerUtil.logMessage("Inside getDistricts : Exception " + e.getLocalizedMessage());

			return false;

		}
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean isDistrictExist(String districtId) {
		Session session = getSession();

		try {
			Criteria criteria = session.createCriteria(DistrictEntity.class, "districtEntity");
			criteria.add(Restrictions.eq("districtEntity.id", districtId));
			ProjectionList proList = Projections.projectionList();
			proList.add(Projections.property("districtEntity.id"));
			criteria.setProjection(proList);

			String districtEntityId = (String) criteria.list().get(0);

			if (districtEntityId.equalsIgnoreCase(districtId)) {
				return true;

			} else {
				return false;
			}
		} catch (Exception e) {
			LoggerUtil.logMessage("Inside getDistricts : Exception " + e.getLocalizedMessage());

			return false;

		}
	}
	/**
	 * {@inheritDoc}
	 */
	@Override
	public List<DistrictGatewayAssociation> getDistrictGatewayList(RequestParameter requestParameter, int page, int recordsPerPage){

		LoggerUtil.logMessage("Inside DistrictManagerDaoImpl : getDistrictGatewayList()");
		

		Session session = getSession();
		List<DistrictGatewayAssociation> districtGatewayAssociationList = new ArrayList<DistrictGatewayAssociation>();
		try {

			Criteria criteria = session.createCriteria(DistrictEntity.class, "districtEntity");
			
			if(requestParameter==null)
			{
				applySortFilterPagination(criteria, requestParameter, page, recordsPerPage, "createdDate", "districtEntity.createddate", "districtEntity.name");
			}
			else
			{
				if(requestParameter.getSortBy().equalsIgnoreCase("name"))
				{
					applySortFilterPagination(criteria, requestParameter, page, recordsPerPage, "name", "districtEntity.name", "districtEntity.name");
				}
				else if(requestParameter.getSortBy().equalsIgnoreCase("createdDate"))
				{
					applySortFilterPagination(criteria, requestParameter, page, recordsPerPage, "createdDate", "districtEntity.createddate", "districtEntity.name");
	
				}
			}
				
			ProjectionList proList = Projections.projectionList();
			proList.add(Projections.property("districtEntity.id").as("id"));
			proList.add(Projections.property("districtEntity.name").as("name"));	
			proList.add(Projections.property("districtEntity.createddate").as("createdDate"));
			proList.add(Projections.property("districtEntity.coordinates").as("districtCoordinates"));
			criteria.setProjection(proList);
			criteria.setResultTransformer(Transformers.aliasToBean(DistrictGatewayAssociation.class));		
			districtGatewayAssociationList = criteria.list();

			for (DistrictGatewayAssociation districtGatewayAssociation : districtGatewayAssociationList) {
				districtGatewayAssociation.setGatewayNameList(getGatewayNames(districtGatewayAssociation.getId()));
			}			

		} catch (Exception e) {
			LoggerUtil.logMessage("Inside getDistricts : Exception " + e.getLocalizedMessage());

		} finally {
			closeSession(session);
		}
		return districtGatewayAssociationList;
	}
	
	private List<String> getGatewayNames(String districtId)
	{
		Session session = getSession();

		List<String> gatewayIds = new ArrayList<String>();
		Criteria mappingCriteria = session.createCriteria(DistrictGatewayMappingEntity.class, "districtgatewayMappingEntity");
		mappingCriteria.add(Restrictions.eq("districtgatewayMappingEntity.districtId", districtId));
		mappingCriteria.createAlias("districtgatewayMappingEntity.gateway", "districtGateway");
		
		ProjectionList proList = Projections.projectionList();
		proList.add(Projections.property("districtGateway.name")) ;
		mappingCriteria.setProjection(proList);

		gatewayIds = mappingCriteria.list();
		
		return gatewayIds;
	}
	/**
     * {@inheritDoc}
     */
     @Override     
     public List<DistrictList> getDistricts(RequestParameter requestParameter, int page, int recordsPerPage) {

    	 LoggerUtil.logMessage("Inside DistrictManagerDaoImpl");
 		

            Session session = getSession();
            List<DistrictList> districtList = new ArrayList<DistrictList>();
            try {
                   Criteria criteria = session.createCriteria(DistrictEntity.class, "districtEntity");
	                  
                   
                   if(requestParameter==null)
       				{
       					applySortFilterPagination(criteria, requestParameter, page, recordsPerPage, "createdDate", "districtEntity.createddate", "districtEntity.name");
       				}
                   else {
	                	   if(requestParameter.getSortBy().equalsIgnoreCase("name"))
	                	   {
				   				applySortFilterPagination(criteria, requestParameter, page, recordsPerPage, "name", "districtEntity.name", "districtEntity.name");
				   			}
				   			else if(requestParameter.getSortBy().equalsIgnoreCase("createdDate"))
				   			{
				   				applySortFilterPagination(criteria, requestParameter, page, recordsPerPage, "createdDate", "districtEntity.createddate", "districtEntity.name");
				
				   			}
                   }
                   
                   
                   
                   ProjectionList proList = Projections.projectionList();
                   proList.add(Projections.property("districtEntity.id").as("id"));
                   proList.add(Projections.property("districtEntity.name").as("name"));
       			   proList.add(Projections.property("districtEntity.createddate").as("createdDate"));
                   proList.add(Projections.property("districtEntity.coordinates").as("districtCoordinates"));
                   criteria.setProjection(proList);                   
                   criteria.setResultTransformer(Transformers.aliasToBean(DistrictList.class));
                   districtList = criteria.list();


            } catch (Exception e) {
            	LoggerUtil.logMessage("Inside getDistricts : Exception " + e.getLocalizedMessage());

            } finally {
                   closeSession(session);
            }
            return districtList;
     }


	/**
	 * {@inheritDoc}
	 */
	@Override
	public List<DistrictDashboardData> getDistrictDashboardDetails(String districtId, String userId) {
		Session session = getSession();
		List<DistrictDashboardData> DistrictDashboardDataList = new ArrayList<DistrictDashboardData>();
		Criteria criteria = session.createCriteria(DistrictEntity.class, "districtEntity");
		//criteria.createAlias("districtEntity.districtUsers", "districtUser");
		//criteria.createAlias("districtUser.scUser", "user");
		//criteria.add(Restrictions.eq("user.id", userId));
		criteria.add(Restrictions.ne("districtEntity.id", districtId));
		ProjectionList distProjList = Projections.projectionList();
		distProjList.add(Projections.property("districtEntity.id").as("districtId"));
		distProjList.add(Projections.property("districtEntity.name").as("districtName"));
		criteria.setProjection(distProjList);
		criteria.setResultTransformer(Transformers.aliasToBean(District.class));
		List<District> district = criteria.list();
		if (district == null) {
			throw new com.smartcity.exception.InvalidInputException("DistrictIdNotValid", new Object[] { districtId });
		}
		for (District districtdt : district) {
			DistrictDashboardData districtDashboardData = new DistrictDashboardData();
			districtDashboardData.setId(districtdt.getDistrictId());
			districtDashboardData.setName(districtdt.getDistrictName());
			DistrictDashboardDataList.add(districtDashboardData);
		}
		return DistrictDashboardDataList;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public DistrictSummary getDistrictSummary(String districtId) {

		LoggerUtil.logMessage("Inside DistrictManagerDaoImpl : function getDistrictSummary()");

		Session session = getSession();
		DistrictSummary districtSummary = new DistrictSummary();

		try {
			long totalGw = 0;
			long operationalGw = 0;
			long nonOperationalGw = 0;
			String districtName = "";
			List<District> districtStatusSummary = new ArrayList<District>();
			Criteria criteria = session.createCriteria(DistrictEntity.class, "districtEntity");
			criteria.createAlias("districtEntity.districtMappingEnity", "dgMapping"); // inner join		
			criteria.createAlias("dgMapping.gateway", "gw"); // inner join																				

			criteria.add(Restrictions.eq("districtEntity.id", districtId));

		//Old :	criteria.createAlias("districtEntity.gateways", "gw"); // inner join																				
		//	criteria.add(Restrictions.eq("districtEntity.id", districtId));

			ProjectionList proList = Projections.projectionList();
			proList.add(Projections.property("districtEntity.name"));
			proList.add(Projections.property("gw.status"));
			proList.add(Projections.count("gw.status"));
			proList.add(Projections.groupProperty("gw.status"));		

			criteria.setProjection(proList);
			districtStatusSummary = criteria.list();
			//List<Object> objectList = criteria.list();
			for (Object obj : districtStatusSummary) {
				Object[] subDataArray = (Object[]) obj;
				// districtName= subDataArray[0].toString();
				if (subDataArray[0] != null) {
					districtName = subDataArray[0].toString();
					if (subDataArray[1].toString().equalsIgnoreCase("Operational")) {
						operationalGw = (long) subDataArray[2];
					}
				}

				if (subDataArray[0] != null) {
					if (subDataArray[1].toString().equalsIgnoreCase("NonOperational")) {
						nonOperationalGw = (long) subDataArray[2];
					}
				}
			}

			totalGw = operationalGw + nonOperationalGw;			
			districtSummary.setDistrictId(districtId);
			districtSummary.setDistrictName(districtName);
			districtSummary.setTotalGateways(String.valueOf(totalGw));
			districtSummary.setTotalOperationalGateways(String.valueOf(operationalGw));
			districtSummary.setTotalNonOperationalGateways(String.valueOf(nonOperationalGw));
			
			districtSummary.setAlertThresholdLimit("");
			// query to get operaional and NonOperational gateways

			// Query to get total street lights and there status
			Query poleStatusQuery = session.createSQLQuery(DBQueryConstants.SQL_GET_DISTRICT_STREET_LIGHTS)
					.addScalar("poleStatus", StringType.INSTANCE).addScalar("districtId", StringType.INSTANCE)
					.setParameter("districtId", districtId)
					.setResultTransformer(Transformers.aliasToBean(DistrictPoleStatus.class));

			List<DistrictPoleStatus> districtPoleStatusList = poleStatusQuery.list();
			if (districtPoleStatusList.size() > 0) {
				StreetLightSummary streetLightSummary = new StreetLightSummary();
				streetLightSummary.setTotal(String.valueOf(districtPoleStatusList.size()));

				int operational = 0, nonOperational = 0;

				for (DistrictPoleStatus districtPoleStatus : districtPoleStatusList) {

					if (districtPoleStatus.getPoleStatus().equalsIgnoreCase("Operational")) {
						operational++;
					} else if (districtPoleStatus.getPoleStatus().equalsIgnoreCase("NonOperational")) {
						nonOperational++;
					}
				}

				streetLightSummary.setOperational(String.valueOf(operational));
				streetLightSummary.setNonOperational(String.valueOf(nonOperational));

				districtSummary.setStreetLights(streetLightSummary);
			}
			// Query to get total street lights and there status
			Query districtDetailsQuery = session.createSQLQuery(DBQueryConstants.SQL_GET_DISTRICT_DETAILS)
					.addScalar("beaconStatus", StringType.INSTANCE).addScalar("beaconColor", StringType.INSTANCE)
					.addScalar("floodLightStatus", StringType.INSTANCE)
					.addScalar("streetLightStatus", StringType.INSTANCE)
					.addScalar("lightIntensity", StringType.INSTANCE).addScalar("audioName", StringType.INSTANCE)
					.addScalar("volume", StringType.INSTANCE).addScalar("warningMessage", StringType.INSTANCE)
					.setParameter("districtId", districtId)
					.setResultTransformer(Transformers.aliasToBean(DistrictDetails.class));

			DistrictDetails districtDetails = (DistrictDetails) districtDetailsQuery.uniqueResult();

			LightSummary lightSummary = new LightSummary();
			lightSummary.setBeaconLightColor(districtDetails.getBeaconColor());
			lightSummary.setBeaconLightStatus(districtDetails.getBeaconStatus());
			lightSummary.setFloodLight(districtDetails.getFloodLightStatus());
			lightSummary.setIntensity(districtDetails.getLightIntensity());
			lightSummary.setStreetLight(districtDetails.getStreetLightStatus());
			districtSummary.setLightSummary(lightSummary);

			AudioSummary audioSummary = new AudioSummary();
			audioSummary.setCurrentPlaylistName(districtDetails.getAudioName());
			audioSummary.setVolume(districtDetails.getVolume());
			districtSummary.setAudioSummary(audioSummary);

			DigitalSignage digitalSignage = new DigitalSignage();
		//	digitalSignage.setTemperature("");
			digitalSignage.setWarningMessage(districtDetails.getWarningMessage());
			districtSummary.setDigitalSignage(digitalSignage);

			// Query to get sensor details
			/*
			 * Query sensorDetailsQuery = session
			 * .createSQLQuery(DBQueryConstants.SQL_GET_DISTRICT_SENSOR_DETAILS)
			 * .addScalar("sensorType", StringType.INSTANCE)
			 * .addScalar("beaconLight", StringType.INSTANCE)
			 * .addScalar("floodLight", StringType.INSTANCE)
			 * .setParameter("districtId", districtId)
			 * .setParameterList("sensorNameList", new String[]{"Beacon",
			 * "Flood light"})
			 * .setResultTransformer(Transformers.aliasToBean(SensorType.class))
			 * ;
			 * 
			 * List<SensorType> sensorTypeDetails = sensorDetailsQuery.list();
			 * 
			 * int floodLightsOff=0,beaconLightsOff=0;
			 * 
			 * int floodLightsOn=0,beaconLightsOn=0;
			 * 
			 * for (SensorType sensorType : sensorTypeDetails) {
			 * 
			 * if(sensorType.getSensorType().equalsIgnoreCase("Beacon")) {
			 * if(sensorType.getBeaconLight().equalsIgnoreCase("On")) {
			 * beaconLightsOn++; } else { beaconLightsOff++; } } else
			 * if(sensorType.getSensorType().equalsIgnoreCase("Flood Light")) {
			 * if(sensorType.getFloodLight().equalsIgnoreCase("On")) {
			 * floodLightsOn++; } else { floodLightsOff++; } } }
			 */

			/*
			 * BeaconSummary beaconSummary= new BeaconSummary(); int totalBeacon
			 * =beaconLightsOff + beaconLightsOn;
			 * beaconSummary.setTotalBeacon(String.valueOf(totalBeacon));
			 * beaconSummary.setOperational(String.valueOf(beaconLightsOn));
			 * beaconSummary.setNonOperational(String.valueOf(beaconLightsOff));
			 * districtSummary.setBeacon(beaconSummary);
			 */

			/*
			 * FloodLights floodLights = new FloodLights(); int totalFloodLights
			 * =floodLightsOff + floodLightsOn;
			 * floodLights.setTotalFloodLights(String.valueOf(totalFloodLights))
			 * ; floodLights.setOn(String.valueOf(floodLightsOn));
			 * floodLights.setOff(String.valueOf(floodLightsOff));
			 * districtSummary.setFloodLights(floodLights);
			 */

			// DigitalSignageSummary digitalSignageSummary=new
			// DigitalSignageSummary();

			/*
			 * int totalSensors=0; int onSensors=0; int offSensors=0;
			 * 
			 * // Query to get digital signage status count Query
			 * digitalSignageStatusCount = session
			 * .createSQLQuery(DBQueryConstants.
			 * SQL_GET_DISTRICT_TOTAL_DIGITAL_SIGNAGE) .addScalar("SensorCount",
			 * IntegerType.INSTANCE) .addScalar("SensorStatus",
			 * StringType.INSTANCE) .setParameter("districtId", districtId)
			 * .setParameter("sensorClassId", "4000");
			 * 
			 * List<Object> sensorStatusList = digitalSignageStatusCount.list();
			 * for ( Object obj : sensorStatusList ) { Object[] subDataArray =
			 * (Object[]) obj; if ( subDataArray[0] != null ) {
			 * if(subDataArray[1].toString().equalsIgnoreCase(
			 * "Fully Operational")) { onSensors=(int) subDataArray[0]; } }
			 * 
			 * if ( subDataArray[0] != null ) {
			 * if(subDataArray[1].toString().equalsIgnoreCase("NonOperational"
			 * )) { offSensors=(int) subDataArray[0]; } }
			 * 
			 * } totalSensors=onSensors+offSensors;
			 * digitalSignageSummary.setOff(String.valueOf(offSensors));
			 * digitalSignageSummary.setOn(String.valueOf(onSensors));
			 * digitalSignageSummary.setTotal(String.valueOf(totalSensors));
			 */

			// districtSummary.setDigitalSignageSummary(digitalSignageSummary);

		} catch (Exception e) {
			LoggerUtil.logMessage("Inside getDistrictSummary : Exception " + e.getLocalizedMessage());

		}

		return districtSummary;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public List<DistrictList> getDistricts() {
		String userName=UserManagerUtil.getLoggedInUserName();
		Session session = getSession();
		String roleName="ROLE_USER";
		List<DistrictList> districtList = new ArrayList<DistrictList>();
		SCUserEntity sCUserEntity=userManagerDao.findByUserName(userName);
		for(SCUserRoleEntity scUserRoleEntity:sCUserEntity.getScUserRole()){
			roleName=((scUserRoleEntity.getScRole() != null?scUserRoleEntity.getScRole().getName():""));
		}
		Criteria criteria = session.createCriteria(DistrictEntity.class, "districtEntity");
		if (roleName.equalsIgnoreCase("ROLE_USER"))
		{
			criteria.createAlias("districtEntity.districtUsers", "districtUsers");
			criteria.add(Restrictions.eq("districtUsers.userId", sCUserEntity.getId()));
		}
		ProjectionList distProjList = Projections.projectionList();
		distProjList.add(Projections.property("districtEntity.id").as("id"));
		distProjList.add(Projections.property("districtEntity.name").as("name"));
		criteria.setProjection(distProjList);
		criteria.addOrder(Order.asc("name").ignoreCase());
		criteria.setResultTransformer(Transformers.aliasToBean(DistrictList.class));
		 districtList = criteria.list();
		if (districtList.isEmpty()) {
			throw new com.smartcity.exception.InvalidInputException("NoDistroictsAllocatedForUser", new Object[] { sCUserEntity.getUsername() });
		}
		
		return districtList;
	}

}
