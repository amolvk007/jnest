package com.smartcity.dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.springframework.stereotype.Repository;

import com.smartcity.dbbean.SCUserRoleEntity;

@Repository
public class UserRoleManagerDaoImpl extends AbstractDAOImpl<SCUserRoleEntity>implements UserRoleManagerDao {

	private static final Logger LOGGER = Logger.getLogger(UserRoleManagerDaoImpl.class);

	public UserRoleManagerDaoImpl() {
		super(SCUserRoleEntity.class);
	}

	@SuppressWarnings("unchecked")
	@Override
	public SCUserRoleEntity findByUserId(String userid) {
		LOGGER.info("userid :::::" + userid);
		Session session = getSession();
		try {
			List<SCUserRoleEntity> users = new ArrayList<SCUserRoleEntity>();
			users = session.createQuery("from SCUserRoleEntity where userId=:userid").setParameter("userid", userid)
					.list();
			LOGGER.info("List Size:::::" + users.size());

			if (users.size() > 0) {
				return users.get(0);
			} else {
				return null;
			}
		} finally {
			closeSession(session);
		}
	}

	@Override
	public void deleteUserRoleAssociation(SCUserRoleEntity sCUserRoleEntity) {
		Session session = getSession();
		try {
			session.createQuery("Delete from SCUserRoleEntity where userId=:userid").setParameter("userid", sCUserRoleEntity.getUserId()).executeUpdate();

		} finally {
			closeSession(session);
		}		
	}


}
