package com.smartcity.dao;

import com.smartcity.dbbean.EventPresetEntity;
import com.smartcity.jsonbean.UpdateDistrictPresetRequest;
import com.smartcity.jsonbean.UpdateGatewayPresetRequest;
import com.smartcity.jsonbean.UpdatePolePresetRequest;

public interface EventPresetDao extends AbstractDAO<EventPresetEntity> {

	/**
	 * @param updatePolePresetRequest Pole preset details
	 * @return Unique preset Id
	 */
	String getEventPresetIdByValues(UpdatePolePresetRequest updatePolePresetRequest);

	/**
	 * @param updatePolePresetRequest Pole preset details
	 * @return Unique preset Id
	 */
	String addEventPresetIdByValues(UpdatePolePresetRequest updatePolePresetRequest);

	/**
	 * @param updateGatewayPresetRequest Gateway preset details
	 * @return Unique preset Id
	 */
	String getEventPresetIdByValues(UpdateGatewayPresetRequest updateGatewayPresetRequest);

	/**
	 * @param updateGatewayDistrictRequest Gateway preset details
	 * @return Unique preset Id
	 */
	String getEventPresetIdByValues(UpdateDistrictPresetRequest updateGatewayDistrictRequest);

	/**
	 * @return Unique preset Id
	 */
	EventPresetEntity getDefaultPresetEventEntity();

}
