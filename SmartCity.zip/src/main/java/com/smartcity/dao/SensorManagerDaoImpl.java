package com.smartcity.dao;

import java.util.ArrayList;
import java.util.List;

import javax.validation.constraints.Null;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.Subqueries;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Repository;

import com.smartcity.dbbean.PoleEntity;
import com.smartcity.dbbean.PoleSensorEntity;
import com.smartcity.dbbean.SensorEntity;
import com.smartcity.exception.SmartCityDBException;
import com.smartcity.jsonbean.DistrictGateway;
import com.smartcity.jsonbean.Sensor;


@Repository
public class SensorManagerDaoImpl extends AbstractDAOImpl<SensorEntity>implements SensorManagerDao {
	private static final Logger LOGGER = Logger.getLogger(SensorManagerDaoImpl.class);

	public SensorManagerDaoImpl() {
		super(SensorEntity.class);
	}

	@Override
	public List<Sensor> getOrphanSensors() {
		Session session = getSession();
		List<Sensor> orphanSensorList = new ArrayList<Sensor>();
		try {
			DetachedCriteria subquery = DetachedCriteria.forClass(PoleSensorEntity.class, "polesen")
										.setProjection(Projections.property("polesen.sensor"));
			Criteria criteria = session.createCriteria(SensorEntity.class, "sensorEntity");			
			ProjectionList projList = Projections.projectionList();
			projList.add(Projections.property("sensorEntity.id").as("id"));
			projList.add(Projections.property("sensorEntity.name").as("name"));
			criteria.setProjection(projList);
			criteria.addOrder(Order.asc(("name")));
			criteria.add(Subqueries.propertyNotIn("sensorEntity.id", subquery));	
			criteria.setResultTransformer(Transformers.aliasToBean(Sensor.class));			
			orphanSensorList = criteria.list();
		} catch (Exception e) {
			throw new SmartCityDBException(e.getMessage(), e);
		} finally {
			closeSession(session);
		}
		return orphanSensorList;
	}

	@Override
	public List<Sensor> getPoleSensors(String poleId) {
		Session session = getSession();
		List<Sensor> poleSensorList = new ArrayList<Sensor>();
		try {
			Criteria criteria = session.createCriteria(SensorEntity.class, "sensorEntity");
			// criteria.add(Restrictions.isNull("sensorEntity.pole"));
			criteria.createAlias("sensorEntity.poleSensors", "poleSensors");
			//criteria.createAlias("poleSensors.sensor", "sensor");
			criteria.createAlias("poleSensors.pole", "pole");
			criteria.add(Restrictions.eq("pole.id", poleId));
			ProjectionList projList = Projections.projectionList();
			projList.add(Projections.property("sensorEntity.id").as("id"));
			projList.add(Projections.property("sensorEntity.name").as("name"));
			criteria.setProjection(projList);
			criteria.addOrder(Order.asc(("name")));
			criteria.setResultTransformer(Transformers.aliasToBean(Sensor.class));
			poleSensorList = criteria.list();
		} catch (Exception e) {
			throw new SmartCityDBException(e.getMessage(), e);
		} finally {
			closeSession(session);

		}
		return poleSensorList;
	}

	@Override
	public List<Sensor> getSensorsForDistrict(String districtId) {
		Session session = getSession();
		List<Sensor>sensorList = new ArrayList<Sensor>();
		try {
			/*DetachedCriteria subquery = DetachedCriteria.forClass(DistrictGateway.class, "distgateway")
										.setProjection(Projections.property("polesen.sensor"));*/
			Criteria criteria = session.createCriteria(SensorEntity.class, "sensorEntity");		
			criteria.createAlias("sensorEntity.poleSensors", "polesensors");
			criteria.createAlias("polesensors.pole", "pole");
			criteria.createAlias("pole.gateway", "gateway");
			criteria.createAlias("gateway.gatewayMappingEntity", "gatewayMappingEntity");
			criteria.add(Restrictions.eq("gatewayMappingEntity.districtId", districtId));
			ProjectionList projList = Projections.projectionList();
			projList.add(Projections.property("sensorEntity.id").as("id"));
			projList.add(Projections.property("sensorEntity.name").as("name"));
			criteria.setProjection(projList);
			criteria.addOrder(Order.asc(("name")));
			//criteria.add(Subqueries.propertyNotIn("sensorEntity.id", subquery));	
			criteria.setResultTransformer(Transformers.aliasToBean(Sensor.class));			
			sensorList = criteria.list();
		} catch (Exception e) {
			throw new SmartCityDBException(e.getMessage(), e);
		} finally {
			closeSession(session);
		}
		return sensorList;
	}

	@Override
	public List<Sensor> getSensorsForGateway(String gatewayId) {
		Session session = getSession();
		List<Sensor>sensorList = new ArrayList<Sensor>();
		try {
			Criteria criteria = session.createCriteria(SensorEntity.class, "sensorEntity");		
			criteria.createAlias("sensorEntity.poleSensors", "polesensors");
			criteria.createAlias("polesensors.pole", "pole");
			criteria.createAlias("pole.gateway", "gateway");			
			criteria.add(Restrictions.eq("gateway.id", gatewayId));
			ProjectionList projList = Projections.projectionList();
			projList.add(Projections.property("sensorEntity.id").as("id"));
			projList.add(Projections.property("sensorEntity.name").as("name"));
			criteria.setProjection(projList);
			criteria.addOrder(Order.asc(("name")));	
			criteria.setResultTransformer(Transformers.aliasToBean(Sensor.class));			
			sensorList = criteria.list();
		} catch (Exception e) {
			throw new SmartCityDBException(e.getMessage(), e);
		} finally {
			closeSession(session);
		}
		return sensorList;
	}

}
