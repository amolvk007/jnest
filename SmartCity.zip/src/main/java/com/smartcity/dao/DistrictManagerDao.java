package com.smartcity.dao;

import java.util.List;

import com.smartcity.common.RequestParameter;
import com.smartcity.dbbean.DistrictEntity;
import com.smartcity.jsonbean.District;
import com.smartcity.jsonbean.DistrictDashboardData;
import com.smartcity.jsonbean.DistrictGatewayAssociation;
import com.smartcity.jsonbean.DistrictId;
import com.smartcity.jsonbean.DistrictList;
import com.smartcity.jsonbean.DistrictSummary;

/**
 * This interface will perform {@link DistrictEntity} operations.
 * 
 * @author akhaware
 *
 */
public interface DistrictManagerDao extends AbstractDAO<DistrictEntity> {
	/**
	 * 
	 * @param districtId
	 * @param userId
	 * @return this method will return District names and id's assigned for a
	 *         particular user except the district passed in parameter ment for
	 *         dashboard
	 */
	List<DistrictDashboardData> getDistrictDashboardDetails(String districtId, String userId);


	/**
	 * Return list of District and gateways associated with district each
	 * 
	 * @param requestParameter Request parameter including sorting and filtering
	 * @param page page number
	 * @param recordePerPage page size for records
	 * @return List of District and gateways associated with District
	 */
	public List<DistrictList> getDistricts(RequestParameter requestParameter, int page, int recordsPerPage);
	

	/**
	 * Returns district Summary
	 * 
	 * @param districtId
	 * @return district summary
	 */
	public DistrictSummary getDistrictSummary(String districtId);
	
	/**
	 * Creates district with name and coordinates
	 * 
	 * @param district details
	 * @return newly generated district id
	 */
	public DistrictId createCustomDistrict(DistrictEntity districtEntity);
	/**
	 * Update district with name and coordinates
	 * 
	 * @param district details
	 * @param id District ID
	 * @return newly generated district entity
	 */
	public DistrictEntity updateCustomDistrict(District district,String id);

	/**
	 * Delete district details.
	 * 
	 * @param districtIds list of district Ids
	 * @return districtId Id of the updated district
	 */
	public String deleteDistricts(List<String> districtIds);
	
	/**
	 * Check and returns true if district exist in the database 
	 * @param districtId Unique district id
	 * @return true/false
	 */
	public boolean isDistrictExist(String districtId);
		
	/**
	 * Check and returns if district with given name exist or not
	 * @param districtName Unique district name
	 * @return true/false
	 */
	public boolean isDistrictNameExist(String districtName);
	
	/**
	 * Return list of District and gateways associated with district each
	 * 
	 * @param requestParameter Request parameter including sorting and filtering
	 * @param page page number
	 * @param recordePerPage page size for records
	 * @return List of District and gateways associated with District
	 */
	public List<DistrictGatewayAssociation> getDistrictGatewayList(RequestParameter requestParameter, int page, int recordsPerPage);

	/**
	 * @return returns list of districts
	 */
	List<DistrictList> getDistricts();


}
