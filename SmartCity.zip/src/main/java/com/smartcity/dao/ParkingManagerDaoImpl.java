package com.smartcity.dao;

public class ParkingManagerDaoImpl implements ParkingManagerDao {

}
