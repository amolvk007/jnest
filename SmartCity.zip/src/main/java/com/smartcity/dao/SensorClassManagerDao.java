package com.smartcity.dao;

import com.smartcity.dbbean.SensorClassEntity;

public interface SensorClassManagerDao extends AbstractDAO<SensorClassEntity>{

	//public List<Pole> getPoles();
	//public Pole getPoleById(String poleId);
}
