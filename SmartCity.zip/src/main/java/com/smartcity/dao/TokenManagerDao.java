/**
 * 
 */
package com.smartcity.dao;

import java.io.Serializable;

import com.smartcity.dbbean.SCToken;

/**
 * @author inrpande01
 *
 */
public interface TokenManagerDao extends AbstractDAO<SCToken>{

	Serializable saveToken(SCToken token);
	SCToken findToken(String token);
	void deleteToken(String token);
	SCToken getTokenByUserName(String token);

}
