package com.smartcity.dao;

import com.smartcity.dbbean.DistrictPresetEntity;
import com.smartcity.dbbean.EventPresetEntity;

public interface DistrictPresetDao extends AbstractDAO<DistrictPresetEntity> {

	/**
	 * @param districtId Unique district Id
	 * @param defaultEvent District Event Preset entity
	 * @return
	 */
	public String addDefaultDistrictPreset(String districtId,EventPresetEntity defaultEvent);	

}
