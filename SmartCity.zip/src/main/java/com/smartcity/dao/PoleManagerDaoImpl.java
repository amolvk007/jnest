package com.smartcity.dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Repository;

import com.smartcity.common.RequestParameter;
import com.smartcity.dbbean.GatewayEntity;
import com.smartcity.dbbean.PoleEntity;
import com.smartcity.exception.SmartCityDBException;
import com.smartcity.jsonbean.Pole;
import com.smartcity.jsonbean.PoleList;

@Repository
public class PoleManagerDaoImpl extends AbstractDAOImpl<PoleEntity>implements PoleManagerDao {
	private static final Logger LOGGER = Logger.getLogger(PoleManagerDaoImpl.class);

	public PoleManagerDaoImpl() {
		super(PoleEntity.class);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean getPoles(String poleId) {
		LOGGER.info("Inside getPoles:: PoleManagerDaoImpl");
		Session session = getSession();
		try {
			Criteria criteria = session.createCriteria(PoleEntity.class, "poleEntity");
			criteria.add(Restrictions.eq("poleEntity.id", poleId));
			ProjectionList proList = Projections.projectionList();
			proList.add(Projections.property("poleEntity.id"));
			criteria.setProjection(proList);

			String poleEntityId = (String) criteria.list().get(0);

			if (poleEntityId.equalsIgnoreCase(poleId)) {
				return true;

			} else {
				return false;
			}
		} catch (Exception e) {
			throw new SmartCityDBException(e.getMessage(), e);
		} finally {
			closeSession(session);
		}
	}

	@Override
	public void associatePoles(GatewayEntity gatewayEntity, List<String> poleIdList) {
		LOGGER.info("Inside associatePoles:: PoleManagerDaoImpl");
		List<PoleEntity> poleList = new ArrayList<PoleEntity>(poleIdList.size());
		for (String poleId : poleIdList) {
			PoleEntity pole = getObjectById(poleId);
			if (pole != null) {
				pole.setGateway(gatewayEntity);
				poleList.add(pole);
			}
		}

		update(poleList);
	}

	@Override
	public void dessociatePoles(GatewayEntity gatewayEntity, List<String> poleIdList) {
		LOGGER.info("Inside dessociatePoles:: PoleManagerDaoImpl");
		List<PoleEntity> poleList = new ArrayList<PoleEntity>(poleIdList.size());
		for (String poleId : poleIdList) {
			PoleEntity pole = getObjectById(poleId);
			if (pole != null) {
				pole.setGateway(null);
				if (pole.getIsGateway() == 1) {
					pole.setIsGateway((byte) 0);
				}
				poleList.add(pole);
			}
		}

		update(poleList);
	}

	@Override
	public PoleEntity findByPoleName(String name) {
		LOGGER.info("Inside findByPoleName:: PoleManagerDaoImpl");
		List<PoleEntity> poles = new ArrayList<PoleEntity>();
		Session session = getSession();
		poles = session.createQuery("from PoleEntity where name=:name").setParameter("name", name).list();

		if (poles.size() > 0) {

			return poles.get(0);

		} else {
			return null;
		}
	}

	@Override
	public PoleEntity findByPoleName(String name,String poleId) {
		LOGGER.info("Inside findByPoleName:: PoleManagerDaoImpl");
		List<PoleEntity> poles = new ArrayList<PoleEntity>();
		Session session = getSession();

		poles = session.createQuery("from PoleEntity where name=:name and Id!=:poleId").setParameter("name", name).setParameter("poleId", poleId).list();

		if (poles.size() > 0) {

			return poles.get(0);

		} else {
			return null;
		}
	}

	@Override
	public List<PoleList> getPoleList(RequestParameter reqParam, int page, int limit) {
		LOGGER.info("Inside getPoleList:: PoleManagerDaoImpl");
		List<PoleList> poleList = new ArrayList<>();
		String filterValue = "";
		String sortBy = "";
		Session session = getSession();		
		if (null != reqParam.getFilter() && (reqParam.getFilter() != "")) {
			filterValue = reqParam.getFilter();
		}
		if ((reqParam.getSortBy() != null) && (reqParam.getSortBy() != "")) {
			if (reqParam.getSortBy().equalsIgnoreCase("name"))
			{
				sortBy = "name";
			}
			else if(reqParam.getSortBy().equalsIgnoreCase("createddate"))
			{
				sortBy = "createdDate";
			}
			else if(reqParam.getSortBy().equalsIgnoreCase("modifieddate"))
			{
				sortBy = "modifiedDate";
			}
		}

		try {
			Criteria criteria = session.createCriteria(PoleEntity.class, "poleEntity");
			if (filterValue != "") {
				criteria.add(Restrictions.like("poleEntity.name", "%" + filterValue + "%"));
			}
			ProjectionList proList = Projections.projectionList();
			proList.add(Projections.property("poleEntity.id").as("id"));
			proList.add(Projections.property("poleEntity.lat").as("lat"));
			proList.add(Projections.property("poleEntity.longi").as("longi"));
			proList.add(Projections.property("poleEntity.name").as("name"));
			proList.add(Projections.property("poleEntity.createdDate").as("createdDate"));
			criteria.setProjection(proList);
			criteria.setFirstResult((page - 1) * limit);
			criteria.setMaxResults(limit);
			
			if (sortBy != "") {
				String sortOrder = reqParam.getSortOrder();
				if ("desc".equalsIgnoreCase(sortOrder)) {
					criteria.addOrder(Order.desc(sortBy).ignoreCase());
				} else {
					criteria.addOrder(Order.asc(sortBy).ignoreCase());
				}
			}
			else
			{
				criteria.addOrder(Order.desc("poleEntity.createdDate").ignoreCase());
			}
			criteria.setResultTransformer(Transformers.aliasToBean(PoleList.class));
			poleList = criteria.list();

		} catch (Exception e) {
			throw new SmartCityDBException(e.getMessage(), e);
		} finally {
			closeSession(session);
		}
		return poleList;
	}

	@Override
	public List<PoleList> getPoles() {
		LOGGER.info("Inside getPoles:: PoleManagerDaoImpl");
		Session session = getSession();
		List<PoleList> poleList = new ArrayList<PoleList>();
		try {
			Criteria criteria = session.createCriteria(PoleEntity.class, "poleEntity");
			ProjectionList projectionList = Projections.projectionList();
			projectionList.add(Projections.property("poleEntity.id").as("id"));
			projectionList.add(Projections.property("poleEntity.name").as("name"));
			criteria.setProjection(projectionList);
			criteria.addOrder(Order.asc(("name")));
			criteria.setResultTransformer(Transformers.aliasToBean(PoleList.class));
			poleList = criteria.list();
		} catch (Exception e) {
			throw new SmartCityDBException(e.getMessage(), e);
		} finally {
			closeSession(session);
		}
		return poleList;
	}

	@Override
	public List<Pole> getOrphanPoles() {
		LOGGER.info("Inside getOrphanPoles:: PoleManagerDaoImpl");
		Session session = getSession();
		List<Pole> orphanPoleList = new ArrayList<Pole>();
		try {
			Criteria criteria = session.createCriteria(PoleEntity.class, "poleEntity");
			criteria.add(Restrictions.isNull("poleEntity.gateway"));
			ProjectionList projList = Projections.projectionList();
			projList.add(Projections.property("poleEntity.id").as("id"));
			projList.add(Projections.property("poleEntity.name").as("name"));
			criteria.setProjection(projList);
			criteria.addOrder(Order.asc(("name")));
			criteria.setResultTransformer(Transformers.aliasToBean(Pole.class));
			orphanPoleList = criteria.list();
		} catch (Exception e) {
			throw new SmartCityDBException(e.getMessage(), e);
		} finally {
			closeSession(session);
		}
		return orphanPoleList;
	}

	@Override
	public List<Pole> getGatewayPoles(String gatewayId) {
		LOGGER.info("Inside getOrphanPoles:: getGatewayPoles");
		Session session = getSession();
		List<Pole> gatewayPoleList = new ArrayList<Pole>();
		try {
			Criteria criteria = session.createCriteria(PoleEntity.class, "poleEntity");
			// criteria.add(Restrictions.isNull("sensorEntity.pole"));
			criteria.createAlias("poleEntity.gateway", "gateway");
			criteria.add(Restrictions.eq("gateway.id", gatewayId));
			ProjectionList projList = Projections.projectionList();
			projList.add(Projections.property("poleEntity.id").as("id"));
			projList.add(Projections.property("poleEntity.name").as("name"));
			projList.add(Projections.property("poleEntity.isGateway").as("isGateway"));
			
			criteria.setProjection(projList);
			criteria.addOrder(Order.asc(("name")));
			criteria.setResultTransformer(Transformers.aliasToBean(Pole.class));
			gatewayPoleList = criteria.list();
		} catch (Exception e) {
			throw new SmartCityDBException(e.getMessage(), e);
		} finally {
			closeSession(session);
		}
		return gatewayPoleList;
	}

	@Override
	public void dessociateGatewaysPoles(GatewayEntity gatewayEntity, List<PoleEntity> poles) {
		LOGGER.info("Inside getOrphanPoles:: dessociateGatewaysPoles");
		List<PoleEntity> poleList = new ArrayList<PoleEntity>(poles.size());
		for (PoleEntity pole : poles) {
			if (pole != null) {
				pole.setGateway(null);
				if (pole.getIsGateway() == 1) {
					pole.setIsGateway((byte) 0);
				}
				poleList.add(pole);
			}
		}

		update(poleList);
	}

}