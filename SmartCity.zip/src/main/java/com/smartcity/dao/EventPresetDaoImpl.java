package com.smartcity.dao;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.smartcity.dbbean.EventPresetEntity;
import com.smartcity.jsonbean.UpdateDistrictPresetRequest;
import com.smartcity.jsonbean.UpdateGatewayPresetRequest;
import com.smartcity.jsonbean.UpdatePolePresetRequest;

@Repository
public class EventPresetDaoImpl extends AbstractDAOImpl<EventPresetEntity>implements EventPresetDao {
	private static final Logger LOGGER = Logger.getLogger(EventPresetDaoImpl.class);

	protected EventPresetDaoImpl() {
		super(EventPresetEntity.class);

	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public String getEventPresetIdByValues(UpdatePolePresetRequest updatePolePresetRequest) {
		EventPresetEntity eventPresetEntity = new EventPresetEntity();

		Session session = getSession();
		Criteria criteria = session.createCriteria(EventPresetEntity.class, "eventPresetEntity");
		criteria.add(
				Restrictions.eq("eventPresetEntity.beaconlightcolor", updatePolePresetRequest.getBeaconLightColor()));
		criteria.add(
				Restrictions.eq("eventPresetEntity.beaconlightpreset", updatePolePresetRequest.getBeaconLightStatus()));
		criteria.add(Restrictions.eq("eventPresetEntity.audio", updatePolePresetRequest.getAudio()));
		criteria.add(
				Restrictions.eq("eventPresetEntity.floodlightpreset", updatePolePresetRequest.getFloodLightStatus()));
		criteria.add(Restrictions.eq("eventPresetEntity.streetlightintensity", updatePolePresetRequest.getIntensity()));
		criteria.add(
				Restrictions.eq("eventPresetEntity.streetlightpreset", updatePolePresetRequest.getStreetLightStatus()));
		criteria.add(Restrictions.eq("eventPresetEntity.textmessage", updatePolePresetRequest.getTextMessage()));
		criteria.add(Restrictions.eq("eventPresetEntity.threshold", updatePolePresetRequest.getThreshold()));
		criteria.add(Restrictions.eq("eventPresetEntity.volume", Double.valueOf(updatePolePresetRequest.getVolume())));
		List<EventPresetEntity> eventPresetEntitylist = criteria.list();

		if (eventPresetEntitylist == null || eventPresetEntitylist.isEmpty()) {
			return null;
		}
		eventPresetEntity = (EventPresetEntity) eventPresetEntitylist.get(0);
		return eventPresetEntity.getId();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String getEventPresetIdByValues(UpdateGatewayPresetRequest updateGatewayPresetRequest) {
		EventPresetEntity eventPresetEntity = new EventPresetEntity();

		Session session = getSession();
		Criteria criteria = session.createCriteria(EventPresetEntity.class, "eventPresetEntity");
		criteria.add(
				Restrictions.eq("eventPresetEntity.beaconlightcolor", updateGatewayPresetRequest.getBeaconLightColor()));
		criteria.add(
				Restrictions.eq("eventPresetEntity.beaconlightpreset", updateGatewayPresetRequest.getBeaconLightStatus()));
		criteria.add(Restrictions.eq("eventPresetEntity.audio", updateGatewayPresetRequest.getAudio()));
		criteria.add(
				Restrictions.eq("eventPresetEntity.floodlightpreset", updateGatewayPresetRequest.getFloodLightStatus()));
		criteria.add(Restrictions.eq("eventPresetEntity.streetlightintensity", updateGatewayPresetRequest.getIntensity()));
		criteria.add(
				Restrictions.eq("eventPresetEntity.streetlightpreset", updateGatewayPresetRequest.getStreetLightStatus()));
		criteria.add(Restrictions.eq("eventPresetEntity.textmessage", updateGatewayPresetRequest.getTextMessage()));
		criteria.add(Restrictions.eq("eventPresetEntity.threshold", updateGatewayPresetRequest.getThreshold()));
		criteria.add(Restrictions.eq("eventPresetEntity.volume", Double.valueOf(updateGatewayPresetRequest.getVolume())));
		List<EventPresetEntity> eventPresetEntitylist = criteria.list();

		if (eventPresetEntitylist == null || eventPresetEntitylist.isEmpty()) {
			return null;
		}
		eventPresetEntity = (EventPresetEntity) eventPresetEntitylist.get(0);
		return eventPresetEntity.getId();
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public String getEventPresetIdByValues(UpdateDistrictPresetRequest updateGatewayDistrictRequest) {
		EventPresetEntity eventPresetEntity = new EventPresetEntity();

		Session session = getSession();
		Criteria criteria = session.createCriteria(EventPresetEntity.class, "eventPresetEntity");
		criteria.add(
				Restrictions.eq("eventPresetEntity.beaconlightcolor", updateGatewayDistrictRequest.getBeaconLightColor()));
		criteria.add(
				Restrictions.eq("eventPresetEntity.beaconlightpreset", updateGatewayDistrictRequest.getBeaconLightStatus()));
		criteria.add(Restrictions.eq("eventPresetEntity.audio", updateGatewayDistrictRequest.getAudio()));
		criteria.add(
				Restrictions.eq("eventPresetEntity.floodlightpreset", updateGatewayDistrictRequest.getFloodLightStatus()));
		criteria.add(Restrictions.eq("eventPresetEntity.streetlightintensity", updateGatewayDistrictRequest.getIntensity()));
		criteria.add(
				Restrictions.eq("eventPresetEntity.streetlightpreset", updateGatewayDistrictRequest.getStreetLightStatus()));
		criteria.add(Restrictions.eq("eventPresetEntity.textmessage", updateGatewayDistrictRequest.getTextMessage()));
		criteria.add(Restrictions.eq("eventPresetEntity.threshold", updateGatewayDistrictRequest.getThreshold()));
		criteria.add(Restrictions.eq("eventPresetEntity.volume", Double.valueOf(updateGatewayDistrictRequest.getVolume())));
		List<EventPresetEntity> eventPresetEntitylist = criteria.list();

		if (eventPresetEntitylist == null || eventPresetEntitylist.isEmpty()) {
			return null;
		}
		eventPresetEntity = (EventPresetEntity) eventPresetEntitylist.get(0);
		return eventPresetEntity.getId();
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public EventPresetEntity getDefaultPresetEventEntity() {
		Session session = getSession();
		EventPresetEntity defaultEventPresetEnitty = null;

		
		Criteria criteria = session.createCriteria(EventPresetEntity.class, "eventPresetEntity");
		criteria.add(Restrictions.eq("eventPresetEntity.isDefaultEvent", true));

		defaultEventPresetEnitty = (EventPresetEntity) criteria.list().get(0);

		return defaultEventPresetEnitty;
		
		
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public String addEventPresetIdByValues(UpdatePolePresetRequest updatePolePresetRequest) {
		// TODO Auto-generated method stub
		return null;
	}

}
