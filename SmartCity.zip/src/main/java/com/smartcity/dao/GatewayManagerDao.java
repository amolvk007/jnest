package com.smartcity.dao;

import java.util.List;

import com.smartcity.dbbean.GatewayEntity;
import com.smartcity.jsonbean.AllGatewayList;
import com.smartcity.jsonbean.BeaconSummary;
import com.smartcity.jsonbean.DigitalSignageSummary;
import com.smartcity.jsonbean.FloodLights;
import com.smartcity.jsonbean.GatewayList;
import com.smartcity.jsonbean.StreetLightSummary;

public interface GatewayManagerDao extends AbstractDAO<GatewayEntity> {

	StreetLightSummary getStreetLightSummaryByGateway(String gatewayId);

	BeaconSummary getBeaconSummaryByGateway(String gatewayId);

	FloodLights getFloodLightSummaryByGateway(String gatewayId);

	DigitalSignageSummary getdigitalSignageSummary(String gatewayId);
	
	List<AllGatewayList> getGateways();
	
	List<GatewayList> getOrphanGateways();

	public List<String> updatePolePresets(String gatewayId);
	
	/**
	 * @param Name of the gateway to search
	 * @return true if name already exist in the database otherwise returns false
	 */
	public boolean isGatewayNameExist(String gatewayName);
	
	List<AllGatewayList> getGatewaysForDistrict(String districtId);

}
