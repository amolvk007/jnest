/**
 * 
 */
package com.smartcity.dao;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.springframework.stereotype.Repository;

import com.smartcity.dbbean.S2cToken;
import com.smartcity.dbbean.SCToken;
import com.smartcity.exception.SmartCityDBException;

/**
 * @author inrpande01
 *
 */
@Repository
public class TokenManagerDaoImpl extends AbstractDAOImpl<SCToken> implements TokenManagerDao  {

	protected TokenManagerDaoImpl() {
		super(SCToken.class);
	}

	private static final Logger LOGGER = Logger
			.getLogger(TokenManagerDaoImpl.class);

	/* (non-Javadoc)
	 * @see com.smartcity.dao.TokenDao#generateToken(com.smartcity.dbbean.Token)
	 */
	@Override
	public Serializable saveToken(SCToken token) {
		// TODO Auto-generated method stub
		LOGGER.info("TokenDaoImpl::::");

		Session session=getSession();
		return session.save(token);
	}

	@SuppressWarnings("unchecked")
	@Override
	public SCToken findToken(String token) {
		// TODO Auto-generated method stub
		  String inputtoken="'"+token+"'";
		  LOGGER.info("TokenDaoImpl:::: findToken::"+inputtoken);
		  
		List<SCToken> tokenlist = new ArrayList<SCToken>();

		Session session=getSession();
		tokenlist = session
			.createQuery("from SCToken where token=:tokenvalue")
			.setString("tokenvalue", token)
			.list();
		LOGGER.info("List Size:::::"+tokenlist.size());
		if (tokenlist.size() > 0) {
			return tokenlist.get(0);
		} else {
			return null;
		}
	}

	
	@Override
	public void deleteToken(String username) {
		// TODO Auto-generated method stub
		  LOGGER.info("TokenDaoImpl:::: deleteToken:: username"+username);

			Session session=getSession();
		int result = session
			.createQuery(" delete from SCToken where username=:username")	
			.setString("username", username).executeUpdate();
		  LOGGER.info("TokenDaoImpl:::: deleteToken:: result"+result);
	}

	@SuppressWarnings("unchecked")
	@Override
	public SCToken getTokenByUserName(String username) {
		// TODO Auto-generated method stub
		List<SCToken> tokenlist = new ArrayList<SCToken>();

		Session session=getSession();
		tokenlist = session
			.createQuery("from SCToken where username=:username")
			.setString("username", username)
			.list();
		LOGGER.info("List Size:::::"+tokenlist.size());
		if (tokenlist.size() > 0) {
			return tokenlist.get(0);
		} else {
			throw new SmartCityDBException("Token Not Available for "+username);
		}
	}

}
