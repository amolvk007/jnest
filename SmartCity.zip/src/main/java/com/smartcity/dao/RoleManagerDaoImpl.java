/**
 * 
 */
package com.smartcity.dao;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.smartcity.dbbean.ScRoleEntity;

/**
 * @author inrpande01
 *
 */
@Repository
public class RoleManagerDaoImpl extends AbstractDAOImpl<ScRoleEntity>implements RoleManagerDao {

	private static final Logger LOGGER = Logger.getLogger(RoleManagerDaoImpl.class);

	protected RoleManagerDaoImpl() {
		super(ScRoleEntity.class);
	}
}
