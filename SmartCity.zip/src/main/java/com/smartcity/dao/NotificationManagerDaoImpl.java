package com.smartcity.dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.springframework.stereotype.Repository;

import com.smartcity.common.RequestParameter;
import com.smartcity.dbbean.NotificationEntity;

@Repository
public class NotificationManagerDaoImpl extends AbstractDAOImpl<NotificationEntity>implements NotificationManagerDao {

	private static final Logger LOGGER = Logger.getLogger(NotificationManagerDaoImpl.class);

	public NotificationManagerDaoImpl() {
		super(NotificationEntity.class);
	}

	@Override
	public List<NotificationEntity> getNotifications(RequestParameter reqParam, int page, int limit) {

		List<NotificationEntity> notificationsList = new ArrayList<>();
		Session session = getSession();
		String filter = "NOTIFICATIONTYPE";
		String sortOrder = "DESC";
		String sortBy = "createdDate";
		String notificationType = "NOTIFICATION";
		try {

			Criteria criteria = session.createCriteria(NotificationEntity.class, "ne");
			
	/*		if ((reqParam != null) && (null != reqParam.getFilter() && (reqParam.getFilter() != ""))
					&& (null != reqParam.getColumnName() && (reqParam.getColumnName() != ""))) {
				sortOrder = reqParam.getSortOrder();
				sortBy = reqParam.getSortBy();
				filter = (reqParam.getColumnName() != null ? reqParam.getColumnName() : "USERNAME").toUpperCase();
				Map<String, Type> ParameterTypes = session.enableFilter(filter).getFilterDefinition()
						.getParameterTypes();
				Set<Entry<String, Type>> entrySet = ParameterTypes.entrySet();
				for (Entry<String, Type> entry : entrySet) {
					if (entry.getKey().equalsIgnoreCase((reqParam.getColumnName()))) {
						session.enableFilter(filter).setParameter(entry.getKey(), reqParam.getFilter());
					}
				}
			}*/
			session.enableFilter(filter).setParameter("notificationtype", notificationType);
			if ("desc".equalsIgnoreCase(sortOrder)) {
				criteria.addOrder(Order.desc(sortBy).ignoreCase());
			} else {
				criteria.addOrder(Order.asc(sortBy).ignoreCase());
			}
			criteria.setFirstResult((page - 1) * limit);
			criteria.setMaxResults(limit);
			notificationsList = criteria.list();
			session.disableFilter(filter);
			if (notificationsList.size() <= 0) {
				throw new com.smartcity.exception.InvalidInputException("datanotfound",
						new Object[] { "datanotfound" });
			}

		} finally {
			closeSession(session);
		}
		return notificationsList;
	}

}
