package com.smartcity.dao;

import java.util.List;

import com.smartcity.common.RequestParameter;
import com.smartcity.dbbean.GatewayEntity;
import com.smartcity.dbbean.PoleEntity;
import com.smartcity.dbbean.PoleSensorEntity;
import com.smartcity.dbbean.SensorEntity;
import com.smartcity.jsonbean.PoleSensorAssociationList;

public interface PoleSensorMappingDao extends AbstractDAO<PoleSensorEntity> {
	public List<PoleSensorAssociationList> getPoleSensorAssociationList(RequestParameter requestParameter, int page, int limt) ;

	public void deletePoleSensorAssociation(PoleEntity poleEntity);

	public String addPoleSensorAssociation(PoleEntity poleEntity, List<SensorEntity> sensorEntityList);

	public List<PoleSensorEntity> poleSensorAssociationList(PoleEntity poleEntity,GatewayEntity gwEntity);
	
	public void deletePoleSensorAssociation(List<String> sensorIdList);

}
