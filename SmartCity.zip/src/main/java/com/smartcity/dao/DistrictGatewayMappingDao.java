package com.smartcity.dao;

import java.util.List;

import com.smartcity.dbbean.DistrictGatewayMappingEntity;
import com.smartcity.jsonbean.DistrictGateway;
import com.smartcity.jsonbean.Gateway;

public interface DistrictGatewayMappingDao extends AbstractDAO<DistrictGatewayMappingEntity>  {

	
	/**
	 * Get district gateways
	 * 
	 * @return List of gateway Id's associated with District
	 */
	public List<Gateway> getDistrictGateways(String districtId);
	/**
	 * @param districtGateway Associated gateway list for district ID
	 */
	public void addDistrictGatewayAssociation(DistrictGateway districtGateway);
	/**
	 * @param districtIds List of districtIds
	 * @return Custom message
	 */
	public String deleteDistrictMapping(List<String> districtIdList);
}
