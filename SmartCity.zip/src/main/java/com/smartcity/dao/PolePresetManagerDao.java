package com.smartcity.dao;

import com.smartcity.dbbean.PolePresetEntity;

public interface PolePresetManagerDao extends AbstractDAO<PolePresetEntity> {

	PolePresetEntity getPolePresetByPoleId(String poleid);
}
