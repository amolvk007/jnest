package com.smartcity.dao;
import com.smartcity.dbbean.EventPresetEntity;
import com.smartcity.dbbean.GatewayPresetEntity;

public interface GatewayPresetDao extends AbstractDAO<GatewayPresetEntity> {


	public String addDefaultGatewayPreset(String gatewayId,EventPresetEntity defaultEvent);
	

}