package com.smartcity.dao;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.smartcity.dbbean.DistrictUserEntity;
import com.smartcity.dbbean.SCUserEntity;
import com.smartcity.exception.SmartCityDBException;
import com.smartcity.jsonbean.DistrictId;
import com.smartcity.jsonbean.UserDistrict;
import com.smartcity.jsonbean.UserId;
import com.smartcity.util.UserManagerUtil;

@Repository
public class DistrictUserMappingDaoImpl extends AbstractDAOImpl<DistrictUserEntity>implements DistrictUserMappingDao {

	private static final Logger LOGGER = Logger.getLogger(DistrictUserMappingDaoImpl.class);

	public DistrictUserMappingDaoImpl() {

		super(DistrictUserEntity.class);
	}

	@Override
	public void deleteDistrictUserAssociation(List<UserId> userIdList) {
		LOGGER.info("Inside :: deleteDistrictUserAssociation");
		Session session = getSession();
		try {
			
			  for(UserId userId:userIdList) {
				  List<DistrictUserEntity> mappingEnity = new ArrayList<DistrictUserEntity>();
				  List<DistrictUserEntity> mappingEntity = null;
			 Criteria criteria = session.createCriteria(DistrictUserEntity.class, "districtUserEntity");
				criteria.createAlias("districtUserEntity.scUser", "scUser");
				criteria.add(Restrictions.eq("scUser.id", userId.getUserId()));
				mappingEnity = criteria.list();
				delete(mappingEnity);

			 }
		} catch (Exception e) {
			throw new SmartCityDBException(e.getMessage(), e);
		} finally {
			closeSession(session);
		}
	}

	@Override
	public List<String> getDistrictUserAssociationIds(List<SCUserEntity> sCUserEntity) {
		LOGGER.info("Inside :: getDistrictUserAssociationIds");
		Session session = getSession();
		List<String> districtUserId = new ArrayList<String>();
		List<DistrictUserEntity> mappingEntity = new ArrayList<DistrictUserEntity>();
		// List<DistrictUserEntity> districtUserEntityList=new
		// ArrayList<DistrictUserEntity>()
		try {

			Criteria criteria = session.createCriteria(DistrictUserEntity.class, "mappingEntity");
			// criteria.createAlias("mappingEntity.scUser", "user");
			criteria.add(Restrictions.in("mappingEntity.scUser", sCUserEntity));
			mappingEntity = criteria.list();
			if (null != mappingEntity) {
				for (DistrictUserEntity mapEntity : mappingEntity) {
					districtUserId.add(mapEntity.getId());
				}
			}
		} catch (Exception e) {
			throw new SmartCityDBException(e.getMessage(), e);
		} finally {
			closeSession(session);
		}
		return districtUserId;

	}
	
	@Override
	public String addDistrictUserAssociation(UserDistrict userDistrict) {

		Date date = new Date();

		for (String user : userDistrict.getUserList()) {
			Session session = getSession();
			List<DistrictUserEntity> mappingEnity = new ArrayList<DistrictUserEntity>();

			Criteria criteria = session.createCriteria(DistrictUserEntity.class, "dmEntity");
			criteria.createAlias("dmEntity.scUser", "scUser");
			criteria.add(Restrictions.eq("scUser.id", user));

			mappingEnity = criteria.list();
			delete(mappingEnity);
		}
		String userId="";
		for (String user : userDistrict.getUserList()) {
			for (String district : userDistrict.getDistrictList()) {
				DistrictUserEntity dmEntity = new DistrictUserEntity();
				dmEntity.setCREATEDBY(UserManagerUtil.getLoggedInUserName());
				dmEntity.setCREATEDDATE(new Timestamp(date.getTime()));
				dmEntity.setMODIFIEDBY(UserManagerUtil.getLoggedInUserName());
				dmEntity.setMODIFIEDDATE(new Timestamp(date.getTime()));
				dmEntity.setDistrictId(district);
				dmEntity.setUserId(user);
				userId=userId+","+insert(dmEntity);
			}
		}
		return userId;
	}
}
