package com.smartcity.dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.smartcity.dbbean.DistrictEntity;
import com.smartcity.dbbean.DistrictGatewayMappingEntity;
import com.smartcity.dbbean.DistrictPresetEntity;
import com.smartcity.dbbean.EventPresetEntity;
import com.smartcity.dbbean.GatewayEntity;
import com.smartcity.dbbean.GatewayPresetEntity;
import com.smartcity.dbbean.PoleEntity;
import com.smartcity.jsonbean.DistrictGateway;
import com.smartcity.jsonbean.Gateway;
import com.smartcity.service.PoleManagerService;
import com.smartcity.util.GatewayManagerUtil;

@Repository
public class DistrictGatewayMappingDaoImpl extends AbstractDAOImpl<DistrictGatewayMappingEntity>implements DistrictGatewayMappingDao {

	private static final Logger LOGGER = Logger.getLogger(DistrictGatewayMappingDaoImpl.class);
		
	@Autowired
	private GatewayManagerDao gatewayManagerDao;	
	
	
	@Autowired 
	private PoleManagerService poleManagerService;
	
	@Autowired
	private EventPresetDao eventPresetDao;

	public DistrictGatewayMappingDaoImpl() {

		super(DistrictGatewayMappingEntity.class);

	}
	
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public String deleteDistrictMapping(List<String> districtIdList)
	{
		Session session = getSession();
		List<DistrictGatewayMappingEntity> mappingEntity = null;

		String result = null;
		
		try {
			

			Criteria criteria = session.createCriteria(DistrictGatewayMappingEntity.class, "mappingEntity");
			criteria.add(Restrictions.in("mappingEntity.districtId", districtIdList));
		
			mappingEntity = criteria.list();
			
			delete(mappingEntity);
			if(mappingEntity.size()==0)
			{
				result = "No district gateway mapping found"; 

			}
			else
			{
				result = "District Gateway mapping deleted successfully"; 

			}
		
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		
		return result;
		
		
	}

	private void updateGatewayListPreset(List<DistrictGatewayMappingEntity> districtGatewayMapping, EventPresetEntity eventPresetEntity )
	{
		if(null!=districtGatewayMapping && !districtGatewayMapping.isEmpty())
		{
			//update gateway-prest for  Gateway under District
			for(DistrictGatewayMappingEntity disGwMapp : districtGatewayMapping)	
			{
				GatewayEntity gatewayEntity=disGwMapp.getGateway();
				GatewayPresetEntity gatewayPresetEntity=gatewayEntity.getGatewayPresets();
				EventPresetEntity gatewayEventPresetEntity=gatewayPresetEntity.getEventPreset();
				// adding new preset
				gatewayEntity=GatewayManagerUtil.convertCurrentPresetsToNewPresetEntity(gatewayEntity, gatewayPresetEntity,gatewayEventPresetEntity, eventPresetEntity);
				this.gatewayManagerDao.saveUpdate(gatewayEntity);
				//update pole-preset for poles under Gateway				
				List<PoleEntity> poleList = gatewayEntity.getPoles();				
				if(poleList!=null && !poleList.isEmpty())
				{
					this.poleManagerService.updateAllPolePresets(poleList, eventPresetEntity);
				}
			
			}
			
		
		}
	}
	/**
	 * {@inheritDoc}
	 */
	@Override
	public void addDistrictGatewayAssociation(DistrictGateway districtGateway)
	{
		Session session = getSession();
		List<DistrictGatewayMappingEntity> mappingEnity =new ArrayList<DistrictGatewayMappingEntity>();
		
			Criteria criteria = session.createCriteria(DistrictGatewayMappingEntity.class, "dmEntity");
			criteria.createAlias("dmEntity.district", "district");
			criteria.add(Restrictions.eq("district.id", districtGateway.getDistrictId()));	

			mappingEnity = criteria.list();
			delete(mappingEnity);	
			
			

			List<DistrictGatewayMappingEntity> newMappingEntity =new ArrayList<DistrictGatewayMappingEntity>();
			DistrictEntity districtEntity =null;
			Criteria districtCriteria = session.createCriteria(DistrictEntity.class, "dEntity");
			districtCriteria.add(Restrictions.eq("dEntity.id", districtGateway.getDistrictId()));	
			districtEntity = (DistrictEntity) districtCriteria.uniqueResult();
			
			
			for (String dgEn : districtGateway.getGatewayIdList()) {
			
				DistrictGatewayMappingEntity dmEntity = new DistrictGatewayMappingEntity();
				
				dmEntity.setDistrict(districtEntity);
				dmEntity.setGateway(this.gatewayManagerDao.getObjectById(dgEn));
				dmEntity.setDistrictId(districtGateway.getDistrictId().toString());
				dmEntity.setGatewayId(dgEn);
				
				insert(dmEntity);
				
				
				DistrictGatewayMappingEntity dwEntity = getObjectById(dmEntity.getId());
				newMappingEntity.add(dwEntity);
				
			}
			
			DistrictPresetEntity districtPresetEntity = districtEntity.getDistrictPresets();
			if(districtPresetEntity!=null)
			{
				EventPresetEntity eventPresetEntity = this.eventPresetDao.getObjectById(districtPresetEntity.getPresetId());
				updateGatewayListPreset(newMappingEntity, eventPresetEntity);
			}
		
			
		
		
	}
	//To Check DistrictGateway mapping  
	/*
		private List<DistrictGatewayMappingEntity> associatedGatewayList(List<String> ids)
		{
			Session session = getSession();
	
			List<DistrictGatewayMappingEntity> list= new ArrayList<DistrictGatewayMappingEntity>();
			
			Criteria criteria = session.createCriteria(DistrictGatewayMappingEntity.class, "dmEntity");
			criteria.add(Restrictions.in("dmEntity.gatewayId", ids));	
	
			list = criteria.list();
			
			return list;
		}*/
	/**
	 * {@inheritDoc}
	 */
	@Override
	public List<Gateway> getDistrictGateways(String districtId)
	{
		Session session = getSession();
		List<Gateway> gatewayIds =new ArrayList<Gateway>();
	
		try {
			
			Criteria criteria = session.createCriteria(DistrictGatewayMappingEntity.class, "dmEntity");
			criteria.createAlias("dmEntity.district", "district");
			criteria.createAlias("dmEntity.gateway", "gateway");

			criteria.add(Restrictions.eq("district.id", districtId));	
					
			ProjectionList proList = Projections.projectionList();
			proList.add(Projections.property("gateway.id").as("id"));
			proList.add(Projections.property("gateway.name").as("name"));
			criteria.setProjection(proList);
			criteria.setResultTransformer(Transformers.aliasToBean(Gateway.class));

			gatewayIds = criteria.list();
			
			
		} catch (Exception e) {
			LOGGER.info("Inside getDistricts : Exception " + e.getLocalizedMessage());
		}
		return gatewayIds;
	}
}
