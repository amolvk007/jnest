package com.smartcity.dao;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.exception.ConstraintViolationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.smartcity.common.RequestParameter;
import com.smartcity.exception.ConstraintsViolationException;
import com.smartcity.exception.SmartCityDBException;

/**
 * Interface defines  generic methods that used are in Hibernate database opetations.
 * @author akhaware
 *
 * @param <T>
 */
@Transactional
public abstract class AbstractDAOImpl<T> implements AbstractDAO<T> {

	private Class<T> classType;
	
	@Autowired
	private SessionFactory sessionFactory;
	
	protected AbstractDAOImpl(Class<T> type) {
		this.classType = type;
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public Criteria applySortFilterPagination(Criteria criteriaSent,RequestParameter requestParameter, int page, int recordsPerPage,String sortColumnName,String entityColumName, String filterType)
	{
		Criteria criterian = criteriaSent;
		String filterValue = null;
		String sortBy = "";

		if(requestParameter!=null)
		{
			filterValue = requestParameter.getFilter();
			
			if (null != requestParameter.getFilter() && (requestParameter.getFilter() != "")) {
				filterValue = requestParameter.getFilter();
				criterian.add(Restrictions.like(filterType, "%"+filterValue+"%"));

			}
			if ((requestParameter.getSortBy() != null) && (requestParameter.getSortBy() != "")) {
				if (requestParameter.getSortBy().equalsIgnoreCase(sortColumnName))
					sortBy = entityColumName;
			}
			if (sortBy != "") {
				String sortOrder = requestParameter.getSortOrder();
				if ("desc".equalsIgnoreCase(sortOrder)) {
					criterian.addOrder(Order.desc(sortBy).ignoreCase());
				} else {
					criterian.addOrder(Order.asc(sortBy).ignoreCase());
				}
			}
			criterian.setFirstResult((page - 1) * recordsPerPage);
			criterian.setMaxResults(recordsPerPage);
			
		}
		else
		{
			criterian.addOrder(Order.desc(entityColumName).ignoreCase());
			criterian.setFirstResult((page - 1) * recordsPerPage);
			criterian.setMaxResults(recordsPerPage);
			
		}

	
		return criterian;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Serializable insert(T object) {
		Session session = getSession();
		try {
			Serializable newId = session.save(object);
			return newId;
		} catch (ConstraintViolationException cve) {
			throw new ConstraintsViolationException("duplicateRecord", new Object[]{"duplicateRecord" });
		} catch (Exception e) {
			throw new SmartCityDBException(e.getMessage(), e);
			
		} finally {
			closeSession(session);
		}
	}


	/**
	 * {@inheritDoc}
	 */
	@Override
	public void insert(Collection<T> collection) {
		Session session = getSession();
		try {
			for ( T object : collection ) {
				session.save(object);
			}
		} catch (Exception e) {
			throw new SmartCityDBException(e.getMessage(), e);
		} finally {
			closeSession(session);
		}
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void update(T object) {
		Session session = getSession();
		try {
			session.update(object);
		} catch (Exception e) {
			throw new SmartCityDBException(e.getMessage(), e);
		} finally {
			closeSession(session);
		}
	}


	/**
	 * {@inheritDoc}
	 */
	@Override
	public void update(Collection<T> collection) {
		Session session = getSession();
		try {
			for ( T object : collection ) {
				session.update(object);
			}
		} catch (Exception e) {
			throw new SmartCityDBException(e.getMessage(), e);
		} finally {
			closeSession(session);
		}
		
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public void delete(List<T> collection) {
		Session session = getSession();
		try {
			for ( T object : collection ) {
				session.delete(object);
			}
		} catch (Exception e) {
			throw new SmartCityDBException(e.getMessage(), e);
		} finally {
			closeSession(session);
		}
		
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void delete(Serializable id) {
		try {
			T object = getObjectById(id);
			if ( object != null)
				delete(object);
		} catch (ConstraintViolationException cve) {
			throw cve;
		}catch(SmartCityDBException s2e) {
			throw s2e;
		}
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void delete(T object) {
		Session session = getSession();
		try {
			session.delete(object);
		} catch (Exception e) {
			throw new SmartCityDBException(e.getMessage(), e);
		} finally {
			closeSession(session);
		}
	}
	
	/**
	 * {@inheritDoc}
	 * @return
	 */
	@Override
	@SuppressWarnings("unchecked")
	public List<T> loadAll() 
	{
		Session session = getSession();
		try {
			Criteria criteria = session.createCriteria(getClassType()).setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
			return criteria.list();
		} catch (Exception e) {
			throw new SmartCityDBException(e.getMessage(), e);
		} finally {
			closeSession(session);
		}
	}



	/**
	 * {@inheritDoc}
	 */
	@Override
	@SuppressWarnings("unchecked")
	public T getObjectById(Serializable id) {
		T object = null;
		Session session = getSession();
		try {
			object = (T) session.get(getClassType(), id);
		} catch (Exception e) {
			throw new SmartCityDBException(e.getMessage(), e);
		} finally {
			closeSession(session);
		}
		return object;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Session getSession() {
		Session session = sessionFactory.getCurrentSession();
		return session;
	}
	
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public Criteria getCriteria(Session session) {
		return session.createCriteria(getClassType());
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void closeSession(Session session) {
		/* implements session close methods.
		Not required as  sessoin is managed by Spring Contrainer. */
	}

	/**
	 * Method return the class of associated Entity.
	 * @return {@link Class}
	 */
	protected Class<T> getClassType() {
		return classType;
	}

	public SessionFactory getSessionFactory()
	{
		return this.sessionFactory;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void saveUpdate(T object) {
		Session session = getSession();
		try {
			session.saveOrUpdate(object);
		} catch (Exception e) {
			throw new SmartCityDBException(e.getMessage(), e);
		} finally {
			closeSession(session);
		}
	}

	
}