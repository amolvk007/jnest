package com.smartcity.dao;

import java.util.List;

import com.smartcity.common.RequestParameter;
import com.smartcity.dbbean.NotificationEntity;

public interface NotificationManagerDao extends AbstractDAO<NotificationEntity> {

	List<NotificationEntity> getNotifications(RequestParameter requestParameter,int page,int limit);
}
