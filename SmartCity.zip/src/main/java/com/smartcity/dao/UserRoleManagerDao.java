package com.smartcity.dao;

import com.smartcity.dbbean.SCUserRoleEntity;

public interface UserRoleManagerDao extends AbstractDAO<SCUserRoleEntity> {

	SCUserRoleEntity findByUserId(String username);
	
	void deleteUserRoleAssociation(SCUserRoleEntity sCUserRoleEntity);
}
