package com.smartcity.dao;

import org.hibernate.Session;
import org.springframework.stereotype.Repository;

import com.smartcity.dbbean.PolePresetEntity;
import com.smartcity.dbbean.SensorPresetEntity;

@Repository
public class PolePresetManagerDaoImpl extends AbstractDAOImpl<PolePresetEntity>implements PolePresetManagerDao {

	public PolePresetManagerDaoImpl() {
		super(PolePresetEntity.class);
	}

	@Override
	public PolePresetEntity getPolePresetByPoleId(String poleid) {
		Session session = getSession();
		PolePresetEntity sensorPresetEntity = (PolePresetEntity) session.createQuery("from PolePresetEntity sp where sp.pole.id=:poleid")
				.setParameter("poleid", poleid).uniqueResult();
		return sensorPresetEntity;
	}


}
