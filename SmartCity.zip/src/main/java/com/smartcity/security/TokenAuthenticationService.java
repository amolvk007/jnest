/**
 * 
 */
package com.smartcity.security;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Service;

import com.smartcity.dbbean.SCToken;
import com.smartcity.service.TokenManagerServices;

/**
 * @author inrpande01
 *
 */
@Service
public class TokenAuthenticationService {

	private static final Logger LOGGER = Logger
			.getLogger(TokenAuthenticationService.class);


	@Autowired
	private TokenManagerServices tokenServices;

	@Autowired
	private UserDetailsService userDetailsService;
 
	public Authentication ValidateToken(String token) throws BadCredentialsException {
        
        LOGGER.info("TokenHandler::::::parseUserFromToken "+token);
      
        
        LOGGER.info("TokenHandler::::::inputtoken "+token);
        SCToken dbtoken=tokenServices.getToken(token);
        
        if (dbtoken == null) {
        	throw new BadCredentialsException("Invalid Token");
		}
        
     /*   if(!isTokenExpired(dbtoken)){
        	  UserDetails userDetails=userDetailsService.loadUserByUsername(dbtoken.getUsername());
        	  tokenServices.deleteToken(userDetails.getUsername());
        		throw new BadCredentialsException("tokenExpired");
        }*/
        LOGGER.info("TokenHandler::::::inputtoken "+dbtoken.getUsername());
        UserDetails userDetails=userDetailsService.loadUserByUsername(dbtoken.getUsername());
        
          return new UsernamePasswordAuthenticationToken(userDetails.getUsername(),
        		  userDetails.getPassword(),  userDetails.getAuthorities());
    }
    
 
/*    private boolean isTokenExpired(S2cToken dbtoken) {
		// TODO Auto-generated method stub
    	  LOGGER.info("TokenHandler::::::isTokenExpired ");
    	  DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    	LocalDateTime currentdatetime =LocalDateTime.of(LocalDate.now(),LocalTime.now());
    	LocalDateTime dbcurrentdatetime =	dbtoken.getCreatedDate();
    	  
    	  
   	 LOGGER.info("TokenHandler::::::isTokenExpired::currentdatetime "+currentdatetime);
	 LOGGER.info("TokenHandler::::::isTokenExpired::dbcurrentdatetime "+dbcurrentdatetime);
	 int result = currentdatetime.format(formatter).compareTo(dbcurrentdatetime.format(formatter));
	 LOGGER.info("TokenHandler::::::isTokenExpired::result "+result);
	 if(result<=0){
			return true;
	 }
		return false;
	}*/
	public SCToken createToken(String username) {
    	
	return	tokenServices.generateToken(username);
    	
    }
    
   
}
