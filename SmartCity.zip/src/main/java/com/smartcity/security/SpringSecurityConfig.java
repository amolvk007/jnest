
package com.smartcity.security;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.ProviderManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.annotation.web.servlet.configuration.EnableWebMvcSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.access.ExceptionTranslationFilter;

/**
 * @author inrpande01
 *
 */
@SuppressWarnings("deprecation")
@Configuration
@EnableWebMvcSecurity
// @EnableScheduling
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class SpringSecurityConfig extends WebSecurityConfigurerAdapter {

	private static final Logger LOGGER = Logger.getLogger(SpringSecurityConfig.class);

	@Autowired
	private UserDetailsService userService;

	private ProviderManager providerManager;

	private DaoAuthenticationProvider daoAuthenticationProvider;

	private TokenAuthenticationService tokenAuthenticationService;

	public SpringSecurityConfig() {
		super(true);

	}

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		LOGGER.info(" In configure(HttpSecurity http) ++++++++++++ ");
		http.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS).and().authorizeRequests()
				.antMatchers("/API/logout/**").permitAll().antMatchers("/API/login/**").permitAll()
				// .antMatchers("/User/updateUser/**").hasRole("ADMIN").antMatchers("/User/deleteUser/**").hasRole("ADMIN")
				.and().anonymous().disable();

		http.addFilterBefore(new RestAuthenticationFilter(providerManager(), tokenAuthenticationService()),
				ExceptionTranslationFilter.class);

		LOGGER.info(" Exit configure(HttpSecurity http) ++++++++++++ ");
	}

	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		LOGGER.info(" Exit configure(AuthenticationManagerBuilder http) ++++++++++++ ");
		auth.authenticationProvider(daoAuthenticationProvider());
	}

	@Bean
	public ProviderManager providerManager() {
		return providerManager = new ProviderManager(providersList());
	}

	@Bean
	public DaoAuthenticationProvider daoAuthenticationProvider() {
		daoAuthenticationProvider = new DaoAuthenticationProvider();
		daoAuthenticationProvider.setUserDetailsService(userService);
		return daoAuthenticationProvider;
	}

	public List<AuthenticationProvider> providersList() {
		List<AuthenticationProvider> providersList = new ArrayList<AuthenticationProvider>();
		providersList.add(daoAuthenticationProvider);
		return providersList;
	}

	@Bean
	public TokenAuthenticationService tokenAuthenticationService() {
		tokenAuthenticationService = new TokenAuthenticationService();
		return tokenAuthenticationService;
	}
}
