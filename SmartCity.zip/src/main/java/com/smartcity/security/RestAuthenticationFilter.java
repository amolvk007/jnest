/**
 * 
 */
package com.smartcity.security;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.ProviderManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.GenericFilterBean;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.smartcity.constant.SmartCityConstant;
import com.smartcity.jsonbean.ErrorMessage;
import com.smartcity.jsonbean.ResponseData;
import com.smartcity.jsonbean.s2c.EncreptedDataCollection;
import com.smartcity.util.JsonUtil;

/**
 * @author inrpande01
 *
 */
public class RestAuthenticationFilter extends GenericFilterBean {
	private static final Logger LOGGER = Logger.getLogger(RestAuthenticationFilter.class);

	private TokenAuthenticationService tokenAuthenticationService;

	private ProviderManager providerManager2;
	private Authentication authentication;
	Set<String> messageSet = new HashSet<String>();

	public RestAuthenticationFilter(ProviderManager providerManager2,
			TokenAuthenticationService tokenAuthenticationService) {
		this.providerManager2 = providerManager2;
		this.tokenAuthenticationService = tokenAuthenticationService;
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain filterChain) throws IOException,
			ServletException, BadCredentialsException, AccessDeniedException, AuthenticationException {
		HttpServletRequest httpRequest = (HttpServletRequest) request;
		HttpServletResponse httpResponse = (HttpServletResponse) response;
		final String token = httpRequest.getHeader("AUTH-TOKEN");
		LOGGER.info(" Token::" + token);
		if (token != null) {
			LOGGER.info("StatelessAuthenticationFilter::doFilter  Token::" + token);
			try {
				authentication = tokenAuthenticationService.ValidateToken(token);
				SecurityContextHolder.getContext().setAuthentication(authentication);
			} catch (BadCredentialsException e) {
				SetResponse(httpResponse, e.getMessage());
			}
		} else if (httpRequest.getRequestURI().endsWith("login")) {
			try {
				Map<String, String> jsonData = JsonUtil.parseJson(httpRequest);
				String username = (String) jsonData.get("userName");
				String password = (String) jsonData.get("password");
				LOGGER.info(" User::" + username + " Password :::" + password);

				String userpassword = new String(
						org.apache.commons.codec.binary.Base64.encodeBase64(password.getBytes(StandardCharsets.UTF_8)));
				UsernamePasswordAuthenticationToken requestAuthentication = new UsernamePasswordAuthenticationToken(
						username, userpassword);
				authentication = providerManager2.authenticate(requestAuthentication);
				SecurityContextHolder.getContext().setAuthentication(authentication);
			} catch (BadCredentialsException e) {
				SetResponse(httpResponse, e.getMessage());
			}
		} else {
			String message = " Credentials are Mandatory";
			SetResponse(httpResponse, message);
		}
		if (SecurityContextHolder.getContext().getAuthentication() != null
				&& SecurityContextHolder.getContext().getAuthentication().isAuthenticated()) {
			filterChain.doFilter(request, response);
		}
		SecurityContextHolder.getContext().setAuthentication(null);
	}

	public ResponseData setData(String message) {
		ErrorMessage errorMessage = new ErrorMessage();
		messageSet.clear();
		messageSet.add(message);
		errorMessage.setErrors(messageSet);
		errorMessage.setId("");
		errorMessage.setCode("");
		ResponseData data = new ResponseData();
		data.setErrorMessage(errorMessage);
		data.setData("");
		data.setResponse(SmartCityConstant.FAILRESPONSE);
		return data;
	}

	public PrintWriter SetResponse(HttpServletResponse httpResponse, String message) throws IOException {
		ResponseData responseData = setData(message);
		ObjectMapper jsonMapper = new ObjectMapper();
		httpResponse.setContentType("application/json;charset=UTF-8");
		((HttpServletResponse) httpResponse).setStatus(Integer.parseInt(SmartCityConstant.SUCCESSCODE));
		PrintWriter out = httpResponse.getWriter();
		out.print(jsonMapper.writeValueAsString(responseData));
		return out;
	}

}
