package com.smartcity.exception;

import java.util.Map;

public class InvalidInputException extends RuntimeException {
	private static final long serialVersionUID = 91L;
	private String errorCode;
	private Object[] objectArray;
	private Map<String,String> messageMap;
	
	public InvalidInputException( String code, Object[] array) {
		this.errorCode = code;
		this.objectArray = array;
	}

	public InvalidInputException( String code,  Map<String,String> messageMap) {
		this.errorCode = code;
		this.setMessageMap(messageMap);
	}
	public String getErrorCode() {
		return errorCode;
	}

	public Object[] getObjectArray() {
		return objectArray;
	}

	public Map<String,String> getMessageMap() {
		return messageMap;
	}

	public void setMessageMap(Map<String,String> messageMap) {
		this.messageMap = messageMap;
	}

}
