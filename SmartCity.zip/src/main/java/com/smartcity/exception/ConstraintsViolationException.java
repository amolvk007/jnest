/**
 * 
 */
package com.smartcity.exception;

/**
 * @author inrpande01
 *
 */
public class ConstraintsViolationException extends RuntimeException {

	private static final long serialVersionUID = 91L;
	private String errorCode;
	private Object[] objectArray;
	
	public ConstraintsViolationException( String code, Object[] array) {
		this.errorCode = code;
		this.objectArray = array;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public Object[] getObjectArray() {
		return objectArray;
	}

}
