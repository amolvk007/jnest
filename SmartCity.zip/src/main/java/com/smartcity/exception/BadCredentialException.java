/**
 * 
 */
package com.smartcity.exception;

import org.springframework.security.core.AuthenticationException;

/**
 * @author inrpande01
 *
 */
public class BadCredentialException extends AuthenticationException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public BadCredentialException(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}


}
