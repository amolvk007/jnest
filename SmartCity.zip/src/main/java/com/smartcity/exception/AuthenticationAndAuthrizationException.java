/**
 * 
 */
package com.smartcity.exception;

/**
 * @author inrpande01
 *
 */
public class AuthenticationAndAuthrizationException extends RuntimeException {

	
	private static final long serialVersionUID = 94441L;
	private String errorCode;
	private Object[] objectArray;
	
	public AuthenticationAndAuthrizationException( String code, Object[] array) {
		this.errorCode = code;
		this.objectArray = array;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public Object[] getObjectArray() {
		return objectArray;
	}
}
