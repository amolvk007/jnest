package com.smartcity.exception;

public class SmartCityRuntimeException extends RuntimeException{
	private static final long serialVersionUID = 1L;
	
	public SmartCityRuntimeException(String message){
		super(message);
	}

	public SmartCityRuntimeException() {
		super();
	}

	public SmartCityRuntimeException(String message, Throwable cause) {
		super(message, cause);
	}

	public SmartCityRuntimeException(Throwable cause) {
		super(cause);
	}

}
