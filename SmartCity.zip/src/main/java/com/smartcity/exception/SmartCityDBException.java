package com.smartcity.exception;

import org.apache.log4j.Logger;

public class SmartCityDBException extends RuntimeException {
	private static final Logger LOGGER = Logger.getLogger(SmartCityDBException.class);
	private static final long serialVersionUID = 1L;
	private String message;
	private Object[] objectArray;
	public SmartCityDBException(String message) {
		super(message);
		this.message = message;
		LOGGER.error(message);
	}
	public SmartCityDBException(String message, Throwable throwable) {
		super(message,throwable);
		LOGGER.error(message);
		
	}
	public SmartCityDBException( String code, Object[] array) {
		this.message = code;
		this.setObjectArray(array);
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Object[] getObjectArray() {
		return objectArray;
	}
	public void setObjectArray(Object[] objectArray) {
		this.objectArray = objectArray;
	}
	
	
}
