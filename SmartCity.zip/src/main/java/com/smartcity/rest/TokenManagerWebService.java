package com.smartcity.rest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.smartcity.jsonbean.TokenResponse;
import com.smartcity.service.TokenManagerServices;
import com.smartcity.util.TokenManagerUtil;
import com.smartcity.util.ValidatorUtils;

@RestController
@RequestMapping(value = "/Token")
public class TokenManagerWebService {
	private static final Logger LOGGER = Logger.getLogger(TokenManagerWebService.class);

	@Autowired
	private TokenManagerServices tokenManagerServices;




	@RequestMapping(value = "/getToken", method = RequestMethod.GET, produces = { "application/json" })
	public TokenResponse getTokenByName(@RequestParam("username") String username) {
		LOGGER.info("User Name::::::" + username);

		if (ValidatorUtils.validateField("userName", username)) {
			return TokenManagerUtil.SCTokenToTokenResponse(tokenManagerServices.getTokenByUserName(username));
		}

		return null;
	}
	
}
