package com.smartcity.rest;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.smartcity.jsonbean.videonext.Event;
import com.smartcity.service.VideoNextManagerService;
import com.smartcity.util.ValidatorUtils;


@RestController
public class VideoNextManagerWebService {
	
	private static final Logger LOGGER = Logger.getLogger(VideoNextManagerWebService.class);
	
	@Value("${VERTICAL_BASE_URL}")
	private String VN_HOST;

	@Value("${VERTICAL_USER}")
	private String VERTICAL_USER;
	
	@Autowired
	private VideoNextManagerService videoNextManagerService;
	
	@RequestMapping(value = "/API/VideoNext/EventLog", method = RequestMethod.GET, produces = { "application/json" })
	@ResponseBody
	List<Event> getEventLog(@RequestParam(required=false,defaultValue="1") int page,@RequestParam(required=false,defaultValue="100") int limit){
		LOGGER.info("Inside getEventLog page=" + page + " limit=" + limit);
		List<Event> events = videoNextManagerService.getEventLog(page, limit);
		return events;
	}
	
	
	@RequestMapping(value = "/VideoNext/MediaExport", method = RequestMethod.GET)
	void mediaExport(HttpServletResponse response, @RequestParam String objectId, @RequestParam String from, @RequestParam String to) {
		LOGGER.info("Inside mediaExport ");
		Map<String, String> params = new HashMap<String, String>();
		params.put("objectId", objectId);
		params.put("from", from);
		params.put("to", to);
		if (ValidatorUtils.validateFields(params)) {
			videoNextManagerService.getVideFootageStream(Integer.valueOf(objectId.trim()), from, to, response);
		}
		LOGGER.info("MediaExport Completed");
	}
	
}
