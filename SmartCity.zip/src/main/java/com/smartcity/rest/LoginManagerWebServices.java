/**
 * 
 */
package com.smartcity.rest;

import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.smartcity.dbbean.SCToken;
import com.smartcity.exception.InvalidInputException;
import com.smartcity.jsonbean.UserResponse;
import com.smartcity.service.TokenManagerServices;
import com.smartcity.service.UserManagerService;

/**
 * @author inrpande01
 *
 */
@RestController
@RequestMapping(value = "/API")
public class LoginManagerWebServices {

	@Autowired
	private TokenManagerServices tokenManagerServices;

	@Autowired
	private UserManagerService userManagerService;

	@Autowired
	private MessageSource messageSource;

	// @PreAuthorize("hasRole(ANONYMOUS,USER,)")
	@RequestMapping(value = "/login", method = RequestMethod.POST, produces = { "application/json" })
	public UserResponse login() {
		UserResponse loginReonse = new UserResponse();
		if (SecurityContextHolder.getContext().getAuthentication().isAuthenticated()) {

			if (SecurityContextHolder.getContext().getAuthentication().getPrincipal() instanceof User) {
				User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
				loginReonse = findUserResponse(user.getUsername());
				if (findToken(user.getUsername()) != null) {
					loginReonse.setToken(findToken(user.getUsername()));
				}
			} else {
				String user = (String) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
				SCToken sCToken=	tokenManagerServices.getTokenByUserName(user);
				loginReonse = findUserResponse(user);
				if (user != null) {
					loginReonse.setToken(sCToken.getToken());
				}
			}
			loginReonse.setMessage(
					messageSource.getMessage("loginSuccess", new Object[] { "loginSuccess" }, Locale.ENGLISH));
			return loginReonse;
		}
		return loginReonse;
	}

	@RequestMapping(value = "/logout", method = RequestMethod.POST, produces = { "application/json" })
	public void logout() {
		if (SecurityContextHolder.getContext().getAuthentication().getPrincipal() instanceof User) {
			User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			tokenManagerServices.deleteToken(user.getUsername());
			throw new InvalidInputException("logout", new Object[] { "logout" });
		} else {
			String user = (String) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			tokenManagerServices.deleteToken(user);
			throw new InvalidInputException("logout", new Object[] { "logout" });
		}
	}

	public String findToken(String user) {
		
		tokenManagerServices.deleteToken(user);
		SCToken generatedtoken = tokenManagerServices.generateToken(user);
		return generatedtoken.getToken();

	}

	public UserResponse findUserResponse(String user) {
		return userManagerService.getUserByName(user);

	}

}
