package com.smartcity.rest;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.smartcity.common.RequestParameter;
import com.smartcity.dao.UserManagerDao;
import com.smartcity.jsonbean.District;
import com.smartcity.jsonbean.DistrictDashboardData;
import com.smartcity.jsonbean.DistrictGateway;
import com.smartcity.jsonbean.DistrictGatewayAssociation;
import com.smartcity.jsonbean.DistrictId;
import com.smartcity.jsonbean.DistrictList;
import com.smartcity.jsonbean.DistrictSummary;
import com.smartcity.jsonbean.Gateway;
import com.smartcity.jsonbean.UpdateDistrictPresetRequest;
import com.smartcity.service.DistrictManagerService;
import com.smartcity.util.LoggerUtil;
import com.smartcity.util.ValidatorUtils;

@RestController
@RequestMapping(value = "/API/District")
public class DistrictManagerWebService {

	@Autowired
	private DistrictManagerService districtManagerService;

	@Autowired
	private MessageSource messageSource;
	
	@Autowired
	private UserManagerDao userManagerDao;
	/**
	 * Returns list of districts and district coordinates as per role
	 *	
	 * @param requestParameter Request parameter including sorting and filtering
	 * @param page page number
	 * @param limit page size for records
	 * @return a list of district
	 */
	@RequestMapping(value = "/DistrictList", method = RequestMethod.POST, produces = { "application/json" })
	public List<DistrictList> getDistrictList(@RequestBody(required=false) final RequestParameter requestParameter,@RequestParam(required=false,defaultValue="1") int page,
			@RequestParam(required=false,defaultValue="100") int limit) {
		LoggerUtil.logMessage("Inside DistrictManagerWebService : getDistrictList()");
		
		List<DistrictList> districtList = new ArrayList<DistrictList>();
		if(requestParameter!=null)
		{	if (ValidatorUtils.validateEntity(requestParameter)) 
			{
				districtList = districtManagerService.getDistricts(requestParameter,page, limit);
			}
		}
		else
		{
			
			districtList = districtManagerService.getDistricts(requestParameter,page, limit);
			
		}
		return districtList;
	}

	/**
	 * Returns list of District and gateways associated with District
	 *	
	 * @return a list of district with details
	 */
	@RequestMapping(value = "/DistrictGatewayAssociationList", method = RequestMethod.POST, produces = { "application/json" })
	public List<DistrictGatewayAssociation> getDistrictGatewayList(@RequestBody(required=false) final RequestParameter requestParameter,@RequestParam(required=false,defaultValue="1") int page,
			@RequestParam(required=false,defaultValue="100") int limit) {
		LoggerUtil.logMessage("Inside DistrictManagerWebService : getDistrictGatewayList()");
		
		
		List<DistrictGatewayAssociation> districtGatewayDetails = null;
		if(requestParameter!=null)
		{
			if (ValidatorUtils.validateEntity(requestParameter)) 
			{
				districtGatewayDetails = districtManagerService.getDistrictGatewayList(requestParameter,page, limit);
			}
			
		}
		else
		{
			
			districtGatewayDetails = districtManagerService.getDistrictGatewayList(requestParameter,page, limit);
			
		}
		return districtGatewayDetails;
	}
	
	/**
	 * Add/Update District and gateway association details
	 * 
	 * @param districtGateway Associated gateway list for district ID
	 * @param result 
	 * @return Valid message
	 */
	@PreAuthorize("hasRole('ADMIN')")
	@RequestMapping(value ="/AddDistrictGatewayAssociation", method = RequestMethod.POST,consumes={"application/json"},produces={"application/json"} )
	public String addDistrictGatewayAssociation(@RequestBody DistrictGateway districtGateway ){
	
		if (ValidatorUtils.validateEntity(districtGateway)) {
		districtManagerService.addDistrictGatewayAssociation(districtGateway);

		}
		
		 return messageSource.getMessage("DistrictGatewayAssociationUpdated",new Object[] { "DistrictGatewayAssociationUpdated" }, Locale.ENGLISH);
	}
	/**
	 * Returns associated gateway list for district ID
	 * 
	 * @param districtId Unique district Id
	 * @return a list of gateway list
	 */
	@RequestMapping(value = "/DistrictGatewayList/{districtId}", method = RequestMethod.GET, produces = { "application/json" })
	public List<Gateway> getDistrictGateways(@PathVariable("districtId") String districtId) {
		
		LoggerUtil.logMessage("Inside DistrictManagerWebService : GatewayList()");
		
		List<Gateway> gatewayList = new ArrayList<Gateway>();
		if(ValidatorUtils.validateField("districtId",districtId))
	{
		gatewayList = districtManagerService.getDistrictGateways(districtId);
	}
		return gatewayList;
	}
	/**
	 * Create district with name and coordinates
	 * 
	 * @param district Name and coordinates
	 * @return a district Id
	 */
	@PreAuthorize("hasRole('ADMIN') or hasRole('SUPER')")
	@RequestMapping(value = "/Create", method = RequestMethod.POST, produces = {"application/json"})
	public DistrictId createdDistrict(@RequestBody District district)
	{
		DistrictId districtId = null;
		
		if (ValidatorUtils.validateEntity(district)) {
			districtId = this.districtManagerService.createCustomDistrict(district);			
		}
		return districtId;
	}
	/**
	 * Update district with name and coordinates
	 * 
	 * @param district Name and coordinates
	 * @param id District ID
	 * @return a district Id
	 */
	@PreAuthorize("hasRole('ADMIN') or hasRole('SUPER')")
	@RequestMapping(value = "/Update/{districtId}", method = RequestMethod.POST, produces = {"application/json"})
	public DistrictId updateDistrict(@RequestBody District district,@PathVariable("districtId") String id)
	{
		DistrictId districtId = null;
		
		if (ValidatorUtils.validateEntity(district) && ValidatorUtils.validateField("districtId",id)) {
			districtId = this.districtManagerService.updateCustomDistrict(district,id);			
		}
		return districtId;
	}
	/**
	 * Delete district details with associated entities with it
	 * 
	 * @param district Name and coordinates
	 * @param id District ID
	 * @return a district Id
	 */
	@PreAuthorize("hasRole('ADMIN') or hasRole('SUPER')")
	@RequestMapping(value = "/Delete", method = RequestMethod.DELETE, produces = {"application/json"})
	public String deleteDistricts(@RequestBody List<DistrictId> districtids)
	{
		String message = null;
		
		if (ValidatorUtils.validateEntity(districtids) && districtids.size()>0) {
			message = this.districtManagerService.deleteDistricts(districtids);			
		}
		else
		{
			return messageSource.getMessage("InvalidInput",new Object[] { "InvalidInput" }, Locale.ENGLISH);
		}
		return message;
	}
	/**
	 * Delete district gateway association
	 * 
	 * @param district Name and coordinates
	 * @param id District ID
	 * @return a string
	 */
	@PreAuthorize("hasRole('ADMIN') or hasRole('SUPER')")
	@RequestMapping(value = "/DeleteGatewayAssociation", method = RequestMethod.DELETE, produces = {"application/json"})
	public String deleteDistrictGatewayAssociation(@RequestBody List<DistrictId> districtids)
	{
		String message = null;
		
		if (ValidatorUtils.validateEntity(districtids) && districtids.size()>0) {
			message = this.districtManagerService.deleteDistrictGatewayMapping(districtids);			
		}
		else
		{
			 return messageSource.getMessage("InvalidInput",new Object[] { "InvalidInput" }, Locale.ENGLISH);

		}
		return message;
	}
	/**
	 * Returns district details like total gateways, flood lights, beacon summary, audio summary 
	 * 
	 * @param districtId
	 * @return district summary
	 */
	@RequestMapping(value = "/DistrictSummary/{districtId}", method = RequestMethod.GET, produces = {
			"application/json" })
	public DistrictSummary getDistrictSummary(@PathVariable("districtId") String districtId) {

		LoggerUtil.logMessage("Inside DistrictManagerWebService : getDistrictSummary()");
		

		DistrictSummary districtSummary = new DistrictSummary();
		districtSummary = districtManagerService.getDistrictSummary(districtId);
		return districtSummary;
	}
	/**
	 * Retrieves District data for Dashboard map and left tree
	 *
	 * @param districtId
	 *            districtId string.
	 * @return json string containing District name List of all district for
	 *         logged in user and district details like gateways,poles belonging
	 *         to given district id
	 * @summary Retrieves district data
	 * @author akhaware
	 */
	@RequestMapping(value = "/DistrictData/{districtId}", method = RequestMethod.GET, produces = { "application/json" })
	/*public List<DistrictDashboardData> getDistrictData(@RequestHeader("userId") String userId,
			@PathVariable("districtId") String districtId) {*/
	public List<DistrictDashboardData> getDistrictData(@RequestHeader("AUTH-TOKEN") String token,@PathVariable("districtId") String districtId) {
		
		LoggerUtil.logMessage("Called API /DistrictData/" + districtId);
		
		
		String userId=userManagerDao.getUserIdFromToken(token);
		List<DistrictDashboardData> districtDashboardDataList = new ArrayList<DistrictDashboardData>();
		districtDashboardDataList = districtManagerService.getDistrictDashboardData(districtId, userId);
		return districtDashboardDataList;
	}
	
	/**
	 * Retrieves District data for Dashboard map and left tree
	 *
	 * @param districtId
	 *            districtId string.
	 * @return json string containing District name List of all district for
	 *         logged in user and district details like gateways,poles belonging
	 *         to default district
	 *         of user is returned
	 * @summary Retrieves district data
	 * @author akhaware
	 */
	@RequestMapping(value = "/DistrictData", method = RequestMethod.GET, produces = { "application/json" })
	public List<DistrictDashboardData> getDistrictDataForToken(@RequestHeader("AUTH-TOKEN") String token) {
		
		LoggerUtil.logMessage("Called API /DistrictData");
		

		String userId=userManagerDao.getUserIdFromToken(token);
		LoggerUtil.logMessage("token=" + token);
		
		//userId="100";
		List<DistrictDashboardData> districtDashboardDataList = new ArrayList<DistrictDashboardData>();
		districtDashboardDataList = districtManagerService.getDistrictDashboardData(null, userId);
		return districtDashboardDataList;
	}
	
	/**
	 * Returns list of districtid and name
	 * 
	 * @return a list of districts
	 */

	@RequestMapping(value = "/AllDistricts", method = RequestMethod.GET, produces = { "application/json" })
	public List<DistrictList> getDistricts() {
		return districtManagerService.getDistricts();
	}
	
	/**
	 * Updates district Preset
	 * 
	 * @param UpdateDistrictPresetRequest
	 * @return message
	 */
	@PreAuthorize("hasRole('ADMIN') or hasRole('SUPER')")
	@RequestMapping(value = "/UpdateDistrictPresets", method = RequestMethod.POST, consumes = {
			"application/json" }, produces = { "application/json" })
	public String updatedistrictPresets(@RequestBody UpdateDistrictPresetRequest updateDistrictPresetRequest) {
		if (ValidatorUtils.validateEntity(updateDistrictPresetRequest)) {
			
			districtManagerService.updateDistrictPresets(updateDistrictPresetRequest);
			
		}
		return messageSource.getMessage("districtPresetsUpdated", new Object[] { "districtPresetsUpdated" }, Locale.ENGLISH);
	}

	
	
}
