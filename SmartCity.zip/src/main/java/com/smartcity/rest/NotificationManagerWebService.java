package com.smartcity.rest;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.smartcity.common.RequestParameter;
import com.smartcity.jsonbean.EventLogResponse;
import com.smartcity.service.NotificationManagerService;

@RestController
@RequestMapping(value = "/API/Notification")

public class NotificationManagerWebService {
	private static final Logger LOGGER = Logger.getLogger(NotificationManagerWebService.class);

	@Autowired
	private NotificationManagerService notificationManagerService;


		
	@RequestMapping(value = "/getNotifications", method = RequestMethod.POST, produces = { "application/json" })
	public List<EventLogResponse> getNotifications(@RequestBody(required = false) final RequestParameter requestParameter,
			@RequestParam(required = false, defaultValue = "1") int page,
			@RequestParam(required = false, defaultValue = "100") int limit) {
		return notificationManagerService.getNotifications(requestParameter, page, limit);
	}

}
