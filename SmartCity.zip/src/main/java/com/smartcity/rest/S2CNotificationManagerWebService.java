package com.smartcity.rest;

import java.io.Serializable;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.smartcity.jsonbean.s2c.GatewayEventLogRequest;
import com.smartcity.jsonbean.s2c.GatewayEventRequest;
import com.smartcity.service.NotificationManagerService;

@RestController
@RequestMapping(value = "/pushevent")

public class S2CNotificationManagerWebService {
	private static final Logger LOGGER = Logger.getLogger(S2CNotificationManagerWebService.class);

	@Autowired
	private NotificationManagerService notificationManagerService;


	//@PreAuthorize("hasRole('ADMIN') or hasRole('SUPER')")
	//Exception Notification
	@RequestMapping(value = "/addgatewaylogevent", method = RequestMethod.POST, produces = { "application/json" })
	public Serializable saveExceptionNotification(@RequestBody GatewayEventLogRequest eventLog) {
		LOGGER.info("EventLog::::::" + eventLog);
		return notificationManagerService.saveExceptionNotification(eventLog);
	}
	
	//Normal notification 
	@RequestMapping(value = "/addgatewayevent", method = RequestMethod.POST, produces = { "application/json" })
	public Serializable saveNotification(@RequestBody GatewayEventRequest gatewayEventRequest) {
		LOGGER.info("EventLog::::::" + gatewayEventRequest);
		return notificationManagerService.saveNotification(gatewayEventRequest);
	}

}
