package com.smartcity.rest;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.smartcity.jsonbean.CreateSensorRequest;
import com.smartcity.jsonbean.Sensor;
import com.smartcity.jsonbean.SensorClassList;
import com.smartcity.jsonbean.SensorData;
import com.smartcity.jsonbean.SensorList;
import com.smartcity.jsonbean.SensorTypeList;
import com.smartcity.jsonbean.UpdateSensorPresetRequest;
import com.smartcity.service.PoleManagerService;
import com.smartcity.service.SensorManagerService;
import com.smartcity.service.SensorPresetManagerService;
import com.smartcity.util.ValidatorUtils;

@RestController
@RequestMapping(value = "/API/Sensor")
public class SensorManagerWebService {

	private static final Logger LOGGER = Logger.getLogger(SensorManagerWebService.class);

	@Autowired
	private SensorManagerService sensorManagerService;

	@Autowired
	private PoleManagerService poleManagerService;
	
	@Autowired
	private	SensorPresetManagerService sensorPresetManagerService;
	
	@Autowired
	private MessageSource messageSource;

	@RequestMapping(value = "/SensorData/{sensorId}", method = RequestMethod.GET, produces = { "application/json" })
	public SensorData getSensorData(@PathVariable("sensorId") String sensorId) {
		LOGGER.info("sensorId ::::" + sensorId);
		SensorData sensorData = new SensorData();
		if (ValidatorUtils.validateField("sensorId", sensorId)) {
			sensorData = sensorManagerService.getSensorData(sensorId);
		}
		return sensorData;
	}

	@RequestMapping(value = "/SensorClassList", method = RequestMethod.GET, produces = { "application/json" })
	public List<SensorClassList> getSensorClassList() {
		List<SensorClassList> sensorClasses = new ArrayList<SensorClassList>();
		sensorClasses = sensorManagerService.getSensorClassList();
		return sensorClasses;
	}

	@RequestMapping(value = "/SensorTypeList", method = RequestMethod.GET, produces = { "application/json" })
	public List<SensorTypeList> getSensorTypeList() throws Exception {
		List<SensorTypeList> sensorTypes = new ArrayList<SensorTypeList>();
		sensorTypes = sensorManagerService.getSensorTypeList();
		return sensorTypes;
	}

	@PreAuthorize("hasRole('ADMIN') or hasRole('SUPER')")
	@RequestMapping(value = "/CreateSensor", method = RequestMethod.POST, produces = { "application/json" })
	public String createSensor(@RequestBody CreateSensorRequest sensorRequest) throws Exception {
		String sensorId = "";
		if (ValidatorUtils.validateEntity(sensorRequest)) {
			sensorId = sensorManagerService.createSensor(sensorRequest);
			sensorPresetManagerService.createSensorPreset(sensorId);
		}
		return sensorId;
	}

	@RequestMapping(value = "/SensorList", method = RequestMethod.GET, produces = { "application/json" })
	public List<SensorList> getSensorList() {
		List<SensorList> sensorLists = sensorManagerService.getSensorList();
		return sensorLists;
	}

	@PreAuthorize("hasRole('ADMIN') or hasRole('SUPER')")
	@RequestMapping(value = "/DeleteSensor", method = RequestMethod.DELETE, produces = {
			"application/json" })
	public Map<String, List<String>> deleteSensor(@RequestBody List<String> sensorIds) throws Exception {
		List<String> invalidSensorIds = new ArrayList<String>();
		for(String sensorId : sensorIds) {
			if (!ValidatorUtils.validateField("sensorId", sensorId) || 
					(!sensorManagerService.isSensorIdExist(sensorId))) {
				invalidSensorIds.add(sensorId);
				sensorIds.remove(sensorId);
			}
		}
		
		Map<String, List<String>> result = new HashMap<String, List<String>>();
		result.put("invalid", invalidSensorIds);
		result.putAll(sensorManagerService.deleteSensor(sensorIds));
		
		return result;
	}

	@PreAuthorize("hasRole('ADMIN') or hasRole('SUPER')")
	@RequestMapping(value = "/UpdateSensor/{sensorId}", method = RequestMethod.POST, produces = { "application/json" })
	public void updateSensor(@PathVariable("sensorId") String sensorId,
			@RequestBody CreateSensorRequest sensorRequest) throws Exception {
		if ((ValidatorUtils.validateField("sensorId", sensorId)) && (ValidatorUtils.validateEntity(sensorRequest))
				&& (sensorManagerService.isSensorIdExist(sensorId))) {
			sensorManagerService.updateSensor(sensorId, sensorRequest);
		}
	}

	@RequestMapping(value = "/SensorDetails/{sensorId}", method = RequestMethod.GET, produces = { "application/json" })
	public SensorList getSensorDetails(@PathVariable("sensorId") String sensorId) {
		SensorList sensorList = new SensorList();
		if (ValidatorUtils.validateField("sensorId", sensorId) && (sensorManagerService.isSensorIdExist(sensorId))) {
			sensorList = sensorManagerService.getSensorDetails(sensorId);
		}
		return sensorList;
	}

	@RequestMapping(value = "/OrphanSensors", method = RequestMethod.GET, produces = { "application/json" })
	public List<Sensor> getOrphanSensors() {
		List<Sensor> sensorLists = sensorManagerService.getOrphanSensors();
		return sensorLists;
	}

	@RequestMapping(value = "/PoleSensors/{poleId}", method = RequestMethod.GET, produces = { "application/json" })
	public List<Sensor> getPoleSensors(@PathVariable("poleId") String poleId) {
		List<Sensor> sensorLists = new ArrayList<Sensor>();
		if ((ValidatorUtils.validateField("PoleId", poleId) && poleManagerService.isPoleIdExist(poleId))) {
			sensorLists = sensorManagerService.getPoleSensors(poleId);
		}
		return sensorLists;
	}
	
	@PreAuthorize("hasRole('ADMIN')")
	@RequestMapping(value = "/UpdateSensorPresets", method = RequestMethod.POST, consumes = {
			"application/json" }, produces = { "application/json" })
	public String updateSensorPresets(@RequestBody UpdateSensorPresetRequest updatePolePresetRequest) {
		if (ValidatorUtils.validateEntity(updatePolePresetRequest)) {
			sensorManagerService.updateSensorPresets(updatePolePresetRequest);
		}
		return messageSource.getMessage("SensorPresetsUpdated", new Object[] { "SensorPresetsUpdated" }, Locale.ENGLISH);
	}
}
