package com.smartcity.rest;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.smartcity.common.RequestParameter;
import com.smartcity.dbbean.SCUserEntity;
import com.smartcity.dbbean.SCUserRoleEntity;
import com.smartcity.jsonbean.DistrictUser;
import com.smartcity.jsonbean.DistrictUserAssociation;
import com.smartcity.jsonbean.DistrictUserDelete;
import com.smartcity.jsonbean.User;
import com.smartcity.jsonbean.UserDistrict;
import com.smartcity.jsonbean.UserId;
import com.smartcity.jsonbean.UserList;
import com.smartcity.jsonbean.UserResponse;
import com.smartcity.service.UserManagerService;
import com.smartcity.service.UserRoleManagerService;
import com.smartcity.util.ValidatorUtils;

@RestController
@RequestMapping(value = "/API/User")

public class UserManagerWebService {
	private static final Logger LOGGER = Logger.getLogger(UserManagerWebService.class);

	@Autowired
	private UserManagerService userManagerService;


	@Autowired
	private MessageSource messageSource;
	
	@Autowired
	UserRoleManagerService userRoleManagerService;

	@RequestMapping(value = "/getUsers/pole", method = RequestMethod.GET, produces = { "application/json" })
	public List<UserResponse> getUsers(@RequestParam("userId") String userId) {
		System.out.println("userId=" + userId);
		if (ValidatorUtils.validateField("UserId", userId)) {
			return userManagerService.getUsers();
		}
		return null;
	}

	@RequestMapping(value = "/getOnlyUsers", method = RequestMethod.POST, produces = { "application/json" })
	public List<UserList> getOnlyUsers(@RequestBody(required = false) final RequestParameter requestParameter,
			@RequestParam(required = false, defaultValue = "1") int page,
			@RequestParam(required = false, defaultValue = "100") int limit) {
		return userManagerService.getOnlyUsers(requestParameter, page, limit);
	}

	@RequestMapping(value = "/getUsers", method = RequestMethod.POST, produces = { "application/json" })
	public List<UserResponse> getAllUsers(@RequestBody(required = false) final RequestParameter requestParameter,
			@RequestParam(required = false, defaultValue = "1") int page,
			@RequestParam(required = false, defaultValue = "100") int limit) {
		return userManagerService.getUsers(requestParameter, page, limit);
	}
	@RequestMapping(value = "/getuserByName", method = RequestMethod.GET, produces = { "application/json" })
	public UserResponse getUserByName(@RequestParam("username") String username) {
		LOGGER.info("User Name::::::" + username);

		if (ValidatorUtils.validateField("userName", username)) {
			return userManagerService.getUserByName(username);
		}

		return null;
	}

	@PreAuthorize("hasRole('ADMIN') or hasRole('SUPER')")
	@RequestMapping(value = "/addUser", method = RequestMethod.POST, produces = { "application/json" })
	public UserResponse addUser(@RequestBody User user) {
		LOGGER.info("User Name::::::" + user.getUserName());
		UserResponse UserResponse = new UserResponse();
		if (ValidatorUtils.validateEntity(user) && userManagerService.isUserNameExist(user)) {
			String userid = null;
			;
			if (userManagerService.checkUserAccess(user)) {
				userid = (String) userManagerService.addUser(user);
			}
			LOGGER.info("User Created UserId::::::" + userid);
			if (userid != null) {
				SCUserRoleEntity SCUserRoleEntity= new SCUserRoleEntity();
				SCUserRoleEntity.setUserId((String)userid);;
				SCUserRoleEntity.setRoleId(user.getUserRole());
				userRoleManagerService.addUserRoleAssociation(SCUserRoleEntity);
				UserResponse.setUserId(userid);
				UserResponse.setMessage(
						messageSource.getMessage("insertmessage", new Object[] { "insertmessage" }, Locale.ENGLISH));
			}
		}
		return UserResponse;
	}

	@PreAuthorize("hasRole('ADMIN') or hasRole('SUPER')")
	@RequestMapping(value = "/updateUser", method = RequestMethod.POST, produces = { "application/json" })
	@ResponseBody
	public UserResponse updateUser(@RequestBody User user) {
		LOGGER.info("User Name::::::" + user.getUserName());
		UserResponse UserResponse = new UserResponse();
		if (ValidatorUtils.validateField("UserId", user.getUserId())
				&& userManagerService.isUserIdExist(user.getUserId())) {

			 if (userManagerService.checkUserAccess(user)) {
			
			SCUserEntity sCUserEntity=userManagerService.findByUserId(user.getUserId());
			userManagerService.updateUser(user,sCUserEntity);
			SCUserRoleEntity sCUserRoleEntity=userRoleManagerService.findByUserId(user.getUserId());
			LOGGER.info("sCUserRoleEntity ::::: " + sCUserRoleEntity);
			if (sCUserRoleEntity != null) {
				sCUserRoleEntity.setUserId(user.getUserId());
				sCUserRoleEntity.setRoleId(user.getUserRole());
				userRoleManagerService.updateUserRoleAssociation(sCUserRoleEntity);
			}
			}

		}
		UserResponse.setMessage(
				messageSource.getMessage("updatemessage", new Object[] { "updatemessage" }, Locale.ENGLISH));
		return UserResponse;
	}

	@PreAuthorize("hasRole('ADMIN') or hasRole('SUPER')")
	@RequestMapping(value = "/deleteUser", method = RequestMethod.DELETE, produces = { "application/json" })
	public UserResponse deleteUser(@RequestBody User userRequest) {

		LOGGER.info("User List::::::" + ((userRequest.getUserIdList() != null) ? userRequest.getUserIdList().size()
				: userRequest.getUserIdList()));
		UserResponse UserResponse = null;
		if (ValidatorUtils.validateList("userIdList", userRequest.getUserIdList())) {
			for (UserId userid : userRequest.getUserIdList()) {
				UserResponse = new UserResponse();
				User user = new User();
				user.setUserId(userid.getUserId());
				if (ValidatorUtils.validateField("UserId", userid.getUserId())
						&& userManagerService.isUserIdExist(user.getUserId())) {
					SCUserRoleEntity sCUserRoleEntity=userRoleManagerService.findByUserId(user.getUserId());
					if (sCUserRoleEntity != null) {
						sCUserRoleEntity.setUserId(user.getUserId());
						userRoleManagerService.deleteUserRoleAssociation(sCUserRoleEntity);
					}
					userManagerService.deleteUser(user);
					LOGGER.info("User Deleted ::::::");
				}
				UserResponse.setMessage(
						messageSource.getMessage("deletemessage", new Object[] { "deletemessage" }, Locale.ENGLISH));
			}
		}
		return UserResponse;
	}

	/**
	 * Adds User district association
	 * 
	 * @param userId
	 * @param DistrictList
	 * @param DefaultDistrictId
	 * @return map with newly created association id
	 */
	@PreAuthorize("hasRole('ADMIN') or hasRole('SUPER')")
	@RequestMapping(value = "/AddUserDistrictAssociation", method = RequestMethod.POST, consumes = {
			"application/json" }, produces = { "application/json" })
	@ResponseBody
	public HashMap<String, String> addUserDistrictAssociation(@RequestBody UserDistrict userDistrict,
			final BindingResult result) {
		HashMap<String, String> map = new HashMap<String, String>();
		if (ValidatorUtils.validateEntity(userDistrict)) {
			String associationId = userManagerService.addUserDistrictAssociation(userDistrict);
			map.put("UserDistrictAssociationId", associationId);
		}
		return map;
	}

	@PreAuthorize("hasRole('ADMIN') or hasRole('SUPER')")
	@RequestMapping(value = "/DeleteDistrictUserAssociation", method = RequestMethod.DELETE, consumes = {
			"application/json" }, produces = { "Application/json" })
	public String deleteDistrictUserAssociation(@RequestBody DistrictUserDelete districtUserDelete) {
		if (ValidatorUtils.validateEntity(districtUserDelete)) {
			this.userManagerService.deleteDistrictUserAssociation(districtUserDelete);
		} else {
			return messageSource.getMessage("InvalidInput", new Object[] { "InvalidInput" }, Locale.ENGLISH);
		}
		return messageSource.getMessage("UserDistrictAssociationDeleted",
				new Object[] { "UserDistrictAssociationDeleted" }, Locale.ENGLISH);

	}

	@RequestMapping(value = "/DistrictUserAssociationList", method = RequestMethod.GET, produces = {
			"application/json" })
	@ResponseBody
	public List<DistrictUserAssociation> districtUserAssociationList() {
		List<DistrictUserAssociation> districtUserAssociationList = userManagerService.getdistrictUserAssociationList();
		return districtUserAssociationList;
	}

	@RequestMapping(value = "/DistrictUserList/{userId}", method = RequestMethod.GET, produces = { "application/json" })
	@ResponseBody
	public List<DistrictUser> districtUserList(@PathVariable("userId") String userId) {
		ValidatorUtils.validateField("userId", userId);
		List<DistrictUser> districtUserList = userManagerService.getdistrictUserList(userId);
		return districtUserList;
	}

	@RequestMapping(value = "/checkUserExistence", method = RequestMethod.POST, produces = { "application/json" })
	public boolean checkUserExistance(@RequestBody User user) {
		LOGGER.info("User Name::::::" + user.getUserName());
		if (ValidatorUtils.validateField("userName", user.getUserName())) {
			return userManagerService.isUserNameExist(user);
		}
		return true;
	}
}
