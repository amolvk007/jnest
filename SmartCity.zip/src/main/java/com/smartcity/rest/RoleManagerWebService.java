package com.smartcity.rest;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.smartcity.jsonbean.Role;
import com.smartcity.jsonbean.RoleResponse;
import com.smartcity.service.RoleManagerService;
import com.smartcity.util.ValidatorUtils;

@RestController
@RequestMapping(value = "/API/Role")
public class RoleManagerWebService {
	private static final Logger LOGGER = Logger.getLogger(RoleManagerWebService.class);

	@Autowired
	private RoleManagerService roleManagerService;

	@RequestMapping(value = "/getRoles", method = RequestMethod.GET, produces = { "application/json" })
	public List<RoleResponse> getRoles() {
		LOGGER.info("getRoles::::::");
		return roleManagerService.getRole();
	}

	@PreAuthorize("hasRole('ADMIN')")
	@RequestMapping(value = "/addRole", method = RequestMethod.POST, produces = { "application/json" })
	public RoleResponse addRole(@RequestBody Role role) {
		LOGGER.info("Role::::::" + role.getRole());
		RoleResponse RoleResponse = new RoleResponse();
		if (ValidatorUtils.validateEntity(role)) {
			String roleid = (String) roleManagerService.addRole(role);
			LOGGER.info("User Created UserId::::::" + roleid);
			RoleResponse.setId(roleid);
		}
		return RoleResponse;
	}

	@PreAuthorize("hasRole('ADMIN')")
	@RequestMapping(value = "/updateRole", method = RequestMethod.POST, produces = { "application/json" })
	public RoleResponse updateRole(@RequestBody Role role) {
		LOGGER.info("Role::::::" + role.getRole());
		RoleResponse roleResponse = new RoleResponse();

		if (ValidatorUtils.validateEntity(role)) {
			roleManagerService.isRoleExist(role);
			roleManagerService.updateRole(role);
		}
		roleResponse.setMessage("Record Updated Successfully");
		return roleResponse;
	}

	@PreAuthorize("hasRole('ADMIN')")
	@RequestMapping(value = "/deleteRole", method = RequestMethod.DELETE, produces = { "application/json" })
	public RoleResponse deleteRole(@RequestBody Role role) {
		LOGGER.info("Role::::::" + role.getRole());
		RoleResponse roleResponse = new RoleResponse();

		if (ValidatorUtils.validateEntity(role)) {
			roleManagerService.isRoleExist(role);
			roleManagerService.deleteRole(role);
		}
		roleResponse.setMessage("Record Deleted Successfully");
		return roleResponse;
	}
}
