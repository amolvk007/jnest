package com.smartcity.rest;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.smartcity.dbbean.EventPresetEntity;
import com.smartcity.dbbean.GatewayEntity;
import com.smartcity.dbbean.PoleEntity;
import com.smartcity.dbbean.PoleSensorEntity;
import com.smartcity.exception.SmartCityDBException;
import com.smartcity.jsonbean.AllGatewayList;
import com.smartcity.jsonbean.CreateGatewayRequest;
import com.smartcity.jsonbean.GatewayList;
import com.smartcity.jsonbean.GatewayPoleAssociationList;
import com.smartcity.jsonbean.GatewayPoleAssociationRequest;
import com.smartcity.jsonbean.GatewaySummary;
import com.smartcity.jsonbean.GatewayType;
import com.smartcity.jsonbean.Pole;
import com.smartcity.jsonbean.UpdateGatewayPresetRequest;
import com.smartcity.jsonbean.s2c.VerticalBundleRequest;
import com.smartcity.jsonbean.s2c.VerticalBundleResponse;
import com.smartcity.jsonbean.s2c.WanPolicyRequest;
import com.smartcity.service.GatewayManagerService;
import com.smartcity.service.PoleManagerService;
import com.smartcity.service.S2CAccessService;
import com.smartcity.util.ValidatorUtils;

@RestController
@RequestMapping(value = "/API/Gateway")
public class GatewayManagerWebService {

	@Autowired
	private MessageSource messageSource;
	
	@Autowired
	private GatewayManagerService gatewayManagerService;
	
	@Autowired
	private PoleManagerService poleManagerService;
	
	@Autowired
	S2CAccessService s2CAccessService;
	
	private static final Logger LOGGER = Logger.getLogger(GatewayManagerWebService.class);
	
	@RequestMapping(value = "/GatewaySummary/{gatewayId}", method = RequestMethod.GET, produces = {
			"application/json" })
	@ResponseBody
	public GatewaySummary getGatewaySummary(@PathVariable("gatewayId") String gatewayId) {
		GatewaySummary gatewaySummary = new GatewaySummary();
		if (ValidatorUtils.validateField("gatewayId", gatewayId)
				&& (gatewayManagerService.isGatewayIdExist(gatewayId))) {
			gatewaySummary = gatewayManagerService.getGatewaySummary(gatewayId);
		}
		return gatewaySummary;
	}

	@RequestMapping(value = "/GatewayTypeList", method = RequestMethod.GET, produces = { "application/json" })
	@ResponseBody
	public List<GatewayType> getGatewayTypeList() throws Exception {
		List<GatewayType> gatewayTypes = new ArrayList<GatewayType>();
		gatewayTypes = gatewayManagerService.getGatewayTypeList();
		return gatewayTypes;
	}

	/**
	 * @param gatewayRequest
	 * @return
	 * @throws Exception
	 */
	@PreAuthorize("hasRole('ADMIN') or hasRole('SUPER')")
	@RequestMapping(value = "/CreateGateway", method = RequestMethod.POST, produces = { "application/json" })
	@ResponseBody
	public String createGateway(@RequestBody CreateGatewayRequest gatewayRequest) throws Exception {
		LOGGER.info("Inside createGateway");
		String gatewayId = "";
		if (ValidatorUtils.validateEntity(gatewayRequest)) {
			gatewayId = gatewayManagerService.createGateway(gatewayRequest);
			
		}
		if(gatewayId!=null){
			
			gatewayManagerService.createWanPolicy(getWanPolicyRequest(gatewayId));
			List<String> tempList=new ArrayList<String>();
			List<VerticalBundleResponse> verticalBundleList=s2CAccessService.getSmartCityVerticalBundles();
			LOGGER.info("verticalBundleList=" + verticalBundleList);
			if (verticalBundleList.size() == 0) {
				gatewayManagerService.createVreticalBundle(getVerticalBundleRequest(gatewayId));
				verticalBundleList=s2CAccessService.getSmartCityVerticalBundles();
			}  
			
			if(verticalBundleList.size() > 0){
				tempList = verticalBundleList.get(0).getGatewayId();
				tempList.add(gatewayId);
				gatewayManagerService.assocaiteVerticalBundleGateway(verticalBundleList.get(0).getBundleId(), tempList);
			}
			
		}
		return gatewayId;
	}

	private VerticalBundleRequest getVerticalBundleRequest(String gatewayId) {
		VerticalBundleRequest VerticalBundleRequest = new VerticalBundleRequest();
		List<String> gatewaylist=new ArrayList<String>();
			gatewaylist.add(gatewayId);
		VerticalBundleRequest.setGatewayIds(gatewaylist);
		VerticalBundleRequest.setBundleName(messageSource.getMessage("S2C_CREATE_VERTICAL_BUNDLE_NAME", new Object[] { "S2C_CREATE_VERTICAL_BUNDLE_NAME" }, Locale.ENGLISH));
		VerticalBundleRequest.setBundleURL(messageSource.getMessage("S2C_CREATE_VERTICAL_BUNDLE_URL", new Object[] { "S2C_CREATE_VERTICAL_BUNDLE_URL" }, Locale.ENGLISH));
		VerticalBundleRequest.setConfigfilename(messageSource.getMessage("S2C_CREATE_VERTICAL_CONFIG_FILE_NAME", new Object[] { "S2C_CREATE_VERTICAL_CONFIG_FILE_NAME" }, Locale.ENGLISH));
		VerticalBundleRequest.setConfigfilepath(messageSource.getMessage("S2C_CREATE_VERTICAL_CONFIG_FILE_PATH", new Object[] { "S2C_CREATE_VERTICAL_CONFIG_FILE_PATH" }, Locale.ENGLISH));
		VerticalBundleRequest.setStartpriority(messageSource.getMessage("S2C_CREATE_VERTICAL_START_PRIORITY", new Object[] { "S2C_CREATE_VERTICAL_START_PRIORITY" }, Locale.ENGLISH));
		VerticalBundleRequest.setVerticalName(messageSource.getMessage("S2C_CREATE_VERTICAL_VERTICAL_NAME", new Object[] { "S2C_CREATE_VERTICAL_VERTICAL_NAME" }, Locale.ENGLISH));
		return VerticalBundleRequest;
	}

	private VerticalBundleRequest getUpdateVerticalBundleRequest(List<VerticalBundleResponse> verticalBundleList,String gatewayId) {
		VerticalBundleRequest VerticalBundleRequest = new VerticalBundleRequest();
		int count=0;
		List<String> gatewaylist=new ArrayList<String>();
		for(VerticalBundleResponse verticalBundleResponse:verticalBundleList){
			if (verticalBundleResponse.getVerticalName().equalsIgnoreCase("smartcity")) {
				if(count<1){
					VerticalBundleRequest.setBundleId(verticalBundleResponse.getBundleId());
					VerticalBundleRequest.setBundleName(verticalBundleResponse.getBundleName());
					VerticalBundleRequest.setBundleURL(verticalBundleResponse.getBundleURL());
					VerticalBundleRequest.setConfigfilename(verticalBundleResponse.getConfigfilename());
					VerticalBundleRequest.setConfigfilepath(verticalBundleResponse.getConfigfilepath());
					VerticalBundleRequest.setStartpriority(verticalBundleResponse.getStartpriority());
					VerticalBundleRequest.setVerticalName(verticalBundleResponse.getVerticalName());
					gatewaylist=verticalBundleResponse.getGatewayId();
				}
			}
			count++;
		}
		gatewaylist.add(gatewayId);
		VerticalBundleRequest.setGatewayIds(gatewaylist);
		return VerticalBundleRequest;
	}
	private WanPolicyRequest getWanPolicyRequest(String gatewayId) {
		WanPolicyRequest wanPolicyRequest = new WanPolicyRequest();
		wanPolicyRequest.setGatewayId(gatewayId);
		wanPolicyRequest.setIpAssignment("DHCP");
		wanPolicyRequest.setPriority("ethernet10");
		wanPolicyRequest.setResetIntervalTime("3600");
		wanPolicyRequest.setReceiveTime("2015-09-11 17:16:06");
		return wanPolicyRequest;
	}

	@RequestMapping(value = "/GatewayList", method = RequestMethod.GET, produces = { "application/json" })
	@ResponseBody
	public List<GatewayList> getGatewayList() {
		List<GatewayList> gatewayLists = gatewayManagerService.getGatewayList();
		return gatewayLists;
	}

	@PreAuthorize("hasRole('ADMIN') or hasRole('SUPER')")
	@RequestMapping(value = "/DeleteGateway", method = RequestMethod.DELETE, produces = {
			"application/json" })
	@ResponseBody
	public Map<String, List<String>> deleteGateway(@RequestBody List<String> gatewayIds) throws Exception {
		List<String> invalidGatewayIds = new ArrayList<String>();
		for(String gatewayId : gatewayIds) {
			if (!ValidatorUtils.validateField("gatewayId", gatewayId)
					|| (!gatewayManagerService.isGatewayIdExist(gatewayId))) {
				invalidGatewayIds.add(gatewayId);
				gatewayIds.remove(gatewayId);
			}
		}
		
		Map<String, List<String>> result = new HashMap<String, List<String>>();
		result.put("invalid", invalidGatewayIds);
		result.putAll(gatewayManagerService.deleteGateway(gatewayIds));
		
		return result;
	}

	@PreAuthorize("hasRole('ADMIN') or hasRole('SUPER')")
	@RequestMapping(value = "/UpdateGateway/{gatewayId}", method = RequestMethod.POST, produces = {
			"application/json" })
	@ResponseBody
	public void updateGateway(@PathVariable("gatewayId") String gatewayId,
			@RequestBody CreateGatewayRequest gatewayRequest) throws Exception {
		if ((ValidatorUtils.validateEntity(gatewayRequest)) && (ValidatorUtils.validateField("gatewayId", gatewayId))
				&& (gatewayManagerService.isGatewayIdExist(gatewayId))) {
			gatewayManagerService.updateGateway(gatewayId, gatewayRequest);
		}
	}

	// Need to think why it is required? While editing any gateway? then
	// makemodel and serial number will be required
	@RequestMapping(value = "/GatewayDetails/{gatewayId}", method = RequestMethod.GET, produces = {
			"application/json" })
	@ResponseBody
	public GatewayList getGatewayDetails(@PathVariable("gatewayId") String gatewayId) {
		GatewayList gatewayList = new GatewayList();
		if (ValidatorUtils.validateField("gatewayId", gatewayId)
				&& (gatewayManagerService.isGatewayIdExist(gatewayId))) {
			gatewayList = gatewayManagerService.getGatewayDetails(gatewayId);
		}
		return gatewayList;
	}

	@RequestMapping(value = "/AllGateways", method = RequestMethod.GET, produces = { "application/json" })
	@ResponseBody
	public List<AllGatewayList> getGateways() {
		return gatewayManagerService.getGateways();
	}

	@RequestMapping(value = "/GatewayPoles/{gatewayId}", method = RequestMethod.GET, produces = { "application/json" })
	@ResponseBody
	public List<Pole> getPoleSensors(@PathVariable("gatewayId") String gatewayId) {
		List<Pole> poles = new ArrayList<Pole>();
		if (ValidatorUtils.validateField("gatewayId", gatewayId)
				&& (gatewayManagerService.isGatewayIdExist(gatewayId))) {
			poles = gatewayManagerService.getGatewayPoles(gatewayId);
		}
		return poles;
	}

	@PreAuthorize("hasRole('ADMIN') or hasRole('SUPER')")
	@RequestMapping(value = "/AssociatePoles", method = RequestMethod.POST, produces = { "application/json" })
	@ResponseBody
	public String associatePoles(@RequestBody GatewayPoleAssociationRequest gatewayPoleAssociationRequest) throws Exception {
		if (ValidatorUtils.validateEntity(gatewayPoleAssociationRequest)
				&& (gatewayManagerService.isGatewayIdExist(gatewayPoleAssociationRequest.getGatewayId()))
				&& (poleManagerService.poleIdsExist(gatewayPoleAssociationRequest.getPoleIdList()))) {
			gatewayManagerService.associatePoles(gatewayPoleAssociationRequest);
			
			//Code to update Pole and Gateway Presets
			List<PoleEntity> poleEntityList = new ArrayList<PoleEntity>();	
			List<Pole> poleList=gatewayManagerService.getGatewayPoles(gatewayPoleAssociationRequest.getGatewayId());
			GatewayEntity gwEntity = gatewayManagerService.getObjectById(gatewayPoleAssociationRequest.getGatewayId());

			for(Pole pole:poleList){
				PoleEntity poleEntity = this.poleManagerService.getPoleEntityById(pole.getId()); 	

				poleEntityList.add(poleEntity);
			}
		
			EventPresetEntity eventPresetEntity = gwEntity.getGatewayPresets().getEventPreset();
			if(eventPresetEntity!=null)
			{
				if(poleEntityList!=null && !poleEntityList.isEmpty())
				{
					this.poleManagerService.updatePolePresets(poleEntityList, eventPresetEntity);
				}
			
				for (PoleEntity poleEntity : poleEntityList) {
					List<PoleSensorEntity> poleSensorEntityList= gatewayManagerService.getPoleSensorEntityById(poleEntity,gwEntity);
					poleEntity.setPoleSensors(poleSensorEntityList);
				}
			}
			else
			{
				throw new SmartCityDBException("Gateway preset not found");
			}
			/////////////////////////////
		}
		return "Associated gateway : "+gatewayPoleAssociationRequest.getGatewayId()+" with poles : "+gatewayPoleAssociationRequest.getPoleIdList().toString()+" successfully.";
	}

	@PreAuthorize("hasRole('ADMIN') or hasRole('SUPER')")
	@RequestMapping(value = "/DessociatePoles", method = RequestMethod.POST, produces = { "application/json" })
	@ResponseBody
	public void dessociatePoles(@RequestBody GatewayPoleAssociationRequest gatewayPoleAssociationRequest) throws Exception {
		if (ValidatorUtils.validateEntity(gatewayPoleAssociationRequest)
				&& (gatewayManagerService.isGatewayIdExist(gatewayPoleAssociationRequest.getGatewayId()))
				&& (poleManagerService.poleIdsExist(gatewayPoleAssociationRequest.getPoleIdList()))) {
			gatewayManagerService.dessociatePoles(gatewayPoleAssociationRequest);
		}
	}
	
	@PreAuthorize("hasRole('ADMIN') or hasRole('SUPER')")
	@RequestMapping(value = "/DessociateGatewaysPoles", method = RequestMethod.POST, produces = { "application/json" })
	@ResponseBody
	public Map<String, List<String>> dessociateGatewaysPoles(@RequestBody List<String> gatewayIds) throws Exception {
		List<String> invalidGatewayIds = new ArrayList<String>();
		for(String gatewayId : gatewayIds) {
			if (!ValidatorUtils.validateField("gatewayId", gatewayId)
					|| (!gatewayManagerService.isGatewayIdExist(gatewayId))) {
				invalidGatewayIds.add(gatewayId);
				gatewayIds.remove(gatewayId);
			}
		}
		
		Map<String, List<String>> result = new HashMap<String, List<String>>();
		result.put("invalid", invalidGatewayIds);
		result.putAll(gatewayManagerService.dessociateGatewaysPoles(gatewayIds));
		
		return result;
	}

	@PreAuthorize("hasRole('ADMIN') or hasRole('SUPER')")
	@RequestMapping(value = "/UpdateGatewayPoleAssociation", method = RequestMethod.POST, produces = {
			"application/json" })
	@ResponseBody
	public void UpdateGatewayPoleAssociation(@RequestBody GatewayPoleAssociationRequest gatewayPoleAssociationRequest) throws Exception {
		if (ValidatorUtils.validateEntity(gatewayPoleAssociationRequest)
				&& (gatewayManagerService.isGatewayIdExist(gatewayPoleAssociationRequest.getGatewayId()))
				&& (poleManagerService.poleIdsExist(gatewayPoleAssociationRequest.getPoleIdList()))) {
			gatewayManagerService.UpdateGatewayPoleAssociation(gatewayPoleAssociationRequest);
		}
	}

	@RequestMapping(value = "/GatewayPoleAssociationList", method = RequestMethod.GET, produces = {
			"application/json" })
	@ResponseBody
	public List<GatewayPoleAssociationList> gatewayPoleAssociationList() {
		List<GatewayPoleAssociationList> gatewayPoleAssociationLists = gatewayManagerService
				.getGatewayPoleAssociationList();
		return gatewayPoleAssociationLists;
	}

	@RequestMapping(value = "/OrphanGateways", method = RequestMethod.GET, produces = { "application/json" })
	@ResponseBody
	public List<GatewayList> OrphanGateways() {
		List<GatewayList> gatewayLists = gatewayManagerService.getOrphanGateways();
		return gatewayLists;
	}
	
	/**
	 * Updates gateway Preset
	 * 
	 * @param UpdateGatewayPresetRequest
	 * @return message
	 */
	@PreAuthorize("hasRole('ADMIN') or hasRole('SUPER')")
	@RequestMapping(value = "/UpdateGatewayPresets", method = RequestMethod.POST, consumes = {
			"application/json" }, produces = { "application/json" })
	@ResponseBody
	public String updategatewayPresets(@RequestBody UpdateGatewayPresetRequest updateGatewayPresetRequest,
			final BindingResult result) {
		if (ValidatorUtils.validateEntity(updateGatewayPresetRequest)) {
			gatewayManagerService.updateGatewayPresets(updateGatewayPresetRequest);
		}
		return messageSource.getMessage("gatewayPresetsUpdated", new Object[] { "gatewayPresetsUpdated" }, Locale.ENGLISH);
	}
	
	@RequestMapping(value = "/VerticalBundleList", method = RequestMethod.GET, produces = { "application/json" })
	@ResponseBody
	public  List<VerticalBundleResponse> getVerticalBundleList() throws Exception {
		return s2CAccessService.getSmartCityVerticalBundles();
	}
}