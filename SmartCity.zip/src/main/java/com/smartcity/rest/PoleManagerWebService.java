package com.smartcity.rest;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.smartcity.common.RequestParameter;
import com.smartcity.jsonbean.CreatePoleRequest;
import com.smartcity.jsonbean.DeletePoleRequest;
import com.smartcity.jsonbean.DeletePoleRequestList;
import com.smartcity.jsonbean.Pole;
import com.smartcity.jsonbean.PoleList;
import com.smartcity.jsonbean.PoleSensor;
import com.smartcity.jsonbean.PoleSensorAssociationList;
import com.smartcity.jsonbean.PoleSummary;
import com.smartcity.jsonbean.UpdatePoleDetailsRequest;
import com.smartcity.jsonbean.UpdatePolePresetRequest;
import com.smartcity.service.PoleManagerService;
import com.smartcity.service.PolePresetManagerService;
import com.smartcity.util.ValidatorUtils;

@RestController
@RequestMapping(value = "/API/Pole")
public class PoleManagerWebService {

	private static final Logger LOGGER = Logger.getLogger(PoleManagerWebService.class);

	@Autowired
	private PoleManagerService poleManagerService;

	@Autowired
	private MessageSource messageSource;

	@Autowired
	private	PolePresetManagerService polePresetManagerService;

	@RequestMapping(value = "/SensorList/{POLEID}", method = RequestMethod.GET, produces = { "application/json" })
	public Pole getSensorDetails(@PathVariable("POLEID") String poleid) {
		LOGGER.info("Inside getSensorDetails:: PoleManagerWebService");
		Pole pole = new Pole();
		pole = poleManagerService.getPoleById(poleid);
		LOGGER.info("Pole Details ::::" + pole);
		return pole;
	}

	/**
	 * Returns Pole Summary
	 * 
	 * @param poleId
	 * @return a list of poleSummary
	 */
	@RequestMapping(value = "/PoleSummary/{poleId}", method = RequestMethod.GET, produces = { "application/json" })	
	public PoleSummary getPoleSummarys(@PathVariable("poleId") String poleId) {
		LOGGER.info("Inside getPoleSummarys:: PoleManagerWebService");
		PoleSummary poleSummary = new PoleSummary();
		poleSummary = poleManagerService.getPoleSummary(poleId);
		return poleSummary;
	}

	/**
	 * Creates New Pole
	 * 
	 * @param poleRequset
	 * @return Message
	 */
	@PreAuthorize("hasRole('ADMIN') or hasRole('SUPER')")
	@RequestMapping(value = "/AddPole", method = RequestMethod.POST, consumes = { "application/json" }, produces = {
			"application/json" })
	public HashMap<String, String> createPole(@RequestBody final CreatePoleRequest poleRequest) {
		LOGGER.info("Inside createPole:: PoleManagerWebService");
		HashMap<String, String> map = new HashMap<String, String>();
		if (ValidatorUtils.validateEntity(poleRequest) && poleManagerService.isPoleNameExist(poleRequest.getName())) {
			LOGGER.info("inside AddPole");
			String poleId = poleManagerService.createPole(poleRequest);
			polePresetManagerService.createPolePreset(poleId);
			map.put("poleId", poleId);

		}
		return map;
	}

	/**
	 * Updates Pole Details
	 * @param UpdatePoleDetailsRequest
	 * @param poleId
	 * @return String displaying Pole Updated message with poleId
	 */
	@PreAuthorize("hasRole('ADMIN') or hasRole('SUPER')")
	@RequestMapping(value = "/UpdatePole/{poleId}", method = RequestMethod.POST, consumes = {
			"application/json" }, produces = { "application/json" })
	public String updatePole(@RequestBody final UpdatePoleDetailsRequest updatePoleDetailsRequest, @PathVariable("poleId") String poleId) {
		LOGGER.info("Inside updatePole:: PoleManagerWebService");		
		if ((ValidatorUtils.validateField("PoleId", poleId) && poleManagerService.isPoleIdExist(poleId))) {
			if (updatePoleDetailsRequest.getName() != null) {
				poleManagerService.isPoleNameExist(updatePoleDetailsRequest.getName(), poleId);
			}
			LOGGER.info("Poles validated::::::");
			this.poleManagerService.updatePole(updatePoleDetailsRequest, poleId);
			return messageSource.getMessage("PoleUpdated", new Object[] { "PoleUpdated" }, Locale.ENGLISH);
		}

		return messageSource.getMessage("PoleNotUpdated", new Object[] { "PoleNotUpdated" }, Locale.ENGLISH);
	}

	/**
	 * Delete pole if not associated with any sensor or gateway
	 * 
	 * @param List
	 *            of pole ids : deletePoleRequestListPoleList
	 * @return message
	 */
	@PreAuthorize("hasRole('ADMIN')")
	@RequestMapping(value = "/DeletePole", method = RequestMethod.DELETE, consumes = {
			"application/json" }, produces = { "application/json" })
	public String deletePole(@RequestBody final DeletePoleRequestList deletePoleRequestList) {		
		LOGGER.info("Inside deletePole:: PoleManagerWebService");	
		LOGGER.info("Pole List size::::::" + deletePoleRequestList.getPoleList().size());
		for (DeletePoleRequest req : deletePoleRequestList.getPoleList()) {
			if (ValidatorUtils.validateField("PoleId", req.getPoleId())
					&& poleManagerService.isPoleIdExist(req.getPoleId())) {
				LOGGER.info("Poles validated::::::");
			}

		}
		this.poleManagerService.deletePole(deletePoleRequestList);
		return messageSource.getMessage("deletemessage", new Object[] { "deletemessage" }, Locale.ENGLISH);
	}

	/**
	 * Returns list of Poles with details
	 * 
	 * @param requestParameter
	 * @return a list of poles
	 */
	@RequestMapping(value = "/PoleList", method = RequestMethod.POST, consumes = { "application/json" }, produces = {
			"application/json" })
	public List<PoleList> getAllPoles(@RequestBody final RequestParameter requestParameter,
			@RequestParam(required = false, defaultValue = "1") int page,
			@RequestParam(required = false, defaultValue = "100") int limit) {
		LOGGER.info("Inside getAllPoles:: PoleManagerWebService");
		return poleManagerService.getPoleList(requestParameter, page, limit);
	}

	/**
	 * Returns list of poleid and name
	 * 
	 * @return a list of poles
	 */
	@PreAuthorize("hasRole('ADMIN')")
	@RequestMapping(value = "/AllPoles", method = RequestMethod.GET, produces = { "application/json" })
	
	public List<PoleList> getPoles() {
		LOGGER.info("Inside getPoles:: PoleManagerWebService");
		return poleManagerService.getPoles();
	}

	@RequestMapping(value = "/OrphanPoles", method = RequestMethod.GET, produces = { "application/json" })
	
	public List<Pole> getOrphanPoles() {
		LOGGER.info("Inside getOrphanPoles:: PoleManagerWebService");
		List<Pole> poles = poleManagerService.getOrphanPoles();
		return poles;
	}

	/**
	 * Adds Pole Sensor association
	 * 
	 * @param poleId
	 * @param SensorList
	 * @return message
	 * @throws Exception
	 */
	@PreAuthorize("hasRole('ADMIN') or hasRole('SUPER')")
	@RequestMapping(value = "/AddPoleSensorAssociation", method = RequestMethod.POST, consumes = {
			"application/json" }, produces = { "application/json" })
	
	public HashMap<String, String> addPoleSensorAssociation(@RequestBody PoleSensor poleSensor) throws Exception {
		LOGGER.info("Inside addPoleSensorAssociation:: PoleManagerWebService");
		HashMap<String, String> map = new HashMap<String, String>();
		if (ValidatorUtils.validateEntity(poleSensor)) {
			String poleSensorId = poleManagerService.addPoleSensorAssociation(poleSensor);
			map.put("poleSensorId", poleSensorId);


		}
		return map;
	}

	/**
	 * Delete Pole Sensor association
	 * 
	 * @param poleId
	 * @param SensorId
	 * @return message
	 * @throws Exception
	 */
	@PreAuthorize("hasRole('ADMIN')")
	@RequestMapping(value = "/DeletePoleSensorAssociation", method = RequestMethod.DELETE, consumes = {
			"application/json" }, produces = { "application/json" })
	public String deletePoleSensorAssociation(@RequestBody final DeletePoleRequestList deletePoleRequestList) throws Exception {
		LOGGER.info("Inside deletePoleSensorAssociation:: PoleManagerWebService");
		for (DeletePoleRequest req : deletePoleRequestList.getPoleList()) {
			if (ValidatorUtils.validateField("PoleId", req.getPoleId())
					&& poleManagerService.isPoleIdExist(req.getPoleId())) {
				LOGGER.info("Poles validated::::::");
			}

		}
		if (ValidatorUtils.validateEntity(deletePoleRequestList)) {
			poleManagerService.deletePoleSensorAssociation(deletePoleRequestList);
		}
		return messageSource.getMessage("PoleSensorAssociationDeleted", new Object[] { "PoleSensorAssociationDeleted" },
				Locale.ENGLISH);
	}

	/*
	 * Returns list of Poles and and respective associations
	 * 
	 * @return a list of Pole with association
	 */
	@RequestMapping(value = "/PoleSensorAssociationList", method = RequestMethod.POST, consumes = {
			"application/json" }, produces = { "application/json" })
	
	public List<PoleSensorAssociationList> poleSensorAssociationList(
			@RequestBody final RequestParameter requestParameter,
			@RequestParam(required = false, defaultValue = "1") int page,
			@RequestParam(required = false, defaultValue = "100") int limit) {
		LOGGER.info("Inside poleSensorAssociationList:: PoleManagerWebService");
		List<PoleSensorAssociationList> poleSensorAssociationList = poleManagerService
				.getPoleSensorAssociationList(requestParameter, page, limit);
		return poleSensorAssociationList;
	}

	/**
	 * Updates Pole Preset
	 * 
	 * @param UpdatePolePresetRequest
	 * @return message
	 */
	@PreAuthorize("hasRole('ADMIN') or hasRole('SUPER')")
	@RequestMapping(value = "/UpdatePolePresets", method = RequestMethod.POST, consumes = {
			"application/json" }, produces = { "application/json" })
	public String updatePolePresets(@RequestBody UpdatePolePresetRequest updatePolePresetRequest) {
		LOGGER.info("Inside updatePolePresets:: PoleManagerWebService");
		if (ValidatorUtils.validateEntity(updatePolePresetRequest)) {
			poleManagerService.updatePolePresets(updatePolePresetRequest);
		}
		return messageSource.getMessage("PolePresetsUpdated", new Object[] { "PolePresetsUpdated" }, Locale.ENGLISH);
	}
}