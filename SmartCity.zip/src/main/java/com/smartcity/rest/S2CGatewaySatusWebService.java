package com.smartcity.rest;

import java.io.Serializable;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.smartcity.jsonbean.s2c.GatewayStatusRequest;
import com.smartcity.service.GatewayStatusService;
@RestController
@RequestMapping(value = "/gateway")
public class S2CGatewaySatusWebService {
	private static final Logger LOGGER = Logger.getLogger(S2CGatewaySatusWebService.class);
	
	@Autowired GatewayStatusService gatewayStatusService;
	
	@RequestMapping(value = "/gatewayStatus", method = RequestMethod.POST, produces = { "application/json" })
	public Serializable saveGatewayStatus(@RequestBody GatewayStatusRequest gatewayStatusRequest) {
		LOGGER.info("GatewayStatusLog::::::" + gatewayStatusRequest);
		return gatewayStatusService.saveGatewayStatus(gatewayStatusRequest);
	}

}
