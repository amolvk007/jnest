package com.smartcity.rest;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.smartcity.jsonbean.ParkingLotDetails;
import com.smartcity.service.ParkingManagerService;

@RestController
@RequestMapping(value = "/API/Parking")
public class ParkingManagerWebService {
	
	@Autowired
	private ParkingManagerService parkingManagerService;
	
	@RequestMapping(value = "/parkingLotDetails/{districtId}", method = RequestMethod.GET, produces = { "application/json" })
    @ResponseBody
	public List<ParkingLotDetails> getDistrictGatewayList(@PathVariable("districtId") String districtId) {
		
		List<ParkingLotDetails> parkingLotDetailsList = new ArrayList<ParkingLotDetails>();
		parkingLotDetailsList = parkingManagerService.getParkingLotDetails(districtId);
		return parkingLotDetailsList;
	}
}
