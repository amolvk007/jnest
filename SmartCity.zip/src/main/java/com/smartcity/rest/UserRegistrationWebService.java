/**
 * 
 */
package com.smartcity.rest;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.smartcity.jsonbean.S2CUserResponse;

/**
 * @author inrpande01
 *
 */
@RestController
@RequestMapping(value = "/userRegistration")
public class UserRegistrationWebService {
	
	private static final Logger LOGGER = Logger.getLogger(UserRegistrationWebService.class);

	@Value("${VERTICAL_USER_FIRST_NAME}")
	private String VERTICAL_USER_FIRST_NAME;
	
	@Value("${VERTICAL_USER_LAST_NAME}")
	private String VERTICAL_USER_LAST_NAME;
	
	@Value("${VERTICAL_USER_EMAIL}")
	private String VERTICAL_USER_EMAIL;
	
	@Value("${VERTICAL_USER}")
	private String VERTICAL_USER;
	
	@RequestMapping(value = "/getUserList", method = RequestMethod.GET, produces = { "application/json" })
	public List<S2CUserResponse> getUserList() {
		LOGGER.info("Syncing users with S2C");
		List<S2CUserResponse> UserResponseList = new ArrayList<S2CUserResponse>();

		S2CUserResponse S2CUserResponse = new S2CUserResponse();

		S2CUserResponse.setFirstName(VERTICAL_USER_FIRST_NAME);
		S2CUserResponse.setLastName(VERTICAL_USER_LAST_NAME);
		S2CUserResponse.setActive("true");
		S2CUserResponse.setEmail(VERTICAL_USER_EMAIL);
		S2CUserResponse.setLoginName(VERTICAL_USER);
		S2CUserResponse.setGender("Male");
		S2CUserResponse.setLastUpdatedDate(System.currentTimeMillis()+"");
		S2CUserResponse.setCreateDate(System.currentTimeMillis()+"");
		UserResponseList.add(S2CUserResponse);
		return UserResponseList;
	}
}
