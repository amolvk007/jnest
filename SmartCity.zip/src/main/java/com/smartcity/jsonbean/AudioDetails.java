package com.smartcity.jsonbean;

public class AudioDetails {

	private String songPlaying;
	private String currentPlaylist;
	private String playlist;
 
	public String getSongPlaying() {
		return songPlaying;
	}
	public void setSongPlaying(String songPlaying) {
		this.songPlaying = songPlaying;
	}
	public String getCurrentPlaylist() {
		return currentPlaylist;
	}
	public void setCurrentPlaylist(String currentPlaylist) {
		this.currentPlaylist = currentPlaylist;
	}
	public String getPlaylist() {
		return playlist;
	}
	public void setPlaylist(String playlist) {
		this.playlist = playlist;
	}
	
	@Override
	public String toString() {
		return "AudioDetails [songPlaying=" + songPlaying + ", currentPlaylist=" + currentPlaylist + ", playlist="
				+ playlist + "]";
	}
 
	
 
}
