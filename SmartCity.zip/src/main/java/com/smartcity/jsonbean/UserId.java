/**
 * 
 */
package com.smartcity.jsonbean;

/**
 * @author inrpande01
 *
 */
public class UserId {

	private String userId;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}
}
