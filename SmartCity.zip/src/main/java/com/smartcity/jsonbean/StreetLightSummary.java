package com.smartcity.jsonbean;

public class StreetLightSummary {
    
	
   	private String total="0";
   	private String operational="0";
   	private String nonOperational="0";
   	
	
	public String getTotal() {
		return total;
	}
	public void setTotal(String total) {
		this.total = total;
	}
	public String getOperational() {
		return operational;
	}
	public void setOperational(String operational) {
		this.operational = operational;
	}
	
	public String getNonOperational() {
		return nonOperational;
	}
	public void setNonOperational(String nonOperational) {
		this.nonOperational = nonOperational;
	}
	@Override
	public String toString() {
		return "StreetLightSummary [total=" + total + ", operational=" + operational + ", nonOperational="
				+ nonOperational + "]";
	}
	
	
   	
   	

}
