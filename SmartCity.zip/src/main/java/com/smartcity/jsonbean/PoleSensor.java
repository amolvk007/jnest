package com.smartcity.jsonbean;

import java.util.List;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;


public class PoleSensor {
	@NotNull(message="mandatory")
	private String poleId;
	
	@NotNull(message="mandatory")
	@NotEmpty(message="mandatory")
	private List<String> sensorIdList;
	
	public String getPoleId() {
		return poleId;
	}
	public void setPoleId(String poleId) {
		this.poleId = poleId;
	}
	public List<String> getSensorIdList() {
		return sensorIdList;
	}
	public void setSensorIdList(List<String> sensorIdList) {
		this.sensorIdList = sensorIdList;
	}
	

}
