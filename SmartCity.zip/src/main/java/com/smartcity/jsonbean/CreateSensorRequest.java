package com.smartcity.jsonbean;

import javax.validation.constraints.NotNull;

public class CreateSensorRequest {

	@NotNull(message="mandatory")
    String name;                         
 
	@NotNull(message="mandatory")
	String sensorTypeId;
	
	@NotNull(message="mandatory")
	String serialNumber;
	
	@NotNull(message="mandatory")
	String connectioninfo;
	
	@NotNull(message="mandatory")
	String connectioninfo1;
	
	public String getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSensorTypeId() {
		return sensorTypeId;
	}
	public void setSensorTypeId(String sensorTypeId) {
		this.sensorTypeId = sensorTypeId;
	}
	public String getConnectioninfo() {
		return connectioninfo;
	}
	public void setConnectioninfo(String connectioninfo) {
		this.connectioninfo = connectioninfo;
	}
	public String getConnectioninfo1() {
		return connectioninfo1;
	}
	public void setConnectioninfo1(String connectioninfo1) {
		this.connectioninfo1 = connectioninfo1;
	}
	
}
