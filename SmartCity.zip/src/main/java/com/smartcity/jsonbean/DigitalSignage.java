package com.smartcity.jsonbean;

public class DigitalSignage {
	   private String temperature;
       private String warningMessage;
       
	public String getTemperature() {
		return temperature;
	}
	public void setTemperature(String temperature) {
		this.temperature = temperature;
	}
	public String getWarningMessage() {
		return warningMessage;
	}
	public void setWarningMessage(String warningMessage) {
		this.warningMessage = warningMessage;
	}
	@Override
	public String toString() {
		return "DigitalSignage [temperature=" + temperature + ", warningMessage=" + warningMessage + "]";
	}
   
       
	       
       

}
