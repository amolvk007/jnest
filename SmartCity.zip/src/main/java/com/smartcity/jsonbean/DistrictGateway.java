package com.smartcity.jsonbean;

import java.util.List;

import javax.validation.constraints.NotNull;

public class DistrictGateway {
	
	@NotNull(message="mandatory")
	private String districtId;
	@NotNull(message="mandatory")
	private List<String> gatewayIdList;
	
	
	public String getDistrictId() {
		return districtId;
	}
	public void setDistrictId(String districtId) {
		this.districtId = districtId;
	}
	public List<String> getGatewayIdList() {
		return gatewayIdList;
	}
	public void setGatewayIdList(List<String> gatewayIdList) {
		this.gatewayIdList = gatewayIdList;
	}
	
	@Override
	public String toString() {
		return "DistrictGateway [districtId=" + districtId + ", gatewayIdList=" + gatewayIdList + "]";
	}
	

	
}
