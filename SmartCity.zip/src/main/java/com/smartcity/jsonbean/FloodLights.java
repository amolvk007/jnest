package com.smartcity.jsonbean;

public class FloodLights {

	private String totalFloodLights;
	private String on;
	private String off;
	
	public String getTotalFloodLights() {
		return totalFloodLights;
	}
	public void setTotalFloodLights(String totalFloodLights) {
		this.totalFloodLights = totalFloodLights;
	}
	public String getOn() {
		return on;
	}
	public void setOn(String on) {
		this.on = on;
	}
	public String getOff() {
		return off;
	}
	public void setOff(String off) {
		this.off = off;
	}
	
	
	@Override
	public String toString() {
		return "FloodLights [totalFloodLights=" + totalFloodLights + ", on=" + on + ", off=" + off + "]";
	}
	
	
       
}
