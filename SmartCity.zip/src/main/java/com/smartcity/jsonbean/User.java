package com.smartcity.jsonbean;

import java.util.List;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;

import com.smartcity.validator.AlphaNumeric;

public class User {
	
	//@NotNull(message="districtId")
	private String districtId;
	
	private String userId;
	
	private List<UserId> userIdList;

	
	@NotNull(message="mandatory")
//	@Size(min=4, max=20)
	@Size(min=4,max=20,message="fieldlengtherror")
	@AlphaNumeric(message="alphanumeric")
	private String userName;
	
	//@NotNull(message="email")
	@Email(message="invalideEmail")
	private String email;

	@NotNull(message="mandatory")
	private String firstName;
	
	@NotNull(message="mandatory")
	private String lastName;
	
	@Size(min=4,max=20,message="fieldlengtherror")
	@NotNull(message="mandatory")
	private String password;

	@NotNull(message="mandatory")
	private String userRole;
	
	private String isPasswordSend;
	private String picPath;

	public String getPicPath() {
		return picPath;
	}
	public void setPicPath(String picPath) {
		this.picPath = picPath;
	}
	
	public String getUserName() {
		return userName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserRole() {
		return userRole;
	}
	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}
	public String getDistrictId() {
		return districtId;
	}
	public void setDistrictId(String districtId) {
		this.districtId = districtId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}

	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String isPasswordSend() {
		return isPasswordSend;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public void setPasswordSend(String isPasswordSend) {
		this.isPasswordSend = isPasswordSend;
	}

	public List<UserId> getUserIdList() {
		return userIdList;
	}

	public void setUserIdList(List<UserId> userIdList) {
		this.userIdList = userIdList;
	}
	@Override
	public String toString() {
		return "User [districtId=" + districtId + ", userId=" + userId + ", userIdList=" + userIdList + ", userName="
				+ userName + ", email=" + email + ", firstName=" + firstName + ", lastName=" + lastName + ", password="
				+ password + ", userRole=" + userRole + ", isPasswordSend=" + isPasswordSend + ", picPath=" + picPath
				+ "]";
	}

	
}
