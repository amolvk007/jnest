package com.smartcity.jsonbean;

import javax.validation.constraints.NotNull;

public class CreateGatewayRequest {
	
	@NotNull(message="mandatory")
    private String gatewayName;

	@NotNull(message="mandatory")
	private String serialNumber;
	
	@NotNull(message="mandatory")
	private String gatwayTypeId;
	
	@NotNull(message="mandatory")
	private String protocol;
	
	public String getGatewayName() {
		return gatewayName;
	}
	public void setGatewayName(String gatewayName) {
		this.gatewayName = gatewayName;
	}
	public String getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	public String getGatwayTypeId() {
		return gatwayTypeId;
	}
	public void setGatwayTypeId(String gatwayTypeId) {
		this.gatwayTypeId = gatwayTypeId;
	}
	public String getProtocol() {
		return protocol;
	}
	public void setProtocol(String protocol) {
		this.protocol = protocol;
	}
	
}
