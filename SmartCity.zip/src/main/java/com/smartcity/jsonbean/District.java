package com.smartcity.jsonbean;

import java.util.List;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;

public class District {
	
	private String districtId;
	
	@NotNull(message="districtName")
	@NotBlank(message="districtName")
	private String districtName;
	
	@NotNull(message="districtCoordinates")
	private List<Coordinates> districtCoordinates;
	
	public String getDistrictId() {
		return districtId;
	}
	public void setDistrictId(String districtId) {
		this.districtId = districtId;
	}
	public String getDistrictName() {
		return districtName;
	}
	public void setDistrictName(String districtName) {
		this.districtName = districtName;
	}
	public List<Coordinates> getDistrictCoordinates() {
		return districtCoordinates;
	}
	public void setDistrictCoordinates(List<Coordinates> districtCoordinates) {
		this.districtCoordinates = districtCoordinates;
	}
	
	@Override
	public String toString() {
		return "District [districtId=" + districtId + ", districtName=" + districtName + ", districtCoordinates="
				+ districtCoordinates + "]";
	}
	
	

	
	
	
	
}
