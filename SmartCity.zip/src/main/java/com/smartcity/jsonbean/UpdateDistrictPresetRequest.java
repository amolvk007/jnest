package com.smartcity.jsonbean;

import javax.validation.constraints.NotNull;

public class UpdateDistrictPresetRequest {

	@NotNull(message="mandatory")
	private String districtId;
	@NotNull(message="mandatory")
	private String beaconLightStatus;
	@NotNull(message="mandatory")
	private String beaconLightColor;	
	@NotNull(message="mandatory")
	private String floodLightStatus;
	@NotNull(message="mandatory")
	private String streetLightStatus;
	@NotNull(message="mandatory")
	private String intensity;
	@NotNull(message="mandatory")
	private String audio;
	@NotNull(message="mandatory")
	private String volume;
	@NotNull(message="mandatory")
	private String textMessage;
	@NotNull(message="mandatory")
	private String threshold;
	public String getDistrictId() {
		return districtId;
	}
	public void setDistrictId(String districtId) {
		this.districtId = districtId;
	}
	public String getBeaconLightStatus() {
		return beaconLightStatus;
	}
	public void setBeaconLightStatus(String beaconLightStatus) {
		this.beaconLightStatus = beaconLightStatus;
	}
	public String getBeaconLightColor() {
		return beaconLightColor;
	}
	public void setBeaconLightColor(String beaconLightColor) {
		this.beaconLightColor = beaconLightColor;
	}
	public String getFloodLightStatus() {
		return floodLightStatus;
	}
	public void setFloodLightStatus(String floodLightStatus) {
		this.floodLightStatus = floodLightStatus;
	}
	public String getStreetLightStatus() {
		return streetLightStatus;
	}
	public void setStreetLightStatus(String streetLightStatus) {
		this.streetLightStatus = streetLightStatus;
	}
	public String getIntensity() {
		return intensity;
	}
	public void setIntensity(String intensity) {
		this.intensity = intensity;
	}
	public String getAudio() {
		return audio;
	}
	public void setAudio(String audio) {
		this.audio = audio;
	}
	public String getVolume() {
		return volume;
	}
	public void setVolume(String volume) {
		this.volume = volume;
	}
	public String getTextMessage() {
		return textMessage;
	}
	public void setTextMessage(String textMessage) {
		this.textMessage = textMessage;
	}
	public String getThreshold() {
		return threshold;
	}
	public void setThreshold(String threshold) {
		this.threshold = threshold;
	}
}
