package com.smartcity.jsonbean;

public class GatewaySummary {

	private String districtId;
	private String districtName;
	private String gatewayId;
	private String gatewayName;
	
	private String ram;
	private String wifi;
	private String storage;
	private String battery;
	private String bluetooth;
	private String security;
	private String ip;
	private String network;

	private String totalPoles;
	private String alertThresholdLimit;
	private StreetLightSummary lights;
	private StreetLightSummary streetLights;

	/*private BeaconSummary beacon;
	private FloodLights floodLights;*/
	private LightSummary lightSummary;
	private AudioSummary audioSummary;
	private DigitalSignage digitalSignage;
	//private DigitalSignageSummary digitalSignageSummary;

	public String getDistrictId() {
		return districtId;
	}

	public void setDistrictId(String districtId) {
		this.districtId = districtId;
	}

	public String getDistrictName() {
		return districtName;
	}

	public String getGatewayId() {
		return gatewayId;
	}

	public void setGatewayId(String gatewayId) {
		this.gatewayId = gatewayId;
	}

	public String getGatewayName() {
		return gatewayName;
	}

	public void setGatewayName(String gatewayName) {
		this.gatewayName = gatewayName;
	}

	public String getRam() {
		return ram;
	}

	public void setRam(String ram) {
		this.ram = ram;
	}

	public String getWifi() {
		return wifi;
	}

	public void setWifi(String wifi) {
		this.wifi = wifi;
	}

	public String getStorage() {
		return storage;
	}

	public void setStorage(String storage) {
		this.storage = storage;
	}

	public String getBattery() {
		return battery;
	}

	public void setBattery(String battery) {
		this.battery = battery;
	}

	public String getBluetooth() {
		return bluetooth;
	}

	public void setBluetooth(String bluetooth) {
		this.bluetooth = bluetooth;
	}

	public String getSecurity() {
		return security;
	}

	public void setSecurity(String security) {
		this.security = security;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public String getNetwork() {
		return network;
	}

	public void setNetwork(String network) {
		this.network = network;
	}

	public void setDistrictName(String districtName) {
		this.districtName = districtName;
	}

	public String getTotalPoles() {
		return totalPoles;
	}

	public void setTotalPoles(String totalPoles) {
		this.totalPoles = totalPoles;
	}

	public String getAlertThresholdLimit() {
		return alertThresholdLimit;
	}

	public void setAlertThresholdLimit(String alertThresholdLimit) {
		this.alertThresholdLimit = alertThresholdLimit;
	}

	public StreetLightSummary getLights() {
		return lights;
	}

	public void setLights(StreetLightSummary lights) {
		this.lights = lights;
	}

	public StreetLightSummary getStreetLights() {
		return streetLights;
	}

	public void setStreetLights(StreetLightSummary streetLights) {
		this.streetLights = streetLights;
	}

	/*public BeaconSummary getBeacon() {
		return beacon;
	}

	public void setBeacon(BeaconSummary beacon) {
		this.beacon = beacon;
	}

	public FloodLights getFloodLights() {
		return floodLights;
	}

	public void setFloodLights(FloodLights floodLights) {
		this.floodLights = floodLights;
	}*/

	public LightSummary getLightSummary() {
		return lightSummary;
	}

	public void setLightSummary(LightSummary lightSummary) {
		this.lightSummary = lightSummary;
	}

	public AudioSummary getAudioSummary() {
		return audioSummary;
	}

	public void setAudioSummary(AudioSummary audioSummary) {
		this.audioSummary = audioSummary;
	}

	public DigitalSignage getDigitalSignage() {
		return digitalSignage;
	}

	/*public DigitalSignageSummary getDigitalSignageSummary() {
		return digitalSignageSummary;
	}

	public void setDigitalSignageSummary(DigitalSignageSummary digitalSignageSummary) {
		this.digitalSignageSummary = digitalSignageSummary;
	}*/

	public void setDigitalSignage(DigitalSignage digitalSignage) {
		this.digitalSignage = digitalSignage;
	}

}
