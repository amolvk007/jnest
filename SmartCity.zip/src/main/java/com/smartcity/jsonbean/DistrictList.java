package com.smartcity.jsonbean;

import java.sql.Timestamp;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;

public class DistrictList {

	private String id;

	@NotNull(message = "districtName")
	@NotBlank(message = "districtName")
	private String name;

	private Timestamp createdDate;

	private String districtCoordinates;

	
	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDistrictCoordinates() {
		return districtCoordinates;
	}

	public void setDistrictCoordinates(String districtCoordinates) {
		this.districtCoordinates = districtCoordinates;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "DistrictList [id=" + id + ", name=" + name + ", createdDate=" + createdDate + ", districtCoordinates="
				+ districtCoordinates + "]";
	}



}
