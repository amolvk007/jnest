package com.smartcity.jsonbean.s2c;

public class S2CGatewayType {

	String gatewayTypeId;
	String make;
	String model;
	String gatewayClass;
	
	String osName;
	String gatewayTypeName;
	
	public String getGatewayTypeId() {
		return gatewayTypeId;
	}
	public void setGatewayTypeId(String gatewayTypeId) {
		this.gatewayTypeId = gatewayTypeId;
	}
	public String getMake() {
		return make;
	}
	public void setMake(String make) {
		this.make = make;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getGatewayClass() {
		return gatewayClass;
	}
	public void setGatewayClass(String gatewayClass) {
		this.gatewayClass = gatewayClass;
	}
	public String getOsName() {
		return osName;
	}
	public void setOsName(String osName) {
		this.osName = osName;
	}
	public String getGatewayTypeName() {
		return gatewayTypeName;
	}
	public void setGatewayTypeName(String gatewayTypeName) {
		this.gatewayTypeName = gatewayTypeName;
	}
	
}
