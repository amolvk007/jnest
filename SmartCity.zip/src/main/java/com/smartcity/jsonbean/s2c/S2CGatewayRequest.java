package com.smartcity.jsonbean.s2c;

public class S2CGatewayRequest {

	String gatewayName;
	String serialNumber;
	String gatewayTypeId;
	String protocol;
	
	public String getGatewayName() {
		return gatewayName;
	}
	public void setGatewayName(String gatewayName) {
		this.gatewayName = gatewayName;
	}
	public String getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	public String getGatewayTypeId() {
		return gatewayTypeId;
	}
	public void setGatewayTypeId(String gatewayTypeId) {
		this.gatewayTypeId = gatewayTypeId;
	}
	public String getProtocol() {
		return protocol;
	}
	public void setProtocol(String protocol) {
		this.protocol = protocol;
	}
}
