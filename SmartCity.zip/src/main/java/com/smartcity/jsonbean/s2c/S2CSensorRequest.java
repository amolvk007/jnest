package com.smartcity.jsonbean.s2c;

public class S2CSensorRequest {

	String make;			//Optional
	String model;			//Optional
	String sensorTypeId;
	String sensorName;		//Optional
	String conninfo;		//Optional
	String frequency;		//Optional
	String minvalue;		//Optional
	String maxvalue;		//Optional
	String minvaluehb;		//Optional
	String maxvaluehb;		//Optional
	String conninfo1;		//Optional
	String serialNumber;
	String missionCritical;
	String verticalName;
	
	public String getMake() {
		return make;
	}
	public void setMake(String make) {
		this.make = make;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getSensorTypeId() {
		return sensorTypeId;
	}
	public void setSensorTypeId(String sensorTypeId) {
		this.sensorTypeId = sensorTypeId;
	}
	public String getSensorName() {
		return sensorName;
	}
	public void setSensorName(String sensorName) {
		this.sensorName = sensorName;
	}
	public String getConninfo() {
		return conninfo;
	}
	public void setConninfo(String conninfo) {
		this.conninfo = conninfo;
	}
	public String getFrequency() {
		return frequency;
	}
	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}
	public String getMinvalue() {
		return minvalue;
	}
	public void setMinvalue(String minvalue) {
		this.minvalue = minvalue;
	}
	public String getMaxvalue() {
		return maxvalue;
	}
	public void setMaxvalue(String maxvalue) {
		this.maxvalue = maxvalue;
	}
	public String getMinvaluehb() {
		return minvaluehb;
	}
	public void setMinvaluehb(String minvaluehb) {
		this.minvaluehb = minvaluehb;
	}
	public String getMaxvaluehb() {
		return maxvaluehb;
	}
	public void setMaxvaluehb(String maxvaluehb) {
		this.maxvaluehb = maxvaluehb;
	}
	public String getConninfo1() {
		return conninfo1;
	}
	public void setConninfo1(String conninfo1) {
		this.conninfo1 = conninfo1;
	}
	public String getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	public String getMissionCritical() {
		return missionCritical;
	}
	public void setMissionCritical(String missionCritical) {
		this.missionCritical = missionCritical;
	}
	public String getVerticalName() {
		return verticalName;
	}
	public void setVerticalName(String verticalName) {
		this.verticalName = verticalName;
	}
}
