/**
 * 
 */
package com.smartcity.jsonbean.s2c;

import java.util.List;

/**
 * @author inrpande01
 *
 */
public class VerticalBundleRequest {

	private String bundleId;
	private String bundleName;
	private String bundleURL;
	private String verticalName;
	private String configfilename;
	private String configfilepath;
	private String startpriority;
	private List<String> gatewayIds;
	
	public String getBundleId() {
		return bundleId;
	}
	public void setBundleId(String bundleId) {
		this.bundleId = bundleId;
	}
	public String getBundleName() {
		return bundleName;
	}
	public void setBundleName(String bundleName) {
		this.bundleName = bundleName;
	}
	public String getBundleURL() {
		return bundleURL;
	}
	public void setBundleURL(String bundleURL) {
		this.bundleURL = bundleURL;
	}
	public String getVerticalName() {
		return verticalName;
	}
	public void setVerticalName(String verticalName) {
		this.verticalName = verticalName;
	}
	public String getConfigfilename() {
		return configfilename;
	}
	public void setConfigfilename(String configfilename) {
		this.configfilename = configfilename;
	}
	public String getConfigfilepath() {
		return configfilepath;
	}
	public void setConfigfilepath(String configfilepath) {
		this.configfilepath = configfilepath;
	}
	public String getStartpriority() {
		return startpriority;
	}
	public void setStartpriority(String startpriority) {
		this.startpriority = startpriority;
	}
	public List<String> getGatewayIds() {
		return gatewayIds;
	}
	public void setGatewayIds(List<String> gatewayIds) {
		this.gatewayIds = gatewayIds;
	}
}
