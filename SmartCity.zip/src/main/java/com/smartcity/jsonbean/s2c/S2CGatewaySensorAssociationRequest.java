package com.smartcity.jsonbean.s2c;

public class S2CGatewaySensorAssociationRequest {

	String sensormmtype;
	String gatewaymmstype;
	String username;
	
	public String getSensormmtype() {
		return sensormmtype;
	}
	public void setSensormmtype(String sensormmtype) {
		this.sensormmtype = sensormmtype;
	}
	public String getGatewaymmstype() {
		return gatewaymmstype;
	}
	public void setGatewaymmstype(String gatewaymmstype) {
		this.gatewaymmstype = gatewaymmstype;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	
	@Override
	public String toString() {
		return "S2CGatewaySensorAssociationRequest [sensormmtype=" + sensormmtype + ", gatewaymmstype=" + gatewaymmstype
				+ ", username=" + username + "]";
	}
		
}
