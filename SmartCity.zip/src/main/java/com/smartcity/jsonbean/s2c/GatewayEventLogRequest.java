/**
 * 
 */
package com.smartcity.jsonbean.s2c;

/**
 * @author inrpande01
 *
 */
public class GatewayEventLogRequest {

	private String notificationId;
	private String gatewayId;
	private Long logEventTime;
	private String message;
	private String level;
	private String file;
	private String exceptionClass;
	private String exceptionMessage;
	private String stacktrace;
	private String exception;
	
	public String getGatewayId() {
		return gatewayId;
	}
	public void setGatewayId(String gatewayId) {
		this.gatewayId = gatewayId;
	}

	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getLevel() {
		return level;
	}
	public void setLevel(String level) {
		this.level = level;
	}
	public String getFile() {
		return file;
	}
	public void setFile(String file) {
		this.file = file;
	}
	public String getExceptionClass() {
		return exceptionClass;
	}
	public void setExceptionClass(String exceptionClass) {
		this.exceptionClass = exceptionClass;
	}
	public String getExceptionMessage() {
		return exceptionMessage;
	}
	public void setExceptionMessage(String exceptionMessage) {
		this.exceptionMessage = exceptionMessage;
	}
	public String getStacktrace() {
		return stacktrace;
	}
	public void setStacktrace(String stacktrace) {
		this.stacktrace = stacktrace;
	}
	public String getException() {
		return exception;
	}
	public void setException(String exception) {
		this.exception = exception;
	}

	public String getNotificationId() {
		return notificationId;
	}
	public void setNotificationId(String notificationId) {
		this.notificationId = notificationId;
	}
	public Long getLogEventTime() {
		return logEventTime;
	}
	public void setLogEventTime(Long logEventTime) {
		this.logEventTime = logEventTime;
	}
}
