package com.smartcity.jsonbean.s2c;

public class GatewayStatusRequest {
	String gatewayId;
    String status;
    /**
     * @return the gatewayId
     */
    public String getGatewayId() {
           return gatewayId;
    }
    /**
     * @param gatewayId the gatewayId to set
     */
    public void setGatewayId(String gatewayId) {
           this.gatewayId = gatewayId;
    }
    /**
     * @return the status
     */
    public String getStatus() {
           return status;
    }
    /**
     * @param status the status to set
     */
    public void setStatus(String status) {
           this.status = status;
    }
	@Override
	public String toString() {
		return "GatewayStatusRequest [gatewayId=" + gatewayId + ", status=" + status + "]";
	}


}
