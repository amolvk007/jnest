package com.smartcity.jsonbean.s2c;

public class SensorDataPoint {

	private String value;
	private String units;
	private String name;
	private String receiveTime;


	public String getName() {
		return this.name;
	}


	public void setName(final String oName) {
		this.name = oName;
	}


	public String getValue() {
		return this.value;
	}


	public void setValue(final String oValue) {
		this.value = oValue;
	}


	public String getUnits() {
		return this.units;
	}


	public void setUnits(final String oUnits) {
		this.units = oUnits;
	}


	public String getReceiveTime() {
		return receiveTime;
	}


	public void setReceiveTime(String receiveTime) {
		this.receiveTime = receiveTime;
	}


	@Override
	public String toString() {
		return "SensorDataUnit [value=" + value + ", units=" + units + ", name=" + name + ", receiveTime=" + receiveTime
				+ "]";
	}
  
}
