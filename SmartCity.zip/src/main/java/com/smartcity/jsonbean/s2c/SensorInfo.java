package com.smartcity.jsonbean.s2c;

import java.util.List;

public class SensorInfo {
	private String sensorId;
	private List<S2CPresets> s2CPresets;

	public String getSensorId() {
		return sensorId;
	}

	public void setSensorId(String sensorId) {
		this.sensorId = sensorId;
	}

	public List<S2CPresets> getS2CPresets() {
		return s2CPresets;
	}

	public void setS2CPresets(List<S2CPresets> s2cPresets) {
		s2CPresets = s2cPresets;
	}

	@Override
	public String toString() {
		return "SensorInfo [sensorId=" + sensorId + ", s2CPresets=" + s2CPresets + "]";
	}
	
}
