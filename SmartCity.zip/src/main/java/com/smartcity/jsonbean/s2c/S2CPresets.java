package com.smartcity.jsonbean.s2c;

public class S2CPresets {
	private String prestName;
	private String presetValue;

	public String getPrestName() {
		return prestName;
	}

	public void setPrestName(String prestName) {
		this.prestName = prestName;
	}

	public String getPresetValue() {
		return presetValue;
	}

	public void setPresetValue(String presetValue) {
		this.presetValue = presetValue;
	}

	@Override
	public String toString() {
		return "S2CPresets [prestName=" + prestName + ", presetValue=" + presetValue + "]";
	}
	
}
