package com.smartcity.jsonbean.s2c;

import java.util.List;

public class GatewayIOTDetailsRequest {
	private List<String> gatewayIds;

	public List<String> getGatewayIds() {
		return gatewayIds;
	}

	public void setGatewayIds(List<String> gatewayIds) {
		this.gatewayIds = gatewayIds;
	}

}
