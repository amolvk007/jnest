package com.smartcity.jsonbean.s2c;

import java.sql.Timestamp;

public class GatewayIOTDetails {
	private String gatewayDiagnosticsId;
	private String gatewayId;
	private String gatewaySerialNo;
	private String gatewayMACId;
	private String gatewayIP;
	private String totalRAM;
	private String freeRAM;
	private String totalStorage;
	private String freeStorage;
	
	private String cellular;
	private String ethernet;
	private String wiFi;
	
	private String bluetooth;
	private String zigBee;
	private String battery;
	private Timestamp receiveTime;
	
	
	public String getGatewayDiagnosticsId() {
		return gatewayDiagnosticsId;
	}
	public void setGatewayDiagnosticsId(String gatewayDiagnosticsId) {
		this.gatewayDiagnosticsId = gatewayDiagnosticsId;
	}
	public String getGatewayId() {
		return gatewayId;
	}
	public void setGatewayId(String gatewayId) {
		this.gatewayId = gatewayId;
	}
	public String getGatewaySerialNo() {
		return gatewaySerialNo;
	}
	public void setGatewaySerialNo(String gatewaySerialNo) {
		this.gatewaySerialNo = gatewaySerialNo;
	}
	public String getGatewayMACId() {
		return gatewayMACId;
	}
	public void setGatewayMACId(String gatewayMACId) {
		this.gatewayMACId = gatewayMACId;
	}
	public String getGatewayIP() {
		return gatewayIP;
	}
	public void setGatewayIP(String gatewayIP) {
		this.gatewayIP = gatewayIP;
	}
	public String getTotalRAM() {
		return totalRAM;
	}
	public void setTotalRAM(String totalRAM) {
		this.totalRAM = totalRAM;
	}
	public String getFreeRAM() {
		return freeRAM;
	}
	public void setFreeRAM(String freeRAM) {
		this.freeRAM = freeRAM;
	}
	public String getTotalStorage() {
		return totalStorage;
	}
	public void setTotalStorage(String totalStorage) {
		this.totalStorage = totalStorage;
	}
	public String getFreeStorage() {
		return freeStorage;
	}
	public void setFreeStorage(String freeStorage) {
		this.freeStorage = freeStorage;
	}
	public String getCellular() {
		return cellular;
	}
	public void setCellular(String cellular) {
		this.cellular = cellular;
	}
	public String getEthernet() {
		return ethernet;
	}
	public void setEthernet(String ethernet) {
		this.ethernet = ethernet;
	}
	public String getWiFi() {
		return wiFi;
	}
	public void setWiFi(String wiFi) {
		this.wiFi = wiFi;
	}
	public String getBluetooth() {
		return bluetooth;
	}
	public void setBluetooth(String bluetooth) {
		this.bluetooth = bluetooth;
	}
	public String getZigBee() {
		return zigBee;
	}
	public void setZigBee(String zigBee) {
		this.zigBee = zigBee;
	}
	public String getBattery() {
		return battery;
	}
	public void setBattery(String battery) {
		this.battery = battery;
	}
	public Timestamp getReceiveTime() {
		return receiveTime;
	}
	public void setReceiveTime(Timestamp receiveTime) {
		this.receiveTime = receiveTime;
	}
	@Override
	public String toString() {
		return "GatewayIOTDetails [gatewayDiagnosticsId=" + gatewayDiagnosticsId + ", gatewayId=" + gatewayId
				+ ", gatewaySerialNo=" + gatewaySerialNo + ", gatewayMACId=" + gatewayMACId + ", gatewayIP=" + gatewayIP
				+ ", totalRAM=" + totalRAM + ", freeRAM=" + freeRAM + ", totalStorage=" + totalStorage
				+ ", freeStorage=" + freeStorage + ", cellular=" + cellular + ", ethernet=" + ethernet + ", wiFi="
				+ wiFi + ", bluetooth=" + bluetooth + ", zigBee=" + zigBee + ", battery=" + battery + ", receiveTime="
				+ receiveTime + "]";
	}	
}
