package com.smartcity.jsonbean.s2c;

public class S2CSendCommandToSensorsRequest {
	private String sensorId;
	private String loginName;
	private S2CSendCommandToSensorsRequestData data;
	public String getSensorId() {
		return sensorId;
	}
	public void setSensorId(String sensorId) {
		this.sensorId = sensorId;
	}
	public String getLoginName() {
		return loginName;
	}
	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}
	public S2CSendCommandToSensorsRequestData getData() {
		return data;
	}
	public void setData(S2CSendCommandToSensorsRequestData data) {
		this.data = data;
	}
	@Override
	public String toString() {
		return "S2CSendCommandToSensorsRequest [sensorId=" + sensorId + ", loginName=" + loginName + ", data=" + data
				+ "]";
	}

}
