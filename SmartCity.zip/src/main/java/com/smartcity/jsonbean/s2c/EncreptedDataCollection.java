package com.smartcity.jsonbean.s2c;

import java.util.List;


public class EncreptedDataCollection {

	private List<SensorRawData> encreptList;
	private String totalRecords;

	public List<SensorRawData> getEncreptList() {
		return encreptList;
	}

	public void setEncreptList(List<SensorRawData> encreptList) {
		this.encreptList = encreptList;
	}
	
	public String getTotalRecords() {
		return totalRecords;
	}

	public void setTotalRecords(String totalRecords) {
		this.totalRecords = totalRecords;
	}
}
