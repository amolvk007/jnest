/**
 * 
 */
package com.smartcity.jsonbean.s2c;

/**
 * @author inrpande01
 *
 */
public class WanPolicyRequest {

	
	private String priority;
	private String resetIntervalTime;
	private String ipAssignment;
	private String gatewayId;
	private String gatewayIp;
	private String receiveTime;
	public String getPriority() {
		return priority;
	}
	public void setPriority(String priority) {
		this.priority = priority;
	}
	public String getResetIntervalTime() {
		return resetIntervalTime;
	}
	public void setResetIntervalTime(String resetIntervalTime) {
		this.resetIntervalTime = resetIntervalTime;
	}
	public String getIpAssignment() {
		return ipAssignment;
	}
	public void setIpAssignment(String ipAssignment) {
		this.ipAssignment = ipAssignment;
	}
	public String getGatewayId() {
		return gatewayId;
	}
	public void setGatewayId(String gatewayId) {
		this.gatewayId = gatewayId;
	}
	public String getGatewayIp() {
		return gatewayIp;
	}
	public void setGatewayIp(String gatewayIp) {
		this.gatewayIp = gatewayIp;
	}
	public String getReceiveTime() {
		return receiveTime;
	}
	public void setReceiveTime(String receiveTime) {
		this.receiveTime = receiveTime;
	}
}
