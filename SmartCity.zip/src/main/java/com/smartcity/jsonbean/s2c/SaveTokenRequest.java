package com.smartcity.jsonbean.s2c;

public class SaveTokenRequest {
	
	private String loginName;
	private String authToken;
	private String verticalURL;
	
	public String getLoginName() {
		return loginName;
	}
	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}
	public String getAuthToken() {
		return authToken;
	}
	public void setAuthToken(String authToken) {
		this.authToken = authToken;
	}
	public String getVerticalURL() {
		return verticalURL;
	}
	public void setVerticalURL(String verticalURL) {
		this.verticalURL = verticalURL;
	}
}
