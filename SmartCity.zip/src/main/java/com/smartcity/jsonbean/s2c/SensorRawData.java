package com.smartcity.jsonbean.s2c;

import java.io.Serializable;

public class SensorRawData implements Serializable {

	private static final long serialVersionUID = 1123123L;

	private int id;
	private String ownerId;
	private String verticalType;
	private String gatewayId;
	private String sensorId;
	private long receiveTime;
	private String osName;
	private byte[] cdfData;

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the ownerId
	 */
	public String getOwnerId() {
		return ownerId;
	}

	/**
	 * @param ownerId
	 *            the ownerId to set
	 */
	public void setOwnerId(String ownerId) {
		this.ownerId = ownerId;
	}

	/**
	 * @return the verticalType
	 */
	public String getVerticalType() {
		return verticalType;
	}

	/**
	 * @param verticalType
	 *            the verticalType to set
	 */
	public void setVerticalType(String verticalType) {
		this.verticalType = verticalType;
	}

	/**
	 * @return the gatewayId
	 */
	public String getGatewayId() {
		return gatewayId;
	}

	/**
	 * @param gatewayId
	 *            the gatewayId to set
	 */
	public void setGatewayId(String gatewayId) {
		this.gatewayId = gatewayId;
	}

	/**
	 * @return the sensorId
	 */
	public String getSensorId() {
		return sensorId;
	}

	/**
	 * @param sensorId
	 *            the sensorId to set
	 */
	public void setSensorId(String sensorId) {
		this.sensorId = sensorId;
	}

	/**
	 * @return the receiveTime
	 */
	public long getReceiveTime() {
		return receiveTime;
	}

	/**
	 * @param receiveTime
	 *            the receiveTime to set
	 */
	public void setReceiveTime(long receiveTime) {
		this.receiveTime = receiveTime;
	}

	/**
	 * @return the osName
	 */
	public String getOsName() {
		return osName;
	}

	/**
	 * @param osName
	 *            the osName to set
	 */
	public void setOsName(String osName) {
		this.osName = osName;
	}

	/**
	 * @return the cdfData
	 */
	public byte[] getCdfData() {
		return cdfData;
	}

	/**
	 * @param cdfData
	 *            the cdfData to set
	 */
	public void setCdfData(byte[] cdfData) {
		this.cdfData = cdfData;
	}

	/**
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
