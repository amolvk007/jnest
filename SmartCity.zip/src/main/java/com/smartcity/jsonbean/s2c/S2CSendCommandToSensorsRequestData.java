package com.smartcity.jsonbean.s2c;

import java.util.List;

public class S2CSendCommandToSensorsRequestData {	
	private List<SensorInfo> sensorInfo;

	public List<SensorInfo> getSensorInfo() {
		return sensorInfo;
	}

	public void setSensorInfo(List<SensorInfo> sensorInfo) {
		this.sensorInfo = sensorInfo;
	}

	@Override
	public String toString() {
		return "S2CSendCommandToSensorsRequestData [sensorInfo=" + sensorInfo + "]";
	}

}
