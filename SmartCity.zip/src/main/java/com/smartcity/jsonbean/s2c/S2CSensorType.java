package com.smartcity.jsonbean.s2c;

public class S2CSensorType {

	String sensorTypeId;
	String vertical;
	String sensorType;
	String make;
	String model;
	String protocol;
	String aggregation;
	String filtration;
	String datapointname;
	String datatype;
	String ppsaJarName;
	String ppsaJarPath;
	
	public String getSensorTypeId() {
		return sensorTypeId;
	}
	public void setSensorTypeId(String sensorTypeId) {
		this.sensorTypeId = sensorTypeId;
	}
	public String getVertical() {
		return vertical;
	}
	public void setVertical(String vertical) {
		this.vertical = vertical;
	}
	public String getSensorType() {
		return sensorType;
	}
	public void setSensorType(String sensorType) {
		this.sensorType = sensorType;
	}
	public String getMake() {
		return make;
	}
	public void setMake(String make) {
		this.make = make;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getProtocol() {
		return protocol;
	}
	public void setProtocol(String protocol) {
		this.protocol = protocol;
	}
	public String getAggregation() {
		return aggregation;
	}
	public void setAggregation(String aggregation) {
		this.aggregation = aggregation;
	}
	public String getFiltration() {
		return filtration;
	}
	public void setFiltration(String filtration) {
		this.filtration = filtration;
	}
	public String getDatapointname() {
		return datapointname;
	}
	public void setDatapointname(String datapointname) {
		this.datapointname = datapointname;
	}
	public String getDatatype() {
		return datatype;
	}
	public void setDatatype(String datatype) {
		this.datatype = datatype;
	}
	public String getPpsaJarName() {
		return ppsaJarName;
	}
	public void setPpsaJarName(String ppsaJarName) {
		this.ppsaJarName = ppsaJarName;
	}
	public String getPpsaJarPath() {
		return ppsaJarPath;
	}
	public void setPpsaJarPath(String ppsaJarPath) {
		this.ppsaJarPath = ppsaJarPath;
	}
}
