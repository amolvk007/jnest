package com.smartcity.jsonbean.s2c;

/**
 * @Description: Generic Rest Response Object
 * @date : Jun 7, 2014
 */
public class ResponseWrapper {
	private String response;
	private Object data;
	private Object errorMessage;
	
	public String getResponse() {
		return response;
	}
	public void setResponse(String response) {
		this.response = response;
	}	
	public Object getData() {
		return data;
	}
	public void setData(Object data) {
		this.data = data;
	}
	public Object getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(Object errorMessage) {
		this.errorMessage = errorMessage;
	}
	@Override
	public String toString() {
		return "ResponseWrapper [response=" + response + ", data=" + data + ", errorMessage=" + errorMessage + "]";
	}
}
