package com.smartcity.jsonbean;

import java.util.List;

import com.smartcity.dbbean.GatewayEntity;
import com.smartcity.dbbean.SensorEntity;

public class Pole {
private String id;
private String name;
private String functionalMode;
private List<Coordinates> coords;
private List<Sensor> sensors;
private Gateway gateway;
private byte isGateway;

public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getFunctionalMode() {
	return functionalMode;
}
public void setFunctionalMode(String functionalMode) {
	this.functionalMode = functionalMode;
}
public List<Coordinates> getCoords() {
	return coords;
}
public void setCoords(List<Coordinates> Coords) {
	this.coords = Coords;
}
public List<Sensor> getSensors() {
	return sensors;
}
public void setSensors(List<Sensor> sensors) {
	this.sensors = sensors;
}
public Gateway getGateway() {
	return gateway;
}
public void setGateway(Gateway gateway) {
	this.gateway = gateway;
}
public byte getIsGateway() {
	return isGateway;
}

public void setIsGateway(byte isGateway) {
	this.isGateway = isGateway;
}


}
