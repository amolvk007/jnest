package com.smartcity.jsonbean;

/**
 * @Description: Generic Rest Response Object
 * @date : Jun 7, 2014
 */
public class ResponseData {
	private String response;
	private Object data;
	private Object errorMessage;

	public Object getErrorMessage() {
		return this.errorMessage;
	}

	public void setErrorMessage(final Object oErrorMessage) {
		this.errorMessage = oErrorMessage;
	}

	public String getResponse() {
		return this.response;
	}

	public void setResponse(final String oResponse) {
		this.response = oResponse;
	}

	public Object getData() {
		return this.data;
	}

	public void setData(final Object oData) {
		this.data = oData;
	}

	@Override
	public String toString() {
		return "ResponseData [response=" + this.response + ", error=" + this.errorMessage + ", data=" + this.data + "]";
	}
}
