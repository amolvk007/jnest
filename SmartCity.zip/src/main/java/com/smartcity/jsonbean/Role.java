/**
 * 
 */
package com.smartcity.jsonbean;

import org.hibernate.validator.constraints.NotEmpty;

/**
 * @author inrpande01
 *
 */
public class Role {

	private String id;
	@NotEmpty(message="role")
	private String role;
	
	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
}
