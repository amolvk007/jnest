package com.smartcity.jsonbean;

public class LightSummary {

	  private String beaconLightColor;
	  private String beaconLightStatus;
	  private String floodLight;
	  private String intensity;
	  private String streetLight;
	  
	public String getBeaconLightColor() {
		return beaconLightColor;
	}
	public void setBeaconLightColor(String beaconLightColor) {
		this.beaconLightColor = beaconLightColor;
	}
	public String getBeaconLightStatus() {
		return beaconLightStatus;
	}
	public void setBeaconLightStatus(String beaconLightStatus) {
		this.beaconLightStatus = beaconLightStatus;
	}
	public String getFloodLight() {
		return floodLight;
	}
	public void setFloodLight(String floodLight) {
		this.floodLight = floodLight;
	}
	public String getIntensity() {
		return intensity;
	}
	public void setIntensity(String intensity) {
		this.intensity = intensity;
	}
	
	public String getStreetLight() {
		return streetLight;
	}
	public void setStreetLight(String streetLight) {
		this.streetLight = streetLight;
	}
	@Override
	public String toString() {
		return "LightSummary [beaconLightColor=" + beaconLightColor + ", beaconLightStatus=" + beaconLightStatus
				+ ", floodLight=" + floodLight + ", intensity=" + intensity + "]";
	}
	  
	  
}
