/**
 * 
 */
package com.smartcity.jsonbean;

/**
 * @author inrpande01
 *
 */
public class SensorData {

private String sensorId;
private String sensorName;
private String temperature;
private String light;
private String humidity;
private String receiveTime;

public String getTemperature() {
	return temperature;
}
public void setTemperature(String temperature) {
	this.temperature = temperature;
}
public String getLight() {
	return light;
}
public void setLight(String light) {
	this.light = light;
}

public String getSensorName() {
	return sensorName;
}
public void setSensorName(String sensorName) {
	this.sensorName = sensorName;
}
public String getHumidity() {
	return humidity;
}
public void setHumidity(String humidity) {
	this.humidity = humidity;
}
public String getSensorId() {
	return sensorId;
}
public void setSensorId(String sensorId) {
	this.sensorId = sensorId;
}

public String getReceiveTime() {
	return receiveTime;
}
public void setReceiveTime(String receiveTime) {
	this.receiveTime = receiveTime;
}
@Override
public String toString() {
	return "SensorData [sensorId=" + sensorId + ", sensorName=" + sensorName + ", temperature=" + temperature
			+ ", light=" + light + ", humidity=" + humidity + "]";
}



}
