package com.smartcity.jsonbean;

import java.util.List;

public class DistrictDashboardData {
	private String id;
	private String name;
	private List<Coordinates> coords;	
	private List<Gateway> gatewayList;
	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public List<Coordinates> getCoords() {
		return coords;
	}
	public void setCoords(List<Coordinates> coords) {
		this.coords = coords;
	}
	public List<Gateway> getGatewayList() {
		return gatewayList;
	}
	public void setGatewayList(List<Gateway> gatewayList) {
		this.gatewayList = gatewayList;
	}
	
	
		
}
