package com.smartcity.jsonbean;

public class GatewayLocation {

	private String gatewayId;
	private String functionalMode;
	private String latitude;
	private String longitude;
	
	public String getGatewayId() {
		return gatewayId;
	}
	public void setGatewayId(String gatewayId) {
		this.gatewayId = gatewayId;
	}
	public String getFunctionalMode() {
		return functionalMode;
	}
	public void setFunctionalMode(String functionalMode) {
		this.functionalMode = functionalMode;
	}
	public String getLatitude() {
		return latitude;
	}
	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}
	public String getLongitude() {
		return longitude;
	}
	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}
	
	@Override
	public String toString() {
		return "GatewayLocation [gatewayId=" + gatewayId + ", functionalMode=" + functionalMode + ", latitude="
				+ latitude + ", longitude=" + longitude + "]";
	}  

	
}
