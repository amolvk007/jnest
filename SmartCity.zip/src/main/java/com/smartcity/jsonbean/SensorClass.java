package com.smartcity.jsonbean;

import java.util.List;


/**
 * The SensorClass class 
 * 
 */
public class SensorClass {
	private String id;

	private String name;

	private List<Sensor> sensors;

	public SensorClass() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Sensor> getSensors() {
		return this.sensors;
	}

	public void setSensors(List<Sensor> sensors) {
		this.sensors = sensors;
	}

	
}