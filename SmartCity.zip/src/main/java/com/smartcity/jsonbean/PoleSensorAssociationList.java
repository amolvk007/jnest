package com.smartcity.jsonbean;

import java.sql.Timestamp;
import java.util.List;

public class PoleSensorAssociationList {
	private String poleId;
	private String poleName;
	private String districtName;
	private String gatewayName;
	private String poleLat;
	private String poleLongi;
	private String poleIsGateway;
	private Timestamp createdDate;
	private List<String> sensorName;
	public String getPoleId() {
		return poleId;
	}
	public void setPoleId(String poleId) {
		this.poleId = poleId;
	}
	public String getPoleName() {
		return poleName;
	}
	public void setPoleName(String poleName) {
		this.poleName = poleName;
	}
	
	public String getDistrictName() {
		return districtName;
	}
	public void setDistrictName(String districtName) {
		this.districtName = districtName;
	}
	public String getGatewayName() {
		return gatewayName;
	}
	public void setGatewayName(String gatewayName) {
		this.gatewayName = gatewayName;
	}
	public String getPoleLat() {
		return poleLat;
	}
	public void setPoleLat(String poleLat) {
		this.poleLat = poleLat;
	}
	public String getPoleLongi() {
		return poleLongi;
	}
	public void setPoleLongi(String poleLongi) {
		this.poleLongi = poleLongi;
	}
	public String getPoleIsGateway() {
		return poleIsGateway;
	}
	public void setPoleIsGateway(String poleIsGateway) {
		this.poleIsGateway = poleIsGateway;
	}
	public List<String> getSensorName() {
		return sensorName;
	}
	public void setSensorName(List<String> sensorName) {
		this.sensorName = sensorName;
	}
	public Timestamp getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
}
