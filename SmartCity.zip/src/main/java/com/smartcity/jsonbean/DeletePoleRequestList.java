package com.smartcity.jsonbean;

import java.util.List;

import javax.validation.constraints.Size;

public class DeletePoleRequestList {
	@Size(min=1 ,message="mandatory")
	List<DeletePoleRequest> poleList;

	public List<DeletePoleRequest> getPoleList() {
		return poleList;
	}

	public void setPoleList(List<DeletePoleRequest> poleList) {
		this.poleList = poleList;
	}
	

}
