package com.smartcity.jsonbean;

import java.util.List;

import org.hibernate.validator.constraints.NotEmpty;

public class DistrictUserDelete {
	@NotEmpty(message = "mandatory")
	private List<UserId> userList;

	public List<UserId> getUserList() {
		return userList;
	}

	public void setUserList(List<UserId> userList) {
		this.userList = userList;
	}

}
