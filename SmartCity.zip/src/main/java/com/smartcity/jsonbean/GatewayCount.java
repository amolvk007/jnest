package com.smartcity.jsonbean;

public class GatewayCount {
	private String totalGateways;
	private String districtName;
	private String districtId;
	
	public String getTotalGateways() {
		return totalGateways;
	}
	public void setTotalGateways(String totalGateways) {
		this.totalGateways = totalGateways;
	}
	public String getDistrictName() {
		return districtName;
	}
	public void setDistrictName(String districtName) {
		this.districtName = districtName;
	}
	public String getDistrictId() {
		return districtId;
	}
	public void setDistrictId(String districtId) {
		this.districtId = districtId;
	}
	@Override
	public String toString() {
		return "GatewayCount [totalGateways=" + totalGateways + ", districtName=" + districtName + ", districtId="
				+ districtId + "]";
	}
	
	
	
}
