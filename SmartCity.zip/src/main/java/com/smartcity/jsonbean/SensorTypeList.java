package com.smartcity.jsonbean;

public class SensorTypeList {

	String sensorTypeId;
	String sensorTypeName;
	public String getSensorTypeId() {
		return sensorTypeId;
	}
	public void setSensorTypeId(String sensorTypeId) {
		this.sensorTypeId = sensorTypeId;
	}
	public String getSensorTypeName() {
		return sensorTypeName;
	}
	public void setSensorTypeName(String sensorTypeName) {
		this.sensorTypeName = sensorTypeName;
	}
}
