package com.smartcity.jsonbean;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class DistrictUserAssociation {
	private String userId;
	private String userName;
	private List<String> districtName;
	private String defaultDistrict;
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public List<String> getDistrictName() {
		return districtName;
	}
	public void setDistrictName(List<String> districtName) {
		this.districtName = districtName;
	}
	public String getDefaultDistrict() {
		return defaultDistrict;
	}
	public void setDefaultDistrict(String defaultDistrict) {
		this.defaultDistrict = defaultDistrict;
	}

}
