package com.smartcity.jsonbean;

public class GatewayType {

	String gatewayTypeId;
	String gatewayTypeName;
	
	public String getGatewayTypeId() {
		return gatewayTypeId;
	}
	public void setGatewayTypeId(String gatewayTypeId) {
		this.gatewayTypeId = gatewayTypeId;
	}
	public String getGatewayTypeName() {
		return gatewayTypeName;
	}
	public void setGatewayTypeName(String gatewayTypeName) {
		this.gatewayTypeName = gatewayTypeName;
	}
}
