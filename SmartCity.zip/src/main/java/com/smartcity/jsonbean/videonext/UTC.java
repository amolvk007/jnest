package com.smartcity.jsonbean.videonext;

public class UTC {
	private String Updated;
	private String From;
	private String To;
	private String When;
	
	public String getUpdated() {
		return Updated;
	}
	public void setUpdated(String updated) {
		Updated = updated;
	}
	public String getFrom() {
		return From;
	}
	public void setFrom(String from) {
		From = from;
	}
	public String getTo() {
		return To;
	}
	public void setTo(String to) {
		To = to;
	}
	public String getWhen() {
		return When;
	}
	public void setWhen(String when) {
		When = when;
	}
	@Override
	public String toString() {
		return "UTC [Updated=" + Updated + ", From=" + From + ", To=" + To + ", When=" + When + "]";
	}

}
