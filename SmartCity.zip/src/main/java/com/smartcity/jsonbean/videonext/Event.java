package com.smartcity.jsonbean.videonext;

public class Event {
	private long id;
    private long objid;
    private String src;
    private int state;
    private String priority;
    private String lifespan;
    private String message;
    private String eventtype;
    private String note;
    private String tag;
    private UTC utc;
    
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public long getObjid() {
		return objid;
	}
	public void setObjid(long objid) {
		this.objid = objid;
	}
	public String getSrc() {
		return src;
	}
	public void setSrc(String src) {
		this.src = src;
	}
	public int getState() {
		return state;
	}
	public void setState(int state) {
		this.state = state;
	}
	public String getPriority() {
		return priority;
	}
	public void setPriority(String priority) {
		this.priority = priority;
	}
	public String getLifespan() {
		return lifespan;
	}
	public void setLifespan(String lifespan) {
		this.lifespan = lifespan;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getEventtype() {
		return eventtype;
	}
	public void setEventtype(String eventtype) {
		this.eventtype = eventtype;
	}
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}
	public String getTag() {
		return tag;
	}
	public void setTag(String tag) {
		this.tag = tag;
	}
	public UTC getUtc() {
		return utc;
	}
	public void setUtc(UTC utc) {
		this.utc = utc;
	}
	
	@Override
	public String toString() {
		return "Event [id=" + id + ", objid=" + objid + ", src=" + src + ", state=" + state + ", priority=" + priority
				+ ", lifespan=" + lifespan + ", message=" + message + ", eventtype=" + eventtype + ", note=" + note
				+ ", tag=" + tag + ", utc=" + utc + "]";
	}
}