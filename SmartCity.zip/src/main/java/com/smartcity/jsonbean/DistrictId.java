package com.smartcity.jsonbean;

public class DistrictId {

	private String districtId;

	public String getDistrictId() {
		return districtId;
	}

	public void setDistrictId(String districtId) {
		this.districtId = districtId;
	}
	
	
}
