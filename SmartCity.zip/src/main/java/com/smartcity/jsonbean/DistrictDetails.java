package com.smartcity.jsonbean;

public class DistrictDetails {
	private String beaconStatus; 
	private String beaconColor;
	private String floodLightStatus; 
	private String streetLightStatus; 
	private String lightIntensity;
	private String audioName; 
	private String volume;
	private String warningMessage;
	
	public String getBeaconStatus() {
		return beaconStatus;
	}
	public void setBeaconStatus(String beaconStatus) {
		this.beaconStatus = beaconStatus;
	}
	public String getBeaconColor() {
		return beaconColor;
	}
	public void setBeaconColor(String beaconColor) {
		this.beaconColor = beaconColor;
	}
	public String getFloodLightStatus() {
		return floodLightStatus;
	}
	public void setFloodLightStatus(String floodLightStatus) {
		this.floodLightStatus = floodLightStatus;
	}
	public String getStreetLightStatus() {
		return streetLightStatus;
	}
	public void setStreetLightStatus(String streetLightStatus) {
		this.streetLightStatus = streetLightStatus;
	}
	public String getLightIntensity() {
		return lightIntensity;
	}
	public void setLightIntensity(String lightIntensity) {
		this.lightIntensity = lightIntensity;
	}
	public String getAudioName() {
		return audioName;
	}
	public void setAudioName(String audioName) {
		this.audioName = audioName;
	}
	public String getVolume() {
		return volume;
	}
	public void setVolume(String volume) {
		this.volume = volume;
	}
	public String getWarningMessage() {
		return warningMessage;
	}
	public void setWarningMessage(String warningMessage) {
		this.warningMessage = warningMessage;
	}
	@Override
	public String toString() {
		return "DistrictDetails [beaconStatus=" + beaconStatus + ", beaconColor=" + beaconColor + ", floodLightStatus="
				+ floodLightStatus + ", streetLightStatus=" + streetLightStatus + ", lightIntensity=" + lightIntensity
				+ ", audioName=" + audioName + ", volume=" + volume + ", warningMessage=" + warningMessage + "]";
	}
	
	
}
