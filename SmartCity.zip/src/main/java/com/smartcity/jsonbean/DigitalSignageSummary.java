package com.smartcity.jsonbean;

public class DigitalSignageSummary {
	private String total;
	private String on;
	private String off;
	
	public String getTotal() {
		return total;
	}
	public void setTotal(String total) {
		this.total = total;
	}
	public String getOn() {
		return on;
	}
	public void setOn(String on) {
		this.on = on;
	}
	public String getOff() {
		return off;
	}
	public void setOff(String off) {
		this.off = off;
	}
	
	@Override
	public String toString() {
		return "DigitalSignageSummary [total=" + total + ", on=" + on + ", off=" + off + "]";
	}
	
	
}
