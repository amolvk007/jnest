package com.smartcity.jsonbean;

public class DistrictGeocoordinates {
	
	private DistrictTopLeft districtTopLeft;
	private DistrictTopRight districtTopRight;
	private DistrictBottomLeft districtBottomLeft;
	private DistrictBottomRight districtBottomRight;
	
	public DistrictTopLeft getDistrictTopLeft() {
		return districtTopLeft;
	}
	public void setDistrictTopLeft(DistrictTopLeft districtTopLeft) {
		this.districtTopLeft = districtTopLeft;
	}
	public DistrictTopRight getDistrictTopRight() {
		return districtTopRight;
	}
	public void setDistrictTopRight(DistrictTopRight districtTopRight) {
		this.districtTopRight = districtTopRight;
	}
	public DistrictBottomLeft getDistrictBottomLeft() {
		return districtBottomLeft;
	}
	public void setDistrictBottomLeft(DistrictBottomLeft districtBottomLeft) {
		this.districtBottomLeft = districtBottomLeft;
	}
	public DistrictBottomRight getDistrictBottomRight() {
		return districtBottomRight;
	}
	public void setDistrictBottomRight(DistrictBottomRight districtBottomRight) {
		this.districtBottomRight = districtBottomRight;
	}
	@Override
	public String toString() {
		return "DistrictGeocoordinates [districtTopLeft=" + districtTopLeft + ", districtTopRight=" + districtTopRight
				+ ", districtBottomLeft=" + districtBottomLeft + ", districtBottomRight=" + districtBottomRight + "]";
	}

	
	
	
}
