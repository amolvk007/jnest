package com.smartcity.jsonbean;

import java.util.List;

public class GatewayPoleAssociationList {

	String gatewayId;
	String gatewayName;
	String districtName;
	List<String> poleName;
	String physicalPoleName;
	String lat;
	String longi;
	
	public String getGatewayId() {
		return gatewayId;
	}
	public void setGatewayId(String gatewayId) {
		this.gatewayId = gatewayId;
	}
	public String getGatewayName() {
		return gatewayName;
	}
	public void setGatewayName(String gatewayName) {
		this.gatewayName = gatewayName;
	}
	public String getDistrictName() {
		return districtName;
	}
	public void setDistrictName(String districtName) {
		this.districtName = districtName;
	}
	public List<String> getPoleName() {
		return poleName;
	}
	public void setPoleName(List<String> poleName) {
		this.poleName = poleName;
	}
	public String getPhysicalPoleName() {
		return physicalPoleName;
	}
	public void setPhysicalPoleName(String physicalPoleName) {
		this.physicalPoleName = physicalPoleName;
	}
	public String getLat() {
		return lat;
	}
	public void setLat(String lat) {
		this.lat = lat;
	}
	public String getLongi() {
		return longi;
	}
	public void setLongi(String longi) {
		this.longi = longi;
	}
}
