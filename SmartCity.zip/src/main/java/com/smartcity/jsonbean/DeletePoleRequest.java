package com.smartcity.jsonbean;

import javax.validation.constraints.NotNull;

public class DeletePoleRequest {
	@NotNull(message="mandatory")
	private String poleId;

	public String getPoleId() {
		return poleId;
	}

	public void setPoleId(String poleId) {
		this.poleId = poleId;
	}

}
