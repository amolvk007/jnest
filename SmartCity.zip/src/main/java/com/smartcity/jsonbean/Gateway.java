package com.smartcity.jsonbean;

import java.util.List;

public class Gateway {
	private String id;
	private String name;
	
	private String functionalMode;	
	private List<Coordinates> coords;
	private List<Pole> poleList;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String getFunctionalMode() {
		return functionalMode;
	}
	public void setFunctionalMode(String functionalMode) {
		this.functionalMode = functionalMode;
	}
	public List<Coordinates> getCoords() {
		return coords;
	}
	public void setCoords(List<Coordinates> coords) {
		this.coords = coords;
	}
	public List<Pole> getPoleList() {
		return poleList;
	}
	public void setPoleList(List<Pole> poleList) {
		this.poleList = poleList;
	}
	
	

}
