package com.smartcity.jsonbean;

import javax.validation.constraints.NotNull;

public class DeletePoleSensorAssociation {
	@NotNull(message="mandatory")
	private String poleId;
	@NotNull(message="mandatory")
	private String sensorId;
	public String getPoleId() {
		return poleId;
	}
	public void setPoleId(String poleId) {
		this.poleId = poleId;
	}
	public String getSensorId() {
		return sensorId;
	}
	public void setSensorId(String sensorId) {
		this.sensorId = sensorId;
	}

}
