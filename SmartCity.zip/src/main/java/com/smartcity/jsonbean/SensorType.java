package com.smartcity.jsonbean;

public class SensorType {

	private String sensorType;
	private String beaconLight;
	private String floodLight;
	
	public String getSensorType() {
		return sensorType;
	}
	public void setSensorType(String sensorType) {
		this.sensorType = sensorType;
	}
	public String getBeaconLight() {
		return beaconLight;
	}
	public void setBeaconLight(String beaconLight) {
		this.beaconLight = beaconLight;
	}
	public String getFloodLight() {
		return floodLight;
	}
	public void setFloodLight(String floodLight) {
		this.floodLight = floodLight;
	}
	
	@Override
	public String toString() {
		return "SensorType [sensorType=" + sensorType + ", beaconLight=" + beaconLight + ", floodLight=" + floodLight
				+ "]";
	}
	
	


}
