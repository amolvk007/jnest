package com.smartcity.jsonbean;

public class DistrictPoleStatus {
	private String poleStatus;
	private String districtId;
	
	public String getPoleStatus() {
		return poleStatus;
	}
	public void setPoleStatus(String poleStatus) {
		this.poleStatus = poleStatus;
	}
	public String getDistrictId() {
		return districtId;
	}
	public void setDistrictId(String districtId) {
		this.districtId = districtId;
	}
	@Override
	public String toString() {
		return "DistrictPoleStatus [poleStatus=" + poleStatus + ", districtId=" + districtId + "]";
	}
	
	
	
}
