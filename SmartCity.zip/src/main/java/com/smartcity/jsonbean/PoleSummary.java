package com.smartcity.jsonbean;

public class PoleSummary {
	
	private String poleId;
	private String poleName;
	private String poleLat;
	private String poleLongi;
	private String totalSensors;
	private String alertThresholdLimit;
	private LightSummary lightSummary;
	private AudioSummary audioSummary;
	private DigitalSignage digitalSignage;
	private SensorData xBeeSensorDetails;
	public String getPoleId() {
		return poleId;
	}
	public void setPoleId(String poleId) {
		this.poleId = poleId;
	}
	public String getPoleName() {
		return poleName;
	}
	public void setPoleName(String poleName) {
		this.poleName = poleName;
	}
	public String getPoleLat() {
		return poleLat;
	}
	public void setPoleLat(String poleLat) {
		this.poleLat = poleLat;
	}
	public String getPoleLongi() {
		return poleLongi;
	}
	public void setPoleLongi(String poleLongi) {
		this.poleLongi = poleLongi;
	}
	public String getTotalSensors() {
		return totalSensors;
	}
	public void setTotalSensors(String totalSensors) {
		this.totalSensors = totalSensors;
	}
	public String getAlertThresholdLimit() {
		return alertThresholdLimit;
	}
	public void setAlertThresholdLimit(String alertThresholdLimit) {
		this.alertThresholdLimit = alertThresholdLimit;
	}
	
	public LightSummary getLightSummary() {
		return lightSummary;
	}
	public void setLightSummary(LightSummary lightSummary) {
		this.lightSummary = lightSummary;
	}
	public AudioSummary getAudioSummary() {
		return audioSummary;
	}
	public void setAudioSummary(AudioSummary audioSummary) {
		this.audioSummary = audioSummary;
	}
	public DigitalSignage getDigitalSignage() {
		return digitalSignage;
	}
	public void setDigitalSignage(DigitalSignage digitalSignage) {
		this.digitalSignage = digitalSignage;
	}
	public SensorData getxBeeSensorDetails() {
		return xBeeSensorDetails;
	}
	public void setxBeeSensorDetails(SensorData xBeeSensorDetails) {
		this.xBeeSensorDetails = xBeeSensorDetails;
	}
	
}
