package com.smartcity.jsonbean;

public class ParkingLotSummary {

	private String total;
	private String open;
	private String full;
	
	
	public String getTotal() {
		return total;
	}
	public void setTotal(String total) {
		this.total = total;
	}
	public String getOpen() {
		return open;
	}
	public void setOpen(String open) {
		this.open = open;
	}
	
	public String getFull() {
		return full;
	}
	public void setFull(String full) {
		this.full = full;
	}
	@Override
	public String toString() {
		return "ParkingLotSummary [total=" + total + ", open=" + open + ", full=" + full + "]";
	}
	
	
	
	
	
     
}
