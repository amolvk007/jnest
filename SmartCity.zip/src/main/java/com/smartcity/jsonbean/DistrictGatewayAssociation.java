package com.smartcity.jsonbean;

import java.sql.Timestamp;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class DistrictGatewayAssociation {
	
	
	private String id;

	private String name;
	
	private Timestamp createdDate;

	private String districtCoordinates;

	private List<String> gatewayNameList;
	


	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public List<String> getGatewayNameList() {
		return gatewayNameList;
	}

	public void setGatewayNameList(List<String> gatewayNameList) {
		this.gatewayNameList = gatewayNameList;
	}

	public String getDistrictCoordinates() {
		return districtCoordinates;
	}

	public void setDistrictCoordinates(String districtCoordinates) {
		this.districtCoordinates = districtCoordinates;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "DistrictGatewayAssociation [id=" + id + ", name=" + name + ", createdDate=" + createdDate
				+ ", districtCoordinates=" + districtCoordinates + ", gatewayNameList=" + gatewayNameList + "]";
	}

	
	

	


	
	

}
