package com.smartcity.jsonbean;

import java.util.HashSet;
import java.util.Set;

public class ErrorMessage {
	private String id;
	private String code;
	private Set<String> errors= new HashSet<String>();




	public Set<String> getErrors() {
		return errors;
	}

	public void setErrors(Set<String> errors) {
		this.errors = errors;
	}

	public String getId() {
		return this.id;
	}

	public void setId(final String oId) {
		this.id = oId;
	}

	public String getCode() {
		return this.code;
	}

	public void setCode(final String oCode) {
		this.code = oCode;
	}

	@Override
	public String toString() {
		return "ErrorMessage [id=" + id + ", code=" + code + ", errors=" + errors + "]";
	}


}
