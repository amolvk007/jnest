package com.smartcity.jsonbean;

public class AudioSummary {

	 private String currentPlaylistName;
	 private String volume;
	 
	public String getCurrentPlaylistName() {
		return currentPlaylistName;
	}
	public void setCurrentPlaylistName(String currentPlaylistName) {
		this.currentPlaylistName = currentPlaylistName;
	}
	public String getVolume() {
		return volume;
	}
	public void setVolume(String volume) {
		this.volume = volume;
	}
	@Override
	public String toString() {
		return "AudioSummary [currentPlaylistName=" + currentPlaylistName + ", volume=" + volume + "]";
	}
	 
	 
}
