package com.smartcity.jsonbean;

import java.util.List;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

public class UserDistrict {
	@NotEmpty(message = "mandatory")
	private List<String> userList;
	/*
	 * @NotNull(message = "mandatory") private String defaultDistrictId;
	 */
	@NotEmpty(message = "mandatory")
	private List<String> districtList;

	public List<String> getUserList() {
		return userList;
	}

	public void setUserList(List<String> userList) {
		this.userList = userList;
	}

	public List<String> getDistrictList() {
		return districtList;
	}

	public void setDistrictList(List<String> districtList) {
		this.districtList = districtList;
	}

	/*
	 * public String getDefaultDistrictId() { return defaultDistrictId; }
	 * 
	 * public void setDefaultDistrictId(String defaultDistrictId) {
	 * this.defaultDistrictId = defaultDistrictId; }
	 */

}
