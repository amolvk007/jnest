package com.smartcity.jsonbean;

import java.util.List;

import javax.validation.constraints.NotNull;

public class GatewayPoleAssociationRequest {
	
	@NotNull(message="mandatory")
    private String gatewayId;
	
	@NotNull(message="mandatory")
    private List<String> poleIdList;
	
	//@NotNull(message="mandatory")
    private String physicalPoleId;
    
	public String getGatewayId() {
		return gatewayId;
	}
	public void setGatewayId(String gatewayId) {
		this.gatewayId = gatewayId;
	}
	public List<String> getPoleIdList() {
		return poleIdList;
	}
	public void setPoleIdList(List<String> poleIdList) {
		this.poleIdList = poleIdList;
	}
	public String getPhysicalPoleId() {
		return physicalPoleId;
	}
	public void setPhysicalPoleId(String physicalPoleId) {
		this.physicalPoleId = physicalPoleId;
	}
}
