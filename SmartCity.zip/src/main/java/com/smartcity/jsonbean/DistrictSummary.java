package com.smartcity.jsonbean;

public class DistrictSummary {
	
	private String districtId="";
	private String districtName="";
	private String totalGateways="";
	private String totalOperationalGateways="";
	private String totalNonOperationalGateways="";
	private String alertThresholdLimit="";
//	private StreetLightSummary lights;
	private StreetLightSummary streetLights=new StreetLightSummary();	
//	private ParkingLotSummary parkingLots;
	
	/*private BeaconSummary beacon=new BeaconSummary();
	private FloodLights floodLights=new FloodLights();*/
	private LightSummary lightSummary=new LightSummary();
	private AudioSummary audioSummary=new AudioSummary();
	private DigitalSignage digitalSignage=new DigitalSignage();
//	private DigitalSignageSummary digitalSignageSummary=new DigitalSignageSummary();
	
	
	public String getDistrictId() {
		return districtId;
	}
	public void setDistrictId(String districtId) {
		this.districtId = districtId;
	}
	public String getDistrictName() {
		return districtName;
	}
	public void setDistrictName(String districtName) {
		this.districtName = districtName;
	}
	public String getTotalGateways() {
		return totalGateways;
	}
	public void setTotalGateways(String totalGateways) {
		this.totalGateways = totalGateways;
	}
	public String getTotalOperationalGateways() {
		return totalOperationalGateways;
	}
	public void setTotalOperationalGateways(String totalOperationalGateways) {
		this.totalOperationalGateways = totalOperationalGateways;
	}
	public String getTotalNonOperationalGateways() {
		return totalNonOperationalGateways;
	}
	public void setTotalNonOperationalGateways(String totalNonOperationalGateways) {
		this.totalNonOperationalGateways = totalNonOperationalGateways;
	}
	public String getAlertThresholdLimit() {
		return alertThresholdLimit;
	}
	public void setAlertThresholdLimit(String alertThresholdLimit) {
		this.alertThresholdLimit = alertThresholdLimit;
	}

	public StreetLightSummary getStreetLights() {
		return streetLights;
	}
	public void setStreetLights(StreetLightSummary streetLights) {
		this.streetLights = streetLights;
	}
	
	/*public BeaconSummary getBeacon() {
		return beacon;
	}
	public void setBeacon(BeaconSummary beacon) {
		this.beacon = beacon;
	}
	public FloodLights getFloodLights() {
		return floodLights;
	}
	public void setFloodLights(FloodLights floodLights) {
		this.floodLights = floodLights;
	}*/
	public LightSummary getLightSummary() {
		return lightSummary;
	}
	public void setLightSummary(LightSummary lightSummary) {
		this.lightSummary = lightSummary;
	}
	public AudioSummary getAudioSummary() {
		return audioSummary;
	}
	public void setAudioSummary(AudioSummary audioSummary) {
		this.audioSummary = audioSummary;
	}
	public DigitalSignage getDigitalSignage() {
		return digitalSignage;
	}
	public void setDigitalSignage(DigitalSignage digitalSignage) {
		this.digitalSignage = digitalSignage;
	}
	/*public DigitalSignageSummary getDigitalSignageSummary() {
		return digitalSignageSummary;
	}
	public void setDigitalSignageSummary(DigitalSignageSummary digitalSignageSummary) {
		this.digitalSignageSummary = digitalSignageSummary;
	}*/
	@Override
	public String toString() {
		return "DistrictSummary [districtId=" + districtId + ", districtName=" + districtName + ", totalGateways="
				+ totalGateways + ", alertThresholdLimit=" + alertThresholdLimit + ", streetLights=" + streetLights
				+ ", lightSummary=" + lightSummary + ", audioSummary=" + audioSummary + ", digitalSignage="
				+ digitalSignage + "]";
	}

	     
	
	
}
