package com.smartcity.jsonbean;

public class BeaconSummary {
	
	private String totalBeacon;
	private String operational;
	private String nonOperational;
	
	public String getTotalBeacon() {
		return totalBeacon;
	}
	public void setTotalBeacon(String totalBeacon) {
		this.totalBeacon = totalBeacon;
	}
	public String getOperational() {
		return operational;
	}
	public void setOperational(String operational) {
		this.operational = operational;
	}
	public String getNonOperational() {
		return nonOperational;
	}
	public void setNonOperational(String nonOperational) {
		this.nonOperational = nonOperational;
	}
	
	@Override
	public String toString() {
		return "BeaconSummary [totalBeacon=" + totalBeacon + ", operational=" + operational + ", nonOperational="
				+ nonOperational + "]";
	}
	 
	
	
	
}
