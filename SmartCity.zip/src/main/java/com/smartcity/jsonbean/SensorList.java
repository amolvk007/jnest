package com.smartcity.jsonbean;

public class SensorList {
	
	String id;
	String name;
	String classId;
	String className;
	String poleId;
	String poleName;
	String threshold;
	String status;
	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getClassId() {
		return classId;
	}
	public void setClassId(String classId) {
		this.classId = classId;
	}
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	public String getPoleId() {
		return poleId;
	}
	public void setPoleId(String poleId) {
		this.poleId = poleId;
	}
	public String getPoleName() {
		return poleName;
	}
	public void setPoleName(String poleName) {
		this.poleName = poleName;
	}
	public String getThreshold() {
		return threshold;
	}
	public void setThreshold(String threshold) {
		this.threshold = threshold;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
}
