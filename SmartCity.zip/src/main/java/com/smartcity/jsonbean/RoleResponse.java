/**
 * 
 */
package com.smartcity.jsonbean;

/**
 * @author inrpande01
 *
 */
public class RoleResponse {

	private String id;
	private String role;
	private String message;
	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
	
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return "RoleResponse [id=" + id + ", role=" + role + ", message=" + message + "]";
	}
}
