package com.smartcity.jsonbean;

import javax.validation.constraints.NotNull;

public class CreatePoleRequest {
	
	@NotNull(message="mandatory")
	private String name;
	@NotNull(message="mandatory")
	private String lat;
	@NotNull(message="mandatory")
	private String longi;
	
	private String status;
	
	private byte isGateway;	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLat() {
		return lat;
	}
	public void setLat(String lat) {
		this.lat = lat;
	}
	public String getLongi() {
		return longi;
	}
	public void setLongi(String longi) {
		this.longi = longi;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public byte getIsGateway() {
		return isGateway;
	}
	public void setIsGateway(byte isGateway) {
		this.isGateway = isGateway;
	}
	

}
