/**
 * 
 */
package com.smartcity.jsonbean;

/**
 * @author inrpande01
 *
 */
public class LoginReonse {

	
	private String message;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
}
