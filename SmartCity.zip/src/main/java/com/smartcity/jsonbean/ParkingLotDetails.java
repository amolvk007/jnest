package com.smartcity.jsonbean;

public class ParkingLotDetails {
	private String lotName;
	private String availability;
	
	public String getLotName() {
		return lotName;
	}
	public void setLotName(String lotName) {
		this.lotName = lotName;
	}
	public String getAvailability() {
		return availability;
	}
	public void setAvailability(String availability) {
		this.availability = availability;
	}
	
	@Override
	public String toString() {
		return "ParkingLotDetails [lotName=" + lotName + ", availability=" + availability + "]";
	}
	
	
	

}
