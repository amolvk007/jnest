package com.smartcity.dbbean;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

/**
 * The persistent class for the sc_role database table.
 * 
 */
@Entity
@Table(name = "SC_ROLE", uniqueConstraints=
@UniqueConstraint(columnNames={"name"}))
public class ScRoleEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
/*	@GeneratedValue(generator = "uuid")
	@GenericGenerator(name = "uuid", strategy = "uuid2")*/
	@Column(name = "ID", nullable = false)	
	private String id;

	private String name;

	/*
	 * //bi-directional many-to-one association to ScUser
	 * 
	 * @OneToMany(mappedBy="scRole", fetch=FetchType.EAGER) private
	 * List<ScUserEntity> scUsers;
	 */

	@OneToMany(mappedBy = "scRole",cascade = CascadeType.ALL,fetch=FetchType.LAZY)
	private Set<SCUserRoleEntity> scUserRole;
	
	public ScRoleEntity() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	/*
	 * public List<ScUserEntity> getScUsers() { return this.scUsers; }
	 * 
	 * public void setScUsers(List<ScUserEntity> scUsers) { this.scUsers =
	 * scUsers; }
	 */

	/*
	 * public ScUserEntity addScUser(ScUserEntity scUser) {
	 * getScUsers().add(scUser); scUser.setScRole(this);
	 * 
	 * return scUser; }
	 * 
	 * public ScUserEntity removeScUser(ScUserEntity scUser) {
	 * getScUsers().remove(scUser); scUser.setScRole(null);
	 * 
	 * return scUser; }
	 */

}