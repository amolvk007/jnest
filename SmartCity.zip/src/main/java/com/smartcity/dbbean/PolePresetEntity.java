package com.smartcity.dbbean;

import java.io.Serializable;
import javax.persistence.*;

import org.hibernate.annotations.GenericGenerator;


/**
 * The persistent class for the pole_preset database table.
 * 
 */
@Entity
@Table(name="POLE_PRESET")
public class PolePresetEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "uuid")
	@GenericGenerator(name = "uuid", strategy = "uuid2")
	@Column(name = "ID", nullable = false)	
	private String id;

	//bi-directional many-to-one association to EventPreset
	@ManyToOne
	@JoinColumn(name="presetid")
	private EventPresetEntity eventPreset;

	//bi-directional many-to-one association to Pole
	@OneToOne
	@JoinColumn(name="poleid")
	private PoleEntity pole;

	public PolePresetEntity() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public EventPresetEntity getEventPreset() {
		return this.eventPreset;
	}

	public void setEventPreset(EventPresetEntity eventPreset) {
		this.eventPreset = eventPreset;
	}

	public PoleEntity getPole() {
		return this.pole;
	}

	public void setPole(PoleEntity pole) {
		this.pole = pole;
	}

}