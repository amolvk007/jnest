package com.smartcity.dbbean;

import java.io.Serializable;
import javax.persistence.*;

import org.hibernate.annotations.GenericGenerator;

import com.smartcity.jsonbean.District;


/**
 * The persistent class for the district_preset database table.
 * 
 */
@Entity
@Table(name="DISTRICT_PRESET")

public class DistrictPresetEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "uuid")
	@GenericGenerator(name = "uuid", strategy = "uuid2")
	private String id;

	@Column(name = "presetid")
	private String presetId;
	
	@Column(name = "districtid")
	private String districtId;
	
	@Column(name = "STORM")
	private byte isStorm;
	
	
	//bi-directional many-to-one association to EventPreset
	@ManyToOne
	@JoinColumn(name="presetid",unique=true, insertable = false, updatable = false)
	private EventPresetEntity eventPreset;

	//bi-directional many-to-one association to District
	@OneToOne
	@JoinColumn(name="districtid",unique=true,insertable = false, updatable = false)
	private DistrictEntity district;

	

	public String getPresetId() {
		return presetId;
	}

	public void setPresetId(String presetId) {
		this.presetId = presetId;
	}

	public String getDistrictId() {
		return districtId;
	}

	public void setDistrictId(String districtId) {
		this.districtId = districtId;
	}

	public DistrictPresetEntity() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public EventPresetEntity getEventPreset() {
		return this.eventPreset;
	}

	public void setEventPreset(EventPresetEntity eventPreset) {
		this.eventPreset = eventPreset;
	}

	public DistrictEntity getDistrict() {
		return this.district;
	}

	public void setDistrict(DistrictEntity district) {
		this.district = district;
	}

}