package com.smartcity.dbbean;

import java.io.Serializable;
//import javax.persistence.*;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

/**
 * The persistent class for the event_preset database table.
 * 
 */
@Entity
@Table(name = "EVENT_PRESET")

public class EventPresetEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "uuid")
	@GenericGenerator(name = "uuid", strategy = "uuid2")
	@Column(name = "ID", nullable = false)
	private String id;

	private String audio;

	private String beaconlightcolor;

	private String beaconlightpreset;

	private String floodlightpreset;

	private String name;

	private String streetlightintensity;

	private String streetlightpreset;

	private String textmessage;

	private double volume;

	private String threshold;
	
	@Column(name = "DEFAULTEVENT", nullable = false)
	private boolean isDefaultEvent;
	


	// bi-directional many-to-one association to DistrictPreset
	@OneToMany(mappedBy = "eventPreset")
	private List<DistrictPresetEntity> districtPresets;

	// bi-directional many-to-one association to GatewayPreset
	@OneToMany(mappedBy = "eventPreset")
	private List<GatewayPresetEntity> gatewayPresets;

	// bi-directional many-to-one association to PolePreset
	@OneToMany(mappedBy = "eventPreset")
	private List<PolePresetEntity> polePresets;

	// bi-directional many-to-one association to SensorPreset
	@OneToMany(mappedBy = "eventPreset")
	private List<SensorPresetEntity> sensorPresets;


	
	
	public boolean isDefaultEvent() {
		return isDefaultEvent;
	}

	public void setDefaultEvent(boolean isDefaultEvent) {
		this.isDefaultEvent = isDefaultEvent;
	}

	public EventPresetEntity() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getAudio() {
		return this.audio;
	}

	public void setAudio(String audio) {
		this.audio = audio;
	}

	public String getBeaconlightcolor() {
		return this.beaconlightcolor;
	}

	public void setBeaconlightcolor(String beaconlightcolor) {
		this.beaconlightcolor = beaconlightcolor;
	}

	public String getBeaconlightpreset() {
		return this.beaconlightpreset;
	}

	public void setBeaconlightpreset(String beaconlightpreset) {
		this.beaconlightpreset = beaconlightpreset;
	}

	public String getFloodlightpreset() {
		return this.floodlightpreset;
	}

	public void setFloodlightpreset(String floodlightpreset) {
		this.floodlightpreset = floodlightpreset;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getStreetlightintensity() {
		return this.streetlightintensity;
	}

	public void setStreetlightintensity(String streetlightintensity) {
		this.streetlightintensity = streetlightintensity;
	}

	public String getStreetlightpreset() {
		return this.streetlightpreset;
	}

	public void setStreetlightpreset(String streetlightpreset) {
		this.streetlightpreset = streetlightpreset;
	}

	public String getTextmessage() {
		return this.textmessage;
	}

	public void setTextmessage(String textmessage) {
		this.textmessage = textmessage;
	}

	public double getVolume() {
		return this.volume;
	}

	public void setVolume(double volume) {
		this.volume = volume;
	}

	public String getThreshold() {
		return threshold;
	}

	public void setThreshold(String threshold) {
		this.threshold = threshold;
	}

	public List<DistrictPresetEntity> getDistrictPresets() {
		return this.districtPresets;
	}

	public void setDistrictPresets(List<DistrictPresetEntity> districtPresets) {
		this.districtPresets = districtPresets;
	}

	public DistrictPresetEntity addDistrictPreset(DistrictPresetEntity districtPreset) {
		getDistrictPresets().add(districtPreset);
		districtPreset.setEventPreset(this);

		return districtPreset;
	}

	public DistrictPresetEntity removeDistrictPreset(DistrictPresetEntity districtPreset) {
		getDistrictPresets().remove(districtPreset);
		districtPreset.setEventPreset(null);

		return districtPreset;
	}

	public List<GatewayPresetEntity> getGatewayPresets() {
		return this.gatewayPresets;
	}

	public void setGatewayPresets(List<GatewayPresetEntity> gatewayPresets) {
		this.gatewayPresets = gatewayPresets;
	}

	public GatewayPresetEntity addGatewayPreset(GatewayPresetEntity gatewayPreset) {
		getGatewayPresets().add(gatewayPreset);
		gatewayPreset.setEventPreset(this);

		return gatewayPreset;
	}

	public GatewayPresetEntity removeGatewayPreset(GatewayPresetEntity gatewayPreset) {
		getGatewayPresets().remove(gatewayPreset);
		gatewayPreset.setEventPreset(null);

		return gatewayPreset;
	}

	public List<PolePresetEntity> getPolePresets() {
		return this.polePresets;
	}

	public void setPolePresets(List<PolePresetEntity> polePresets) {
		this.polePresets = polePresets;
	}

	public PolePresetEntity addPolePreset(PolePresetEntity polePreset) {
		getPolePresets().add(polePreset);
		polePreset.setEventPreset(this);

		return polePreset;
	}

	public PolePresetEntity removePolePreset(PolePresetEntity polePreset) {
		getPolePresets().remove(polePreset);
		polePreset.setEventPreset(null);

		return polePreset;
	}

	public List<SensorPresetEntity> getSensorPresets() {
		return this.sensorPresets;
	}

	public void setSensorPresets(List<SensorPresetEntity> sensorPresets) {
		this.sensorPresets = sensorPresets;
	}

	public SensorPresetEntity addSensorPreset(SensorPresetEntity sensorPreset) {
		getSensorPresets().add(sensorPreset);
		sensorPreset.setEventPreset(this);

		return sensorPreset;
	}

	public SensorPresetEntity removeSensorPreset(SensorPresetEntity sensorPreset) {
		getSensorPresets().remove(sensorPreset);
		sensorPreset.setEventPreset(null);

		return sensorPreset;
	}

}