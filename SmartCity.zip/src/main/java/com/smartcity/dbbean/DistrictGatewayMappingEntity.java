package com.smartcity.dbbean;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

/**
 * The persistent class for the DISTRICT_GATEWAY database table.
 * 
 */
@Entity
@Table(name = "DISTRICT_GATEWAY")
public class DistrictGatewayMappingEntity implements Serializable {
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "uuid")
	@GenericGenerator(name = "uuid", strategy = "uuid2")
	@Column(name = "ID", nullable = false)
	private String id;

	@Column(name = "DISTRICTID")
	private String districtId;
	
	@Column(name = "GATEWAYID")
	private String gatewayId;
	
	@Column(name = "CREATEDBY")
	private String createdby;

	@Column(name = "CREATEDDATE")
	private Timestamp createddate;

	@Column(name = "MODIFIEDBY")
	private String modifiedby;

	@Column(name = "MODIFIEDDATE")
	private Timestamp modifiedDate;
	
	@ManyToOne
	@JoinColumn(name="DISTRICTID", insertable=false, updatable=false)
	private DistrictEntity district;
	
	@OneToOne
	@JoinColumn(name="GATEWAYID", insertable=false, updatable=false)
	private GatewayEntity gateway;

	
	public String getDistrictId() {
		return districtId;
	}

	public void setDistrictId(String districtId) {
		this.districtId = districtId;
	}

	public String getGatewayId() {
		return gatewayId;
	}

	public void setGatewayId(String gatewayId) {
		this.gatewayId = gatewayId;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public DistrictEntity getDistrict() {
		return district;
	}

	public void setDistrict(DistrictEntity district) {
		this.district = district;
	}

	public GatewayEntity getGateway() {
		return gateway;
	}

	public void setGateway(GatewayEntity gateway) {
		this.gateway = gateway;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
	
}
