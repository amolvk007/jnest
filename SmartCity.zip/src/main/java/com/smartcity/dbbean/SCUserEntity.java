package com.smartcity.dbbean;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.hibernate.annotations.Filter;
import org.hibernate.annotations.FilterDef;
import org.hibernate.annotations.FilterDefs;
import org.hibernate.annotations.Filters;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.ParamDef;

/**
 * The persistent class for the sc_user database table.
 * 
 */
@Entity
@Table(name = "SC_USER", uniqueConstraints = @UniqueConstraint(columnNames = { "username" }) )
@FilterDefs({ @FilterDef(name = "USERNAME", parameters = { @ParamDef(name = "username", type = "string") }),
		@FilterDef(name = "FIRSTNAME", parameters = { @ParamDef(name = "firstname", type = "string") }),
		@FilterDef(name = "LASTNAME", parameters = { @ParamDef(name = "lastname", type = "string") }),
		@FilterDef(name = "EMAIL", parameters = { @ParamDef(name = "email", type = "string") })})

@Filters({ @Filter(name = "USERNAME", condition = ":username like username "),
		@Filter(name = "FIRSTNAME", condition = ":firstname like firstname"),
		@Filter(name = "LASTNAME", condition = ":lastname like lastname"),
		@Filter(name = "EMAIL", condition = ":email=email ")})
		
/*
 * @NamedQueries(value = {
 * 
 * @NamedQuery(name = "UserDetailsByName", query =
 * "select * from SC_USER SC_USER inner join  where  scUserEntity.externalTransactionId = :externalTransactionId"
 * ) })
 */
public class SCUserEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	// @GeneratedValue(strategy=GenerationType.IDENTITY)
	@GeneratedValue(generator = "uuid")
	@GenericGenerator(name = "uuid", strategy = "uuid2")
	@Column(name = "ID", nullable = false)
	private String id;

	private String firstname;

	private String lastname;

	private String password;

	@Column(name = "username", unique = true)
	private String username;

	private String email;

	private String passwordsend;

	private String picpath;

	private String createdBy;

	private Timestamp createdDate;

	private String modifiedBy;

	private Timestamp modifiedDate;

	@OneToMany(mappedBy = "scUsers",cascade = CascadeType.ALL,fetch=FetchType.EAGER)
	private Set<SCUserRoleEntity> scUserRole;

	public String getPicpath() {
		return picpath;
	}

	public String isPasswordsend() {
		return passwordsend;
	}

	public void setPasswordsend(String passwordsend) {
		this.passwordsend = passwordsend;
	}

	public void setPicpath(String picpath) {
		this.picpath = picpath;
	}

	// bi-directional many-to-one association to DistrictUser
	@OneToMany(mappedBy = "scUser", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	private List<DistrictUserEntity> districtUsers;

	// bi-directional many-to-one association to ScRole
	/*
	 * @ManyToOne()
	 * 
	 * @JoinColumn(name="ROLEID") private ScRoleEntity scRole;
	 */

	public SCUserEntity() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getFirstname() {
		return this.firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return this.lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Set<SCUserRoleEntity> getScUserRole() {
		return scUserRole;
	}

	public void setScUserRole(Set<SCUserRoleEntity> scUserRole) {
		this.scUserRole = scUserRole;
	}

	public String getUsername() {
		return this.username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public List<DistrictUserEntity> getDistrictUsers() {
		return this.districtUsers;
	}

	public void setDistrictUsers(List<DistrictUserEntity> districtUsers) {
		this.districtUsers = districtUsers;
	}

	/*
	 * public DistrictUserEntity addDistrictUser(DistrictUserEntity
	 * districtUser) { getDistrictUsers().add(districtUser);
	 * districtUser.setScUser(this);
	 * 
	 * return districtUser; }
	 * 
	 * public DistrictUserEntity removeDistrictUser(DistrictUserEntity
	 * districtUser) { getDistrictUsers().remove(districtUser);
	 * districtUser.setScUser(null);
	 * 
	 * return districtUser; }
	 */

	/*
	 * public ScRoleEntity getScRole() { return this.scRole; }
	 * 
	 * public void setScRole(ScRoleEntity scRole) { this.scRole = scRole; }
	 */



	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Timestamp getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

}