package com.smartcity.dbbean;


import java.io.Serializable;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;


/**
 * The persistent class for the sensor database table.
 * 
 */
@Entity
@Table (name="SENSOR")
public class SensorEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String id;

	private String name;

	private String status;

	private String threshold;

	//bi-directional many-to-one association to SensorPreset
	@OneToOne(mappedBy="sensor")
	private SensorPresetEntity sensorPresets;
		
	//bi-directional many-to-one association to SensorClass
	@ManyToOne
	@JoinColumn(name="CLASSID")
	private SensorClassEntity sensorClass;

	
/*	@ManyToOne(fetch = FetchType.LAZY, cascade=CascadeType.ALL)
	@JoinTable(name = "POLE_SENSOR", joinColumns = { @JoinColumn(name = "SENSORID") }, 
		inverseJoinColumns = { @JoinColumn(name = "poleid") })
	private PoleEntity pole;*/
	
	//bi-directional many-to-one association to PoleSensor
	@OneToMany(mappedBy="sensor",fetch = FetchType.LAZY)
	private List<PoleSensorEntity> poleSensors;

	public SensorEntity() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getThreshold() {
		return this.threshold;
	}

	public void setThreshold(String threshold) {
		this.threshold = threshold;
	}

	public SensorClassEntity getSensorClass() {
		return this.sensorClass;
	}

	public void setSensorClass(SensorClassEntity sensorClass) {
		this.sensorClass = sensorClass;
	}

	public SensorPresetEntity getSensorPresets() {
		return this.sensorPresets;
	}

	public void setSensorPresets(SensorPresetEntity sensorPresets) {
		this.sensorPresets = sensorPresets;
	}

	public List<PoleSensorEntity> getPoleSensors() {
		return poleSensors;
	}

	public void setPoleSensors(List<PoleSensorEntity> poleSensors) {
		this.poleSensors = poleSensors;
	}

	/*public PoleEntity getPole() {
		return this.pole;
	}

	public void setPole(PoleEntity pole) {
		this.pole = pole;
	}
*/
}