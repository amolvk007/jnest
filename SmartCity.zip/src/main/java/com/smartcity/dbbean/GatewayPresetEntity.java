package com.smartcity.dbbean;

import java.io.Serializable;
import javax.persistence.*;

import org.hibernate.annotations.GenericGenerator;


/**
 * The persistent class for the gateway_preset database table.
 * 
 */
@Entity
@Table(name="GATEWAY_PRESET")

public class GatewayPresetEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "uuid")
	@GenericGenerator(name = "uuid", strategy = "uuid2")
	private String id;

	@Column(name = "presetid")
	private String presetId;
	
	@Column(name = "gatewayid")
	private String gatewayId;
	
	//bi-directional many-to-one association to EventPreset
	@ManyToOne
	@JoinColumn(name="presetid", unique=true, insertable = false, updatable = false)
	private EventPresetEntity eventPreset;

	//bi-directional many-to-one association to Gateway
	@OneToOne
	@JoinColumn(name="gatewayid",unique=true, insertable = false, updatable = false)
	private GatewayEntity gateway;

	public GatewayPresetEntity() {
	}

	public String getPresetId() {
		return presetId;
	}

	public void setPresetId(String presetId) {
		this.presetId = presetId;
	}

	public String getGatewayId() {
		return gatewayId;
	}

	public void setGatewayId(String gatewayId) {
		this.gatewayId = gatewayId;
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public EventPresetEntity getEventPreset() {
		return this.eventPreset;
	}

	public void setEventPreset(EventPresetEntity eventPreset) {
		this.eventPreset = eventPreset;
	}

	public GatewayEntity getGateway() {
		return this.gateway;
	}

	public void setGateway(GatewayEntity gateway) {
		this.gateway = gateway;
	}

}