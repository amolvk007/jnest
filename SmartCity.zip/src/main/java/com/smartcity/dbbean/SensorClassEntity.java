package com.smartcity.dbbean;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the sensor_class database table.
 * 
 */
@Entity
@Table(name="SENSOR_CLASS")
public class SensorClassEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private String id;

	private String name;

	//bi-directional many-to-one association to Sensor
	@OneToMany(mappedBy="sensorClass", fetch=FetchType.EAGER)
	private List<SensorEntity> sensors;

	public SensorClassEntity() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<SensorEntity> getSensors() {
		return this.sensors;
	}

	public void setSensors(List<SensorEntity> sensors) {
		this.sensors = sensors;
	}

	public SensorEntity addSensor(SensorEntity sensor) {
		getSensors().add(sensor);
		sensor.setSensorClass(this);

		return sensor;
	}

	public SensorEntity removeSensor(SensorEntity sensor) {
		getSensors().remove(sensor);
		sensor.setSensorClass(null);

		return sensor;
	}

}