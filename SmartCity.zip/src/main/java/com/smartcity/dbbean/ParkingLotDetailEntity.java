package com.smartcity.dbbean;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the parking_lot_details database table.
 * 
 */
@Entity
@Table(name="PARKING_LOT_DETAILS")
public class ParkingLotDetailEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private String id;

	private String parkinglevel;

	private String status;

	//bi-directional many-to-one association to ParkingLot
	@ManyToOne
	@JoinColumn(name="PARKINGLOTID")
	private ParkingLotEntity parkingLot;

	public ParkingLotDetailEntity() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getParkinglevel() {
		return this.parkinglevel;
	}

	public void setParkinglevel(String parkinglevel) {
		this.parkinglevel = parkinglevel;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public ParkingLotEntity getParkingLot() {
		return this.parkingLot;
	}

	public void setParkingLot(ParkingLotEntity parkingLot) {
		this.parkingLot = parkingLot;
	}

}