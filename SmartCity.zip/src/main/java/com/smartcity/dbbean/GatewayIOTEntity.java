package com.smartcity.dbbean;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * The persistent class for the gateway database table.
 * 
 */
@Entity
@Table(name = "GATEWAY_IOT")
public class GatewayIOTEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@OneToOne
	@JoinColumn(name="id")
	private GatewayEntity gateway;

	private String ram;
	private String wifi;
	private String storage;
	private String battery;
	private String bluetooth;
	private String security;
	private String ip;
	private String network;

	public GatewayIOTEntity() {
	}

	public String getRam() {
		return ram;
	}

	public void setRam(String ram) {
		this.ram = ram;
	}

	public String getWifi() {
		return wifi;
	}

	public void setWifi(String wifi) {
		this.wifi = wifi;
	}

	public String getStorage() {
		return storage;
	}

	public void setStorage(String storage) {
		this.storage = storage;
	}

	public String getBattery() {
		return battery;
	}

	public void setBattery(String battery) {
		this.battery = battery;
	}

	public String getBluetooth() {
		return bluetooth;
	}

	public void setBluetooth(String bluetooth) {
		this.bluetooth = bluetooth;
	}

	public String getSecurity() {
		return security;
	}

	public void setSecurity(String security) {
		this.security = security;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public String getNetwork() {
		return network;
	}

	public void setNetwork(String network) {
		this.network = network;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public GatewayEntity getGateway() {
		return gateway;
	}

	public void setGateway(GatewayEntity gateway) {
		this.gateway = gateway;
	}
}