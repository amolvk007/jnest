package com.smartcity.dbbean;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "DISTRICT_USER")
public class DistrictUserEntity implements Serializable {

	/**
	 * The persistent class for the district_user database table.
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "uuid")
	@GenericGenerator(name = "uuid", strategy = "uuid2")
	private String id;

	@Column(name = "USERID")
	private String userId;

	@Column(name = "DISTRICTID")
	private String districtId;
	// bi-directional many-to-one association to District
	@ManyToOne
	@JoinColumn(name = "DISTRICTID", insertable = false, updatable = false)
	private DistrictEntity district;

	// bi-directional many-to-one association to ScUserEntity
	@ManyToOne
	@JoinColumn(name = "USERID", insertable = false, updatable = false)
	private SCUserEntity scUser;

	private Timestamp CREATEDDATE;
	private Timestamp MODIFIEDDATE;
	private String CREATEDBY;
	private String MODIFIEDBY;

	public DistrictUserEntity() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public DistrictEntity getDistrict() {
		return this.district;
	}

	public void setDistrict(DistrictEntity district) {
		this.district = district;
	}

	public SCUserEntity getScUser() {
		return this.scUser;
	}

	public void setScUser(SCUserEntity scUser) {
		this.scUser = scUser;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getDistrictId() {
		return districtId;
	}

	public void setDistrictId(String districtId) {
		this.districtId = districtId;
	}

	public Timestamp getCREATEDDATE() {
		return CREATEDDATE;
	}

	public void setCREATEDDATE(Timestamp cREATEDDATE) {
		CREATEDDATE = cREATEDDATE;
	}

	public Timestamp getMODIFIEDDATE() {
		return MODIFIEDDATE;
	}

	public void setMODIFIEDDATE(Timestamp MODIFIEDDATE) {
		MODIFIEDDATE = MODIFIEDDATE;
	}

	public String getCREATEDBY() {
		return CREATEDBY;
	}

	public void setCREATEDBY(String cREATEDBY) {
		CREATEDBY = cREATEDBY;
	}

	public String getMODIFIEDBY() {
		return MODIFIEDBY;
	}

	public void setMODIFIEDBY(String mODIFIEDBY) {
		MODIFIEDBY = mODIFIEDBY;
	}
}
