package com.smartcity.dbbean;

import java.io.Serializable;
import javax.persistence.*;

import org.hibernate.annotations.GenericGenerator;


/**
 * The persistent class for the sensor_preset database table.
 * 
 */
@Entity
@Table(name="SENSOR_PRESET")
public class SensorPresetEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "uuid")
	@GenericGenerator(name = "uuid", strategy = "uuid2")
	private String id;

	//bi-directional many-to-one association to EventPreset
	@ManyToOne
	@JoinColumn(name="presetid")
	private EventPresetEntity eventPreset;

	//bi-directional many-to-one association to Sensor
	@OneToOne
	@JoinColumn(name="sensorid")
	private SensorEntity sensor;

	public SensorPresetEntity() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public EventPresetEntity getEventPreset() {
		return this.eventPreset;
	}

	public void setEventPreset(EventPresetEntity eventPreset) {
		this.eventPreset = eventPreset;
	}

	public SensorEntity getSensor() {
		return this.sensor;
	}

	public void setSensor(SensorEntity sensor) {
		this.sensor = sensor;
	}

}