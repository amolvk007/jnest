package com.smartcity.dbbean;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the parking_lot database table.
 * 
 */
@Entity
@Table(name="PARKING_LOT")
public class ParkingLotEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private String id;

	private String availability;

	private String lat;

	private String longi;

	private String name;

	private String poleids;

	//bi-directional many-to-one association to District
	@ManyToOne
	@JoinColumn(name="DISTRICTID")
	private DistrictEntity district;

	//bi-directional many-to-one association to ParkingLotDetail
	@OneToMany(mappedBy="parkingLot", fetch=FetchType.EAGER)
	private List<ParkingLotDetailEntity> parkingLotDetails;

	public ParkingLotEntity() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getAvailability() {
		return this.availability;
	}

	public void setAvailability(String availability) {
		this.availability = availability;
	}

	public String getLat() {
		return this.lat;
	}

	public void setLat(String lat) {
		this.lat = lat;
	}

	public String getLongi() {
		return this.longi;
	}

	public void setLongi(String longi) {
		this.longi = longi;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPoleids() {
		return this.poleids;
	}

	public void setPoleids(String poleids) {
		this.poleids = poleids;
	}

	public DistrictEntity getDistrict() {
		return this.district;
	}

	public void setDistrict(DistrictEntity district) {
		this.district = district;
	}

	public List<ParkingLotDetailEntity> getParkingLotDetails() {
		return this.parkingLotDetails;
	}

	public void setParkingLotDetails(List<ParkingLotDetailEntity> parkingLotDetails) {
		this.parkingLotDetails = parkingLotDetails;
	}

	public ParkingLotDetailEntity addParkingLotDetail(ParkingLotDetailEntity parkingLotDetail) {
		getParkingLotDetails().add(parkingLotDetail);
		parkingLotDetail.setParkingLot(this);

		return parkingLotDetail;
	}

	public ParkingLotDetailEntity removeParkingLotDetail(ParkingLotDetailEntity parkingLotDetail) {
		getParkingLotDetails().remove(parkingLotDetail);
		parkingLotDetail.setParkingLot(null);

		return parkingLotDetail;
	}

}