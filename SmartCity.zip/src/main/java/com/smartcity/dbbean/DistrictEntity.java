package com.smartcity.dbbean;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;
import org.hibernate.annotations.GenericGenerator;


/**
 * The persistent class for the district database table.
 * 
 */
@Entity
@Table(name= "DISTRICT")
public class DistrictEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "uuid")
	@GenericGenerator(name = "uuid", strategy = "uuid2")
	@Column(name = "ID", nullable = false)	
	private String id;

	@Lob
	@Column(name = "COORDINATES")
	private String coordinates;

	@Column(name = "NAME")
	private String name;
	
	@Column(name = "CREATEDBY")
	private String createdby;

	@Column(name = "CREATEDDATE")
	private Timestamp createddate;

	@Column(name = "MODIFIEDBY")

	private String modifiedby;
	@Column(name = "MODIFIEDDATE")
	private Timestamp modifiedDate;
	
	//bi-directional many-to-one association to DistrictPreset
	@OneToOne(mappedBy="district")
	@Cascade({CascadeType.DELETE})
	private DistrictPresetEntity districtPresets;
		
	//bi-directional many-to-one association to DistrictUser
	@OneToMany(mappedBy="district" , fetch=FetchType.LAZY)
	@Cascade({CascadeType.ALL})
	private List<DistrictUserEntity> districtUsers;

	/*//TODO : Need to remove if the district and gateway mapping entity is introduced.
	//bi-directional many-to-one association to Gateway
	@OneToMany(mappedBy="district", fetch=FetchType.LAZY)
	private List<GatewayEntity> gateways;
	*/	
	@OneToMany(mappedBy="district", fetch=FetchType.LAZY)
	@Cascade({CascadeType.DELETE})
	private List<DistrictGatewayMappingEntity> districtMappingEnity;


	//bi-directional many-to-one association to ParkingLot
	@OneToMany(mappedBy="district", fetch=FetchType.LAZY)
	private List<ParkingLotEntity> parkingLots;
	
	
	public String getCreatedby() {
			return createdby;
		}



		public void setCreatedby(String createdby) {
			this.createdby = createdby;
		}



		public Timestamp getCreateddate() {
			return createddate;
		}



		public void setCreateddate(Timestamp createddate) {
			this.createddate = createddate;
		}



		public String getModifiedby() {
			return modifiedby;
		}



		public void setModifiedby(String modifiedby) {
			this.modifiedby = modifiedby;
		}



		public Timestamp getModifiedDate() {
			return modifiedDate;
		}



		public void setModifiedDate(Timestamp modifiedDate) {
			this.modifiedDate = modifiedDate;
		}



	public List<DistrictGatewayMappingEntity> getDistrictMappingEnity() {
		return districtMappingEnity;
	}



	public void setDistrictMappingEnity(List<DistrictGatewayMappingEntity> districtMappingEnity) {
		this.districtMappingEnity = districtMappingEnity;
	}



	public DistrictEntity() {
	}

	
	
	public String getCoordinates() {
		return coordinates;
	}



	public void setCoordinates(String coordinates) {
		this.coordinates = coordinates;
	}



	/*public List<GatewayEntity> getGateways() {
		return gateways;
	}



	public void setGateways(List<GatewayEntity> gateways) {
		this.gateways = gateways;
	}

*/


	public static long getSerialversionuid() {
		return serialVersionUID;
	}



	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getcoordinates() {
		return this.coordinates;
	}

	public void setcoordinates(String coordinates) {
		this.coordinates = coordinates;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public DistrictPresetEntity getDistrictPresets() {
		return this.districtPresets;
	}

	public void setDistrictPresets(DistrictPresetEntity districtPresets) {
		this.districtPresets = districtPresets;
	}

	
	public List<DistrictUserEntity> getDistrictUsers() {
		return this.districtUsers;
	}

	public void setDistrictUsers(List<DistrictUserEntity> districtUsers) {
		this.districtUsers = districtUsers;
	}

	/*public DistrictUserEntity addDistrictUser(DistrictUserEntity districtUser) {
		getDistrictUsers().add(districtUser);
		districtUser.setDistrict(this);

		return districtUser;
	}
*/
	/*public DistrictUserEntity removeDistrictUser(DistrictUserEntity districtUser) {
		getDistrictUsers().remove(districtUser);
		districtUser.setDistrict(null);

		return districtUser;
	}*/


	public List<ParkingLotEntity> getParkingLots() {
		return this.parkingLots;
	}

	public void setParkingLots(List<ParkingLotEntity> parkingLots) {
		this.parkingLots = parkingLots;
	}

	public ParkingLotEntity addParkingLot(ParkingLotEntity parkingLot) {
		getParkingLots().add(parkingLot);
		parkingLot.setDistrict(this);

		return parkingLot;
	}

	public ParkingLotEntity removeParkingLot(ParkingLotEntity parkingLot) {
		getParkingLots().remove(parkingLot);
		parkingLot.setDistrict(null);

		return parkingLot;
	}

}