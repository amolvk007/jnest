package com.smartcity.dbbean;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.hibernate.annotations.GenericGenerator;


/**
 * The persistent class for the pole database table.
 * 
 */
@Entity
@Table (name="POLE",uniqueConstraints=@UniqueConstraint(columnNames={"name"}))
public class PoleEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "uuid")
	@GenericGenerator(name = "uuid", strategy = "uuid2")
	@Column(name = "ID", nullable = false)	
	private String id;

	private String lat;

	private String longi;

	private String name;
	private String status;
	
	private byte isGateway;
	
	private String createdBy;

	private Timestamp createdDate;

	private String modifiedBy;
	
	private Timestamp modifiedDate;


	@ManyToOne(fetch = FetchType.LAZY,cascade=CascadeType.ALL )
	@JoinTable(name = "GATEWAY_POLE", joinColumns = { @JoinColumn(name = "POLEID") }, 
		inverseJoinColumns = { @JoinColumn(name = "GATEWAYID") })
	private GatewayEntity gateway;

	//bi-directional many-to-one association to PolePreset
	@OneToOne(mappedBy="pole", fetch = FetchType.LAZY,cascade=CascadeType.ALL)
	private PolePresetEntity polePresets;
	
	// bi-directional many-to-one association to Pole
	/*@OneToMany(mappedBy="pole", fetch = FetchType.LAZY)
	private List<SensorEntity> sensors;*/

	//bi-directional many-to-one association to PoleSensor
	@OneToMany(mappedBy="pole", fetch = FetchType.LAZY)
	private List<PoleSensorEntity> poleSensors;
		
	public PoleEntity() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getLat() {
		return this.lat;
	}

	public void setLat(String lat) {
		this.lat = lat;
	}

	public String getLongi() {
		return this.longi;
	}

	public void setLongi(String longi) {
		this.longi = longi;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public byte getIsGateway() {
		return isGateway;
	}

	public void setIsGateway(byte isGateway) {
		this.isGateway = isGateway;
	}

	public GatewayEntity getGateway() {
		return this.gateway;
	}

	public void setGateway(GatewayEntity gateway) {
		this.gateway = gateway;
	}

	public PolePresetEntity getPolePresets() {
		return this.polePresets;
	}

	public void setPolePresets(PolePresetEntity polePresets) {
		this.polePresets = polePresets;
	}

	public List<PoleSensorEntity> getPoleSensors() {
		return poleSensors;
	}

	public void setPoleSensors(List<PoleSensorEntity> poleSensors) {
		this.poleSensors = poleSensors;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Timestamp getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	
	/*public List<SensorEntity> getSensors() {
		return this.sensors;
	}

	public void setSensors(List<SensorEntity> sensors) {
		this.sensors = sensors;
	}*/

	/*public SensorEntity addSensor(SensorEntity sensor) {
		getSensors().add(sensor);
		sensor.setPole(this);

		return sensor;
	}

	public SensorEntity removeSensor(SensorEntity sensor) {
		getSensors().remove(sensor);
		sensor.setPole(null);

		return sensor;
	}
*/
}