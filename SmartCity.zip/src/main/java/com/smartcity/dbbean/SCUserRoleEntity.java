/**
 * 
 */
package com.smartcity.dbbean;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Filter;
import org.hibernate.annotations.FilterDef;
import org.hibernate.annotations.FilterDefs;
import org.hibernate.annotations.Filters;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.ParamDef;

/**
 * @author inrpande01
 *
 */
@Entity
@Table(name = "SC_USER_ROLE" )
@FilterDefs({ @FilterDef(name = "ROLEID", parameters = { @ParamDef(name = "roleid", type = "string") })})
@Filters({ @Filter(name = "ROLEID",condition=" roleId NOT IN(:roleid)")})
public class SCUserRoleEntity implements Serializable{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "uuid")
	@GenericGenerator(name = "uuid", strategy = "uuid2")
	@Column(name = "ID", nullable = false)
	private String id;

	@Column(name = "USER_ID", nullable = false)
	private String userId;
	
	@Column(name = "ROLE_ID", nullable = false)
	private String roleId;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="ROLE_ID" ,unique=true,insertable = false, updatable = false)
	private ScRoleEntity scRole;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="USER_ID" ,unique=true,insertable = false, updatable = false)
	private SCUserEntity scUsers;


	public ScRoleEntity getScRole() {
		return scRole;
	}

	public void setScRole(ScRoleEntity scRole) {
		this.scRole = scRole;
	}

	public SCUserEntity getScUsers() {
		return scUsers;
	}

	public void setScUsers(SCUserEntity scUsers) {
		this.scUsers = scUsers;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getRoleId() {
		return roleId;
	}

	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}

	
}
