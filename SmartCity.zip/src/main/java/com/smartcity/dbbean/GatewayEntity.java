package com.smartcity.dbbean;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * The persistent class for the gateway database table.
 * 
 */
@Entity
@Table(name = "GATEWAY")
public class GatewayEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	//@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String id;

	private String name;

	private String status;

	@OneToOne(mappedBy = "gateway", fetch = FetchType.LAZY)
	private DistrictGatewayMappingEntity gatewayMappingEntity;

	// bi-directional many-to-one association to GatewayPreset
	@OneToOne(mappedBy = "gateway")
	private GatewayPresetEntity gatewayPresets;

	// bi-directional many-to-one association to Pole
	@OneToMany(mappedBy = "gateway", fetch = FetchType.LAZY, cascade=CascadeType.ALL)
	private List<PoleEntity> poles;
	
	// bi-directional many-to-one association to GatewayPreset
	@OneToOne(mappedBy = "gateway")
	private GatewayIOTEntity gatewayIOTParameters;

	public DistrictGatewayMappingEntity getGatewayMappingEntity() {
		return gatewayMappingEntity;
	}

	public void setGatewayMappingEntity(DistrictGatewayMappingEntity gatewayMappingEntity) {
		this.gatewayMappingEntity = gatewayMappingEntity;
	}

	public GatewayEntity() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	public GatewayPresetEntity getGatewayPresets() {
		return this.gatewayPresets;
	}

	public void setGatewayPresets(GatewayPresetEntity gatewayPresets) {
		this.gatewayPresets = gatewayPresets;
	}

	public List<PoleEntity> getPoles() {
		return this.poles;
	}

	public void setPoles(List<PoleEntity> poles) {
		this.poles = poles;
	}

	public GatewayIOTEntity getGatewayIOTParameters() {
		return gatewayIOTParameters;
	}

	public void setGatewayIOTParameters(GatewayIOTEntity gatewayIOTParameters) {
		this.gatewayIOTParameters = gatewayIOTParameters;
	}
}