package com.smartcity.common;

import java.util.List;

public class UIFilter {
	private String name;
	
	private String value;
	
	private List<String> filterValues;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public List<String> getFilterValues() {
		return filterValues;
	}

	public void setFilterValues(List<String> filterValues) {
		this.filterValues = filterValues;
	}


}
