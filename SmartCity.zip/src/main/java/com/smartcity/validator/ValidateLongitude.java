/**
 * 
 */
package com.smartcity.validator;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.Payload;
import javax.validation.ReportAsSingleViolation;
import javax.validation.constraints.Pattern;

/**
 * @author inrpande01
 *
 */
@Pattern(regexp = "^\\([-+]?(?:180(?:\\.0+)?|(?:(?:[0-9]?[0-9]|1[0-7][0-9])(?:\\.[0-9]+)?))\\)$")
@ReportAsSingleViolation
@Target({ METHOD, FIELD	})
@Retention(RUNTIME)
@Constraint(validatedBy = {})
@Documented
public @interface ValidateLongitude {

	   String message()
       default "notvalid";
   Class<?>[] groups() default {};
   Class<? extends Payload>[] payload() default {};
}
