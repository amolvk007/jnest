
package com.videonext.stratus.sdk2.objectmanagement.websvc.types;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.videonext.skm.om.websvc.types package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.videonext.skm.om.websvc.types
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link ParameterDesc }
     * 
     */
    public ParameterDesc createParameterDesc() {
        return new ParameterDesc();
    }

    /**
     * Create an instance of {@link CreateObjectTask }
     * 
     */
    public CreateObjectTask createCreateObjectTask() {
        return new CreateObjectTask();
    }

    /**
     * Create an instance of {@link ModifyObjectsResponse }
     * 
     */
    public ModifyObjectsResponse createModifyObjectsResponse() {
        return new ModifyObjectsResponse();
    }

    /**
     * Create an instance of {@link ServiceManagementResponse }
     * 
     */
    public ServiceManagementResponse createServiceManagementResponse() {
        return new ServiceManagementResponse();
    }

    /**
     * Create an instance of {@link MethodDescList }
     * 
     */
    public MethodDescList createMethodDescList() {
        return new MethodDescList();
    }

    /**
     * Create an instance of {@link ServiceManagementRequest }
     * 
     */
    public ServiceManagementRequest createServiceManagementRequest() {
        return new ServiceManagementRequest();
    }

    /**
     * Create an instance of {@link CreateObjectReceipt }
     * 
     */
    public CreateObjectReceipt createCreateObjectReceipt() {
        return new CreateObjectReceipt();
    }

    /**
     * Create an instance of {@link PropertyList }
     * 
     */
    public PropertyList createPropertyList() {
        return new PropertyList();
    }

    /**
     * Create an instance of {@link ObjectsRequest }
     * 
     */
    public ObjectsRequest createObjectsRequest() {
        return new ObjectsRequest();
    }

    /**
     * Create an instance of {@link Filter }
     * 
     */
    public Filter createFilter() {
        return new Filter();
    }

    /**
     * Create an instance of {@link Property }
     * 
     */
    public Property createProperty() {
        return new Property();
    }

    /**
     * Create an instance of {@link Host }
     * 
     */
    public Host createHost() {
        return new Host();
    }

    /**
     * Create an instance of {@link Method }
     * 
     */
    public Method createMethod() {
        return new Method();
    }

    /**
     * Create an instance of {@link ObjectHostFilter }
     * 
     */
    public ObjectHostFilter createObjectHostFilter() {
        return new ObjectHostFilter();
    }

    /**
     * Create an instance of {@link MethodDesc }
     * 
     */
    public MethodDesc createMethodDesc() {
        return new MethodDesc();
    }

    /**
     * Create an instance of {@link ServiceStatusResponse }
     * 
     */
    public ServiceStatusResponse createServiceStatusResponse() {
        return new ServiceStatusResponse();
    }

    /**
     * Create an instance of {@link DeletePropertyList }
     * 
     */
    public DeletePropertyList createDeletePropertyList() {
        return new DeletePropertyList();
    }

    /**
     * Create an instance of {@link ModifyObjectsRequest }
     * 
     */
    public ModifyObjectsRequest createModifyObjectsRequest() {
        return new ModifyObjectsRequest();
    }

    /**
     * Create an instance of {@link ObjectsResponse }
     * 
     */
    public ObjectsResponse createObjectsResponse() {
        return new ObjectsResponse();
    }

    /**
     * Create an instance of {@link OutputOptions }
     * 
     */
    public OutputOptions createOutputOptions() {
        return new OutputOptions();
    }

    /**
     * Create an instance of {@link ServiceStatusRequest }
     * 
     */
    public ServiceStatusRequest createServiceStatusRequest() {
        return new ServiceStatusRequest();
    }

    /**
     * Create an instance of {@link ObjectReceipt }
     * 
     */
    public ObjectReceipt createObjectReceipt() {
        return new ObjectReceipt();
    }

    /**
     * Create an instance of {@link Object }
     * 
     */
    public Object createObject() {
        return new Object();
    }

    /**
     * Create an instance of {@link Parameter }
     * 
     */
    public Parameter createParameter() {
        return new Parameter();
    }

    /**
     * Create an instance of {@link ObjectTypeFilter }
     * 
     */
    public ObjectTypeFilter createObjectTypeFilter() {
        return new ObjectTypeFilter();
    }

    /**
     * Create an instance of {@link UpdateObjectTask }
     * 
     */
    public UpdateObjectTask createUpdateObjectTask() {
        return new UpdateObjectTask();
    }

    /**
     * Create an instance of {@link InvokeMethodResponse }
     * 
     */
    public InvokeMethodResponse createInvokeMethodResponse() {
        return new InvokeMethodResponse();
    }

    /**
     * Create an instance of {@link NameRef }
     * 
     */
    public NameRef createNameRef() {
        return new NameRef();
    }

    /**
     * Create an instance of {@link ObjectRefList }
     * 
     */
    public ObjectRefList createObjectRefList() {
        return new ObjectRefList();
    }

    /**
     * Create an instance of {@link ObjectRef }
     * 
     */
    public ObjectRef createObjectRef() {
        return new ObjectRef();
    }

    /**
     * Create an instance of {@link DeleteMethodList }
     * 
     */
    public DeleteMethodList createDeleteMethodList() {
        return new DeleteMethodList();
    }

    /**
     * Create an instance of {@link InvokeMethodRequest }
     * 
     */
    public InvokeMethodRequest createInvokeMethodRequest() {
        return new InvokeMethodRequest();
    }

}
