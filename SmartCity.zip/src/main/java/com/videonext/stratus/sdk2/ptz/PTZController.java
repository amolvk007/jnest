package com.videonext.stratus.sdk2.ptz;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.client.ClientProtocolException;

import com.videonext.stratus.sdk2.session.Session;

public class PTZController {
	private static Session session = Session.getSession();

	public enum ZDirection {
		IN("in"), OUT("out");

		private final String zdirection;

		private ZDirection(String zdirection) {
			this.zdirection = zdirection;
		}

		@Override
		public String toString() {
			return zdirection;
		}
	}

	public enum FDirection {
		NEAR("near"), FAR("far");

		private final String fdirection;

		private FDirection(String fdirection) {
			this.fdirection = fdirection;
		}

		@Override
		public String toString() {
			return fdirection;
		}
	}

	public enum Direction {
		LEFT("left"), RIGHT("right"), UP("up"), DOWN("down"), UPLEFT("upleft"), UPRIGHT(
				"upright"), DOWNLEFT("downleft"), DOWNRIGHT("downright"), STOP(
				"stop");

		private final String direction;

		private Direction(String direction) {
			this.direction = direction;
		}

		@Override
		public String toString() {
			return direction;
		}
	}

	/**
	 * 
	 * @param objid
	 * @param presetid
	 * @throws ClientProtocolException
	 * @throws IOException
	 */
	public static void gotoPreset(int objid, int presetid)
			throws ClientProtocolException, IOException {
		sendPTZCommand(objid, "mode=preset%26goto=" + presetid);
	}

	/**
	 * sets the given preset number, if supported.
	 * @param objid
	 * @param presetid
	 * @throws ClientProtocolException
	 * @throws IOException
	 */
	public static void definePreset(int objid, int presetid)
			throws ClientProtocolException, IOException {
		sendPTZCommand(objid, "mode=preset%26save=" + presetid);
	}

	/** 
	 * unsets the given preset number, if supported.
	 * @param objid
	 * @param presetid
	 * @throws ClientProtocolException
	 * @throws IOException
	 */
	public static void clearPreset(int objid, int presetid)
			throws ClientProtocolException, IOException {
		sendPTZCommand(objid, "mode=preset%26clear=" + presetid);
	}

	/**
	 * 
	 * @param objid
	 * @param direction
	 * @throws ClientProtocolException
	 * @throws IOException
	 */
	public static void stepMove(int objid, Direction direction)
			throws ClientProtocolException, IOException {
		sendPTZCommand(objid, "mode=step%26move=" + direction.toString());
	}

	/**
	 * 
	 * @param objid
	 * @param zdirection in or out
	 * @throws ClientProtocolException
	 * @throws IOException
	 */
	public static void stepZMove(int objid, ZDirection zdirection)
			throws ClientProtocolException, IOException {
		sendPTZCommand(objid, "mode=step%26zoom=" + zdirection.toString());
	}

	/**
	 * 
	 * @param objid
	 * @param fdirection near or far
	 * @throws ClientProtocolException
	 * @throws IOException
	 */
	public static void stepFMove(int objid, FDirection fdirection)
			throws ClientProtocolException, IOException {
		sendPTZCommand(objid, "mode=step%26focus=" + fdirection.toString());
	}

	/**
	 * 
	 * @param objid
	 * @param pan zoom -100 - 100.
	 * @param tilt zoom -100 - 100.
	 * @throws ClientProtocolException
	 * @throws IOException
	 */
	public static void ptMove(int objid, int pan, int tilt)
			throws ClientProtocolException, IOException {
		sendPTZCommand(objid, "mode=speed%26pt=" + pan + "," + tilt);
	}

	/**
	 * 
	 * @param objid
	 * @param zoom -100 - 100.
	 * @throws ClientProtocolException
	 * @throws IOException
	 */
	public static void zoomMove(int objid, int zoom)
			throws ClientProtocolException, IOException {
		sendPTZCommand(objid, "mode=speed%26zoom=" + zoom);
	}

	/**
	 * 
	 * @param objid
	 * @param focus zoom -100 - 100.
	 * @throws ClientProtocolException
	 * @throws IOException
	 */
	public static void focusMove(int objid, int focus)
			throws ClientProtocolException, IOException {
		sendPTZCommand(objid, "mode=speed%26focus=" + focus);
	}

	/**
	 * absolute movement.
	 * @param objid
	 * @param pan 0 - 360
	 * @param tilt -90 - +90. Useable range depends on the camera.
	 * @throws ClientProtocolException
	 * @throws IOException
	 */
	public static void absMove(int objid, int pan, int tilt)
			throws ClientProtocolException, IOException {
		sendPTZCommand(objid, "mode=abs%26pt=" + pan + "," + tilt);
	}

	/**
	 * absolute zoom movement
	 * @param objid
	 * @param zoom 0 - 100
	 * @throws ClientProtocolException
	 * @throws IOException
	 */
	public static void absZMove(int objid, int zoom)
			throws ClientProtocolException, IOException {
		sendPTZCommand(objid, "mode=abs%26z=" + zoom);
	}

	/**
	 * Relative movement.
	 * @param objid
	 * @param pan Allowed values are from -100 to 100. The value of 100 means a 90 degree movement.
	 * @param tilt Allowed values are from -100 to 100. The value of 100 means a 90 degree movement.
	 * @throws ClientProtocolException
	 * @throws IOException
	 */
	public static void relMove(int objid, int pan, int tilt)
			throws ClientProtocolException, IOException {
		pan += 100;
		tilt += 100;
		if(Math.abs(pan) > 200) pan = 200;
		if(Math.abs(tilt) > 200 ) tilt = 200;
		sendPTZCommand(objid, "mode=rel%26size=200x200%26xy=" + pan + "," + tilt);
	}

	private static void sendPTZCommand(int objid, String command)
			throws ClientProtocolException, IOException {
		String url = "/ptz/cgi-bin/send_message.pl";
		String formatUrl = "data=%3CPTZ_Command%3Edo.ptz?dev=" + objid + "%26"
				+ command + "%26priority=9%3C/PTZ_Command%3E";
		List<String> params = new ArrayList<String>();
		params.add(formatUrl);

		session.httpGetCall(url, params, false);
	}

}
