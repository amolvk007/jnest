
package com.videonext.stratus.sdk2.vmx.protocol;

import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for BORDERType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BORDERType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;attribute name="FRAMESHAPE" use="required" type="{http://websvc.videonext.com/protocol}FRAMESHAPEType" />
 *       &lt;attribute name="LINEWIDTH" type="{http://www.w3.org/2001/XMLSchema}nonNegativeInteger" default="0" />
 *       &lt;attribute name="MARGIN" type="{http://www.w3.org/2001/XMLSchema}nonNegativeInteger" default="0" />
 *       &lt;attribute name="MIDLINEWIDTH" type="{http://www.w3.org/2001/XMLSchema}nonNegativeInteger" default="0" />
 *       &lt;attribute name="SHADOWSTYLE" default="Plain">
 *         &lt;simpleType>
 *           &lt;restriction base="{http://websvc.videonext.com/protocol}SHADOWSTYLEType">
 *           &lt;/restriction>
 *         &lt;/simpleType>
 *       &lt;/attribute>
 *       &lt;attribute name="COLOR" type="{http://www.w3.org/2001/XMLSchema}int" default="0" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BORDERType")
public class BORDERType {

    @XmlAttribute(name = "FRAMESHAPE", required = true)
    protected FRAMESHAPEType frameshape;
    @XmlAttribute(name = "LINEWIDTH")
    @XmlSchemaType(name = "nonNegativeInteger")
    protected BigInteger linewidth;
    @XmlAttribute(name = "MARGIN")
    @XmlSchemaType(name = "nonNegativeInteger")
    protected BigInteger margin;
    @XmlAttribute(name = "MIDLINEWIDTH")
    @XmlSchemaType(name = "nonNegativeInteger")
    protected BigInteger midlinewidth;
    @XmlAttribute(name = "SHADOWSTYLE")
    protected SHADOWSTYLEType shadowstyle;
    @XmlAttribute(name = "COLOR")
    protected Integer color;

    /**
     * Gets the value of the frameshape property.
     * 
     * @return
     *     possible object is
     *     {@link FRAMESHAPEType }
     *     
     */
    public FRAMESHAPEType getFRAMESHAPE() {
        return frameshape;
    }

    /**
     * Sets the value of the frameshape property.
     * 
     * @param value
     *     allowed object is
     *     {@link FRAMESHAPEType }
     *     
     */
    public void setFRAMESHAPE(FRAMESHAPEType value) {
        this.frameshape = value;
    }

    /**
     * Gets the value of the linewidth property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getLINEWIDTH() {
        if (linewidth == null) {
            return new BigInteger("0");
        } else {
            return linewidth;
        }
    }

    /**
     * Sets the value of the linewidth property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setLINEWIDTH(BigInteger value) {
        this.linewidth = value;
    }

    /**
     * Gets the value of the margin property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getMARGIN() {
        if (margin == null) {
            return new BigInteger("0");
        } else {
            return margin;
        }
    }

    /**
     * Sets the value of the margin property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setMARGIN(BigInteger value) {
        this.margin = value;
    }

    /**
     * Gets the value of the midlinewidth property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getMIDLINEWIDTH() {
        if (midlinewidth == null) {
            return new BigInteger("0");
        } else {
            return midlinewidth;
        }
    }

    /**
     * Sets the value of the midlinewidth property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setMIDLINEWIDTH(BigInteger value) {
        this.midlinewidth = value;
    }

    /**
     * Gets the value of the shadowstyle property.
     * 
     * @return
     *     possible object is
     *     {@link SHADOWSTYLEType }
     *     
     */
    public SHADOWSTYLEType getSHADOWSTYLE() {
        if (shadowstyle == null) {
            return SHADOWSTYLEType.PLAIN;
        } else {
            return shadowstyle;
        }
    }

    /**
     * Sets the value of the shadowstyle property.
     * 
     * @param value
     *     allowed object is
     *     {@link SHADOWSTYLEType }
     *     
     */
    public void setSHADOWSTYLE(SHADOWSTYLEType value) {
        this.shadowstyle = value;
    }

    /**
     * Gets the value of the color property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public int getCOLOR() {
        if (color == null) {
            return  0;
        } else {
            return color;
        }
    }

    /**
     * Sets the value of the color property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setCOLOR(Integer value) {
        this.color = value;
    }

}
