
package com.videonext.stratus.sdk2.vmx.protocol;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ctrl_cellType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ctrl_cellType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;attribute name="id" use="required" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="scale" use="required" type="{http://websvc.videonext.com/protocol}scaleType" />
 *       &lt;attribute name="state" use="required" type="{http://websvc.videonext.com/protocol}stateType" />
 *       &lt;attribute name="monitorID" use="required" type="{http://www.w3.org/2001/XMLSchema}unsignedInt" />
 *       &lt;attribute name="show_text" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="volume" type="{http://www.w3.org/2001/XMLSchema}int" default="-1" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ctrl_cellType")
public class CtrlCellType {

    @XmlAttribute(name = "id", required = true)
    protected String id;
    @XmlAttribute(name = "scale", required = true)
    protected ScaleType scale;
    @XmlAttribute(name = "state", required = true)
    protected StateType state;
    @XmlAttribute(name = "monitorID", required = true)
    @XmlSchemaType(name = "unsignedInt")
    protected long monitorID;
    @XmlAttribute(name = "show_text")
    protected String showText;
    @XmlAttribute(name = "volume")
    protected Integer volume;

    /**
     * Gets the value of the id property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setId(String value) {
        this.id = value;
    }

    /**
     * Gets the value of the scale property.
     * 
     * @return
     *     possible object is
     *     {@link ScaleType }
     *     
     */
    public ScaleType getScale() {
        return scale;
    }

    /**
     * Sets the value of the scale property.
     * 
     * @param value
     *     allowed object is
     *     {@link ScaleType }
     *     
     */
    public void setScale(ScaleType value) {
        this.scale = value;
    }

    /**
     * Gets the value of the state property.
     * 
     * @return
     *     possible object is
     *     {@link StateType }
     *     
     */
    public StateType getState() {
        return state;
    }

    /**
     * Sets the value of the state property.
     * 
     * @param value
     *     allowed object is
     *     {@link StateType }
     *     
     */
    public void setState(StateType value) {
        this.state = value;
    }

    /**
     * Gets the value of the monitorID property.
     * 
     */
    public long getMonitorID() {
        return monitorID;
    }

    /**
     * Sets the value of the monitorID property.
     * 
     */
    public void setMonitorID(long value) {
        this.monitorID = value;
    }

    /**
     * Gets the value of the showText property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getShowText() {
        return showText;
    }

    /**
     * Sets the value of the showText property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setShowText(String value) {
        this.showText = value;
    }

    /**
     * Gets the value of the volume property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public int getVolume() {
        if (volume == null) {
            return -1;
        } else {
            return volume;
        }
    }

    /**
     * Sets the value of the volume property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setVolume(Integer value) {
        this.volume = value;
    }

}
