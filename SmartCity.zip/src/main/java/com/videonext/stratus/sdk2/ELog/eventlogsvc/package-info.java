/**
 * 
 * 		This file contains definitions of Web services to log events
 * 	
 * 
 */
package com.videonext.stratus.sdk2.ELog.eventlogsvc;
