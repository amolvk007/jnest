
package com.videonext.stratus.sdk2.vmx.protocol;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;



/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.videonext.websvc.protocol package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {
    private final static QName _DSP_QNAME = new QName("http://websvc.videonext.com/protocol", "DSP");
    private final static QName _ObjectID_QNAME = new QName("http://websvc.videonext.com/protocol", "ObjectID");
    private final static QName _Wall_QNAME = new QName("http://websvc.videonext.com/protocol", "wall");
    private final static QName _ObjectIDIn_QNAME = new QName("http://websvc.videonext.com/protocol", "ObjectID_in");
    private final static QName _MonitorInfo_QNAME = new QName("http://websvc.videonext.com/protocol", "monitor_info");
    private final static QName _APPEARANCE_QNAME = new QName("http://websvc.videonext.com/protocol", "APPEARANCE");
    private final static QName _GetWallsIn_QNAME = new QName("http://websvc.videonext.com/protocol", "GetWalls_in");
    private final static QName _GetMonitorListIn_QNAME = new QName("http://websvc.videonext.com/protocol", "GetMonitorList_in");
    private final static QName _GetLayoutListIn_QNAME = new QName("http://websvc.videonext.com/protocol", "GetLayoutList_in");
    private final static QName _ResourcesFilter_QNAME = new QName("http://websvc.videonext.com/protocol", "ResourcesFilter");
    private final static QName _ErrorMessage_QNAME = new QName("http://websvc.videonext.com/protocol", "ErrorMessage");
    private final static QName _Touring_QNAME = new QName("http://websvc.videonext.com/protocol", "Touring");
    private final static QName _Priority_QNAME = new QName("http://websvc.videonext.com/protocol", "Priority");
    private final static QName _SessionID_QNAME = new QName("http://websvc.videonext.com/protocol", "SessionID");
    private final static QName _Screenshot_QNAME = new QName("http://websvc.videonext.com/protocol", "Screenshot");
    private final static QName _RecallLayoutIn_QNAME = new QName("http://websvc.videonext.com/protocol", "RecallLayout_in");
    private final static QName _Cell_QNAME = new QName("http://websvc.videonext.com/protocol", "cell");
    private final static QName _DSPListOut_QNAME = new QName("http://websvc.videonext.com/protocol", "DSPList_out");
    private final static QName _GetAudioDevicesIn_QNAME = new QName("http://websvc.videonext.com/protocol", "GetAudioDevices_in");
    private final static QName _APCInfo_QNAME = new QName("http://websvc.videonext.com/protocol", "APCInfo");
    private final static QName _WallList_QNAME = new QName("http://websvc.videonext.com/protocol", "Wall_List");
    private final static QName _DeleteLayoutIn_QNAME = new QName("http://websvc.videonext.com/protocol", "DeleteLayout_in");
    private final static QName _GetScreenshotIn_QNAME = new QName("http://websvc.videonext.com/protocol", "GetScreenshot_in");
    private final static QName _ReadLayoutIn_QNAME = new QName("http://websvc.videonext.com/protocol", "ReadLayout_in");
    private final static QName _MonitorStateID_QNAME = new QName("http://websvc.videonext.com/protocol", "MonitorStateID");
    private final static QName _KeyValueList_QNAME = new QName("http://websvc.videonext.com/protocol", "KeyValueList");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.videonext.websvc.protocol
     * 
     */
    public ObjectFactory() {
    	
    }

    /**
     * Create an instance of {@link SplitInfo }
     * 
     */
    public SplitInfo createSplitInfo() {
        return new SplitInfo();
    }

    /**
     * Create an instance of {@link CellmatrixType }
     * 
     */
    public CellmatrixType createCellmatrixType() {
        return new CellmatrixType();
    }

    /**
     * Create an instance of {@link CellType }
     * 
     */
    public CellType createCellType() {
        return new CellType();
    }

    /**
     * Create an instance of {@link AppearanceType }
     * 
     */
    public AppearanceType createAppearanceType() {
        return new AppearanceType();
    }

    /**
     * Create an instance of {@link CellPriorityType }
     * 
     */
    public CellPriorityType createCellPriorityType() {
        return new CellPriorityType();
    }

    /**
     * Create an instance of {@link SetAPCIn }
     * 
     */
    public SetAPCIn createSetAPCIn() {
        return new SetAPCIn();
    }

    /**
     * Create an instance of {@link APCInfoType }
     * 
     */
    public APCInfoType createAPCInfoType() {
        return new APCInfoType();
    }

    /**
     * Create an instance of {@link ObjectIdRequest }
     * 
     */
    public ObjectIdRequest createObjectIdRequest() {
        return new ObjectIdRequest();
    }

    /**
     * Create an instance of {@link SessionIDOut }
     * 
     */
    public SessionIDOut createSessionIDOut() {
        return new SessionIDOut();
    }

    /**
     * Create an instance of {@link KeyValueListType }
     * 
     */
    public KeyValueListType createKeyValueListType() {
        return new KeyValueListType();
    }

    /**
     * Create an instance of {@link CheckCredentialsIn }
     * 
     */
    public CheckCredentialsIn createCheckCredentialsIn() {
        return new CheckCredentialsIn();
    }

    /**
     * Create an instance of {@link ResourcesRequest }
     * 
     */
    public ResourcesRequest createResourcesRequest() {
        return new ResourcesRequest();
    }

    /**
     * Create an instance of {@link ResourcesFilterType }
     * 
     */
    public ResourcesFilterType createResourcesFilterType() {
        return new ResourcesFilterType();
    }

    /**
     * Create an instance of {@link LayoutIn }
     * 
     */
    public LayoutIn createLayoutIn() {
        return new LayoutIn();
    }

    /**
     * Create an instance of {@link WallType }
     * 
     */
    public WallType createWallType() {
        return new WallType();
    }

    /**
     * Create an instance of {@link WallListType }
     * 
     */
    public WallListType createWallListType() {
        return new WallListType();
    }

    /**
     * Create an instance of {@link WallStateIn }
     * 
     */
    public WallStateIn createWallStateIn() {
        return new WallStateIn();
    }

    /**
     * Create an instance of {@link DSPListType }
     * 
     */
    public DSPListType createDSPListType() {
        return new DSPListType();
    }

    /**
     * Create an instance of {@link DSPListIn }
     * 
     */
    public DSPListIn createDSPListIn() {
        return new DSPListIn();
    }

    /**
     * Create an instance of {@link DSPType }
     * 
     */
    public DSPType createDSPType() {
        return new DSPType();
    }

    /**
     * Create an instance of {@link MonitorStateIn }
     * 
     */
    public MonitorStateIn createMonitorStateIn() {
        return new MonitorStateIn();
    }

    /**
     * Create an instance of {@link SetPriorityIn }
     * 
     */
    public SetPriorityIn createSetPriorityIn() {
        return new SetPriorityIn();
    }

    /**
     * Create an instance of {@link SessionAttrIn }
     * 
     */
    public SessionAttrIn createSessionAttrIn() {
        return new SessionAttrIn();
    }

    /**
     * Create an instance of {@link ObjectAttrsIn }
     * 
     */
    public ObjectAttrsIn createObjectAttrsIn() {
        return new ObjectAttrsIn();
    }

    /**
     * Create an instance of {@link MonitorStateOut }
     * 
     */
    public MonitorStateOut createMonitorStateOut() {
        return new MonitorStateOut();
    }

    /**
     * Create an instance of {@link MonitorInfoType }
     * 
     */
    public MonitorInfoType createMonitorInfoType() {
        return new MonitorInfoType();
    }

    /**
     * Create an instance of {@link AssignInfo }
     * 
     */
    public AssignInfo createAssignInfo() {
        return new AssignInfo();
    }

    /**
     * Create an instance of {@link AssignedCellType }
     * 
     */
    public AssignedCellType createAssignedCellType() {
        return new AssignedCellType();
    }

    /**
     * Create an instance of {@link ObjectInfoListOut }
     * 
     */
    public ObjectInfoListOut createObjectInfoListOut() {
        return new ObjectInfoListOut();
    }

    /**
     * Create an instance of {@link ObjInfoType }
     * 
     */
    public ObjInfoType createObjInfoType() {
        return new ObjInfoType();
    }

    /**
     * Create an instance of {@link TouringType }
     * 
     */
    public TouringType createTouringType() {
        return new TouringType();
    }

    /**
     * Create an instance of {@link BooleanOut }
     * 
     */
    public BooleanOut createBooleanOut() {
        return new BooleanOut();
    }

    /**
     * Create an instance of {@link CellControlIn }
     * 
     */
    public CellControlIn createCellControlIn() {
        return new CellControlIn();
    }

    /**
     * Create an instance of {@link CtrlCellType }
     * 
     */
    public CtrlCellType createCtrlCellType() {
        return new CtrlCellType();
    }

    /**
     * Create an instance of {@link LoginInfo }
     * 
     */
    public LoginInfo createLoginInfo() {
        return new LoginInfo();
    }

    /**
     * Create an instance of {@link ObjectIDOut }
     * 
     */
    public ObjectIDOut createObjectIDOut() {
        return new ObjectIDOut();
    }

    /**
     * Create an instance of {@link WallStateOut }
     * 
     */
    public WallStateOut createWallStateOut() {
        return new WallStateOut();
    }

    /**
     * Create an instance of {@link WallCellType }
     * 
     */
    public WallCellType createWallCellType() {
        return new WallCellType();
    }

    /**
     * Create an instance of {@link BORDERType }
     * 
     */
    public BORDERType createBORDERType() {
        return new BORDERType();
    }

    /**
     * Create an instance of {@link KeyValType }
     * 
     */
    public KeyValType createKeyValType() {
        return new KeyValType();
    }

    /**
     * Create an instance of {@link HEADERType }
     * 
     */
    public HEADERType createHEADERType() {
        return new HEADERType();
    }

    /**
     * Create an instance of {@link TOURSOURCEType }
     * 
     */
    public TOURSOURCEType createTOURSOURCEType() {
        return new TOURSOURCEType();
    }

    /**
     * Create an instance of {@link FONTType }
     * 
     */
    public FONTType createFONTType() {
        return new FONTType();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DSPType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://websvc.videonext.com/protocol", name = "DSP")
    public JAXBElement<DSPType> createDSP(DSPType value) {
        return new JAXBElement<DSPType>(_DSP_QNAME, DSPType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://websvc.videonext.com/protocol", name = "ObjectID")
    public JAXBElement<Long> createObjectID(Long value) {
        return new JAXBElement<Long>(_ObjectID_QNAME, Long.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link WallType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://websvc.videonext.com/protocol", name = "wall")
    public JAXBElement<WallType> createWall(WallType value) {
        return new JAXBElement<WallType>(_Wall_QNAME, WallType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ObjectIdRequest }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://websvc.videonext.com/protocol", name = "ObjectID_in")
    public JAXBElement<ObjectIdRequest> createObjectIDIn(ObjectIdRequest value) {
        return new JAXBElement<ObjectIdRequest>(_ObjectIDIn_QNAME, ObjectIdRequest.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MonitorInfoType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://websvc.videonext.com/protocol", name = "monitor_info")
    public JAXBElement<MonitorInfoType> createMonitorInfo(MonitorInfoType value) {
        return new JAXBElement<MonitorInfoType>(_MonitorInfo_QNAME, MonitorInfoType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AppearanceType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://websvc.videonext.com/protocol", name = "APPEARANCE")
    public JAXBElement<AppearanceType> createAPPEARANCE(AppearanceType value) {
        return new JAXBElement<AppearanceType>(_APPEARANCE_QNAME, AppearanceType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://websvc.videonext.com/protocol", name = "GetWalls_in")
    public JAXBElement<String> createGetWallsIn(String value) {
        return new JAXBElement<String>(_GetWallsIn_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://websvc.videonext.com/protocol", name = "GetMonitorList_in")
    public JAXBElement<String> createGetMonitorListIn(String value) {
        return new JAXBElement<String>(_GetMonitorListIn_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ObjectIdRequest }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://websvc.videonext.com/protocol", name = "GetLayoutList_in")
    public JAXBElement<ObjectIdRequest> createGetLayoutListIn(ObjectIdRequest value) {
        return new JAXBElement<ObjectIdRequest>(_GetLayoutListIn_QNAME, ObjectIdRequest.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ResourcesFilterType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://websvc.videonext.com/protocol", name = "ResourcesFilter")
    public JAXBElement<ResourcesFilterType> createResourcesFilter(ResourcesFilterType value) {
        return new JAXBElement<ResourcesFilterType>(_ResourcesFilter_QNAME, ResourcesFilterType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://websvc.videonext.com/protocol", name = "ErrorMessage")
    public JAXBElement<String> createErrorMessage(String value) {
        return new JAXBElement<String>(_ErrorMessage_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TouringType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://websvc.videonext.com/protocol", name = "Touring")
    public JAXBElement<TouringType> createTouring(TouringType value) {
        return new JAXBElement<TouringType>(_Touring_QNAME, TouringType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CellPriorityType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://websvc.videonext.com/protocol", name = "Priority")
    public JAXBElement<CellPriorityType> createPriority(CellPriorityType value) {
        return new JAXBElement<CellPriorityType>(_Priority_QNAME, CellPriorityType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://websvc.videonext.com/protocol", name = "SessionID")
    public JAXBElement<String> createSessionID(String value) {
        return new JAXBElement<String>(_SessionID_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link byte[]}{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://websvc.videonext.com/protocol", name = "Screenshot")
    public JAXBElement<byte[]> createScreenshot(byte[] value) {
        return new JAXBElement<byte[]>(_Screenshot_QNAME, byte[].class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ObjectIdRequest }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://websvc.videonext.com/protocol", name = "RecallLayout_in")
    public JAXBElement<ObjectIdRequest> createRecallLayoutIn(ObjectIdRequest value) {
        return new JAXBElement<ObjectIdRequest>(_RecallLayoutIn_QNAME, ObjectIdRequest.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CellType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://websvc.videonext.com/protocol", name = "cell")
    public JAXBElement<CellType> createCell(CellType value) {
        return new JAXBElement<CellType>(_Cell_QNAME, CellType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DSPListType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://websvc.videonext.com/protocol", name = "DSPList_out")
    public JAXBElement<DSPListType> createDSPListOut(DSPListType value) {
        return new JAXBElement<DSPListType>(_DSPListOut_QNAME, DSPListType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://websvc.videonext.com/protocol", name = "GetAudioDevices_in")
    public JAXBElement<String> createGetAudioDevicesIn(String value) {
        return new JAXBElement<String>(_GetAudioDevicesIn_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link APCInfoType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://websvc.videonext.com/protocol", name = "APCInfo")
    public JAXBElement<APCInfoType> createAPCInfo(APCInfoType value) {
        return new JAXBElement<APCInfoType>(_APCInfo_QNAME, APCInfoType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link WallListType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://websvc.videonext.com/protocol", name = "Wall_List")
    public JAXBElement<WallListType> createWallList(WallListType value) {
        return new JAXBElement<WallListType>(_WallList_QNAME, WallListType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ObjectIdRequest }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://websvc.videonext.com/protocol", name = "DeleteLayout_in")
    public JAXBElement<ObjectIdRequest> createDeleteLayoutIn(ObjectIdRequest value) {
        return new JAXBElement<ObjectIdRequest>(_DeleteLayoutIn_QNAME, ObjectIdRequest.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ObjectIdRequest }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://websvc.videonext.com/protocol", name = "GetScreenshot_in")
    public JAXBElement<ObjectIdRequest> createGetScreenshotIn(ObjectIdRequest value) {
        return new JAXBElement<ObjectIdRequest>(_GetScreenshotIn_QNAME, ObjectIdRequest.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ObjectIdRequest }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://websvc.videonext.com/protocol", name = "ReadLayout_in")
    public JAXBElement<ObjectIdRequest> createReadLayoutIn(ObjectIdRequest value) {
        return new JAXBElement<ObjectIdRequest>(_ReadLayoutIn_QNAME, ObjectIdRequest.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://websvc.videonext.com/protocol", name = "MonitorStateID")
    public JAXBElement<Long> createMonitorStateID(Long value) {
        return new JAXBElement<Long>(_MonitorStateID_QNAME, Long.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link KeyValueListType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://websvc.videonext.com/protocol", name = "KeyValueList")
    public JAXBElement<KeyValueListType> createKeyValueList(KeyValueListType value) {
        return new JAXBElement<KeyValueListType>(_KeyValueList_QNAME, KeyValueListType.class, null, value);
    }

}
