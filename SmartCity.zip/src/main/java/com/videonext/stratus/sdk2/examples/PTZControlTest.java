package com.videonext.stratus.sdk2.examples;

import java.io.IOException;
import java.util.logging.Level;

import org.apache.http.client.ClientProtocolException;
import org.json.JSONException;

import com.videonext.stratus.sdk2.session.Session;
import com.videonext.stratus.sdk2.ptz.PTZController;
import com.videonext.stratus.sdk2.ptz.PTZController.ZDirection;

public class PTZControlTest {

	/**
	 * @param args
	 * @throws JSONException
	 * @throws IOException
	 * @throws IllegalStateException
	 * @throws ClientProtocolException
	 * @throws InterruptedException
	 */
	public static void main(String[] args) throws ClientProtocolException,
			IllegalStateException, IOException, JSONException,
			InterruptedException {
		Session session = Session.getSession();

		session.setTrustAll(true);
		session.setLogger(Level.INFO);
		session.openSession("demo-10.videonext.com", "admin", "topse", "https");

		PTZController.stepZMove(125, ZDirection.IN);
	}

}
