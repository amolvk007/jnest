
package com.videonext.stratus.sdk2.ELog.eventlogsvc.protocol;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ACTIONRESPONSEType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ACTIONRESPONSEType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;all>
 *         &lt;element name="ACTIONSTATUS" type="{http://eventlogsvc.videonext.com/protocol}ACTIONSTATUSType"/>
 *       &lt;/all>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ACTIONRESPONSEType", propOrder = {

})
public class ACTIONRESPONSEType {

    @XmlElement(name = "ACTIONSTATUS", required = true)
    protected ACTIONSTATUSType actionstatus;

    /**
     * Gets the value of the actionstatus property.
     * 
     * @return
     *     possible object is
     *     {@link ACTIONSTATUSType }
     *     
     */
    public ACTIONSTATUSType getACTIONSTATUS() {
        return actionstatus;
    }

    /**
     * Sets the value of the actionstatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link ACTIONSTATUSType }
     *     
     */
    public void setACTIONSTATUS(ACTIONSTATUSType value) {
        this.actionstatus = value;
    }

}
