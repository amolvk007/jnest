package com.videonext.stratus.sdk2.objectmanagement;

import com.videonext.stratus.sdk2.ELog.SSLUtilities;
import com.videonext.stratus.sdk2.objectmanagement.websvc.ObjectManagementPortType;
import com.videonext.stratus.sdk2.objectmanagement.websvc.ObjectManagementService;
import com.videonext.stratus.sdk2.objectmanagement.websvc.types.ObjectsRequest;
import com.videonext.stratus.sdk2.objectmanagement.websvc.types.ObjectsResponse;
import com.videonext.stratus.sdk2.session.Session;

import javax.xml.namespace.QName;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.Service;
import javax.xml.ws.handler.MessageContext;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public class OMServiceRequestor {
    private static final Session session = Session.getSession();
    private static final QName qOM = new QName(
            "http://skm.videonext.com/om/websvc", "ObjectManagementService");
    private static final QName omPort = new QName(
            "http://skm.videonext.com/om/websvc", "ObjectManagementPort");


    /**
     * Gets the current state of objects matching the objectsRequest provided.
     * @param objectsRequest incoming request, with filters
     * @return ObjectResponse containing the information for all objects that match the provided filter
     * @throws MalformedURLException
     */
    public static ObjectsResponse getObjects(ObjectsRequest objectsRequest) throws MalformedURLException{

        SSLUtilities.trustAllHttpsCertificates();
        SSLUtilities.trustAllHostnames();

        Service service = ObjectManagementService.create(
                new URL("http://" + session.getMasterHost()
                        + "/cxf/webservices/ObjectManagementService?wsdl"), qOM);
        ObjectManagementPortType port = service.getPort(omPort, ObjectManagementPortType.class);
        List<String> headers = new ArrayList<String>();
        headers.add("PHPSESSID=" + session.getSessionId());
        headers.add("token=" + session.getTokenId());
        ((BindingProvider) port).getRequestContext().put(
                MessageContext.HTTP_REQUEST_HEADERS,
                Collections.singletonMap("Cookie", headers));

        return port.getObjects(objectsRequest);

    }

    /*
    public static ServiceStatusResponse getServiceStatus(ServiceStatusRequest serviceStatusRequest) throws MalformedURLException{
        Service service = ObjectManagementService.create(
                new URL("http://" + session.getMasterHost()
                        + "/cxf/webservices/ObjectManagementService?wsdl"), qOM);
        ObjectManagementPortType port = service.getPort(omPort, ObjectManagementPortType.class);
        List<String> headers = new ArrayList<String>();
        headers.add("PHPSESSID=" + session.getSessionId());
        headers.add("token=" + session.getTokenId());
        ((BindingProvider) port).getRequestContext().put(
                MessageContext.HTTP_REQUEST_HEADERS,
                Collections.singletonMap("Cookie", headers));

        return port.getServiceStatus(serviceStatusRequest);
    }
    */
}
