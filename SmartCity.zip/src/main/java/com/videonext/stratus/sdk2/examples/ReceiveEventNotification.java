package com.videonext.stratus.sdk2.examples;

import com.videonext.skm.fw.servicing.*;
import com.videonext.skm.elog.iface.*;
import com.videonext.stratus.sdk2.session.Session;
import com.videonext.stratus.sdk2.system.ServerTimeRequestor;
import com.videonext.stratus.sdk2.system.SystemStatusRequestor;
import com.videonext.stratus.sdk2.system.VersionRequestor;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;


public class ReceiveEventNotification {
	
	public static void main(String[] args) {
		Session session = Session.getSession();

		// Do not use this in a production environment. It sets the
		// application to accept any ssl-cert, defeating the purpose of
		// using ssl.
		session.setTrustAll(true);
        try {
            session.openSession("vtm.videonext.com", "mogale", "Videonext123!", "http");
        } catch (Exception e) {
            ;
        }

		NotificationListener notificationListener = new NotificationListener(session.getMasterHost());
		try {
			notificationListener.processNotifications(
					"skm.eventlog.notifications",
					new ELogNotification.Processor(new NotificationReceiver()),
					new StateListener(),
					session.getSessionId());
			
			Thread.sleep(5*60*1000); // wait 5 min
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		notificationListener.close();
	}


	protected static class NotificationReceiver implements ELogNotification.Iface {
		public void eventNotification(Event event) {
			
			String type = (event.eventtype == 0) ? "info" : "alert";
			String objName = (event.obj != null) ? event.obj.name : "";			
			int tsFrom = event.utc.from, tsWhen = event.utc.when, tsTo = event.utc.to;
			
			if (event.witnesses != null && !event.witnesses.isEmpty()) {
				// loop through witnesses list
			}
			
			if (event.properties != null && !event.properties.isEmpty()) {
				// loop through properties map
			}
			
			System.out.println(
				String.format("%d : type=%s msg=%s note=%s source=%d priority=%d lifespan=%d objid=%d(%s) [from=%d, when=%d to=%d]",
					event.id,
					type,
					event.msg,
					event.note,
					event.sourceId,
					event.priority,
					event.lifespan,
					event.objId,
					objName,
					tsFrom, tsWhen, tsTo
					)
				);
		}
	}
	
	protected static class StateListener implements NotificationListener.TransportStateListener {
		public void onConnect() { System.out.println("#Connected"); }
		public void onDisconnect(String reason) { System.out.println("#Disconnected: " + reason);}
	}
}
