
package com.videonext.stratus.sdk2.vmx.protocol;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for WallCellType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="WallCellType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="row" type="{http://www.w3.org/2001/XMLSchema}unsignedByte"/>
 *         &lt;element name="col" type="{http://www.w3.org/2001/XMLSchema}unsignedByte"/>
 *         &lt;element name="monid" type="{http://www.w3.org/2001/XMLSchema}unsignedInt"/>
 *         &lt;element ref="{http://websvc.videonext.com/protocol}monitor_info" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "WallCellType", propOrder = {
    "row",
    "col",
    "monid",
    "monitorInfo"
})
public class WallCellType {

    @XmlSchemaType(name = "unsignedByte")
    protected short row;
    @XmlSchemaType(name = "unsignedByte")
    protected short col;
    @XmlSchemaType(name = "unsignedInt")
    protected long monid;
    @XmlElement(name = "monitor_info")
    protected MonitorInfoType monitorInfo;

    /**
     * Gets the value of the row property.
     * 
     */
    public short getRow() {
        return row;
    }

    /**
     * Sets the value of the row property.
     * 
     */
    public void setRow(short value) {
        this.row = value;
    }

    /**
     * Gets the value of the col property.
     * 
     */
    public short getCol() {
        return col;
    }

    /**
     * Sets the value of the col property.
     * 
     */
    public void setCol(short value) {
        this.col = value;
    }

    /**
     * Gets the value of the monid property.
     * 
     */
    public long getMonid() {
        return monid;
    }

    /**
     * Sets the value of the monid property.
     * 
     */
    public void setMonid(long value) {
        this.monid = value;
    }

    /**
     * Gets the value of the monitorInfo property.
     * 
     * @return
     *     possible object is
     *     {@link MonitorInfoType }
     *     
     */
    public MonitorInfoType getMonitorInfo() {
        return monitorInfo;
    }

    /**
     * Sets the value of the monitorInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link MonitorInfoType }
     *     
     */
    public void setMonitorInfo(MonitorInfoType value) {
        this.monitorInfo = value;
    }

}
