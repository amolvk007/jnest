package com.videonext.stratus.sdk2.examples;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.json.JSONException;
import org.json.JSONObject;

import com.videonext.stratus.sdk2.session.Session;

public class cameraProbeTest {

	/**
	 * @param args
	 * @throws JSONException 
	 * @throws IOException 
	 * @throws IllegalStateException 
	 * @throws ClientProtocolException 
	 */
	public static void main(String[] args) throws ClientProtocolException, IllegalStateException, IOException, JSONException {
		Session session = Session.getSession();
		session.openSession("demo-16.videonext.com", "admin", "topse");
		
		
		List<String> params = new ArrayList<String>();
		params.add("function=getCameraModel");
		params.add("ip=207.207.160.45");
		params.add("port=80");
		params.add("user=root");
		params.add("password=pass");
		params.add("model=Axis");
		HttpResponse response = session.httpGetCall("/sdi/admincirrus/call.php", params);
		
		System.out.println(response.toString());
		
		try{
			JSONObject json = session.readJSONResponse(response);
			System.out.println(json.toString());
		}catch (Exception e){

		}
		
	}

}
