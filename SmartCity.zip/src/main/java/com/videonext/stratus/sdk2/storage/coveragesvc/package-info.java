@javax.xml.bind.annotation.XmlSchema(namespace = "coveragesvc.videonext.com", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.videonext.stratus.sdk2.storage.coveragesvc;
