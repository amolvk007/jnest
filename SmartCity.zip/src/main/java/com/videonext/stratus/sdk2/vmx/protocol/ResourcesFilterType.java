
package com.videonext.stratus.sdk2.vmx.protocol;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ResourcesFilterType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ResourcesFilterType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;attribute name="ObjectType" type="{http://www.w3.org/2001/XMLSchema}string" default="None" />
 *       &lt;attribute name="ObjectSubType" type="{http://www.w3.org/2001/XMLSchema}string" default="" />
 *       &lt;attribute name="NodeID" type="{http://www.w3.org/2001/XMLSchema}int" default="-1" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ResourcesFilterType")
public class ResourcesFilterType {

    @XmlAttribute(name = "ObjectType")
    protected String objectType;
    @XmlAttribute(name = "ObjectSubType")
    protected String objectSubType;
    @XmlAttribute(name = "NodeID")
    protected Integer nodeID;

    /**
     * Gets the value of the objectType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getObjectType() {
        if (objectType == null) {
            return "None";
        } else {
            return objectType;
        }
    }

    /**
     * Sets the value of the objectType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setObjectType(String value) {
        this.objectType = value;
    }

    /**
     * Gets the value of the objectSubType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getObjectSubType() {
        if (objectSubType == null) {
            return "";
        } else {
            return objectSubType;
        }
    }

    /**
     * Sets the value of the objectSubType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setObjectSubType(String value) {
        this.objectSubType = value;
    }

    /**
     * Gets the value of the nodeID property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public int getNodeID() {
        if (nodeID == null) {
            return -1;
        } else {
            return nodeID;
        }
    }

    /**
     * Sets the value of the nodeID property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setNodeID(Integer value) {
        this.nodeID = value;
    }

}
