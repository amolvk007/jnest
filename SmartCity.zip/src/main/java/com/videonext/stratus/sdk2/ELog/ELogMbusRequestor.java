package com.videonext.stratus.sdk2.ELog;

import java.util.Hashtable;
import java.util.Map;

import com.videonext.skm.elog.iface.ELog;
import com.videonext.skm.elog.iface.Eventtype;
import com.videonext.skm.elog.iface.Lifespan;
import com.videonext.skm.elog.iface.Priority;
import com.videonext.skm.fw.iface.Action;
import com.videonext.skm.fw.iface.ActionResponse;
import com.videonext.skm.fw.servicing.Client;
import com.videonext.stratus.sdk2.session.Session;

public class ELogMbusRequestor {
	private static final Session session = Session.getSession();

	public static class ELogEvent {
		private int objid;
		private String msg;

		private Long whenTime, toTime, fromTime;
		private EventPriority priority = EventPriority.MEDIUM;
		private EventLifespan lifespan = EventLifespan.MODERATE;
		private EventSource source = EventSource.USER;
		private EventType eventtype = EventType.ALERT;

		public ELogEvent(int objid, String message) {
			this.objid = objid;
			this.msg = message;
		}

		public Map<String, String> toParameter() {
			Map<String, String> parameters = new Hashtable<String, String>();

			// required parameters
			parameters.put("objid", String.valueOf(objid));
			parameters.put("source", source.toString());
			parameters.put("msg", msg);

			// optional parameters;
			if (whenTime != null)
				parameters.put("when", String.valueOf(whenTime));
			parameters.put("priority", priority.toString());
			parameters.put("lifespan", lifespan.toString());
			parameters.put("eventtype", eventtype.toString());

			return parameters;
		}

		public String getMsg() {
			return msg;
		}

		public void setMsg(String msg) {
			this.msg = msg;
		}

		public int getObjid() {
			return objid;
		}

		public void setObjid(int objid) {
			this.objid = objid;
		}

		public long getWhenTime() {
			return whenTime;
		}

		public void setWhenTime(long whenTime) {
			this.whenTime = whenTime;
		}

		public long getToTime() {
			return toTime;
		}

		public void setToTime(long toTime) {
			this.toTime = toTime;
		}

		public long getFromTime() {
			return fromTime;
		}

		public void setFromTime(long fromTime) {
			this.fromTime = fromTime;
		}

		public EventPriority getPriority() {
			return priority;
		}

		public void setPriority(EventPriority priority) {
			this.priority = priority;
		}

		public EventLifespan getLifespan() {
			return lifespan;
		}

		public void setLifespan(EventLifespan lifespan) {
			this.lifespan = lifespan;
		}

		public EventType getEventtype() {
			return eventtype;
		}

		public void setEventtype(EventType eventtype) {
			this.eventtype = eventtype;
		}

		public EventSource getEventSource() {
			return source;
		}

		public void setEventSource(EventSource source) {
			this.source = source;
		}

	}

	public enum EventType {
		INFO(Eventtype.INFO), ALERT(Eventtype.ALERT);
		private final int mask;

		private EventType(int mask) {
			this.mask = mask;
		}

		public String toString() {
			return String.valueOf(mask);
		}
	}

	public enum EventLifespan {
		AUTOMATIC(Lifespan.AUTOMATIC), EXTENDED(Lifespan.EXTENDED), INTERMEDIATE(
				Lifespan.INTERMEDIATE), LONG(Lifespan.LONG), MODERATE(
				Lifespan.MODERATE), SHORT(Lifespan.SHORT), TRANSIENT(
				Lifespan.TRANSIENT);
		private final int mask;

		private EventLifespan(int mask) {
			this.mask = mask;
		}

		public String toString() {
			return String.valueOf(mask);
		}
	}

	public enum EventPriority {
		HIGH(Priority.HIGH), ELEVATED(Priority.ELEVATED), LOW(Priority.LOW), MEDIUM(
				Priority.MEDUIUM), URGENT(Priority.URGENT);
		private final int mask;

		private EventPriority(int mask) {
			this.mask = mask;
		}

		public String toString() {
			return String.valueOf(mask);
		}
	}

	public enum EventSource {
		MOTION_DETECTION(1), CMD(2), SENSOR(3), USER(4), ACS(5), ANALYTICS(6);
		private final int mask;

		private EventSource(int mask) {
			this.mask = mask;
		}

		public String toString() {
			return String.valueOf(mask);
		}
	}

	/**
	 * Creates a new event for the given objid and message. This is the minimum required information
	 * @param objid
	 * @param msg
	 * @return
	 */
	public static int createEvent(int objid, String msg) {
		ELogEvent e = new ELogEvent(objid, msg);
		return createEvent(e);
	}

	/**
	 * Creates a new event for the given objid and message, at the given time.
	 * @param objid
	 * @param whenTime
	 * @param msg
	 * @return
	 */
	public static int createEvent(String objid, String whenTime, String msg) {
		ELogEvent e = new ELogEvent(Integer.parseInt(objid), msg);
		e.setWhenTime(Long.parseLong(whenTime));
		e.setEventSource(EventSource.SENSOR);

		return createEvent(e);
	}

	private static ActionResponse elogAction(Action action) {
		Client client = new Client(session.getMasterHost());
		try {
			client.open(session.getSessionId());
			ELog.Client elogClient = new ELog.Client(
					client.getProtocol("skm.eventlog"));
			return elogClient.submitAction(action);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			client.close();
		}
		return null;
	}

	/**
	 * Creates a new event based on the provided ELogEvent's settings.
	 * @param event
	 * @return
	 */
	public static int createEvent(ELogEvent event) {
		if (event == null)
			return 0;

		Action action = new Action("create", event.toParameter(), null);
		ActionResponse actionResponse = elogAction(action);

		try {
			String eventid = actionResponse.parameters.get("eventid");
			return Integer.parseInt(eventid);
		} catch (Exception e) {
			return 0;
		}
	}

	/**
	 * Acknowledges the event with the given Event ID
	 * @param eventId
	 * @return
	 */
	public static long ackEvent(int eventId) {
		Map<String, String> parameters = new Hashtable<String, String>();
		parameters.put("eventid", String.valueOf(eventId));

		Action action = new Action("ack", parameters, null);
		ActionResponse actionResponse = elogAction(action);

		try {
			String eventid = actionResponse.parameters.get("eventid");
			return Integer.parseInt(eventid);
		} catch (Exception e) {
			return 0;
		}
	}

	public static ActionResponse checkPulse(long requestId) {
		Map<String, String> parameters = new Hashtable<String, String>();
		parameters.put("requestid", String.valueOf(requestId));
		Action action = new Action("check_pulse", parameters, null);
		return elogAction(action);
	}
	
	/**
	 * Sets the event to be migrated, where the video for the event will be moved to the server's 'Migrate' directory.
	 * @param eventId
	 * @return
	 */
	public static ActionResponse migrateEvent(int eventId) {
		Map<String, String> parameters = new Hashtable<String, String>();
		parameters.put("property.MIGRATE", "1");
		return updateEvent(eventId, parameters);
	}
	
	/**
	 * Updates an event, given by ID, by settings its values to the values provided in params.
	 * @param eventId
	 * @param params
	 * @return
	 */
	public static ActionResponse updateEvent(int eventId, Map<String, String> params){
		params.put("eventid",String.valueOf(eventId));
		Action action = new Action("update", params, null);
		return elogAction(action);
	}

}
