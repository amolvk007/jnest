
package com.videonext.stratus.sdk2.ELog.eventlogsvc.protocol;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PAGEType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PAGEType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;attribute name="PAGE" use="required" type="{http://www.w3.org/2001/XMLSchema}int" />
 *       &lt;attribute name="SNAPSHOT_ID" use="required" type="{http://www.w3.org/2001/XMLSchema}int" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PAGEType")
public class PAGEType {

    @XmlAttribute(name = "PAGE", required = true)
    protected int page;
    @XmlAttribute(name = "SNAPSHOT_ID", required = true)
    protected int snapshotid;

    /**
     * Gets the value of the page property.
     * 
     */
    public int getPAGE() {
        return page;
    }

    /**
     * Sets the value of the page property.
     * 
     */
    public void setPAGE(int value) {
        this.page = value;
    }

    /**
     * Gets the value of the snapshotid property.
     * 
     */
    public int getSNAPSHOTID() {
        return snapshotid;
    }

    /**
     * Sets the value of the snapshotid property.
     * 
     */
    public void setSNAPSHOTID(int value) {
        this.snapshotid = value;
    }

}
