
package com.videonext.stratus.sdk2.vmx.protocol;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for SHADOWSTYLEType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="SHADOWSTYLEType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="Plain"/>
 *     &lt;enumeration value="Raised"/>
 *     &lt;enumeration value="Sunken"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "SHADOWSTYLEType")
@XmlEnum
public enum SHADOWSTYLEType {

    @XmlEnumValue("Plain")
    PLAIN("Plain"),
    @XmlEnumValue("Raised")
    RAISED("Raised"),
    @XmlEnumValue("Sunken")
    SUNKEN("Sunken");
    private final String value;

    SHADOWSTYLEType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static SHADOWSTYLEType fromValue(String v) {
        for (SHADOWSTYLEType c: SHADOWSTYLEType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
