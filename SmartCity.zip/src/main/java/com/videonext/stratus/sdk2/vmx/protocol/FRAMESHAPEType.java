
package com.videonext.stratus.sdk2.vmx.protocol;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for FRAMESHAPEType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="FRAMESHAPEType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="NoFrame"/>
 *     &lt;enumeration value="Box"/>
 *     &lt;enumeration value="Panel"/>
 *     &lt;enumeration value="StyledPanel"/>
 *     &lt;enumeration value="PopupPanel"/>
 *     &lt;enumeration value="WinPanel"/>
 *     &lt;enumeration value="ToolBarPanel"/>
 *     &lt;enumeration value="MenuBarPanel"/>
 *     &lt;enumeration value="HLine"/>
 *     &lt;enumeration value="VLine"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "FRAMESHAPEType")
@XmlEnum
public enum FRAMESHAPEType {

    @XmlEnumValue("NoFrame")
    NO_FRAME("NoFrame"),
    @XmlEnumValue("Box")
    BOX("Box"),
    @XmlEnumValue("Panel")
    PANEL("Panel"),
    @XmlEnumValue("StyledPanel")
    STYLED_PANEL("StyledPanel"),
    @XmlEnumValue("PopupPanel")
    POPUP_PANEL("PopupPanel"),
    @XmlEnumValue("WinPanel")
    WIN_PANEL("WinPanel"),
    @XmlEnumValue("ToolBarPanel")
    TOOL_BAR_PANEL("ToolBarPanel"),
    @XmlEnumValue("MenuBarPanel")
    MENU_BAR_PANEL("MenuBarPanel"),
    @XmlEnumValue("HLine")
    H_LINE("HLine"),
    @XmlEnumValue("VLine")
    V_LINE("VLine");
    private final String value;

    FRAMESHAPEType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static FRAMESHAPEType fromValue(String v) {
        for (FRAMESHAPEType c: FRAMESHAPEType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
