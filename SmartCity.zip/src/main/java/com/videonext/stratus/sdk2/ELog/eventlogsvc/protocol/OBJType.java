
package com.videonext.stratus.sdk2.ELog.eventlogsvc.protocol;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 * 			Since release 2.7.0 value of T_DST contains commonly used time zone ID
 * 			(like America/Chicago, Europe/Munich, etc) instead of custom "USA&Canada"
 *             and "Europe". Attribute T_ZONE contains raw timezone offset (without DST) and
 *             used only for compatibility with release 2.6.3 and earlier (where T_ZONE was
 * 			required attribute)
 * 			
 * 
 * <p>Java class for OBJType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="OBJType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;attribute name="OBJID" use="required" type="{http://www.w3.org/2001/XMLSchema}unsignedInt" />
 *       &lt;attribute name="NAME" use="required" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="OTYPE" use="required" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="SUBTYPE" use="required" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="T_DST" use="required" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="T_ZONE" type="{http://eventlogsvc.videonext.com/protocol}T_ZONEType" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "OBJType")
public class OBJType {

    @XmlAttribute(name = "OBJID", required = true)
    @XmlSchemaType(name = "unsignedInt")
    protected long objid;
    @XmlAttribute(name = "NAME", required = true)
    protected String name;
    @XmlAttribute(name = "OTYPE", required = true)
    protected String otype;
    @XmlAttribute(name = "SUBTYPE", required = true)
    protected String subtype;
    @XmlAttribute(name = "T_DST", required = true)
    protected String tdst;
    @XmlAttribute(name = "T_ZONE")
    protected Float tzone;

    /**
     * Gets the value of the objid property.
     * 
     */
    public long getOBJID() {
        return objid;
    }

    /**
     * Sets the value of the objid property.
     * 
     */
    public void setOBJID(long value) {
        this.objid = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNAME() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNAME(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the otype property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOTYPE() {
        return otype;
    }

    /**
     * Sets the value of the otype property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOTYPE(String value) {
        this.otype = value;
    }

    /**
     * Gets the value of the subtype property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSUBTYPE() {
        return subtype;
    }

    /**
     * Sets the value of the subtype property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSUBTYPE(String value) {
        this.subtype = value;
    }

    /**
     * Gets the value of the tdst property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTDST() {
        return tdst;
    }

    /**
     * Sets the value of the tdst property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTDST(String value) {
        this.tdst = value;
    }

    /**
     * Gets the value of the tzone property.
     * 
     * @return
     *     possible object is
     *     {@link Float }
     *     
     */
    public Float getTZONE() {
        return tzone;
    }

    /**
     * Sets the value of the tzone property.
     * 
     * @param value
     *     allowed object is
     *     {@link Float }
     *     
     */
    public void setTZONE(Float value) {
        this.tzone = value;
    }

}
