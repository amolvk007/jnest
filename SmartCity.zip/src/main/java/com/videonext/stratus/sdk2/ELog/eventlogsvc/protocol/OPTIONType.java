
package com.videonext.stratus.sdk2.ELog.eventlogsvc.protocol;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for OPTIONType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="OPTIONType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;attribute name="name" use="required" type="{http://eventlogsvc.videonext.com/protocol}st_optname" />
 *       &lt;attribute name="value" use="required" type="{http://eventlogsvc.videonext.com/protocol}st_optvalue" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "OPTIONType")
public class OPTIONType {

    @XmlAttribute(required = true)
    protected StOptname name;
    @XmlAttribute(required = true)
    protected StOptvalue value;

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link StOptname }
     *     
     */
    public StOptname getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link StOptname }
     *     
     */
    public void setName(StOptname value) {
        this.name = value;
    }

    /**
     * Gets the value of the value property.
     * 
     * @return
     *     possible object is
     *     {@link StOptvalue }
     *     
     */
    public StOptvalue getValue() {
        return value;
    }

    /**
     * Sets the value of the value property.
     * 
     * @param value
     *     allowed object is
     *     {@link StOptvalue }
     *     
     */
    public void setValue(StOptvalue value) {
        this.value = value;
    }

}
