package com.videonext.stratus.sdk2.objectmanagement;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;

import com.videonext.stratus.sdk2.session.Session;

public class DeviceListRequestor {
	private static final Session session = Session.getSession();

	public static enum DeviceType {
		CAMERA("camera"), AUDIO("audio"), NODE("node"), ANY("any");
		private final String type;
		private DeviceType(String type){
			this.type = type;
		}
		
		@Override
		public String toString(){
			return type;
		}
	}

	public static class DeviceInfo {
		private int objid;
		String type;
		String subtype;
		String name;
		String location;

		Map<String, String> attrs = null;

		public Map<String, String> getAttrs() {
			return attrs;
		}

		public String toString() {
			return "[" + getObjid() + "] " + name;
		}

		public int getObjid() {
			return objid;
		}

		public void setObjid(int objid) {
			this.objid = objid;
		}
	}

	/**
	 * Gets the list of all cameras.
	 * 
	 * @return
	 * @throws Exception
	 */
	public static Map<Integer, DeviceInfo> getCameraList() throws Exception {
		return getDeviceList(DeviceType.CAMERA, false);
	}

	/**
	 * Gets the list of all devices of the given type. You can set the output to
	 * optionally include the extended attributes of the device.
	 * 
	 * @param type
	 * @param withAttributes
	 * @return
	 * @throws Exception
	 */
	public static Map<Integer, DeviceInfo> getDeviceList(DeviceType type,
			boolean withAttributes) throws Exception {
		Map<Integer, DeviceInfo> objList = new HashMap<Integer, DeviceInfo>();

		String apiCallPath = "/api/call/getObjectList";

		List<String> params = new ArrayList<String>();
		params.add("type="+type.toString());

		params.add("withAttributes=" + String.valueOf(withAttributes));

		JSONObject json = session.readJSONResponse(apiCallPath, params);
		JSONArray jlist = json.getJSONArray("list");

		for (int i = 0; i < jlist.length(); i++) {
			DeviceInfo obj = new DeviceInfo();
			json = jlist.getJSONObject(i);
			obj.setObjid(json.getInt("obj"));
			obj.name = json.getString("name");
			obj.type = json.getString("otype");
			obj.subtype = json.getString("subtype");
			obj.location = json.getString("location");

			if (withAttributes) {
				JSONObject attributes = json.getJSONObject("attributes");
				obj.attrs = new HashMap<String, String>();
				for (String a : JSONObject.getNames(attributes)) {
					obj.attrs.put(a, attributes.getString(a));
				}
			}

			objList.put(obj.objid, obj);
		}

		return objList;
	}

}
