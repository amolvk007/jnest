
package com.videonext.stratus.sdk2.ELog.eventlogsvc.protocol;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for st_optname.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="st_optname">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="timeformat"/>
 *     &lt;enumeration value="properties"/>
 *     &lt;enumeration value="witnesses"/>
 *     &lt;enumeration value="useractions"/>
 *     &lt;enumeration value="history"/>
 *     &lt;enumeration value="objinfo"/>
 *     &lt;enumeration value="mediasize"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "st_optname")
@XmlEnum
public enum StOptname {

    @XmlEnumValue("timeformat")
    TIMEFORMAT("timeformat"),
    @XmlEnumValue("properties")
    PROPERTIES("properties"),
    @XmlEnumValue("witnesses")
    WITNESSES("witnesses"),
    @XmlEnumValue("useractions")
    USERACTIONS("useractions"),
    @XmlEnumValue("history")
    HISTORY("history"),
    @XmlEnumValue("objinfo")
    OBJINFO("objinfo"),
    @XmlEnumValue("mediasize")
    MEDIASIZE("mediasize");
    private final String value;

    StOptname(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static StOptname fromValue(String v) {
        for (StOptname c: StOptname.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
