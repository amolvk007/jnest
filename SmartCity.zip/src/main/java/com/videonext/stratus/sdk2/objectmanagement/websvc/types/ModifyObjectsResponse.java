
package com.videonext.stratus.sdk2.objectmanagement.websvc.types;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="CreateObjectReceipt" type="{http://skm.videonext.com/om/websvc/types}CreateObjectReceipt" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="UpdateObjectReceipt" type="{http://skm.videonext.com/om/websvc/types}ObjectReceipt" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="DeleteObjectReceipt" type="{http://skm.videonext.com/om/websvc/types}ObjectReceipt" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "createObjectReceipt",
    "updateObjectReceipt",
    "deleteObjectReceipt"
})
@XmlRootElement(name = "ModifyObjectsResponse")
public class ModifyObjectsResponse {

    @XmlElement(name = "CreateObjectReceipt")
    protected List<CreateObjectReceipt> createObjectReceipt;
    @XmlElement(name = "UpdateObjectReceipt")
    protected List<ObjectReceipt> updateObjectReceipt;
    @XmlElement(name = "DeleteObjectReceipt")
    protected List<ObjectReceipt> deleteObjectReceipt;

    /**
     * Gets the value of the createObjectReceipt property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the createObjectReceipt property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCreateObjectReceipt().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CreateObjectReceipt }
     * 
     * 
     */
    public List<CreateObjectReceipt> getCreateObjectReceipt() {
        if (createObjectReceipt == null) {
            createObjectReceipt = new ArrayList<CreateObjectReceipt>();
        }
        return this.createObjectReceipt;
    }

    /**
     * Gets the value of the updateObjectReceipt property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the updateObjectReceipt property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getUpdateObjectReceipt().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ObjectReceipt }
     * 
     * 
     */
    public List<ObjectReceipt> getUpdateObjectReceipt() {
        if (updateObjectReceipt == null) {
            updateObjectReceipt = new ArrayList<ObjectReceipt>();
        }
        return this.updateObjectReceipt;
    }

    /**
     * Gets the value of the deleteObjectReceipt property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the deleteObjectReceipt property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDeleteObjectReceipt().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ObjectReceipt }
     * 
     * 
     */
    public List<ObjectReceipt> getDeleteObjectReceipt() {
        if (deleteObjectReceipt == null) {
            deleteObjectReceipt = new ArrayList<ObjectReceipt>();
        }
        return this.deleteObjectReceipt;
    }

}
