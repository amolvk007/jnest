
package com.videonext.stratus.sdk2.vmx.protocol;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://websvc.videonext.com/protocol}SessionID"/>
 *         &lt;element ref="{http://websvc.videonext.com/protocol}ObjectID"/>
 *         &lt;choice>
 *           &lt;element name="MonitorPriority" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *           &lt;element ref="{http://websvc.videonext.com/protocol}Priority" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;/choice>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "sessionID",
    "objectID",
    "monitorPriority",
    "priority"
})
@XmlRootElement(name = "SetPriority_in")
public class SetPriorityIn {

    @XmlElement(name = "SessionID", required = true)
    protected String sessionID;
    @XmlElement(name = "ObjectID")
    @XmlSchemaType(name = "unsignedInt")
    protected long objectID;
    @XmlElement(name = "MonitorPriority")
    protected Integer monitorPriority;
    @XmlElement(name = "Priority")
    protected List<CellPriorityType> priority;

    /**
     * Gets the value of the sessionID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSessionID() {
        return sessionID;
    }

    /**
     * Sets the value of the sessionID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSessionID(String value) {
        this.sessionID = value;
    }

    /**
     * Gets the value of the objectID property.
     * 
     */
    public long getObjectID() {
        return objectID;
    }

    /**
     * Sets the value of the objectID property.
     * 
     */
    public void setObjectID(long value) {
        this.objectID = value;
    }

    /**
     * Gets the value of the monitorPriority property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getMonitorPriority() {
        return monitorPriority;
    }

    /**
     * Sets the value of the monitorPriority property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setMonitorPriority(Integer value) {
        this.monitorPriority = value;
    }

    /**
     * Gets the value of the priority property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the priority property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPriority().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CellPriorityType }
     * 
     * 
     */
    public List<CellPriorityType> getPriority() {
        if (priority == null) {
            priority = new ArrayList<CellPriorityType>();
        }
        return this.priority;
    }

}
