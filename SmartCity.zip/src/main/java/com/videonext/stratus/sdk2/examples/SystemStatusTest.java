package com.videonext.stratus.sdk2.examples;

import com.videonext.stratus.sdk2.session.Session;
import com.videonext.stratus.sdk2.system.ServerTimeRequestor;
import com.videonext.stratus.sdk2.system.SystemStatusRequestor;
import com.videonext.stratus.sdk2.system.SystemStatusRequestor.SystemStatus;
import com.videonext.stratus.sdk2.system.VersionRequestor;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;

public class SystemStatusTest {

	public static void main(String[] args) {
		Session session = Session.getSession();

		try {
			// Do not use this in a production environment. It sets the
			// application to accept any ssl-cert, defeating the purpose of
			// using ssl.
			session.setTrustAll(true);
			session.openSession("vtm.videonext.com", "admin", "topse", "http");

			String version = VersionRequestor.getVersion();
			SystemStatus status = SystemStatusRequestor.getSystemStatus();
			long systemTime = ServerTimeRequestor.getServerTime();
			
			Date date = new Date(systemTime*1000);
			Format format = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
			
			System.out.println("Current system time: " + format.format(date) + " ("+systemTime+")");
			System.out.println("API Version: " + version);
			System.out.println("Status: " + status.status);
			System.out.println("Status Description: " + status.description);
			System.out.println("Reasons: ");
			for (String reason : status.reasons) {
				System.out.println("\t" + reason);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
