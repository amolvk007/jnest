
package com.videonext.stratus.sdk2.ELog.eventlogsvc.protocol;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for st_timeformat.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="st_timeformat">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="UTC"/>
 *     &lt;enumeration value="LOCAL"/>
 *     &lt;enumeration value="UTCTIME"/>
 *     &lt;enumeration value="LOCALTIME"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "st_timeformat")
@XmlEnum
public enum StTimeformat {

    UTC,
    LOCAL,
    UTCTIME,
    LOCALTIME;

    public String value() {
        return name();
    }

    public static StTimeformat fromValue(String v) {
        return valueOf(v);
    }

}
