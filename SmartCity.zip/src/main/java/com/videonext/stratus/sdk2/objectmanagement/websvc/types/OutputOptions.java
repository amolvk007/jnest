
package com.videonext.stratus.sdk2.objectmanagement.websvc.types;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * <p>Java class for OutputOptions complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="OutputOptions">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;attribute name="host" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *       &lt;attribute name="properties" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *       &lt;attribute name="propertylist" type="{http://skm.videonext.com/om/websvc/types}PropertyNamesType" />
 *       &lt;attribute name="methods" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *       &lt;attribute name="notification" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "OutputOptions")
public class OutputOptions {

    @XmlAttribute(name = "host")
    protected Boolean host;
    @XmlAttribute(name = "properties")
    protected Boolean properties;
    @XmlAttribute(name = "propertylist")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    protected String propertylist;
    @XmlAttribute(name = "methods")
    protected Boolean methods;
    @XmlAttribute(name = "notification")
    protected Boolean notification;

    /**
     * Gets the value of the host property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isHost() {
        return host;
    }

    /**
     * Sets the value of the host property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setHost(Boolean value) {
        this.host = value;
    }

    /**
     * Gets the value of the properties property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isProperties() {
        return properties;
    }

    /**
     * Sets the value of the properties property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setProperties(Boolean value) {
        this.properties = value;
    }

    /**
     * Gets the value of the propertylist property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPropertylist() {
        return propertylist;
    }

    /**
     * Sets the value of the propertylist property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPropertylist(String value) {
        this.propertylist = value;
    }

    /**
     * Gets the value of the methods property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isMethods() {
        return methods;
    }

    /**
     * Sets the value of the methods property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setMethods(Boolean value) {
        this.methods = value;
    }

    /**
     * Gets the value of the notification property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isNotification() {
        return notification;
    }

    /**
     * Sets the value of the notification property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setNotification(Boolean value) {
        this.notification = value;
    }

}
