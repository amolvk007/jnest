
package com.videonext.stratus.sdk2.ELog.eventlogsvc.protocol;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for t_unixtime_element complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="t_unixtime_element">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;attribute name="WHEN" use="required" type="{http://eventlogsvc.videonext.com/protocol}t_unixtime" />
 *       &lt;attribute name="FROM" use="required" type="{http://eventlogsvc.videonext.com/protocol}t_unixtime" />
 *       &lt;attribute name="TO" use="required" type="{http://eventlogsvc.videonext.com/protocol}t_unixtime" />
 *       &lt;attribute name="UPDATED" use="required" type="{http://eventlogsvc.videonext.com/protocol}t_unixtime" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "t_unixtime_element")
public class TUnixtimeElement {

    @XmlAttribute(name = "WHEN", required = true)
    protected long when;
    @XmlAttribute(name = "FROM", required = true)
    protected long from;
    @XmlAttribute(name = "TO", required = true)
    protected long to;
    @XmlAttribute(name = "UPDATED", required = true)
    protected long updated;

    /**
     * Gets the value of the when property.
     * 
     */
    public long getWHEN() {
        return when;
    }

    /**
     * Sets the value of the when property.
     * 
     */
    public void setWHEN(long value) {
        this.when = value;
    }

    /**
     * Gets the value of the from property.
     * 
     */
    public long getFROM() {
        return from;
    }

    /**
     * Sets the value of the from property.
     * 
     */
    public void setFROM(long value) {
        this.from = value;
    }

    /**
     * Gets the value of the to property.
     * 
     */
    public long getTO() {
        return to;
    }

    /**
     * Sets the value of the to property.
     * 
     */
    public void setTO(long value) {
        this.to = value;
    }

    /**
     * Gets the value of the updated property.
     * 
     */
    public long getUPDATED() {
        return updated;
    }

    /**
     * Sets the value of the updated property.
     * 
     */
    public void setUPDATED(long value) {
        this.updated = value;
    }

}
