
package com.videonext.stratus.sdk2.ELog.eventlogsvc.protocol;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for EVENTREQUESTType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="EVENTREQUESTType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://eventlogsvc.videonext.com/protocol}FILTER"/>
 *         &lt;element ref="{http://eventlogsvc.videonext.com/protocol}OUTPUTOPTIONS" minOccurs="0"/>
 *         &lt;element ref="{http://eventlogsvc.videonext.com/protocol}PAGEBREAK" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "EVENTREQUESTType", propOrder = {
    "filter",
    "outputoptions",
    "pagebreak"
})
public class EVENTREQUESTType {

    @XmlElement(name = "FILTER", required = true)
    protected FILTERType filter;
    @XmlElement(name = "OUTPUTOPTIONS")
    protected OUTPUTOPTIONSType outputoptions;
    @XmlElement(name = "PAGEBREAK")
    protected PAGEBREAKType pagebreak;

    /**
     * Gets the value of the filter property.
     * 
     * @return
     *     possible object is
     *     {@link FILTERType }
     *     
     */
    public FILTERType getFILTER() {
        return filter;
    }

    /**
     * Sets the value of the filter property.
     * 
     * @param value
     *     allowed object is
     *     {@link FILTERType }
     *     
     */
    public void setFILTER(FILTERType value) {
        this.filter = value;
    }

    /**
     * Gets the value of the outputoptions property.
     * 
     * @return
     *     possible object is
     *     {@link OUTPUTOPTIONSType }
     *     
     */
    public OUTPUTOPTIONSType getOUTPUTOPTIONS() {
        return outputoptions;
    }

    /**
     * Sets the value of the outputoptions property.
     * 
     * @param value
     *     allowed object is
     *     {@link OUTPUTOPTIONSType }
     *     
     */
    public void setOUTPUTOPTIONS(OUTPUTOPTIONSType value) {
        this.outputoptions = value;
    }

    /**
     * Gets the value of the pagebreak property.
     * 
     * @return
     *     possible object is
     *     {@link PAGEBREAKType }
     *     
     */
    public PAGEBREAKType getPAGEBREAK() {
        return pagebreak;
    }

    /**
     * Sets the value of the pagebreak property.
     * 
     * @param value
     *     allowed object is
     *     {@link PAGEBREAKType }
     *     
     */
    public void setPAGEBREAK(PAGEBREAKType value) {
        this.pagebreak = value;
    }

}
