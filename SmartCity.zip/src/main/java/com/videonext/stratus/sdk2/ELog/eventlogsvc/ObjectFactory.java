
package com.videonext.stratus.sdk2.ELog.eventlogsvc;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;

import com.videonext.stratus.sdk2.ELog.eventlogsvc.protocol.ACTIONREQUESTType;
import com.videonext.stratus.sdk2.ELog.eventlogsvc.protocol.ACTIONRESPONSEType;
import com.videonext.stratus.sdk2.ELog.eventlogsvc.protocol.EVENTREQUESTType;
import com.videonext.stratus.sdk2.ELog.eventlogsvc.protocol.EVENTRESPONSEType;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.videonext.eventlogsvc package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _EVENTREQUEST_QNAME = new QName("http://eventlogsvc.videonext.com", "EVENTREQUEST");
    private final static QName _ACTIONREQUEST_QNAME = new QName("http://eventlogsvc.videonext.com", "ACTIONREQUEST");
    private final static QName _EVENTRESPONSE_QNAME = new QName("http://eventlogsvc.videonext.com", "EVENTRESPONSE");
    private final static QName _ACTIONRESPONSE_QNAME = new QName("http://eventlogsvc.videonext.com", "ACTIONRESPONSE");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.videonext.eventlogsvc
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EVENTREQUESTType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://eventlogsvc.videonext.com", name = "EVENTREQUEST")
    public JAXBElement<EVENTREQUESTType> createEVENTREQUEST(EVENTREQUESTType value) {
        return new JAXBElement<EVENTREQUESTType>(_EVENTREQUEST_QNAME, EVENTREQUESTType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ACTIONREQUESTType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://eventlogsvc.videonext.com", name = "ACTIONREQUEST")
    public JAXBElement<ACTIONREQUESTType> createACTIONREQUEST(ACTIONREQUESTType value) {
        return new JAXBElement<ACTIONREQUESTType>(_ACTIONREQUEST_QNAME, ACTIONREQUESTType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EVENTRESPONSEType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://eventlogsvc.videonext.com", name = "EVENTRESPONSE")
    public JAXBElement<EVENTRESPONSEType> createEVENTRESPONSE(EVENTRESPONSEType value) {
        return new JAXBElement<EVENTRESPONSEType>(_EVENTRESPONSE_QNAME, EVENTRESPONSEType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ACTIONRESPONSEType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://eventlogsvc.videonext.com", name = "ACTIONRESPONSE")
    public JAXBElement<ACTIONRESPONSEType> createACTIONRESPONSE(ACTIONRESPONSEType value) {
        return new JAXBElement<ACTIONRESPONSEType>(_ACTIONRESPONSE_QNAME, ACTIONRESPONSEType.class, null, value);
    }

}
