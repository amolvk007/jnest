package com.videonext.stratus.sdk2.examples;

import com.videonext.stratus.sdk2.objectmanagement.OMServiceRequestor;
import com.videonext.stratus.sdk2.objectmanagement.websvc.types.*;
import com.videonext.stratus.sdk2.session.Session;

import java.util.List;

/*
 otype |       name
-------+------------------
 D     | Device
 X     | External objects
 V     | Avatar

 otype | subtype |         name
-------+---------+-----------------------
 D     | C       | Camera
 D     | R       | Relay
 D     | S       | Sensor
 D     | A       | Audio Source
 D     | V       | vMX Monitor
 D     | W       | vMX Wall
 D     | E       | External device
 D     | N       | Node
 X     | G       | Gateway
 X     | S       | Access Control Sensor
 X     | D       | Door
 X     | P       | Perimeter
 X     | A       | Area
 V     | *       | Avatar
 */

/**
 * This example shows how to use the ObjectManagementService webservice to query the health of
 * camera devices in the system.
 *
 * In the example we query using a filter based on object type. Objects have a primary type, 'otype',
 * and a secondary type, 'subtype'.
 *
 * Here is the list of most otypes and subtypes (there are others, but they don't belong to physical objects)
 *
 * otype |       name
 * -------+------------------
 * D     | Device
 * X     | External objects
 * V     | Avatar
 *
 * otype | subtype |         name
 * -------+---------+-----------------------
 * D     | C       | Camera
 * D     | R       | Relay
 * D     | S       | Sensor
 * D     | A       | Audio Source
 * D     | V       | vMX Monitor
 * D     | W       | vMX Wall
 * D     | E       | External device
 * D     | N       | Node
 * X     | G       | Gateway
 * X     | S       | Access Control Sensor
 * X     | D       | Door
 * X     | P       | Perimeter
 * X     | A       | Area
 * V     | *       | Avatar
 */

public class OMServiceTest {

    public static void main(String args[]) throws Exception {

        Session session = Session.getSession();
        String masterHost = "vtm.videonext.com";
        session.setTrustAll(true);
        session.openSession(masterHost, "admin", "topse", "http");

        ObjectTypeFilter value = new ObjectTypeFilter();
        value.setType("D"); // primary type of "D"evice
        value.setSubtype("C"); // sub-type of "C"amera



        Filter filter = new Filter();
        filter.setObjectTypeFilter(value);
        ObjectRef ref = new ObjectRef();
        //ref.setObjid(101);
        //filter.setObjectFilter(ref);


        ObjectsRequest objectsRequest = new ObjectsRequest();
        objectsRequest.setFilter(filter);

        OutputOptions options = new OutputOptions();
        options.setProperties(Boolean.TRUE);
        options.setPropertylist("health");
        objectsRequest.setOutputOptions(options);

        ObjectsResponse resp = OMServiceRequestor.getObjects(objectsRequest);

        List<com.videonext.stratus.sdk2.objectmanagement.websvc.types.Object> objList = resp.getObject();
        for (com.videonext.stratus.sdk2.objectmanagement.websvc.types.Object obj : objList) {
            int objid = obj.getObjid();
            System.out.print("objid:" + objid + " - ");
            PropertyList plist = obj.getProperties();

            for (Property prop : plist.getProperty()) {
                System.out.println(prop.getName() + "=" + prop.getValue());
            }
        }

    }
}
