
package com.videonext.stratus.sdk2.ELog.eventlogsvc.protocol;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for st_sort.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="st_sort">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="eventid"/>
 *     &lt;enumeration value="when"/>
 *     &lt;enumeration value="duration"/>
 *     &lt;enumeration value="objtype"/>
 *     &lt;enumeration value="objname"/>
 *     &lt;enumeration value="priority"/>
 *     &lt;enumeration value="lifespan"/>
 *     &lt;enumeration value="message"/>
 *     &lt;enumeration value="note"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "st_sort")
@XmlEnum
public enum StSort {

    @XmlEnumValue("eventid")
    EVENTID("eventid"),
    @XmlEnumValue("when")
    WHEN("when"),
    @XmlEnumValue("duration")
    DURATION("duration"),
    @XmlEnumValue("objtype")
    OBJTYPE("objtype"),
    @XmlEnumValue("objname")
    OBJNAME("objname"),
    @XmlEnumValue("priority")
    PRIORITY("priority"),
    @XmlEnumValue("lifespan")
    LIFESPAN("lifespan"),
    @XmlEnumValue("message")
    MESSAGE("message"),
    @XmlEnumValue("note")
    NOTE("note");
    private final String value;

    StSort(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static StSort fromValue(String v) {
        for (StSort c: StSort.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
