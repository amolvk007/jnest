package com.videonext.stratus.sdk2.examples;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.http.client.ClientProtocolException;
import org.json.JSONException;

import com.videonext.stratus.sdk2.session.Session;
import com.videonext.stratus.sdk2.storage.StorageUsageRequestor;
import com.videonext.stratus.sdk2.storage.StorageUsageRequestor.Granularity;
import com.videonext.stratus.sdk2.storage.StorageUsageRequestor.StorageCoverage;

public class StorageUsageTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Session session = Session.getSession();

		String HOST = "demo-10.videonext.com";
		int[] OBJID = { 101 };

		try {
			// Do not use this in a production environment. It sets the
			// application to accept any ssl-cert, defeating the purpose of
			// using ssl.
			session.setTrustAll(true);
			session.openSession(HOST, "admin", "topse", "https");
		} catch (ClientProtocolException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalStateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		List<Integer> objList = new ArrayList<Integer>();
		for (int obj : OBJID)
			objList.add(obj);
		long currentTime = System.currentTimeMillis() / 1000;
		long startTime = currentTime - 3600; // one hour ago
        Granularity granularity = StorageUsageRequestor.Granularity.MIN;
		boolean digest = false;
		Map<Integer, StorageCoverage> response = null;

		try {
			response = StorageUsageRequestor.getStorageCoverage(objList,
					startTime, currentTime, granularity, digest);

			for (Entry<Integer, StorageCoverage> c : StorageUsageRequestor
					.getStorageUsage(objList, granularity).entrySet()) {
				if (response.containsKey(c.getKey())) {
					StorageCoverage cov = response.get(c.getKey());
					StorageCoverage cov2 = c.getValue();
					cov.setOldestTime(cov2.getOldestTime());
					cov.setStorageUsage(cov2.getStorageUsage());
					cov.setTotalUsage(cov2.getTotalUsage());
					cov.setUnit(cov2.getUnit());

					response.remove(c.getKey());
					response.put(c.getKey(), cov);
				}
			}

		} catch (IllegalStateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClientProtocolException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		if (response == null) {
			System.err.println("No response");
			System.exit(0);
		}

		for (Entry<Integer, StorageCoverage> coverage : response.entrySet()) {
			System.out.println(coverage.getKey() + " - "
					+ coverage.getValue().toString());
		}

	}

}
