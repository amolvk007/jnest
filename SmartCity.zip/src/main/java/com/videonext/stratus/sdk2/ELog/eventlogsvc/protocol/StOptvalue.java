
package com.videonext.stratus.sdk2.ELog.eventlogsvc.protocol;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for st_optvalue.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="st_optvalue">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="true"/>
 *     &lt;enumeration value="false"/>
 *     &lt;enumeration value="UTC"/>
 *     &lt;enumeration value="LOCAL"/>
 *     &lt;enumeration value="UTCTIME"/>
 *     &lt;enumeration value="LOCALTIME"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "st_optvalue")
@XmlEnum
public enum StOptvalue {

    @XmlEnumValue("true")
    TRUE("true"),
    @XmlEnumValue("false")
    FALSE("false"),
    UTC("UTC"),
    LOCAL("LOCAL"),
    UTCTIME("UTCTIME"),
    LOCALTIME("LOCALTIME");
    private final String value;

    StOptvalue(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static StOptvalue fromValue(String v) {
        for (StOptvalue c: StOptvalue.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
