
package com.videonext.stratus.sdk2.ELog.eventlogsvc.protocol;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for EVENTRESPONSEType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="EVENTRESPONSEType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;all>
 *         &lt;element name="PAGE" type="{http://eventlogsvc.videonext.com/protocol}PAGEType" minOccurs="0"/>
 *         &lt;element ref="{http://eventlogsvc.videonext.com/protocol}EVENTS"/>
 *       &lt;/all>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "EVENTRESPONSEType", propOrder = {

})
public class EVENTRESPONSEType {

    @XmlElement(name = "PAGE")
    protected PAGEType page;
    @XmlElement(name = "EVENTS", required = true)
    protected EVENTSType events;

    /**
     * Gets the value of the page property.
     * 
     * @return
     *     possible object is
     *     {@link PAGEType }
     *     
     */
    public PAGEType getPAGE() {
        return page;
    }

    /**
     * Sets the value of the page property.
     * 
     * @param value
     *     allowed object is
     *     {@link PAGEType }
     *     
     */
    public void setPAGE(PAGEType value) {
        this.page = value;
    }

    /**
     * Gets the value of the events property.
     * 
     * @return
     *     possible object is
     *     {@link EVENTSType }
     *     
     */
    public EVENTSType getEVENTS() {
        return events;
    }

    /**
     * Sets the value of the events property.
     * 
     * @param value
     *     allowed object is
     *     {@link EVENTSType }
     *     
     */
    public void setEVENTS(EVENTSType value) {
        this.events = value;
    }

}
