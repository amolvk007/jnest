
package com.videonext.stratus.sdk2.vmx.protocol;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for CellPriorityType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CellPriorityType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;attribute name="priority" use="required" type="{http://www.w3.org/2001/XMLSchema}int" />
 *       &lt;attribute name="override" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *       &lt;attribute name="cellid" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CellPriorityType")
public class CellPriorityType {

    @XmlAttribute(name = "priority", required = true)
    protected int priority;
    @XmlAttribute(name = "override")
    protected Boolean override;
    @XmlAttribute(name = "cellid")
    protected String cellid;

    /**
     * Gets the value of the priority property.
     * 
     */
    public int getPriority() {
        return priority;
    }

    /**
     * Sets the value of the priority property.
     * 
     */
    public void setPriority(int value) {
        this.priority = value;
    }

    /**
     * Gets the value of the override property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isOverride() {
        return override;
    }

    /**
     * Sets the value of the override property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setOverride(Boolean value) {
        this.override = value;
    }

    /**
     * Gets the value of the cellid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCellid() {
        return cellid;
    }

    /**
     * Sets the value of the cellid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCellid(String value) {
        this.cellid = value;
    }

}
