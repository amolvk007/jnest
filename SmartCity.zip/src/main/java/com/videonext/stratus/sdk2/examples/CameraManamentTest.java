package com.videonext.stratus.sdk2.examples;

import java.util.ArrayList;
import java.util.List;

import com.videonext.stratus.sdk2.objectmanagement.ObjectManagementRequestor;
import com.videonext.stratus.sdk2.objectmanagement.ObjectManagementRequestor.Camera;
import com.videonext.stratus.sdk2.session.Session;

public class CameraManamentTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Session session = Session.getSession();
		String masterHost = "demo-16.videonext.com";

		try {
			// Do not use this in a production environment. It sets the
			// application to accept any ssl-cert, defeating the purpose of
			// using ssl.
			session.setTrustAll(true);
			session.openSession(masterHost, "admin", "topse", "https");
			
			ObjectManagementRequestor objR = new ObjectManagementRequestor();
			Camera camera = objR.new Camera();
			
			camera.setCameraModel("Axis");
			camera.setCamInput(0);
			camera.setDevIP("207.207.160.45");
			camera.setModelID("P1347");
			camera.setName("North Parkinglot camera");
			camera.setUserName("root");
			camera.setPassword("pass");
			
			int objid = ObjectManagementRequestor.addCamera(camera);
			
			System.out.println(ObjectManagementRequestor.getObjectAttributes(objid).toString());
			
			List<Integer> objidList = new ArrayList<Integer>();
			objidList.add(objid);
			ObjectManagementRequestor.deleteObject(objidList);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
