
package com.videonext.stratus.sdk2.vmx.protocol;

import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;



/**
 * <p>Java class for FONTType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FONTType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;attribute name="FAMILY" type="{http://www.w3.org/2001/XMLSchema}string" default="Helvetica" />
 *       &lt;attribute name="POINTSIZE" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" default="18" />
 *       &lt;attribute name="WEIGHT" type="{http://websvc.videonext.com/protocol}WEIGHTType" default="Normal" />
 *       &lt;attribute name="STRETCH" type="{http://www.w3.org/2001/XMLSchema}string" default="Unstretched" />
 *       &lt;attribute name="RGB" type="{http://www.w3.org/2001/XMLSchema}int" default="0" />
 *       &lt;attribute name="ITALIC" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
 *       &lt;attribute name="UNDERLINE" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
 *       &lt;attribute name="OVERLINE" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
 *       &lt;attribute name="STRIKEOUT" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FONTType")
public class FONTType {

    @XmlAttribute(name = "FAMILY")
    protected String family;
    @XmlAttribute(name = "POINTSIZE")
    @XmlSchemaType(name = "positiveInteger")
    protected BigInteger pointsize;
    @XmlAttribute(name = "WEIGHT")
    protected WEIGHTType weight;
    @XmlAttribute(name = "STRETCH")
    protected String stretch;
    @XmlAttribute(name = "RGB")
    protected Integer rgb;
    @XmlAttribute(name = "ITALIC")
    protected Boolean italic;
    @XmlAttribute(name = "UNDERLINE")
    protected Boolean underline;
    @XmlAttribute(name = "OVERLINE")
    protected Boolean overline;
    @XmlAttribute(name = "STRIKEOUT")
    protected Boolean strikeout;

    /**
     * Gets the value of the family property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFAMILY() {
        if (family == null) {
            return "Helvetica";
        } else {
            return family;
        }
    }

    /**
     * Sets the value of the family property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFAMILY(String value) {
        this.family = value;
    }

    /**
     * Gets the value of the pointsize property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getPOINTSIZE() {
        if (pointsize == null) {
            return new BigInteger("18");
        } else {
            return pointsize;
        }
    }

    /**
     * Sets the value of the pointsize property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setPOINTSIZE(BigInteger value) {
        this.pointsize = value;
    }

    /**
     * Gets the value of the weight property.
     * 
     * @return
     *     possible object is
     *     {@link WEIGHTType }
     *     
     */
    public WEIGHTType getWEIGHT() {
        if (weight == null) {
            return WEIGHTType.NORMAL;
        } else {
            return weight;
        }
    }

    /**
     * Sets the value of the weight property.
     * 
     * @param value
     *     allowed object is
     *     {@link WEIGHTType }
     *     
     */
    public void setWEIGHT(WEIGHTType value) {
        this.weight = value;
    }

    /**
     * Gets the value of the stretch property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSTRETCH() {
        if (stretch == null) {
            return "Unstretched";
        } else {
            return stretch;
        }
    }

    /**
     * Sets the value of the stretch property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSTRETCH(String value) {
        this.stretch = value;
    }

    /**
     * Gets the value of the rgb property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public int getRGB() {
        if (rgb == null) {
            return  0;
        } else {
            return rgb;
        }
    }

    /**
     * Sets the value of the rgb property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setRGB(Integer value) {
        this.rgb = value;
    }

    /**
     * Gets the value of the italic property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public boolean isITALIC() {
        if (italic == null) {
            return false;
        } else {
            return italic;
        }
    }

    /**
     * Sets the value of the italic property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setITALIC(Boolean value) {
        this.italic = value;
    }

    /**
     * Gets the value of the underline property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public boolean isUNDERLINE() {
        if (underline == null) {
            return false;
        } else {
            return underline;
        }
    }

    /**
     * Sets the value of the underline property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setUNDERLINE(Boolean value) {
        this.underline = value;
    }

    /**
     * Gets the value of the overline property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public boolean isOVERLINE() {
        if (overline == null) {
            return false;
        } else {
            return overline;
        }
    }

    /**
     * Sets the value of the overline property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setOVERLINE(Boolean value) {
        this.overline = value;
    }

    /**
     * Gets the value of the strikeout property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public boolean isSTRIKEOUT() {
        if (strikeout == null) {
            return false;
        } else {
            return strikeout;
        }
    }

    /**
     * Sets the value of the strikeout property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setSTRIKEOUT(Boolean value) {
        this.strikeout = value;
    }

}
