
package com.videonext.stratus.sdk2.vmx.protocol;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ALIGNType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="ALIGNType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="AlignLeft"/>
 *     &lt;enumeration value="AlignRight"/>
 *     &lt;enumeration value="AlignTop"/>
 *     &lt;enumeration value="AlignBottom"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "ALIGNType")
@XmlEnum
public enum ALIGNType {

    @XmlEnumValue("AlignLeft")
    ALIGN_LEFT("AlignLeft"),
    @XmlEnumValue("AlignRight")
    ALIGN_RIGHT("AlignRight"),
    @XmlEnumValue("AlignTop")
    ALIGN_TOP("AlignTop"),
    @XmlEnumValue("AlignBottom")
    ALIGN_BOTTOM("AlignBottom");
    private final String value;

    ALIGNType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ALIGNType fromValue(String v) {
        for (ALIGNType c: ALIGNType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
