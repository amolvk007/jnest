package com.videonext.stratus.sdk2.system;

import java.io.IOException;

import org.json.JSONException;
import org.json.JSONObject;

import com.videonext.stratus.sdk2.session.Session;

public class ServerTimeRequestor {
	private static final Session session = Session.getSession();

	/**
	 * gets the time as seen by the server, in seconds since Unix epoch UTC time.
	 * @return
	 * @throws IOException
	 * @throws IllegalStateException
	 * @throws JSONException
	 */
	public static long getServerTime() throws IOException, IllegalStateException, JSONException {
		String apiCallPath = "/api/call/getServerTime";

		JSONObject json = session.readJSONResponse(apiCallPath, null);
		return json.getLong("servertime"); // should be 1.1 if successful
	}
}
