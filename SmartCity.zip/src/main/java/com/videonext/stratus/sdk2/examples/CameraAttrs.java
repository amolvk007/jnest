package com.videonext.stratus.sdk2.examples;

import java.util.Map;
import java.util.Map.Entry;

import com.videonext.stratus.sdk2.objectmanagement.DeviceListRequestor;
import com.videonext.stratus.sdk2.objectmanagement.DeviceListRequestor.DeviceInfo;
import com.videonext.stratus.sdk2.objectmanagement.DeviceListRequestor.DeviceType;
import com.videonext.stratus.sdk2.session.Session;

public class CameraAttrs {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Session session = Session.getSession();
		String masterHost = "vtm.videonext.com";

		try {
			// Do not use this in a production environment. It sets the
			// application to accept any ssl-cert, defeating the purpose of
			// using ssl.
			session.setTrustAll(true);
			session.openSession(masterHost, "admin", "topse", "http");
			
			Map<Integer, DeviceInfo> result = DeviceListRequestor.getDeviceList(DeviceType.CAMERA, true);
			for(Entry<Integer, DeviceInfo> entry : result.entrySet()){
				System.out.println(entry.getKey() + " : " + entry.getValue());
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
