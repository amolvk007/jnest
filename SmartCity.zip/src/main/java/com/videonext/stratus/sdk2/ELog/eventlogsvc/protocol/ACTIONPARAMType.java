
package com.videonext.stratus.sdk2.ELog.eventlogsvc.protocol;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ACTIONPARAMType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ACTIONPARAMType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;attribute name="NAME" use="required" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="REQUIRED" use="required" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *       &lt;attribute name="TYPE" use="required" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="LOOKUPTABLE" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ACTIONPARAMType")
public class ACTIONPARAMType {

    @XmlAttribute(name = "NAME", required = true)
    protected String name;
    @XmlAttribute(name = "REQUIRED", required = true)
    protected boolean required;
    @XmlAttribute(name = "TYPE", required = true)
    protected String type;
    @XmlAttribute(name = "LOOKUPTABLE")
    protected String lookuptable;

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNAME() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNAME(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the required property.
     * 
     */
    public boolean isREQUIRED() {
        return required;
    }

    /**
     * Sets the value of the required property.
     * 
     */
    public void setREQUIRED(boolean value) {
        this.required = value;
    }

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTYPE() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTYPE(String value) {
        this.type = value;
    }

    /**
     * Gets the value of the lookuptable property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLOOKUPTABLE() {
        return lookuptable;
    }

    /**
     * Sets the value of the lookuptable property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLOOKUPTABLE(String value) {
        this.lookuptable = value;
    }

}
