package com.videonext.stratus.sdk2.media;

import java.awt.Image;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.imageio.ImageIO;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONException;
import org.json.JSONObject;

import com.videonext.stratus.sdk2.session.Session;

public class AuthMngRs {
	private final static Session session = Session.getSession();
	private final static String apiCallPath = "/api/call/authorizationManager";
	
	public static class AuthStream {
		private String url;
		private String authid;
		
		private Map<String, String> params;
		
		public AuthStream(String url, String authid, Map<String, String> params){
			this.setUrl(url);
			this.setAuthid(authid);
			this.setParams(params);
		}

		public String getUrl() {
			return url;
		}

		public void setUrl(String url) {
			this.url = url;
		}

		public String getAuthid() {
			return authid;
		}

		public void setAuthid(String authid) {
			this.authid = authid;
		}

		public Map<String, String> getParams() {
			return params;
		}

		public void setParams(Map<String, String> params) {
			this.params = params;
		}
		
		@Override
		public String toString(){
			String formatted = String.format("url:%s, authid:%s, param:{", url, authid );
			for(Entry<String, String> param : params.entrySet()){
				formatted += String.format("%s:%s, ", param.getKey(), param.getValue());
			}
			formatted += "}";
			return formatted;
		}
	}
	
	/**
	 * Request the authorized stream / url for the specified objid and for the specified stream type (live, archive, snapshot).
	 * Currently the archive mode does not allow additional parameters (such as the archive period you are interested in).
	 * @param objid
	 * @param type
	 * @return
	 * @throws IllegalStateException
	 * @throws ClientProtocolException
	 * @throws IOException
	 * @throws JSONException
	 */
	public static AuthStream getAuth(int objid, StreamType type, boolean analytics) throws IllegalStateException, ClientProtocolException, IOException, JSONException{
		return getAuth(objid, type, 0, 0, analytics);
	}
	
	public static AuthStream getAuth(int objid, StreamType type, long tsFrom, long tsTo, boolean analytics) throws IllegalStateException, ClientProtocolException, IOException, JSONException {
		List<String> params = new ArrayList<String>();
		
		params.add("objid="+objid);
		params.add("streamtype=" + type.toString());
		if(analytics) params.add("analytics=3");
		
		if(tsFrom != 0){
			params.add("time_start=" + tsFrom);
		}
		if(tsTo != 0){
			params.add("time_end=" + tsTo);
		}
		
		JSONObject json = session.readJSONResponse(apiCallPath, params);
		JSONObject result = json.getJSONObject("result");
		
		String url = result.getString("url");
		String authid = result.getString("authid");
		
		JSONObject param = result.getJSONObject("param");
		Map<String, String> paramMap = new HashMap<String, String>();
		for(String paramName : JSONObject.getNames(param)){
			paramMap.put(paramName, param.getString(paramName));
		}
		
		return new AuthStream(url, authid, paramMap);
	}
	
	public enum StreamType {
		LIVE("live"), ARCHIVE("archive"), SNAPSHOT("snapshot");
		
		private final String streamType;
		private StreamType(String streamType){
			this.streamType = streamType;
		}
		
		public String toString(){
			return streamType;
		}
	}
	
	/**
	 * Returns the Java Image object representing the snapshot for the requested objid.
	 * @param objid
	 * @return
	 * @throws IllegalStateException
	 * @throws ClientProtocolException
	 * @throws IOException
	 * @throws JSONException
	 */
	public static Image getSnapshot(int objid) throws IllegalStateException, ClientProtocolException, IOException, JSONException{
		Session session = Session.getSession();
		AuthStream authStream = getAuth(objid, StreamType.SNAPSHOT, 0, 0, false);
		
		HttpClient client = new DefaultHttpClient();
		HttpGet request = new HttpGet(authStream.getUrl());
		session.addSessionCookie(request);
		HttpResponse response = client.execute(request);
		return ImageIO.read(response.getEntity().getContent());
	}
	
	
	
}
