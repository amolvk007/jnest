
package com.videonext.stratus.sdk2.objectmanagement.websvc.types;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for UpdateObjectTask complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="UpdateObjectTask">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Properties" type="{http://skm.videonext.com/om/websvc/types}PropertyList" minOccurs="0"/>
 *         &lt;element name="DeleteProperties" type="{http://skm.videonext.com/om/websvc/types}DeletePropertyList" minOccurs="0"/>
 *         &lt;element name="Methods" type="{http://skm.videonext.com/om/websvc/types}MethodDescList" minOccurs="0"/>
 *         &lt;element name="DeleteMethods" type="{http://skm.videonext.com/om/websvc/types}DeleteMethodList" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="objid" use="required" type="{http://www.w3.org/2001/XMLSchema}int" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "UpdateObjectTask", propOrder = {
    "properties",
    "deleteProperties",
    "methods",
    "deleteMethods"
})
public class UpdateObjectTask {

    @XmlElement(name = "Properties")
    protected PropertyList properties;
    @XmlElement(name = "DeleteProperties")
    protected DeletePropertyList deleteProperties;
    @XmlElement(name = "Methods")
    protected MethodDescList methods;
    @XmlElement(name = "DeleteMethods")
    protected DeleteMethodList deleteMethods;
    @XmlAttribute(name = "objid", required = true)
    protected int objid;

    /**
     * Gets the value of the properties property.
     * 
     * @return
     *     possible object is
     *     {@link PropertyList }
     *     
     */
    public PropertyList getProperties() {
        return properties;
    }

    /**
     * Sets the value of the properties property.
     * 
     * @param value
     *     allowed object is
     *     {@link PropertyList }
     *     
     */
    public void setProperties(PropertyList value) {
        this.properties = value;
    }

    /**
     * Gets the value of the deleteProperties property.
     * 
     * @return
     *     possible object is
     *     {@link DeletePropertyList }
     *     
     */
    public DeletePropertyList getDeleteProperties() {
        return deleteProperties;
    }

    /**
     * Sets the value of the deleteProperties property.
     * 
     * @param value
     *     allowed object is
     *     {@link DeletePropertyList }
     *     
     */
    public void setDeleteProperties(DeletePropertyList value) {
        this.deleteProperties = value;
    }

    /**
     * Gets the value of the methods property.
     * 
     * @return
     *     possible object is
     *     {@link MethodDescList }
     *     
     */
    public MethodDescList getMethods() {
        return methods;
    }

    /**
     * Sets the value of the methods property.
     * 
     * @param value
     *     allowed object is
     *     {@link MethodDescList }
     *     
     */
    public void setMethods(MethodDescList value) {
        this.methods = value;
    }

    /**
     * Gets the value of the deleteMethods property.
     * 
     * @return
     *     possible object is
     *     {@link DeleteMethodList }
     *     
     */
    public DeleteMethodList getDeleteMethods() {
        return deleteMethods;
    }

    /**
     * Sets the value of the deleteMethods property.
     * 
     * @param value
     *     allowed object is
     *     {@link DeleteMethodList }
     *     
     */
    public void setDeleteMethods(DeleteMethodList value) {
        this.deleteMethods = value;
    }

    /**
     * Gets the value of the objid property.
     * 
     */
    public int getObjid() {
        return objid;
    }

    /**
     * Sets the value of the objid property.
     * 
     */
    public void setObjid(int value) {
        this.objid = value;
    }

}
