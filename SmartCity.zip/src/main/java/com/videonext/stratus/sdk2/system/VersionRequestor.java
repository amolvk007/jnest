package com.videonext.stratus.sdk2.system;

import java.io.IOException;

import org.apache.http.client.ClientProtocolException;
import org.json.JSONException;
import org.json.JSONObject;

import com.videonext.stratus.sdk2.session.Session;

public class VersionRequestor {
	private static final Session session = Session.getSession();

	/**
	 * Gets the api version. Either 1.0 or 1.1.
	 * @return
	 * @throws IOException
	 */
	public static String getVersion() throws IOException {
		String apiCallPath = "/api/call/version";
		
		String version = "1.0";
		try {
			JSONObject json = session.readJSONResponse(apiCallPath, null);
			version = json.getString("api"); // should be 1.1 if successful 
			
		} catch (JSONException e) {
			//do nothing, assume 1.0
		} catch (IllegalStateException e) {
			//do nothing
		} catch (ClientProtocolException e) {
			throw new ClientProtocolException(e);
		} catch (IOException e) {
			throw new IOException(e);
		}
		
		return version;

	}
}
