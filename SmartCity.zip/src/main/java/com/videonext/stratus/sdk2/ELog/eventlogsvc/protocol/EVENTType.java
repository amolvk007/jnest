
package com.videonext.stratus.sdk2.ELog.eventlogsvc.protocol;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for EVENTType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="EVENTType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;choice>
 *           &lt;element name="UTC" type="{http://eventlogsvc.videonext.com/protocol}t_time_element"/>
 *           &lt;element name="UTCTIME" type="{http://eventlogsvc.videonext.com/protocol}t_unixtime_element"/>
 *           &lt;element name="LOCALTIME" type="{http://eventlogsvc.videonext.com/protocol}t_unixtime_element"/>
 *           &lt;element name="LOCAL" type="{http://eventlogsvc.videonext.com/protocol}t_time_element"/>
 *         &lt;/choice>
 *         &lt;sequence>
 *           &lt;element name="OBJ" type="{http://eventlogsvc.videonext.com/protocol}OBJType" minOccurs="0"/>
 *           &lt;element name="PROPERTIES" type="{http://eventlogsvc.videonext.com/protocol}PROPERTIESType" minOccurs="0"/>
 *           &lt;element name="WITNESSES" type="{http://eventlogsvc.videonext.com/protocol}WITNESSESType" minOccurs="0"/>
 *           &lt;element name="ACTIONS" type="{http://eventlogsvc.videonext.com/protocol}ACTIONSType" minOccurs="0"/>
 *           &lt;element name="HISTORY" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *           &lt;element name="MEDIASIZE" type="{http://eventlogsvc.videonext.com/protocol}MEDIASIZEType" minOccurs="0"/>
 *         &lt;/sequence>
 *       &lt;/sequence>
 *       &lt;attribute name="ID" use="required" type="{http://www.w3.org/2001/XMLSchema}unsignedInt" />
 *       &lt;attribute name="OBJID" use="required" type="{http://www.w3.org/2001/XMLSchema}unsignedInt" />
 *       &lt;attribute name="SRC" use="required" type="{http://www.w3.org/2001/XMLSchema}unsignedShort" />
 *       &lt;attribute name="STATE" use="required" type="{http://www.w3.org/2001/XMLSchema}unsignedShort" />
 *       &lt;attribute name="PRIORITY" use="required" type="{http://www.w3.org/2001/XMLSchema}unsignedByte" />
 *       &lt;attribute name="LIFESPAN" use="required" type="{http://www.w3.org/2001/XMLSchema}unsignedByte" />
 *       &lt;attribute name="MESSAGE" use="required" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="EVENTTYPE" use="required" type="{http://eventlogsvc.videonext.com/protocol}st_01" />
 *       &lt;attribute name="NOTE" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="TAG" type="{http://eventlogsvc.videonext.com/protocol}paramValueType" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "EVENTType", propOrder = {
    "utc",
    "utctime",
    "localtime",
    "local",
    "obj",
    "properties",
    "witnesses",
    "actions",
    "history",
    "mediasize"
})
public class EVENTType {

    @XmlElement(name = "UTC")
    protected TTimeElement utc;
    @XmlElement(name = "UTCTIME")
    protected TUnixtimeElement utctime;
    @XmlElement(name = "LOCALTIME")
    protected TUnixtimeElement localtime;
    @XmlElement(name = "LOCAL")
    protected TTimeElement local;
    @XmlElement(name = "OBJ")
    protected OBJType obj;
    @XmlElement(name = "PROPERTIES")
    protected PROPERTIESType properties;
    @XmlElement(name = "WITNESSES")
    protected WITNESSESType witnesses;
    @XmlElement(name = "ACTIONS")
    protected ACTIONSType actions;
    @XmlElement(name = "HISTORY")
    protected String history;
    @XmlElement(name = "MEDIASIZE")
    protected MEDIASIZEType mediasize;
    @XmlAttribute(name = "ID", required = true)
    @XmlSchemaType(name = "unsignedInt")
    protected long id;
    @XmlAttribute(name = "OBJID", required = true)
    @XmlSchemaType(name = "unsignedInt")
    protected long objid;
    @XmlAttribute(name = "SRC", required = true)
    @XmlSchemaType(name = "unsignedShort")
    protected int src;
    @XmlAttribute(name = "STATE", required = true)
    @XmlSchemaType(name = "unsignedShort")
    protected int state;
    @XmlAttribute(name = "PRIORITY", required = true)
    @XmlSchemaType(name = "unsignedByte")
    protected short priority;
    @XmlAttribute(name = "LIFESPAN", required = true)
    @XmlSchemaType(name = "unsignedByte")
    protected short lifespan;
    @XmlAttribute(name = "MESSAGE", required = true)
    protected String message;
    @XmlAttribute(name = "EVENTTYPE", required = true)
    protected int eventtype;
    @XmlAttribute(name = "NOTE")
    protected String note;
    @XmlAttribute(name = "TAG")
    protected String tag;

    /**
     * Gets the value of the utc property.
     * 
     * @return
     *     possible object is
     *     {@link TTimeElement }
     *     
     */
    public TTimeElement getUTC() {
        return utc;
    }

    /**
     * Sets the value of the utc property.
     * 
     * @param value
     *     allowed object is
     *     {@link TTimeElement }
     *     
     */
    public void setUTC(TTimeElement value) {
        this.utc = value;
    }

    /**
     * Gets the value of the utctime property.
     * 
     * @return
     *     possible object is
     *     {@link TUnixtimeElement }
     *     
     */
    public TUnixtimeElement getUTCTIME() {
        return utctime;
    }

    /**
     * Sets the value of the utctime property.
     * 
     * @param value
     *     allowed object is
     *     {@link TUnixtimeElement }
     *     
     */
    public void setUTCTIME(TUnixtimeElement value) {
        this.utctime = value;
    }

    /**
     * Gets the value of the localtime property.
     * 
     * @return
     *     possible object is
     *     {@link TUnixtimeElement }
     *     
     */
    public TUnixtimeElement getLOCALTIME() {
        return localtime;
    }

    /**
     * Sets the value of the localtime property.
     * 
     * @param value
     *     allowed object is
     *     {@link TUnixtimeElement }
     *     
     */
    public void setLOCALTIME(TUnixtimeElement value) {
        this.localtime = value;
    }

    /**
     * Gets the value of the local property.
     * 
     * @return
     *     possible object is
     *     {@link TTimeElement }
     *     
     */
    public TTimeElement getLOCAL() {
        return local;
    }

    /**
     * Sets the value of the local property.
     * 
     * @param value
     *     allowed object is
     *     {@link TTimeElement }
     *     
     */
    public void setLOCAL(TTimeElement value) {
        this.local = value;
    }

    /**
     * Gets the value of the obj property.
     * 
     * @return
     *     possible object is
     *     {@link OBJType }
     *     
     */
    public OBJType getOBJ() {
        return obj;
    }

    /**
     * Sets the value of the obj property.
     * 
     * @param value
     *     allowed object is
     *     {@link OBJType }
     *     
     */
    public void setOBJ(OBJType value) {
        this.obj = value;
    }

    /**
     * Gets the value of the properties property.
     * 
     * @return
     *     possible object is
     *     {@link PROPERTIESType }
     *     
     */
    public PROPERTIESType getPROPERTIES() {
        return properties;
    }

    /**
     * Sets the value of the properties property.
     * 
     * @param value
     *     allowed object is
     *     {@link PROPERTIESType }
     *     
     */
    public void setPROPERTIES(PROPERTIESType value) {
        this.properties = value;
    }

    /**
     * Gets the value of the witnesses property.
     * 
     * @return
     *     possible object is
     *     {@link WITNESSESType }
     *     
     */
    public WITNESSESType getWITNESSES() {
        return witnesses;
    }

    /**
     * Sets the value of the witnesses property.
     * 
     * @param value
     *     allowed object is
     *     {@link WITNESSESType }
     *     
     */
    public void setWITNESSES(WITNESSESType value) {
        this.witnesses = value;
    }

    /**
     * Gets the value of the actions property.
     * 
     * @return
     *     possible object is
     *     {@link ACTIONSType }
     *     
     */
    public ACTIONSType getACTIONS() {
        return actions;
    }

    /**
     * Sets the value of the actions property.
     * 
     * @param value
     *     allowed object is
     *     {@link ACTIONSType }
     *     
     */
    public void setACTIONS(ACTIONSType value) {
        this.actions = value;
    }

    /**
     * Gets the value of the history property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHISTORY() {
        return history;
    }

    /**
     * Sets the value of the history property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHISTORY(String value) {
        this.history = value;
    }

    /**
     * Gets the value of the mediasize property.
     * 
     * @return
     *     possible object is
     *     {@link MEDIASIZEType }
     *     
     */
    public MEDIASIZEType getMEDIASIZE() {
        return mediasize;
    }

    /**
     * Sets the value of the mediasize property.
     * 
     * @param value
     *     allowed object is
     *     {@link MEDIASIZEType }
     *     
     */
    public void setMEDIASIZE(MEDIASIZEType value) {
        this.mediasize = value;
    }

    /**
     * Gets the value of the id property.
     * 
     */
    public long getID() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     */
    public void setID(long value) {
        this.id = value;
    }

    /**
     * Gets the value of the objid property.
     * 
     */
    public long getOBJID() {
        return objid;
    }

    /**
     * Sets the value of the objid property.
     * 
     */
    public void setOBJID(long value) {
        this.objid = value;
    }

    /**
     * Gets the value of the src property.
     * 
     */
    public int getSRC() {
        return src;
    }

    /**
     * Sets the value of the src property.
     * 
     */
    public void setSRC(int value) {
        this.src = value;
    }

    /**
     * Gets the value of the state property.
     * 
     */
    public int getSTATE() {
        return state;
    }

    /**
     * Sets the value of the state property.
     * 
     */
    public void setSTATE(int value) {
        this.state = value;
    }

    /**
     * Gets the value of the priority property.
     * 
     */
    public short getPRIORITY() {
        return priority;
    }

    /**
     * Sets the value of the priority property.
     * 
     */
    public void setPRIORITY(short value) {
        this.priority = value;
    }

    /**
     * Gets the value of the lifespan property.
     * 
     */
    public short getLIFESPAN() {
        return lifespan;
    }

    /**
     * Sets the value of the lifespan property.
     * 
     */
    public void setLIFESPAN(short value) {
        this.lifespan = value;
    }

    /**
     * Gets the value of the message property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMESSAGE() {
        return message;
    }

    /**
     * Sets the value of the message property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMESSAGE(String value) {
        this.message = value;
    }

    /**
     * Gets the value of the eventtype property.
     * 
     */
    public int getEVENTTYPE() {
        return eventtype;
    }

    /**
     * Sets the value of the eventtype property.
     * 
     */
    public void setEVENTTYPE(int value) {
        this.eventtype = value;
    }

    /**
     * Gets the value of the note property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNOTE() {
        return note;
    }

    /**
     * Sets the value of the note property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNOTE(String value) {
        this.note = value;
    }

    /**
     * Gets the value of the tag property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTAG() {
        return tag;
    }

    /**
     * Sets the value of the tag property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTAG(String value) {
        this.tag = value;
    }

}
