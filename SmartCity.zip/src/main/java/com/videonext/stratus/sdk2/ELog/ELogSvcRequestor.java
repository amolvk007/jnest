package com.videonext.stratus.sdk2.ELog;

import com.videonext.stratus.sdk2.ELog.eventlogsvc.EvSvcPortType;
import com.videonext.stratus.sdk2.ELog.eventlogsvc.EventLogService;
import com.videonext.stratus.sdk2.ELog.eventlogsvc.protocol.*;
import com.videonext.stratus.sdk2.session.Session;

import javax.xml.namespace.QName;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.Service;
import javax.xml.ws.handler.MessageContext;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ELogSvcRequestor {
	private static final Session session = Session.getSession();

	private static final QName qELog = new QName(
			"http://eventlogsvc.videonext.com", "EventLogService");
	private static final QName eLogPort = new QName(
			"http://eventlogsvc.videonext.com", "EvSvcPort");

	protected static final ObjectFactory reqFactory = new ObjectFactory();

	public static OPTIONType createOption(StOptname name, StOptvalue value) {
		OPTIONType option = reqFactory.createOPTIONType();
		option.setName(name);
		option.setValue(value);
		return option;
	}


	/**
	 * Pull all events that match the various parameters you pass
	 * 
	 * @param filter
	 *            Filter for returned events
	 * @param pagebreak
	 *            Defines the number of event entries to return. If there are
	 *            more entries than PAGEBREAKSize, it will be split to multiple
	 *            pages. Set PAGE to which page you would like to view.
	 * @param options
	 *            Set the output options defining what all information will be
	 *            returned. You can use the 'createOption' helper function to
	 *            add new options.
	 * @return
	 * @throws MalformedURLException
	 */
	public static EVENTRESPONSEType getEvents(FILTERType filter,
			PAGEBREAKType pagebreak, OUTPUTOPTIONSType options)
			throws MalformedURLException {

        SSLUtilities.trustAllHostnames();
        SSLUtilities.trustAllHttpsCertificates();

        Service service = EventLogService.create(
				new URL("http://" + session.getMasterHost()
						+ "/cxf/webservices/EventLogService?wsdl"), qELog);

		EvSvcPortType port = service.getPort(eLogPort, EvSvcPortType.class);
		service.addPort(qELog, javax.xml.ws.soap.SOAPBinding.SOAP12HTTP_MTOM_BINDING, "http://" + session.getMasterHost()
						+ "/cxf/webservices/EventLogService");
		List<String> headers = new ArrayList<String>();
		headers.add("PHPSESSID=" + session.getSessionId() +
			"; token=" + session.getTokenId());
		BindingProvider bp = (BindingProvider)port;
		bp.getRequestContext().put(
				MessageContext.HTTP_REQUEST_HEADERS,
				Collections.singletonMap("Cookie", headers));
		bp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY,"http://" + session.getMasterHost()
		+ "/cxf/webservices/EventLogService");

		EVENTREQUESTType request = reqFactory.createEVENTREQUESTType();

		request.setFILTER(filter);
		request.setOUTPUTOPTIONS(options);
		request.setPAGEBREAK(pagebreak);

		return port.getEvents(request);
	}

	/**
	 * Grabs the last 50 events from any source
	 * 
	 * @return
	 * @throws MalformedURLException
	 */
	public static EVENTRESPONSEType getEvents() throws MalformedURLException {
		FILTERType filter = reqFactory.createFILTERType();

		PAGEBREAKType pagebreak = reqFactory.createPAGEBREAKType();
		pagebreak.setPAGESIZE(50);

		OUTPUTOPTIONSType outops = reqFactory.createOUTPUTOPTIONSType();
		List<OPTIONType> ops = outops.getOPTION();
		ops.add(createOption(StOptname.PROPERTIES, StOptvalue.TRUE));
		ops.add(createOption(StOptname.OBJINFO, StOptvalue.TRUE));

		return getEvents(filter, pagebreak, outops);
	}

}
