
package com.videonext.stratus.sdk2.objectmanagement.websvc.types;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="CreateObjectTask" type="{http://skm.videonext.com/om/websvc/types}CreateObjectTask" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="UpdateObjectTask" type="{http://skm.videonext.com/om/websvc/types}UpdateObjectTask" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="DeleteObjectTask" type="{http://skm.videonext.com/om/websvc/types}ObjectRef" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="requestorId" use="required" type="{http://www.w3.org/2001/XMLSchema}int" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "createObjectTask",
    "updateObjectTask",
    "deleteObjectTask"
})
@XmlRootElement(name = "ModifyObjectsRequest")
public class ModifyObjectsRequest {

    @XmlElement(name = "CreateObjectTask")
    protected List<CreateObjectTask> createObjectTask;
    @XmlElement(name = "UpdateObjectTask")
    protected List<UpdateObjectTask> updateObjectTask;
    @XmlElement(name = "DeleteObjectTask")
    protected List<ObjectRef> deleteObjectTask;
    @XmlAttribute(name = "requestorId", required = true)
    protected int requestorId;

    /**
     * Gets the value of the createObjectTask property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the createObjectTask property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCreateObjectTask().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CreateObjectTask }
     * 
     * 
     */
    public List<CreateObjectTask> getCreateObjectTask() {
        if (createObjectTask == null) {
            createObjectTask = new ArrayList<CreateObjectTask>();
        }
        return this.createObjectTask;
    }

    /**
     * Gets the value of the updateObjectTask property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the updateObjectTask property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getUpdateObjectTask().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link UpdateObjectTask }
     * 
     * 
     */
    public List<UpdateObjectTask> getUpdateObjectTask() {
        if (updateObjectTask == null) {
            updateObjectTask = new ArrayList<UpdateObjectTask>();
        }
        return this.updateObjectTask;
    }

    /**
     * Gets the value of the deleteObjectTask property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the deleteObjectTask property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDeleteObjectTask().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ObjectRef }
     * 
     * 
     */
    public List<ObjectRef> getDeleteObjectTask() {
        if (deleteObjectTask == null) {
            deleteObjectTask = new ArrayList<ObjectRef>();
        }
        return this.deleteObjectTask;
    }

    /**
     * Gets the value of the requestorId property.
     * 
     */
    public int getRequestorId() {
        return requestorId;
    }

    /**
     * Sets the value of the requestorId property.
     * 
     */
    public void setRequestorId(int value) {
        this.requestorId = value;
    }

}
