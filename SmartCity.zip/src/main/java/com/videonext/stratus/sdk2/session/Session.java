package com.videonext.stratus.sdk2.session;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.cookie.Cookie;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URLConnection;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Session {
	protected static final String SESSION_COOKIE = "PHPSESSID";
	protected static final String TOKEN = "token";
	private String masterHost;
	private String sessionId = null;
	private String tokenId = null;
	private static Session activeSession = null;
	private boolean isactive = false;
	private boolean trustAll = false;
	private String connType = "https";

	private final static Logger logger = Logger
			.getLogger(com.videonext.stratus.sdk2.session.Session.class
					.getName());
        
        private final static char[] hexArray = "0123456789abcdef".toCharArray();

	protected Session() {
		// making Session unable to be instantiated, singleton
		logger.setLevel(Level.WARNING);
	}
	
	public void setLogger(Level level){
		logger.setLevel(level);
	}

	/**
	 * Gets the singleton session, or returns null
	 * 
	 * @return
	 */
	public static synchronized Session getSession() {
		if (activeSession == null)
			activeSession = new Session();
		return activeSession;
	}

	/**
	 * By default Stratus comes installed with a self-signed certificate. Java
	 * refuses to recognize self-signed certificates, so setting this option to
	 * 'true' forces Java to accept all certificates.
	 * 
	 * It is not recommend that you use this setting in a production
	 * environment.
	 * 
	 * @param trust
	 */
	public void setTrustAll(boolean trust) {
		this.trustAll = trust;
	}

	private DefaultHttpClient getNewHttpClient() {
		DefaultHttpClient base = new DefaultHttpClient();
		if (trustAll) {
			try {
				SSLContext ctx = SSLContext.getInstance("TLS");
				X509TrustManager tm = new X509TrustManager() {

					public void checkClientTrusted(X509Certificate[] xcs,
							String string) throws CertificateException {
					}

					public void checkServerTrusted(X509Certificate[] xcs,
							String string) throws CertificateException {
					}

					public X509Certificate[] getAcceptedIssuers() {
						return null;
					}
				};

				ctx.init(null, new TrustManager[] { tm }, null);
				SSLSocketFactory ssf = new SSLSocketFactory(ctx,
						SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
				ClientConnectionManager ccm = base.getConnectionManager();
				SchemeRegistry sr = ccm.getSchemeRegistry();
				sr.register(new Scheme("https", 443, ssf));
				return new DefaultHttpClient(ccm, base.getParams());
			} catch (Exception ex) {
				ex.printStackTrace();
				return null;
			}
		} else {
			return base;
		}
	}

	/**
	 * 
	 * @param masterHost
	 * @param username
	 * @param password
	 * @return
	 * @throws IOException
	 * @throws ClientProtocolException
	 * @throws JSONException
	 * @throws IllegalStateException
	 * @throws Exception
	 */
	public boolean openSession(String masterHost, String username,
			String password) throws ClientProtocolException, IOException,
			IllegalStateException, JSONException {
		return openSession(masterHost, username, password, "http");
	}

	/**
	 * 
	 * @param masterHost
	 * @param username
	 * @param password
	 * @return
	 * @throws IOException
	 * @throws ClientProtocolException
	 * @throws JSONException
	 * @throws IllegalStateException
	 * @throws Exception
	 */
	public boolean openSession(String masterHost, String username,
			String password, String connType) throws ClientProtocolException,
			IOException, IllegalStateException, JSONException {
		this.masterHost = masterHost;
		this.connType = connType;

		//
		// Phase 1. GETting login information + hash salt
		//

		DefaultHttpClient client = getNewHttpClient();

		HttpGet request = new HttpGet(connType + "://" + masterHost
				+ "/api/call/getLoginInfo");
		HttpResponse response = client.execute(request);

		List<Cookie> cookies = client.getCookieStore().getCookies();
		setCookies(cookies);

		String encryptionKey = readEncryptionKey(response);

		if (encryptionKey == null) {
			throw new org.apache.http.ParseException(
					"Failed to parse login info documents: missing required parameter \"ENCRYPTIONKEY\"");
		}

		//
		// Phase 2. Calculate password hash
		//
		String passwordHash = getSHADigest(password, encryptionKey);

		//
		// Phase 3. POSTing login parameters and completing login.
		//
		Map<String, String> params = new HashMap<String, String>();
		params.put("name", username);
		params.put("credentials", passwordHash);

		List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(
				params.size() + 1);
		for (Entry<String, String> param : params.entrySet()) {
			BasicNameValuePair bnvp = new BasicNameValuePair(param.getKey(),
					param.getValue());
			nameValuePairs.add(bnvp);
		}

		// add CSRF token
		nameValuePairs.add(new BasicNameValuePair("token", tokenId));

		client = getNewHttpClient();

		HttpPost post = new HttpPost(connType + "://" + masterHost
				+ "/api/call/login");
		post.setEntity(new UrlEncodedFormEntity(nameValuePairs));
		addSessionCookie(post);
		response = client.execute(post);

                if (response.getStatusLine().getStatusCode() != 200) {
                    isactive = false;
                    readJSONResponse(response);
                }
                else {
                    cookies = client.getCookieStore().getCookies();
                    setCookies(cookies);

                    isactive = true;
                }
                
		return isactive;

	}

	/**
	 * Using SHA-512 digest algorithm, calculates 'sha-512( encryptionKey +
	 * (sha-512(password)) + encryptionKey)'. The resulting Byte array is
	 * returned as a lower-case hex string.
	 * 
	 * @param value
	 * @param digestKey
	 * @return returns SHA1 digest of value and digestKey
	 */
	private String getSHADigest(String value, String digestKey) {
		String digest = null;
		MessageDigest sha;

		byte[] valueBytes;
		try {
			sha = MessageDigest.getInstance("SHA-512");
			valueBytes = value.getBytes("US-ASCII");
			byte[] valueDigest = sha.digest(valueBytes);

			digest = bytesToHex(valueDigest);
			if ((digestKey != null) && !"".equals(digestKey)) {
				String tmp = digestKey + digest + digestKey;

				byte[] combinedBytes = tmp.getBytes("US-ASCII");
				byte[] combinedDigest = sha.digest(combinedBytes);
				digest = bytesToHex(combinedDigest);
			}
		} catch (UnsupportedEncodingException e) {
			// Should never happen
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			// Should never happen
			e.printStackTrace();
		}
		return digest;
	}

	/**
	 * Parses server response and sets the session and token cookie values
	 * 
	 * @param cookies
	 * @throws IOException
	 * @throws Exception
	 */
	private void setCookies(List<Cookie> cookies) throws IOException {
		String tokenId = "";
		String sessionId = "";

		for (Cookie cookie : cookies) {
			if (cookie.getName().equals(SESSION_COOKIE))
				sessionId = cookie.getValue();
			if (cookie.getName().equals(TOKEN))
				tokenId = cookie.getValue();
		}

		if (sessionId == null)
			throw new IOException("No SessionID found");

		if (tokenId == null)
			throw new IOException("No Token found");

		setTokenId(tokenId);
		setSessionId(sessionId);
	}

	/**
	 * Logs out of the session and closes it
	 */
	public void close() {
		if (sessionId != null) {
			try {
				HttpClient client = getNewHttpClient();
				HttpGet request = new HttpGet(connType + "://" + masterHost
						+ "/api/call/logout");
				client.execute(request);
			} catch (Exception e) {
			}

			sessionId = null;
			tokenId = null;
			activeSession = null;
		}
	}

	/* ****************************************************************
	 * * Below here are mostly getters, setters, and helper functions *
	 * ****************************************************************
	 */

	@Deprecated
	/**
	 * 
	 * @param masterHost
	 * @param username
	 * @param password
	 * @throws Exception
	 */
	public void open(String masterHost, String username, String password)
			throws Exception {
		openSession(masterHost, username, password);
	}

	public String getMasterHost() {
		return this.masterHost;
	}

	public String getSessionId() {
		return sessionId;
	}

	private void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	public String getTokenId() {
		return tokenId;
	}

	private void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}
        
        private String bytesToHex(byte[] bytes) {
            char[] hexChars = new char[bytes.length * 2];
            for ( int j = 0; j < bytes.length; j++ ) {
                int v = bytes[j] & 0xFF;
                hexChars[j * 2] = hexArray[v >>> 4];
                hexChars[j * 2 + 1] = hexArray[v & 0x0F];
            }
            return new String(hexChars);
        }

	/**
	 * Simple helper function to parse the JSON response of 'getLoginInfo' for
	 * the value of 'encryptionKey'
	 * 
	 * @param response
	 *            the HttpResponse object of the HTTP GET call to 'getLoginInfo'
	 * @return The encryptionKey salt for password digest
	 * @throws JSONException
	 * @throws IOException
	 * @throws IllegalStateException
	 * @throws Exception
	 */
	private String readEncryptionKey(HttpResponse response)
			throws IllegalStateException, IOException, JSONException {
		JSONObject json = readJSONResponse(response);
		return json.getJSONObject("loginInfo").getString("encryptionKey");
	}

	/**
	 * adds Session cookies to the HttpGet client
	 * 
	 * @param client
	 */
	public void addSessionCookie(HttpGet client) {
		client.addHeader("Cookie", String.format("%s=%s; %s=%s",
				SESSION_COOKIE, sessionId, TOKEN, tokenId));
	}

	/**
	 * adds Session cookies to the HttpPost client
	 * 
	 * @param post
	 */
	private void addSessionCookie(HttpPost post) {
		post.addHeader("Cookie", String.format("%s=%s; %s=%s", SESSION_COOKIE,
				sessionId, TOKEN, tokenId));
	}

	/**
	 * Adds session and token cookies to the URLConnection
	 * 
	 * @param connection
	 */
	public URLConnection addSessionCookie(URLConnection connection) {
		connection.setRequestProperty("Cookie", SESSION_COOKIE + "="
				+ sessionId + ";" + TOKEN + "=" + tokenId);
		// connection.setRequestProperty("Cookie", TOKEN + "=" + tokenId);
		return connection;
	}

	/**
	 * Make HTTP GET call and parse response as JSON
	 * 
	 * @param url
	 * @return
	 * @throws JSONException
	 * @throws IOException
	 * @throws ClientProtocolException
	 * @throws IllegalStateException
	 * @throws Exception
	 */
	public JSONObject readJSONResponse(String url, List<String> params)
			throws IllegalStateException, ClientProtocolException, IOException,
			JSONException {
		return this.readJSONResponse(this.httpGetCall(url, params));
	}

	/**
	 * Parse HttpResponse for JSON objects
	 * 
	 * @param response
	 * @return
	 * @throws IOException
	 * @throws IllegalStateException
	 * @throws JSONException
	 * @throws Exception
	 */
	public JSONObject readJSONResponse(HttpResponse response)
			throws IllegalStateException, IOException, JSONException {
		String jsonResponse = "";

		BufferedReader rd = new BufferedReader(new InputStreamReader(response
				.getEntity().getContent()));

		String line = null;
		while ((line = rd.readLine()) != null) {
			jsonResponse += line;
		}

		JSONObject json = new JSONObject(jsonResponse);
		
		logger.log(Level.INFO, json.toString());
		
		try {
			Integer code = Integer.parseInt(json.getString("code"));
			if (code != 200) {
				throw new org.apache.http.client.HttpResponseException(code,
						json.getString("error"));
			}
		} catch (JSONException je) {
			throw new JSONException("Expected call results, got: "
					+ jsonResponse);
		}

		return json;
	}

	/**
	 * Execute HTTP GET call on the provided URL. This function will handle CSRF
	 * tokens and cookies on its own.
	 * 
	 * @param url
	 *            Full URL of call, including server IP
	 * @return The response of making this call
	 * @throws ClientProtocolException
	 * @throws IOException
	 */
	public HttpResponse httpGetCall(String url, List<String> params)
			throws ClientProtocolException, IOException {
		return httpGetCall(url, params, true);
	}

	/**
	 * Execute HTTP GET call on the provided URL. This function will handle CSRF
	 * tokens and cookies on its own, if addToken is TRUE.
	 * 
	 * @param url
	 *            Full URL of call, including server IP
	 * @param params
	 *            list of key-value pairs to be passed on GET request
	 * @param addToken
	 *            Set to FALSE to not include CSRF token (e.g. when first
	 *            getting login documents)
	 * @return The response of making this call
	 * @throws ClientProtocolException
	 * @throws IOException
	 */
	public HttpResponse httpGetCall(String url, List<String> params,
			boolean addToken) throws ClientProtocolException, IOException {

		if (addToken) {
			url += "?token=" + this.tokenId;
		} else if (params != null) {
			url += "?" + params.get(0);
			params.remove(0);
		}

		if (params != null) {
			for (String param : params)
				url += "&" + param;
		}

		HttpClient client = getNewHttpClient();

		logger.log(Level.INFO, url);
		HttpGet request = new HttpGet(connType + "://" + masterHost + url);

		addSessionCookie(request);

		return client.execute(request);
	}

	/**
	 * Execute HTTP POST call on the provided URL. This function will handle
	 * CSRF tokens and cookies on its own.
	 * 
	 * @param url
	 *            Full URL of call, including server IP
	 * @param params
	 *            Map of POST parameters to to send
	 * @return The response of making this call
	 * @throws ClientProtocolException
	 * @throws IOException
	 */
	public HttpResponse httpPostCall(String url, Map<String, String> params)
			throws ClientProtocolException, IOException {
		List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(
				params.size() + 1);
		for (Entry<String, String> param : params.entrySet()) {
			nameValuePairs.add(new BasicNameValuePair(param.getKey(), param
					.getValue()));
		}

		// add CSRF token
		nameValuePairs.add(new BasicNameValuePair("token", tokenId));
		logger.log(Level.INFO, url);
		logger.log(Level.INFO, nameValuePairs.toString());
		HttpClient client = getNewHttpClient();
		HttpPost post = new HttpPost(connType + "://" + masterHost + url);
		post.setEntity(new UrlEncodedFormEntity(nameValuePairs));
		addSessionCookie(post);

        return client.execute(post);
	}

	@Deprecated
	/**
	 * @deprecated Use getXMLResponse as its name is more indicative of what it does
	 * @param relativePath
	 * @return
	 * @throws ClientProtocolException
	 * @throws IllegalStateException
	 * @throws IOException
	 * @throws ParserConfigurationException
	 * @throws SAXException
	 */
	public Document getAPICallDocument(String relativePath)
			throws ClientProtocolException, IllegalStateException, IOException,
			ParserConfigurationException, SAXException {
		return getXMLResponse(relativePath);
	}

	/**
	 * 
	 * @param relativePath
	 * @return
	 * @throws ClientProtocolException
	 * @throws IOException
	 * @throws ParserConfigurationException
	 * @throws IllegalStateException
	 * @throws SAXException
	 */
	public Document getXMLResponse(String relativePath)
			throws ClientProtocolException, IOException,
			ParserConfigurationException, IllegalStateException, SAXException {

		relativePath += "&token=" + this.tokenId;

		logger.log(Level.INFO, "xml call path: " + relativePath);

		HttpResponse response = httpGetCall(relativePath, null, false);

		Document doc = null;

		// parse response
		//
		DocumentBuilderFactory builderFactory = DocumentBuilderFactory
				.newInstance();
		DocumentBuilder documentBuilder = builderFactory.newDocumentBuilder();

		doc = documentBuilder.parse(response.getEntity().getContent());
		Element docElement = doc.getDocumentElement();

		// parse request status
		//
		NodeList nl = docElement.getElementsByTagName("STATUS");
		if (nl != null && nl.getLength() > 0) {
			Element statusElement = (Element) nl.item(0);
			String status = statusElement.getAttribute("VALUE");

			if (status == null) {
				throw new org.w3c.dom.DOMException((short) 0,
						"Failed to get request status: missing attribute STATUS.VALUE");
			} else if (!status.equalsIgnoreCase("OK")) {
				String msg = statusElement.getAttribute("MESSAGE");
				throw new javax.xml.parsers.ParserConfigurationException(
						"Failed to get resource list: "
								+ ((msg == null) ? "unknown error" : msg));
			}
		}
		return doc;

	}

	public void finalize() {
		if (activeSession.isActive()) {
			activeSession.close();
		}
		activeSession = null;
	}

	private boolean isActive() {
		return isactive;
	}

	public void destroy() {
		this.finalize();
	}
}
