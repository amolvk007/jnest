package com.videonext.stratus.sdk2.examples;

/**
 * Please modify this class to meet your needs
 * This class is not complete
 */

import java.util.Map;
import com.videonext.stratus.sdk2.objectmanagement.DeviceListRequestor;
import com.videonext.stratus.sdk2.objectmanagement.DeviceListRequestor.DeviceInfo;
import com.videonext.stratus.sdk2.objectmanagement.DeviceListRequestor.DeviceType;
import com.videonext.stratus.sdk2.session.Session;
import com.videonext.stratus.sdk2.vmx.WallSvcFactory;
import com.videonext.stratus.sdk2.vmx.WallSvcPortType;
import com.videonext.stratus.sdk2.vmx.protocol.*;

public final class WallSvcTest {
	private static final Session session = Session.getSession();

	public static void main(String args[]) throws java.lang.Exception {
		session.openSession("demo-10.videonext.com", "admin", "topse", "http");
		//session.setLogger(Level.INFO);
		WallSvcFactory factory = new WallSvcFactory();

		/*
		 * Getting a properly configured port is a bit of a pain, so use the
		 * WallSvcFactory to make one
		 */
		WallSvcPortType port = factory.createWallSvcPort();

		WallListType walls = port.getWalls(session.getSessionId());

		Map<Integer, DeviceInfo> devList = DeviceListRequestor.getDeviceList(DeviceType.CAMERA, true);
		for (WallType wall : walls.getWall()) {
			System.out.println(wall.getId() + " - " + wall.getName() + "["
					+ wall.getRows() + "x" + wall.getCols() + "]");
			for (WallCellType cell : wall.getWallCell()) {
				System.out.println("   " + cell.getMonid());

				/*
				 * We need to create an 'ObjectIdRequest' object, which includes
				 * the object id and the session id. To save on space, you can
				 * use the factory to create one;
				 */
				ObjectIdRequest objectIDIn = factory.createObjectIdRequest(cell
						.getMonid());
				MonitorStateOut monitorState = port.getMonitorState(objectIDIn);

				for (CellType monCell : monitorState.getMonitorInfo().getCell()) {
					System.out.print("      " + monCell.getId() + " - "
							+ monCell.getSourceOBJID());
					if (monCell.getSourceOBJID() > 0) {
						System.out.print(" \"" + devList.get((int)(long)monCell.getSourceOBJID()).getAttrs().get("NAME") + "\"");
					}
					System.out.println();
				}
			}
		}


        SplitInfo split_info = new SplitInfo();
        split_info.setSessionID(session.getSessionId());
        CellmatrixType cellMatrix = new CellmatrixType();
        cellMatrix.setCols((short)2);
        cellMatrix.setRows((short) 2);
        split_info.setObjectID(114);
        split_info.setCellmatrix(cellMatrix);

        for(int i=0; i<4 ; i++){
            CellType cellType = new CellType();
            cellType.setScale(ScaleType.CELL);
            cellType.setId("cell"+i);
            cellType.setSourceOBJID(101l);
            cellType.setState(StateType.PLAY);

            split_info.getCell().add(cellType);
        }



        BooleanOut booleanOut = port.splitMonitor(split_info);

        System.out.println("Split monitor result: " + booleanOut.isResult() + " ("+booleanOut.getErrorMessage()+")");

        System.exit(0);
	}
}
