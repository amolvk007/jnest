
package com.videonext.stratus.sdk2.vmx.protocol;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for TouringType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="TouringType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://websvc.videonext.com/protocol}Priority" minOccurs="0"/>
 *         &lt;element name="SOURCE" type="{http://websvc.videonext.com/protocol}TOURSOURCEType" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="SessionID" use="required" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="MonitorOBJID" use="required" type="{http://www.w3.org/2001/XMLSchema}unsignedInt" />
 *       &lt;attribute name="CellID" use="required" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="DelaySeconds" use="required" type="{http://www.w3.org/2001/XMLSchema}unsignedByte" />
 *       &lt;attribute name="Position" type="{http://www.w3.org/2001/XMLSchema}int" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TouringType", propOrder = {
    "priority",
    "source"
})
public class TouringType {

    @XmlElement(name = "Priority")
    protected CellPriorityType priority;
    @XmlElement(name = "SOURCE")
    protected List<TOURSOURCEType> source;
    @XmlAttribute(name = "SessionID", required = true)
    protected String sessionID;
    @XmlAttribute(name = "MonitorOBJID", required = true)
    @XmlSchemaType(name = "unsignedInt")
    protected long monitorOBJID;
    @XmlAttribute(name = "CellID", required = true)
    protected String cellID;
    @XmlAttribute(name = "DelaySeconds", required = true)
    @XmlSchemaType(name = "unsignedByte")
    protected short delaySeconds;
    @XmlAttribute(name = "Position")
    protected Integer position;

    /**
     * Gets the value of the priority property.
     * 
     * @return
     *     possible object is
     *     {@link CellPriorityType }
     *     
     */
    public CellPriorityType getPriority() {
        return priority;
    }

    /**
     * Sets the value of the priority property.
     * 
     * @param value
     *     allowed object is
     *     {@link CellPriorityType }
     *     
     */
    public void setPriority(CellPriorityType value) {
        this.priority = value;
    }

    /**
     * Gets the value of the source property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the source property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSOURCE().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link TOURSOURCEType }
     * 
     * 
     */
    public List<TOURSOURCEType> getSOURCE() {
        if (source == null) {
            source = new ArrayList<TOURSOURCEType>();
        }
        return this.source;
    }

    /**
     * Gets the value of the sessionID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSessionID() {
        return sessionID;
    }

    /**
     * Sets the value of the sessionID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSessionID(String value) {
        this.sessionID = value;
    }

    /**
     * Gets the value of the monitorOBJID property.
     * 
     */
    public long getMonitorOBJID() {
        return monitorOBJID;
    }

    /**
     * Sets the value of the monitorOBJID property.
     * 
     */
    public void setMonitorOBJID(long value) {
        this.monitorOBJID = value;
    }

    /**
     * Gets the value of the cellID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCellID() {
        return cellID;
    }

    /**
     * Sets the value of the cellID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCellID(String value) {
        this.cellID = value;
    }

    /**
     * Gets the value of the delaySeconds property.
     * 
     */
    public short getDelaySeconds() {
        return delaySeconds;
    }

    /**
     * Sets the value of the delaySeconds property.
     * 
     */
    public void setDelaySeconds(short value) {
        this.delaySeconds = value;
    }

    /**
     * Gets the value of the position property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getPosition() {
        return position;
    }

    /**
     * Sets the value of the position property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setPosition(Integer value) {
        this.position = value;
    }

}
