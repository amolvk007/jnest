
package com.videonext.stratus.sdk2.objectmanagement.websvc.types;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Host complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Host">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;attribute name="objid" use="required" type="{http://www.w3.org/2001/XMLSchema}int" />
 *       &lt;attribute name="lanaddress" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="lanmediaport" type="{http://www.w3.org/2001/XMLSchema}int" />
 *       &lt;attribute name="wanaddress" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="wanmediaport" type="{http://www.w3.org/2001/XMLSchema}int" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Host")
public class Host {

    @XmlAttribute(name = "objid", required = true)
    protected int objid;
    @XmlAttribute(name = "lanaddress")
    protected String lanaddress;
    @XmlAttribute(name = "lanmediaport")
    protected Integer lanmediaport;
    @XmlAttribute(name = "wanaddress")
    protected String wanaddress;
    @XmlAttribute(name = "wanmediaport")
    protected Integer wanmediaport;

    /**
     * Gets the value of the objid property.
     * 
     */
    public int getObjid() {
        return objid;
    }

    /**
     * Sets the value of the objid property.
     * 
     */
    public void setObjid(int value) {
        this.objid = value;
    }

    /**
     * Gets the value of the lanaddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLanaddress() {
        return lanaddress;
    }

    /**
     * Sets the value of the lanaddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLanaddress(String value) {
        this.lanaddress = value;
    }

    /**
     * Gets the value of the lanmediaport property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getLanmediaport() {
        return lanmediaport;
    }

    /**
     * Sets the value of the lanmediaport property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setLanmediaport(Integer value) {
        this.lanmediaport = value;
    }

    /**
     * Gets the value of the wanaddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWanaddress() {
        return wanaddress;
    }

    /**
     * Sets the value of the wanaddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWanaddress(String value) {
        this.wanaddress = value;
    }

    /**
     * Gets the value of the wanmediaport property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getWanmediaport() {
        return wanmediaport;
    }

    /**
     * Sets the value of the wanmediaport property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setWanmediaport(Integer value) {
        this.wanmediaport = value;
    }

}
