package com.videonext.stratus.sdk2.examples;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Scanner;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;

import com.facebook.thrift.TException;
import com.videonext.skm.fw.servicing.*;
import com.videonext.skm.elog.iface.*;

import org.apache.http.client.ClientProtocolException;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.util.ArrayList;

import com.videonext.stratus.sdk2.ptz.PTZController;
import com.videonext.stratus.sdk2.session.Session;

public class ELogPTZController {

	public static void main(String[] args) throws ClientProtocolException,
			IllegalStateException, IOException, JSONException {
		Session session = Session.getSession();
		String host = args[0];
		String fileName = args[1];
		session.openSession(host, "admin", "topse", "http");
		ELogPTZController pc = new ELogPTZController();

		BlockingQueue<Event> eventQueue = new LinkedBlockingQueue<Event>();
		HashMap<Integer, ArrayList<Binding>> ruleBinding = new HashMap<Integer, ArrayList<Binding>>();

		File file = new File(fileName);
		String content = new Scanner(file).useDelimiter("\\Z").next();
		JSONTokener tokener = new JSONTokener(content);

		JSONObject root = new JSONObject(tokener);

		for (String objid : JSONObject.getNames(root)) {
			JSONArray ruleArray = root.getJSONArray(objid);
			ArrayList<Binding> array = new ArrayList<Binding>();
			for (int i = 0; i < ruleArray.length(); i++) {
				JSONObject bind = ruleArray.getJSONObject(i);

				array.add(pc.new Binding(bind.getString("rule"), bind
						.getInt("ptzObj"), bind.getInt("preset")));
			}
			ruleBinding.put(Integer.parseInt(objid), array);
		}
		System.out.println(ruleBinding.toString());
		//System.exit(0);

		PtzProcessor ptz = pc.new PtzProcessor(eventQueue, ruleBinding);
		Executors.newSingleThreadExecutor().execute(ptz);

		NotificationListener notificationListener = new NotificationListener(
				host);

		try {
			notificationListener.processNotifications(
					"skm.eventlog.notifications",
					new ELogNotification.Processor(new NotificationReciever(
							eventQueue)), new StateListener(), session
							.getSessionId());
			Thread.sleep(5 * 60 * 1000);// sleep for 5 minutes
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			notificationListener.close();
		}

	}

	protected class Binding {
		String rule;
		int ptzObj;
		int preset;

		public Binding(String rule, int ptzObj, int preset) {
			this.rule = rule;
			this.preset = preset;
			this.ptzObj = ptzObj;
		}
		
		@Override
		public String toString(){
			return String.format("%d - %s => %d", ptzObj, rule, preset);
		}
	}

	protected class PtzProcessor implements Runnable {
		private BlockingQueue<Event> eventQueue;
		private HashMap<Integer, ArrayList<Binding>> ruleBinding;

		public PtzProcessor(BlockingQueue<Event> eventQueue,
				HashMap<Integer, ArrayList<Binding>> ruleBinding) {
			this.eventQueue = eventQueue;
			this.ruleBinding = ruleBinding;
		}

		@Override
		public void run() {
			Event event;
			while (true) {
				try {
					event = eventQueue.take();
					System.out.println("Checking event:" + event.id + "-"+event.objId+":"+event.msg);
					if (ruleBinding.containsKey(new Integer(event.objId))) {
						//System.out.println("Event is for watched camera!");
						for (Binding bind : ruleBinding.get(event.objId)) {
							if (event.msg.matches(".*"+bind.rule+".*")) {
								System.out
										.println("rule match, going to preset");
								PTZController.gotoPreset(bind.ptzObj,
										bind.preset);
							}
						}
					}

				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					System.out.println(e.getLocalizedMessage());
					break;
				} catch (ClientProtocolException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

	}

	protected static class NotificationReciever implements
			ELogNotification.Iface {
		private BlockingQueue<Event> eventQueue;

		public NotificationReciever(BlockingQueue<Event> eventQueue) {
			this.eventQueue = eventQueue;
		}

		@Override
		public void eventNotification(Event event) throws TException {
			try {
				eventQueue.put(event);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	protected static class StateListener implements
			NotificationListener.TransportStateListener {

		@Override
		public void onConnect() {
			System.out.println("#Connected to elog");
		}

		@Override
		public void onDisconnect(String reason) {
			System.out.println("Disconnected: " + reason);
		}

	}

}
