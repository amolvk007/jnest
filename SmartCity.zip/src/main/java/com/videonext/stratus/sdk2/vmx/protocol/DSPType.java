
package com.videonext.stratus.sdk2.vmx.protocol;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DSPType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DSPType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;attribute name="ID" use="required" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="SourceObjID" use="required" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="SourceOptions" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="STATE" use="required" type="{http://websvc.videonext.com/protocol}stateType" />
 *       &lt;attribute name="open_timeout" type="{http://www.w3.org/2001/XMLSchema}unsignedByte" />
 *       &lt;attribute name="play_timeout" type="{http://www.w3.org/2001/XMLSchema}unsignedByte" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DSPType")
public class DSPType {

    @XmlAttribute(name = "ID", required = true)
    protected String id;
    @XmlAttribute(name = "SourceObjID", required = true)
    protected String sourceObjID;
    @XmlAttribute(name = "SourceOptions")
    protected String sourceOptions;
    @XmlAttribute(name = "STATE", required = true)
    protected StateType state;
    @XmlAttribute(name = "open_timeout")
    @XmlSchemaType(name = "unsignedByte")
    protected Short openTimeout;
    @XmlAttribute(name = "play_timeout")
    @XmlSchemaType(name = "unsignedByte")
    protected Short playTimeout;

    /**
     * Gets the value of the id property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getID() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setID(String value) {
        this.id = value;
    }

    /**
     * Gets the value of the sourceObjID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSourceObjID() {
        return sourceObjID;
    }

    /**
     * Sets the value of the sourceObjID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSourceObjID(String value) {
        this.sourceObjID = value;
    }

    /**
     * Gets the value of the sourceOptions property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSourceOptions() {
        return sourceOptions;
    }

    /**
     * Sets the value of the sourceOptions property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSourceOptions(String value) {
        this.sourceOptions = value;
    }

    /**
     * Gets the value of the state property.
     * 
     * @return
     *     possible object is
     *     {@link StateType }
     *     
     */
    public StateType getSTATE() {
        return state;
    }

    /**
     * Sets the value of the state property.
     * 
     * @param value
     *     allowed object is
     *     {@link StateType }
     *     
     */
    public void setSTATE(StateType value) {
        this.state = value;
    }

    /**
     * Gets the value of the openTimeout property.
     * 
     * @return
     *     possible object is
     *     {@link Short }
     *     
     */
    public Short getOpenTimeout() {
        return openTimeout;
    }

    /**
     * Sets the value of the openTimeout property.
     * 
     * @param value
     *     allowed object is
     *     {@link Short }
     *     
     */
    public void setOpenTimeout(Short value) {
        this.openTimeout = value;
    }

    /**
     * Gets the value of the playTimeout property.
     * 
     * @return
     *     possible object is
     *     {@link Short }
     *     
     */
    public Short getPlayTimeout() {
        return playTimeout;
    }

    /**
     * Sets the value of the playTimeout property.
     * 
     * @param value
     *     allowed object is
     *     {@link Short }
     *     
     */
    public void setPlayTimeout(Short value) {
        this.playTimeout = value;
    }

}
