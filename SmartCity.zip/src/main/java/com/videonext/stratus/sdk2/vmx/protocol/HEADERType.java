
package com.videonext.stratus.sdk2.vmx.protocol;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for HEADERType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="HEADERType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="FONT" type="{http://websvc.videonext.com/protocol}FONTType" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="TEXT" use="required" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="ALIGN" type="{http://websvc.videonext.com/protocol}ALIGNType" default="AlignLeft" />
 *       &lt;attribute name="COLOR" type="{http://www.w3.org/2001/XMLSchema}int" default="0" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "HEADERType", propOrder = {
    "font"
})
public class HEADERType {

    @XmlElement(name = "FONT")
    protected FONTType font;
    @XmlAttribute(name = "TEXT", required = true)
    protected String text;
    @XmlAttribute(name = "ALIGN")
    protected ALIGNType align;
    @XmlAttribute(name = "COLOR")
    protected Integer color;

    /**
     * Gets the value of the font property.
     * 
     * @return
     *     possible object is
     *     {@link FONTType }
     *     
     */
    public FONTType getFONT() {
        return font;
    }

    /**
     * Sets the value of the font property.
     * 
     * @param value
     *     allowed object is
     *     {@link FONTType }
     *     
     */
    public void setFONT(FONTType value) {
        this.font = value;
    }

    /**
     * Gets the value of the text property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTEXT() {
        return text;
    }

    /**
     * Sets the value of the text property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTEXT(String value) {
        this.text = value;
    }

    /**
     * Gets the value of the align property.
     * 
     * @return
     *     possible object is
     *     {@link ALIGNType }
     *     
     */
    public ALIGNType getALIGN() {
        if (align == null) {
            return ALIGNType.ALIGN_LEFT;
        } else {
            return align;
        }
    }

    /**
     * Sets the value of the align property.
     * 
     * @param value
     *     allowed object is
     *     {@link ALIGNType }
     *     
     */
    public void setALIGN(ALIGNType value) {
        this.align = value;
    }

    /**
     * Gets the value of the color property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public int getCOLOR() {
        if (color == null) {
            return  0;
        } else {
            return color;
        }
    }

    /**
     * Sets the value of the color property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setCOLOR(Integer value) {
        this.color = value;
    }

}
