package com.videonext.stratus.sdk2.vmx;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.xml.namespace.QName;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.Service;
import javax.xml.ws.handler.MessageContext;

import com.videonext.stratus.sdk2.session.Session;
import com.videonext.stratus.sdk2.vmx.protocol.CellControlIn;
import com.videonext.stratus.sdk2.vmx.protocol.CellPriorityType;
import com.videonext.stratus.sdk2.vmx.protocol.CheckCredentialsIn;
import com.videonext.stratus.sdk2.vmx.protocol.LayoutIn;
import com.videonext.stratus.sdk2.vmx.protocol.ObjectIdRequest;
import com.videonext.stratus.sdk2.vmx.protocol.ResourcesFilterType;
import com.videonext.stratus.sdk2.vmx.protocol.ResourcesRequest;
import com.videonext.stratus.sdk2.vmx.protocol.SetAPCIn;
import com.videonext.stratus.sdk2.vmx.protocol.SetPriorityIn;
import com.videonext.stratus.sdk2.vmx.protocol.WallStateIn;
import com.videonext.stratus.sdk2.vmx.protocol.WallType;

public class WallSvcFactory {
	private final Session session;

	private static final QName qWallSvc = new QName(
			"http://websvc.videonext.com", "Wall_svc");
	private static final QName qWallSvcPort = new QName(
			"http://websvc.videonext.com", "WallPort");
	
	public WallSvcFactory(){
		this.session = Session.getSession();
	}

	public WallSvcPortType createWallSvcPort() throws MalformedURLException {
		Service service = WallSvc.create(
				new URL("http://" + session.getMasterHost()
						+ ":8181/cxf/webservices/Wall_svc?wsdl"), qWallSvc);
		WallSvcPortType port = service.getPort(qWallSvcPort,
				WallSvcPortType.class);
		List<String> headers = new ArrayList<String>();
		headers.add("PHPSESSID=" + session.getSessionId());
		headers.add("token=" + session.getTokenId());
		((BindingProvider) port).getRequestContext().put(
				MessageContext.HTTP_REQUEST_HEADERS,
				Collections.singletonMap("Cookie", headers));
		return port;
	}
	
	public ObjectIdRequest createObjectIdRequest(long objid) {
		ObjectIdRequest objectIDIn = new ObjectIdRequest();
		objectIDIn.setObjectID(objid);
		objectIDIn.setSessionID(session.getSessionId());
		return objectIDIn;
	}
	
	public CellControlIn createCellControlIn(CellPriorityType cellPriority) {
		CellControlIn cellIn = new CellControlIn();
		cellIn.setSessionID(session.getSessionId());
		cellIn.setPriority(cellPriority);
		return cellIn;
	}
	
	public ResourcesRequest createResourcesRequest(ResourcesFilterType resourceFilter){
		ResourcesRequest resources = new ResourcesRequest();
		resources.setSessionID(session.getSessionId());
		resources.setResourcesFilter(resourceFilter);
		return resources;
	}
	
	public SetAPCIn createSetAPCIn(boolean value){
		SetAPCIn setAPC = new SetAPCIn();
		setAPC.setSessionID(session.getSessionId());
		setAPC.setActionFlag(value);
		return setAPC;
	}
	
	public WallStateIn createWallStateIn(int objid, String state){
		WallStateIn wallState = new WallStateIn();
		wallState.setSID(session.getSessionId());
		wallState.setWallObjid(objid);
		wallState.setWallState(state);
		return wallState;
	}
	
	public LayoutIn createLayoutIn(long objid, WallType wall){
		LayoutIn layout = new LayoutIn();
		layout.setObjectID(objid);
		layout.setSessionID(session.getSessionId());
		layout.setWall(wall);
		return layout;
	}
	
	public CheckCredentialsIn createCheckCredentialsIn(long objid, String credentialsSet) {
    	CheckCredentialsIn creds = new CheckCredentialsIn();
    	creds.setSessionID(session.getSessionId());
    	creds.setCredentialsSet(credentialsSet);
    	creds.setObjectID(objid);
        return creds;
    }
	
	public SetPriorityIn createSetPriorityIn(long objid, int monPriority){
		SetPriorityIn priority = new SetPriorityIn();
		priority.setSessionID(session.getSessionId());
		priority.setObjectID(objid);
		priority.setMonitorPriority(monPriority);
		return priority;
	}

}
