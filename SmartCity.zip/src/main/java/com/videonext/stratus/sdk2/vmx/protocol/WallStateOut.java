
package com.videonext.stratus.sdk2.vmx.protocol;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;



/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;choice>
 *         &lt;element ref="{http://websvc.videonext.com/protocol}ErrorMessage"/>
 *         &lt;sequence>
 *           &lt;element name="wall_state" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *           &lt;element ref="{http://websvc.videonext.com/protocol}wall"/>
 *         &lt;/sequence>
 *       &lt;/choice>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "errorMessage",
    "wallState",
    "wall"
})
@XmlRootElement(name = "WallState_out")
public class WallStateOut {

    @XmlElement(name = "ErrorMessage")
    protected String errorMessage;
    @XmlElement(name = "wall_state")
    protected String wallState;
    protected WallType wall;

    /**
     * Gets the value of the errorMessage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getErrorMessage() {
        return errorMessage;
    }

    /**
     * Sets the value of the errorMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setErrorMessage(String value) {
        this.errorMessage = value;
    }

    /**
     * Gets the value of the wallState property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWallState() {
        return wallState;
    }

    /**
     * Sets the value of the wallState property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWallState(String value) {
        this.wallState = value;
    }

    /**
     * Gets the value of the wall property.
     * 
     * @return
     *     possible object is
     *     {@link WallType }
     *     
     */
    public WallType getWall() {
        return wall;
    }

    /**
     * Sets the value of the wall property.
     * 
     * @param value
     *     allowed object is
     *     {@link WallType }
     *     
     */
    public void setWall(WallType value) {
        this.wall = value;
    }

}
