package com.videonext.stratus.sdk2.objectmanagement;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.videonext.stratus.sdk2.session.Session;

public class ObjectManagementRequestor {
	private static final Session session = Session.getSession();

	public enum DeviceType {
		CAMERA("camera");

		private final String type;

		private DeviceType(String type) {
			this.type = type;
		}

		@Override
		public String toString() {
			return type;
		}
	}

	public class Camera {
		public String getCameraModel() {
			return cameraModel;
		}

		public void setCameraModel(String cameraModel) {
			this.cameraModel = cameraModel;
		}

		public String getModelID() {
			return modelId;
		}

		public void setModelID(String modelID) {
			this.modelId = modelID;
		}

		public String getDevIP() {
			return devIP;
		}

		public void setDevIP(String devIP) {
			this.devIP = devIP;
		}

		public int getCamInput() {
			return camInput;
		}

		public void setCamInput(int camInput) {
			this.camInput = camInput;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getUserName() {
			return userName;
		}

		public void setUserName(String userName) {
			this.userName = userName;
		}

		public String getPassword() {
			return password;
		}

		public void setPassword(String password) {
			this.password = password;
		}

		private String cameraModel = "";
		private String modelId = "";
		private String devIP = "";
		private int camInput = 1;
		private String name = "";
		private String userName = "";
		private String password = "";

		public Map<String, String> toAttributes() {
			Map<String, String> attrs = new HashMap<String, String>();
			attrs.put("CAMERAMODEL", cameraModel);
			attrs.put("MODELID", modelId);
			attrs.put("DEVIP", devIP);
			attrs.put("CAMERA", String.valueOf(camInput));
			attrs.put("NAME", name);
			attrs.put("USRNAME", userName);
			attrs.put("PASSWD", password);
			return attrs;
		}
	}

	/**
	 * Returns a map of the attributes for the specified object.
	 * @param objid
	 * @return
	 * @throws ClientProtocolException
	 * @throws IOException
	 * @throws IllegalStateException
	 * @throws JSONException
	 */
	public static Map<String, String> getObjectAttributes(int objid)
			throws ClientProtocolException, IOException, IllegalStateException,
			JSONException {
		Map<String, String> attrs = new HashMap<String, String>();

		List<String> params = new ArrayList<String>();
		params.add("obj=" + objid);

		JSONObject response = session.readJSONResponse(
				"/api/call/getAttributes", params);
		JSONObject jsonAttributes = response.getJSONObject("list");

		String[] jsonAttrs = JSONObject.getNames(jsonAttributes);

		for (String attr : jsonAttrs) {
			attrs.put(attr, jsonAttributes.getString(attr));
		}

		return attrs;
	}

	/**
	 * Adds a camera to the system with the attributes defined in provided camera object.
	 * @param camera
	 * @return objid of the created camera
	 * @throws ClientProtocolException
	 * @throws IOException
	 * @throws JSONException
	 */
	public static int addCamera(Camera camera)
			throws ClientProtocolException, IOException, JSONException {
		return addObject(DeviceType.CAMERA, camera.toAttributes(), 0, 0);
	}

	/**
	 * Adds a camera to the system with the attributes defined in the provided key-value map
	 * @param attributes
	 * @return objid of the created camera
	 * @throws ClientProtocolException
	 * @throws IOException
	 * @throws JSONException
	 */
	public static int addCamera(Map<String, String> attributes)
			throws ClientProtocolException, IOException, JSONException {
		return addObject(DeviceType.CAMERA, attributes, 0, 0);
	}

	public static int addCamera(Map<String, String> attributes, int setId,
			int nodeId) throws ClientProtocolException, IOException, JSONException {
		return addObject(DeviceType.CAMERA, attributes, setId, nodeId);
	}

	/**
	 * Adds an object of the given DeviceType, with the given attribute key-value map.
	 * @param type
	 * @param attributes
	 * @return objid of the created object
	 * @throws ClientProtocolException
	 * @throws IOException
	 * @throws JSONException
	 */
	public static int addObject(DeviceType type,
			Map<String, String> attributes) throws ClientProtocolException,
			IOException, JSONException {
		return addObject(type, attributes, 0, 0);
	}

	/**
	 * Adds an object of the given DeviceType, with the given attribute key-value map. Object is added to the given set and node (if non-0).
	 * @param type
	 * @param attributes
	 * @param setId
	 * @param nodeId
	 * @return objid of the created object
	 * @throws ClientProtocolException
	 * @throws IOException
	 * @throws JSONException
	 */
	public static int addObject(DeviceType type,
			Map<String, String> attributes, int setId, int nodeId)
			throws ClientProtocolException, IOException, JSONException {
		Map<String, String> params = new HashMap<String, String>();
		params.put("type", type.toString());
		if(setId != 0) params.put("setid", String.valueOf(setId));
		if(nodeId != 0) params.put("nodeId", String.valueOf(nodeId));
		JSONObject array = new JSONObject();

		for(Entry<String, String> e : attributes.entrySet()){
			array.put(e.getKey(), e.getValue());
		}
		
		JSONObject json = new JSONObject();
		json.put("list", array);
		params.put("attributes", array.toString());
		HttpResponse response = session.httpPostCall("/api/call/addObject", params);
		JSONObject out = session.readJSONResponse(response);
		return out.getInt("obj");
	}
	
	/**
	 * Sets / updates the attributes for the given object to the provided attribute key-value map. Only parameters provided in the map are updated.
	 * @param objId
	 * @param attributes
	 * @return true if the call completed successfully.
	 * @throws JSONException
	 * @throws ClientProtocolException
	 * @throws IOException
	 */
	public static boolean setAttributes(int objId, Map<String, String> attributes) throws JSONException, ClientProtocolException, IOException{
		JSONObject array = new JSONObject();

		for(Entry<String, String> e : attributes.entrySet()){
			array.put(e.getKey(), e.getValue());
		}
		
		Map<String,String> params = new HashMap<String,String>();
		params.put("obj", String.valueOf(objId));
		params.put("attributes", array.toString());
		
		HttpResponse response = session.httpPostCall("/api/call/setAttributes", params);
		JSONObject json = session.readJSONResponse(response);
		int code = json.getInt("code");
		System.out.println(json.toString());
		return (code == 200);
	}

	/**
	 * Deletes all objects in the provided list of objects.
	 * @param objidList
	 * @return true if the call completed successfully.
	 * @throws ClientProtocolException
	 * @throws IOException
	 * @throws IllegalStateException
	 * @throws JSONException
	 */
	public static boolean deleteObject(List<Integer> objidList) throws ClientProtocolException, IOException, IllegalStateException, JSONException {		
		Map<String, String> params = new HashMap<String,String>();
		JSONArray array = new JSONArray(objidList);
		params.put("objList", array.toString());
		HttpResponse response = session.httpPostCall("/api/call/deleteObject", params);
		
		JSONObject json = session.readJSONResponse(response);
		int code = json.getInt("code");
		System.out.println(json.toString());
		return (code == 200);
	}

}
