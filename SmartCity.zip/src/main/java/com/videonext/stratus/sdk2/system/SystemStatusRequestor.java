package com.videonext.stratus.sdk2.system;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.client.ClientProtocolException;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.videonext.stratus.sdk2.session.Session;

public class SystemStatusRequestor {
	private static final Session session = Session.getSession();

	public static class SystemStatus {
		
		public String status;
		public String description;
		public List<String> reasons;
		
		@Override
		public String toString(){
			String ret = status;
			ret += " : " + description + " (";
			for(String reason : reasons){
				ret += reason + ", ";
			}
			ret += ")";
			return ret;
		}
		
	}

	/**
	 * Gets the system status. If the system is in a degraded or critical state, gets the reason(s) for that state.
	 * @return
	 * @throws IllegalStateException
	 * @throws ClientProtocolException
	 * @throws IOException
	 * @throws JSONException
	 */
	public static SystemStatus getSystemStatus() throws IllegalStateException,
			ClientProtocolException, IOException, JSONException {
		SystemStatus systemStatus = new SystemStatus();
		systemStatus.reasons = new ArrayList<String>();
		
		String apiCallPath = "/api/call/getSystemStatus";

		JSONObject json = session.readJSONResponse(apiCallPath, null);

		systemStatus.status = json.getString("status");
		systemStatus.description = json.getString("description");
		
		JSONArray resultArray = json.getJSONArray("reasons");
		
		for(int i=0; i < resultArray.length(); i++){
			systemStatus.reasons.add(resultArray.getString(i));
		}
		
		return systemStatus;
	}
}
