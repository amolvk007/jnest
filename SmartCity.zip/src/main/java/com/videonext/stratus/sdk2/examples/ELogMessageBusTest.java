package com.videonext.stratus.sdk2.examples;

import java.util.Hashtable;
import java.util.Map;

import com.videonext.skm.fw.iface.ActionResponse;
import com.videonext.stratus.sdk2.ELog.ELogMbusRequestor;
import com.videonext.stratus.sdk2.ELog.ELogMbusRequestor.ELogEvent;
import com.videonext.stratus.sdk2.ELog.ELogMbusRequestor.EventLifespan;
import com.videonext.stratus.sdk2.ELog.ELogMbusRequestor.EventPriority;
import com.videonext.stratus.sdk2.ELog.ELogMbusRequestor.EventSource;
import com.videonext.stratus.sdk2.ELog.ELogMbusRequestor.EventType;
import com.videonext.stratus.sdk2.session.Session;

/**
 * Requires a few libraries from the server:
 * 
 * /opt/sarch/elog/bin/elogiface.jar /opt/sarch/fw/bin/libfwiface.jar
 * /opt/sarch/fw/bin/serviceapi.jar
 * 
 * @author jscott
 * 
 */
public class ELogMessageBusTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Session session = Session.getSession();
		int objid = 127;
		int eventId = 0;
		try {
			session.openSession("vtm.videonext.com", "admin", "topse");
			objid = 127;
		} catch (Exception e) {
			e.printStackTrace();
		}

		if (objid != 0) {
			long time = System.currentTimeMillis() / 1000;

			ELogEvent event = new ELogEvent(objid, "@Java Test Event");
			event.setEventtype(EventType.ALERT);
			event.setLifespan(EventLifespan.MODERATE);
			event.setPriority(EventPriority.MEDIUM);
			event.setEventSource(EventSource.USER);
			event.setWhenTime(time);

			eventId = ELogMbusRequestor.createEvent(event);
			System.out.println("Event response from server -> eventId = "
					+ eventId);
		}

		// acknowledge the event
		if (eventId != 0) {
			System.out.println("Ack response: "
					+ ELogMbusRequestor.ackEvent(eventId));
		}

		/*
		 * // check pulse the event if(eventId != 0){ long ts =
		 * System.currentTimeMillis(); ActionResponse response =
		 * ELogMbusRequestor.checkPulse(eventId); ts =
		 * System.currentTimeMillis() - ts;
		 * System.out.println("check pulse response:"); for (Map.Entry<String,
		 * String> entry : response.parameters.entrySet()){
		 * System.out.println(" " + entry.getKey() + "=" + entry.getValue()); }
		 * System.out.println(ts+"msec"); }
		 */

		// migrate the event
		if (eventId != 0) {
			ActionResponse response = ELogMbusRequestor.migrateEvent(eventId);
			System.out.println("migrate event response:");
			for (Map.Entry<String, String> entry : response.parameters
					.entrySet()) {
				System.out.println(" " + entry.getKey() + "="
						+ entry.getValue());
			}
		}

		// update event
		if (eventId != 0) {
			Map<String, String> params = new Hashtable<String, String>();
			params.put("priority", EventPriority.LOW.toString());
			// you can add more parameters to update
			ActionResponse response = ELogMbusRequestor.updateEvent(eventId,
					params);
			System.out.println("update event response:");
			for (Map.Entry<String, String> entry : response.parameters
					.entrySet()) {
				System.out.println(" " + entry.getKey() + "="
						+ entry.getValue());
			}
		}
	}

}
