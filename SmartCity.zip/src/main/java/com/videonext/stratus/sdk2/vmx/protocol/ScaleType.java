
package com.videonext.stratus.sdk2.vmx.protocol;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for scaleType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="scaleType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="Cell"/>
 *     &lt;enumeration value="Proportional"/>
 *     &lt;enumeration value="MaxSize"/>
 *     &lt;enumeration value="Original"/>
 *     &lt;enumeration value="Hidden"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "scaleType")
@XmlEnum
public enum ScaleType {

    @XmlEnumValue("Cell")
    CELL("Cell"),
    @XmlEnumValue("Proportional")
    PROPORTIONAL("Proportional"),
    @XmlEnumValue("MaxSize")
    MAX_SIZE("MaxSize"),
    @XmlEnumValue("Original")
    ORIGINAL("Original"),
    @XmlEnumValue("Hidden")
    HIDDEN("Hidden");
    private final String value;

    ScaleType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ScaleType fromValue(String v) {
        for (ScaleType c: ScaleType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
