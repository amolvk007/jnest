
package com.videonext.stratus.sdk2.objectmanagement.websvc.types;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Filter complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Filter">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;choice>
 *         &lt;sequence>
 *           &lt;element name="ObjectFilter" type="{http://skm.videonext.com/om/websvc/types}ObjectRef" minOccurs="0"/>
 *           &lt;element name="ObjectListFilter" type="{http://skm.videonext.com/om/websvc/types}ObjectRefList" minOccurs="0"/>
 *         &lt;/sequence>
 *         &lt;sequence>
 *           &lt;element name="ObjectHostFilter" type="{http://skm.videonext.com/om/websvc/types}ObjectHostFilter" minOccurs="0"/>
 *           &lt;element name="ObjectTypeFilter" type="{http://skm.videonext.com/om/websvc/types}ObjectTypeFilter" minOccurs="0"/>
 *         &lt;/sequence>
 *       &lt;/choice>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Filter", propOrder = {
    "objectFilter",
    "objectListFilter",
    "objectHostFilter",
    "objectTypeFilter"
})
public class Filter {

    @XmlElement(name = "ObjectFilter")
    protected ObjectRef objectFilter;
    @XmlElement(name = "ObjectListFilter")
    protected ObjectRefList objectListFilter;
    @XmlElement(name = "ObjectHostFilter")
    protected ObjectHostFilter objectHostFilter;
    @XmlElement(name = "ObjectTypeFilter")
    protected ObjectTypeFilter objectTypeFilter;

    /**
     * Gets the value of the objectFilter property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectRef }
     *     
     */
    public ObjectRef getObjectFilter() {
        return objectFilter;
    }

    /**
     * Sets the value of the objectFilter property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectRef }
     *     
     */
    public void setObjectFilter(ObjectRef value) {
        this.objectFilter = value;
    }

    /**
     * Gets the value of the objectListFilter property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectRefList }
     *     
     */
    public ObjectRefList getObjectListFilter() {
        return objectListFilter;
    }

    /**
     * Sets the value of the objectListFilter property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectRefList }
     *     
     */
    public void setObjectListFilter(ObjectRefList value) {
        this.objectListFilter = value;
    }

    /**
     * Gets the value of the objectHostFilter property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectHostFilter }
     *     
     */
    public ObjectHostFilter getObjectHostFilter() {
        return objectHostFilter;
    }

    /**
     * Sets the value of the objectHostFilter property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectHostFilter }
     *     
     */
    public void setObjectHostFilter(ObjectHostFilter value) {
        this.objectHostFilter = value;
    }

    /**
     * Gets the value of the objectTypeFilter property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectTypeFilter }
     *     
     */
    public ObjectTypeFilter getObjectTypeFilter() {
        return objectTypeFilter;
    }

    /**
     * Sets the value of the objectTypeFilter property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectTypeFilter }
     *     
     */
    public void setObjectTypeFilter(ObjectTypeFilter value) {
        this.objectTypeFilter = value;
    }

}
