package com.videonext.stratus.sdk2.objectmanagement.websvc;

import java.net.MalformedURLException;
import java.net.URL;
import javax.xml.namespace.QName;
import javax.xml.ws.WebEndpoint;
import javax.xml.ws.WebServiceFeature;
import javax.xml.ws.Service;

public class ObjectManagementService extends Service {

    public final static URL WSDL_LOCATION;

    public final static QName SERVICE = new QName("http://skm.videonext.com/om/websvc", "ObjectManagementService");
    public final static QName ObjectManagementPort = new QName("http://skm.videonext.com/om/websvc", "ObjectManagementPort");
    static {
        URL url = null;
        try {
            URL baseUrl;
            baseUrl = com.videonext.stratus.sdk2.objectmanagement.websvc.ObjectManagementService.class.getResource(".");
            url = new URL(baseUrl, "wsdls/ObjectManagementService.wsdl");
        } catch (MalformedURLException e) {
            java.util.logging.Logger.getLogger(ObjectManagementService.class.getName())
                .log(java.util.logging.Level.INFO, 
                     "Can not initialize the default wsdl from {0}", url.toString());
        }
        WSDL_LOCATION = url;
    }

    public ObjectManagementService(URL wsdlLocation) {
        super(wsdlLocation, SERVICE);
    }

    public ObjectManagementService(URL wsdlLocation, QName serviceName) {
        super(wsdlLocation, serviceName);
    }

    public ObjectManagementService() {
        super(WSDL_LOCATION, SERVICE);
    }
    

    /**
     *
     * @return
     *     returns ObjectManagementPortType
     */
    @WebEndpoint(name = "ObjectManagementPort")
    public ObjectManagementPortType getObjectManagementPort() {
        return super.getPort(ObjectManagementPort, ObjectManagementPortType.class);
    }

    /**
     * 
     * @param features
     *     A list of {@link javax.xml.ws.WebServiceFeature} to configure on the proxy.  Supported features not in the <code>features</code> parameter will have their default values.
     * @return
     *     returns ObjectManagementPortType
     */
    @WebEndpoint(name = "ObjectManagementPort")
    public ObjectManagementPortType getObjectManagementPort(WebServiceFeature... features) {
        return super.getPort(ObjectManagementPort, ObjectManagementPortType.class, features);
    }

}
