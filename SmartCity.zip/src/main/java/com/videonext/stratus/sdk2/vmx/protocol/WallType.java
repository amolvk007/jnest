
package com.videonext.stratus.sdk2.vmx.protocol;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;



/**
 * <p>Java class for wallType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="wallType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="id" type="{http://www.w3.org/2001/XMLSchema}unsignedInt"/>
 *         &lt;element name="rows" type="{http://www.w3.org/2001/XMLSchema}unsignedByte"/>
 *         &lt;element name="cols" type="{http://www.w3.org/2001/XMLSchema}unsignedByte"/>
 *         &lt;element name="name" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="desc" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="WallCell" type="{http://websvc.videonext.com/protocol}WallCellType" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "wallType", propOrder = {
    "id",
    "rows",
    "cols",
    "name",
    "desc",
    "wallCell"
})
public class WallType {

    @XmlSchemaType(name = "unsignedInt")
    protected long id;
    @XmlSchemaType(name = "unsignedByte")
    protected short rows;
    @XmlSchemaType(name = "unsignedByte")
    protected short cols;
    @XmlElement(required = true)
    protected String name;
    @XmlElement(required = true)
    protected String desc;
    @XmlElement(name = "WallCell")
    protected List<WallCellType> wallCell;

    /**
     * Gets the value of the id property.
     * 
     */
    public long getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     */
    public void setId(long value) {
        this.id = value;
    }

    /**
     * Gets the value of the rows property.
     * 
     */
    public short getRows() {
        return rows;
    }

    /**
     * Sets the value of the rows property.
     * 
     */
    public void setRows(short value) {
        this.rows = value;
    }

    /**
     * Gets the value of the cols property.
     * 
     */
    public short getCols() {
        return cols;
    }

    /**
     * Sets the value of the cols property.
     * 
     */
    public void setCols(short value) {
        this.cols = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the desc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDesc() {
        return desc;
    }

    /**
     * Sets the value of the desc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDesc(String value) {
        this.desc = value;
    }

    /**
     * Gets the value of the wallCell property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the wallCell property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getWallCell().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link WallCellType }
     * 
     * 
     */
    public List<WallCellType> getWallCell() {
        if (wallCell == null) {
            wallCell = new ArrayList<WallCellType>();
        }
        return this.wallCell;
    }

}
