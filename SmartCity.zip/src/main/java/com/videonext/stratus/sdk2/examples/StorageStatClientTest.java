package com.videonext.stratus.sdk2.examples;

/**
 * Please modify this class to meet your needs
 * This class is not complete
 */

import java.math.BigInteger;
import java.net.URI;
import javax.xml.namespace.QName;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.Service;
import javax.xml.ws.handler.MessageContext;

import com.videonext.stratus.sdk2.session.Session;
import com.videonext.stratus.sdk2.storage.coveragesvc.CoverageParamsIn;
import com.videonext.stratus.sdk2.storage.coveragesvc.CoveragePort;
import com.videonext.stratus.sdk2.storage.coveragesvc.ObjectFactory;
import com.videonext.stratus.sdk2.storage.coveragesvc.StorageStat;
import com.videonext.stratus.sdk2.storage.coveragesvc.TimeWithPercentage;

public final class StorageStatClientTest {
	private final static String HOST = "ngc371-19.dev.videonext.net";

	private static final QName qStorage = new QName(
			"coveragesvc.videonext.com", "StorageStat");

	private StorageStatClientTest() {
	}

	public static void main(String args[]) throws java.lang.Exception {
		// Get a new Session
		Session session = Session.getSession();

		// Do not use this in a production environment. It sets the
		// application to accept any ssl-cert, defeating the purpose of
		// using ssl.
		session.setTrustAll(true);
		session.openSession(HOST, "admin", "topse", "http");

		// load WSDLs for binding
		URI serviceURI = new URI("file://" + System.getProperty("user.dir")
				+ "/wsdls/");
		URI uri = serviceURI.resolve("storagestat.wsdl");

		System.out.println(System.getProperty("user.dir"));

		// create Service reference and Port
		Service ss = StorageStat.create(uri.toURL(), qStorage);
		ss.addPort(qStorage,
				javax.xml.ws.soap.SOAPBinding.SOAP12HTTP_MTOM_BINDING,
				"http://" + HOST + "/axis2c/services/StorageStat");
		CoveragePort port = ss.getPort(new QName("coveragesvc.videonext.com",
				"CoverageSoap"), CoveragePort.class);

		// List of device IDs to get storage coverage on
		String[] ids = { "864", "880", "886" };
		int pointer = 0;

		System.out.println("Invoking getCoverageCollection...");
		// Pull storage stats ever 5000ms
        while (true) {
			// configure filter parameters (granularity, objid, etc)
			
			ObjectFactory of = new ObjectFactory();
			
			CoverageParamsIn params = of.createCoverageParamsIn();
			
			params.setSessionId(session.getSessionId());
			
			params.setGranularity("min");
			params.setMultiplier(1L);

			params.getId().add(ids[pointer]);
			BigInteger startTime = BigInteger.valueOf(System
					.currentTimeMillis() / 1000 - 1200);
			BigInteger stopTime = BigInteger
					.valueOf(System.currentTimeMillis() / 1000 + 1200);
			System.out.println("Coverage period: " + startTime + " - "
					+ stopTime);
			params.setStartTime(startTime);
			params.setFinishTime(stopTime);

			// make the StorageStat call, response is timed
			long start = System.currentTimeMillis();
			com.videonext.stratus.sdk2.storage.coveragesvc.CoverageParamsOut _return = port
					.getCoverageCollection(params);
			
			((BindingProvider)port).getResponseContext().get(MessageContext.HTTP_REQUEST_HEADERS);
			long total = System.currentTimeMillis() - start;

			System.out
					.println("getCoverageCollection.result getTimeAndPercentage "
							+ ids[pointer] + " (" + (total) + "ms) =");
			for (TimeWithPercentage i : _return.getTimeAndPercentage()) {
				System.out.print(i.getTime() + " : " + i.getPercentage()
						+ "%, ");
			}
			System.out.print("\n");
			pointer++;
			if (pointer >= ids.length)
				pointer = 0;

			Thread.sleep(5000);
		}

		// System.exit(0);
	}
}
