
package com.videonext.stratus.sdk2.ELog.eventlogsvc.protocol;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for FILTERType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FILTERType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;all>
 *         &lt;element ref="{http://eventlogsvc.videonext.com/protocol}lifespan" minOccurs="0"/>
 *         &lt;element ref="{http://eventlogsvc.videonext.com/protocol}priority" minOccurs="0"/>
 *         &lt;element ref="{http://eventlogsvc.videonext.com/protocol}eventid" minOccurs="0"/>
 *         &lt;element ref="{http://eventlogsvc.videonext.com/protocol}crossinterval" minOccurs="0"/>
 *         &lt;element ref="{http://eventlogsvc.videonext.com/protocol}eventsource" minOccurs="0"/>
 *         &lt;element ref="{http://eventlogsvc.videonext.com/protocol}objid" minOccurs="0"/>
 *         &lt;element ref="{http://eventlogsvc.videonext.com/protocol}started" minOccurs="0"/>
 *         &lt;element ref="{http://eventlogsvc.videonext.com/protocol}state" minOccurs="0"/>
 *         &lt;element ref="{http://eventlogsvc.videonext.com/protocol}tscovered" minOccurs="0"/>
 *         &lt;element ref="{http://eventlogsvc.videonext.com/protocol}workflow" minOccurs="0"/>
 *         &lt;element ref="{http://eventlogsvc.videonext.com/protocol}tag" minOccurs="0"/>
 *         &lt;element ref="{http://eventlogsvc.videonext.com/protocol}eventtype" minOccurs="0"/>
 *         &lt;element ref="{http://eventlogsvc.videonext.com/protocol}snapshotid" minOccurs="0"/>
 *         &lt;element ref="{http://eventlogsvc.videonext.com/protocol}message" minOccurs="0"/>
 *         &lt;element ref="{http://eventlogsvc.videonext.com/protocol}setid" minOccurs="0"/>
 *       &lt;/all>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FILTERType", propOrder = {

})
public class FILTERType {

    protected TCommonParamType lifespan;
    protected TCommonParamType priority;
    protected TCommonParamType eventid;
    protected TBetweenParam crossinterval;
    protected T3ConditionParam eventsource;
    protected T3ConditionParam objid;
    protected TBetweenParam started;
    protected T3ConditionParam state;
    protected TEqParam tscovered;
    protected T3ConditionParam workflow;
    protected T3ConditionParam tag;
    protected T3ConditionParam eventtype;
    protected TEqParamInt snapshotid;
    protected TTextFilter message;
    protected T3ConditionParam setid;

    /**
     * Gets the value of the lifespan property.
     * 
     * @return
     *     possible object is
     *     {@link TCommonParamType }
     *     
     */
    public TCommonParamType getLifespan() {
        return lifespan;
    }

    /**
     * Sets the value of the lifespan property.
     * 
     * @param value
     *     allowed object is
     *     {@link TCommonParamType }
     *     
     */
    public void setLifespan(TCommonParamType value) {
        this.lifespan = value;
    }

    /**
     * Gets the value of the priority property.
     * 
     * @return
     *     possible object is
     *     {@link TCommonParamType }
     *     
     */
    public TCommonParamType getPriority() {
        return priority;
    }

    /**
     * Sets the value of the priority property.
     * 
     * @param value
     *     allowed object is
     *     {@link TCommonParamType }
     *     
     */
    public void setPriority(TCommonParamType value) {
        this.priority = value;
    }

    /**
     * Gets the value of the eventid property.
     * 
     * @return
     *     possible object is
     *     {@link TCommonParamType }
     *     
     */
    public TCommonParamType getEventid() {
        return eventid;
    }

    /**
     * Sets the value of the eventid property.
     * 
     * @param value
     *     allowed object is
     *     {@link TCommonParamType }
     *     
     */
    public void setEventid(TCommonParamType value) {
        this.eventid = value;
    }

    /**
     * Gets the value of the crossinterval property.
     * 
     * @return
     *     possible object is
     *     {@link TBetweenParam }
     *     
     */
    public TBetweenParam getCrossinterval() {
        return crossinterval;
    }

    /**
     * Sets the value of the crossinterval property.
     * 
     * @param value
     *     allowed object is
     *     {@link TBetweenParam }
     *     
     */
    public void setCrossinterval(TBetweenParam value) {
        this.crossinterval = value;
    }

    /**
     * Gets the value of the eventsource property.
     * 
     * @return
     *     possible object is
     *     {@link T3ConditionParam }
     *     
     */
    public T3ConditionParam getEventsource() {
        return eventsource;
    }

    /**
     * Sets the value of the eventsource property.
     * 
     * @param value
     *     allowed object is
     *     {@link T3ConditionParam }
     *     
     */
    public void setEventsource(T3ConditionParam value) {
        this.eventsource = value;
    }

    /**
     * Gets the value of the objid property.
     * 
     * @return
     *     possible object is
     *     {@link T3ConditionParam }
     *     
     */
    public T3ConditionParam getObjid() {
        return objid;
    }

    /**
     * Sets the value of the objid property.
     * 
     * @param value
     *     allowed object is
     *     {@link T3ConditionParam }
     *     
     */
    public void setObjid(T3ConditionParam value) {
        this.objid = value;
    }

    /**
     * Gets the value of the started property.
     * 
     * @return
     *     possible object is
     *     {@link TBetweenParam }
     *     
     */
    public TBetweenParam getStarted() {
        return started;
    }

    /**
     * Sets the value of the started property.
     * 
     * @param value
     *     allowed object is
     *     {@link TBetweenParam }
     *     
     */
    public void setStarted(TBetweenParam value) {
        this.started = value;
    }

    /**
     * Gets the value of the state property.
     * 
     * @return
     *     possible object is
     *     {@link T3ConditionParam }
     *     
     */
    public T3ConditionParam getState() {
        return state;
    }

    /**
     * Sets the value of the state property.
     * 
     * @param value
     *     allowed object is
     *     {@link T3ConditionParam }
     *     
     */
    public void setState(T3ConditionParam value) {
        this.state = value;
    }

    /**
     * Gets the value of the tscovered property.
     * 
     * @return
     *     possible object is
     *     {@link TEqParam }
     *     
     */
    public TEqParam getTscovered() {
        return tscovered;
    }

    /**
     * Sets the value of the tscovered property.
     * 
     * @param value
     *     allowed object is
     *     {@link TEqParam }
     *     
     */
    public void setTscovered(TEqParam value) {
        this.tscovered = value;
    }

    /**
     * Gets the value of the workflow property.
     * 
     * @return
     *     possible object is
     *     {@link T3ConditionParam }
     *     
     */
    public T3ConditionParam getWorkflow() {
        return workflow;
    }

    /**
     * Sets the value of the workflow property.
     * 
     * @param value
     *     allowed object is
     *     {@link T3ConditionParam }
     *     
     */
    public void setWorkflow(T3ConditionParam value) {
        this.workflow = value;
    }

    /**
     * Gets the value of the tag property.
     * 
     * @return
     *     possible object is
     *     {@link T3ConditionParam }
     *     
     */
    public T3ConditionParam getTag() {
        return tag;
    }

    /**
     * Sets the value of the tag property.
     * 
     * @param value
     *     allowed object is
     *     {@link T3ConditionParam }
     *     
     */
    public void setTag(T3ConditionParam value) {
        this.tag = value;
    }

    /**
     * Gets the value of the eventtype property.
     * 
     * @return
     *     possible object is
     *     {@link T3ConditionParam }
     *     
     */
    public T3ConditionParam getEventtype() {
        return eventtype;
    }

    /**
     * Sets the value of the eventtype property.
     * 
     * @param value
     *     allowed object is
     *     {@link T3ConditionParam }
     *     
     */
    public void setEventtype(T3ConditionParam value) {
        this.eventtype = value;
    }

    /**
     * Gets the value of the snapshotid property.
     * 
     * @return
     *     possible object is
     *     {@link TEqParamInt }
     *     
     */
    public TEqParamInt getSnapshotid() {
        return snapshotid;
    }

    /**
     * Sets the value of the snapshotid property.
     * 
     * @param value
     *     allowed object is
     *     {@link TEqParamInt }
     *     
     */
    public void setSnapshotid(TEqParamInt value) {
        this.snapshotid = value;
    }

    /**
     * Gets the value of the message property.
     * 
     * @return
     *     possible object is
     *     {@link TTextFilter }
     *     
     */
    public TTextFilter getMessage() {
        return message;
    }

    /**
     * Sets the value of the message property.
     * 
     * @param value
     *     allowed object is
     *     {@link TTextFilter }
     *     
     */
    public void setMessage(TTextFilter value) {
        this.message = value;
    }

    /**
     * Gets the value of the setid property.
     * 
     * @return
     *     possible object is
     *     {@link T3ConditionParam }
     *     
     */
    public T3ConditionParam getSetid() {
        return setid;
    }

    /**
     * Sets the value of the setid property.
     * 
     * @param value
     *     allowed object is
     *     {@link T3ConditionParam }
     *     
     */
    public void setSetid(T3ConditionParam value) {
        this.setid = value;
    }

}
