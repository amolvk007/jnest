
package com.videonext.stratus.sdk2.vmx.protocol;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for WEIGHTType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="WEIGHTType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="Light"/>
 *     &lt;enumeration value="Normal"/>
 *     &lt;enumeration value="DemiBold"/>
 *     &lt;enumeration value="Bold"/>
 *     &lt;enumeration value="Black"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "WEIGHTType")
@XmlEnum
public enum WEIGHTType {

    @XmlEnumValue("Light")
    LIGHT("Light"),
    @XmlEnumValue("Normal")
    NORMAL("Normal"),
    @XmlEnumValue("DemiBold")
    DEMI_BOLD("DemiBold"),
    @XmlEnumValue("Bold")
    BOLD("Bold"),
    @XmlEnumValue("Black")
    BLACK("Black");
    private final String value;

    WEIGHTType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static WEIGHTType fromValue(String v) {
        for (WEIGHTType c: WEIGHTType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
