@javax.xml.bind.annotation.XmlSchema(namespace = "http://websvc.videonext.com/protocol", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.videonext.stratus.sdk2.vmx.protocol;
