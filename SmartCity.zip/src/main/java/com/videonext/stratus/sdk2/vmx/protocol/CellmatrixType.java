
package com.videonext.stratus.sdk2.vmx.protocol;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for cellmatrixType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="cellmatrixType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;attribute name="rows" use="required" type="{http://www.w3.org/2001/XMLSchema}unsignedByte" />
 *       &lt;attribute name="cols" use="required" type="{http://www.w3.org/2001/XMLSchema}unsignedByte" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "cellmatrixType")
public class CellmatrixType {

    @XmlAttribute(name = "rows", required = true)
    @XmlSchemaType(name = "unsignedByte")
    protected short rows;
    @XmlAttribute(name = "cols", required = true)
    @XmlSchemaType(name = "unsignedByte")
    protected short cols;

    /**
     * Gets the value of the rows property.
     * 
     */
    public short getRows() {
        return rows;
    }

    /**
     * Sets the value of the rows property.
     * 
     */
    public void setRows(short value) {
        this.rows = value;
    }

    /**
     * Gets the value of the cols property.
     * 
     */
    public short getCols() {
        return cols;
    }

    /**
     * Sets the value of the cols property.
     * 
     */
    public void setCols(short value) {
        this.cols = value;
    }

}
