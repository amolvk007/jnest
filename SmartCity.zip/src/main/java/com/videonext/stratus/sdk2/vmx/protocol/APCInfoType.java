
package com.videonext.stratus.sdk2.vmx.protocol;

import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for APCInfoType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="APCInfoType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;attribute name="monid" use="required" type="{http://www.w3.org/2001/XMLSchema}unsignedInt" />
 *       &lt;attribute name="groupid" use="required" type="{http://www.w3.org/2001/XMLSchema}unsignedInt" />
 *       &lt;attribute name="cellid" use="required" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="eventid" type="{http://www.w3.org/2001/XMLSchema}unsignedLong" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "APCInfoType")
public class APCInfoType {

    @XmlAttribute(name = "monid", required = true)
    @XmlSchemaType(name = "unsignedInt")
    protected long monid;
    @XmlAttribute(name = "groupid", required = true)
    @XmlSchemaType(name = "unsignedInt")
    protected long groupid;
    @XmlAttribute(name = "cellid", required = true)
    protected String cellid;
    @XmlAttribute(name = "eventid")
    @XmlSchemaType(name = "unsignedLong")
    protected BigInteger eventid;

    /**
     * Gets the value of the monid property.
     * 
     */
    public long getMonid() {
        return monid;
    }

    /**
     * Sets the value of the monid property.
     * 
     */
    public void setMonid(long value) {
        this.monid = value;
    }

    /**
     * Gets the value of the groupid property.
     * 
     */
    public long getGroupid() {
        return groupid;
    }

    /**
     * Sets the value of the groupid property.
     * 
     */
    public void setGroupid(long value) {
        this.groupid = value;
    }

    /**
     * Gets the value of the cellid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCellid() {
        return cellid;
    }

    /**
     * Sets the value of the cellid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCellid(String value) {
        this.cellid = value;
    }

    /**
     * Gets the value of the eventid property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getEventid() {
        return eventid;
    }

    /**
     * Sets the value of the eventid property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setEventid(BigInteger value) {
        this.eventid = value;
    }

}
