
package com.videonext.stratus.sdk2.vmx.protocol;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for monitor_infoType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="monitor_infoType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence maxOccurs="unbounded">
 *         &lt;element ref="{http://websvc.videonext.com/protocol}cell" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="id" use="required" type="{http://www.w3.org/2001/XMLSchema}unsignedInt" />
 *       &lt;attribute name="hres" type="{http://www.w3.org/2001/XMLSchema}unsignedShort" />
 *       &lt;attribute name="vres" type="{http://www.w3.org/2001/XMLSchema}unsignedShort" />
 *       &lt;attribute name="cellscount" type="{http://www.w3.org/2001/XMLSchema}unsignedShort" />
 *       &lt;attribute name="statenum" type="{http://www.w3.org/2001/XMLSchema}int" />
 *       &lt;attribute name="state">
 *         &lt;simpleType>
 *           &lt;restriction base="{http://websvc.videonext.com/protocol}st_monstate">
 *           &lt;/restriction>
 *         &lt;/simpleType>
 *       &lt;/attribute>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "monitor_infoType", propOrder = {
    "cell"
})
public class MonitorInfoType {

    protected List<CellType> cell;
    @XmlAttribute(name = "id", required = true)
    @XmlSchemaType(name = "unsignedInt")
    protected long id;
    @XmlAttribute(name = "hres")
    @XmlSchemaType(name = "unsignedShort")
    protected Integer hres;
    @XmlAttribute(name = "vres")
    @XmlSchemaType(name = "unsignedShort")
    protected Integer vres;
    @XmlAttribute(name = "cellscount")
    @XmlSchemaType(name = "unsignedShort")
    protected Integer cellscount;
    @XmlAttribute(name = "statenum")
    protected Integer statenum;
    @XmlAttribute(name = "state")
    protected StMonstate state;

    /**
     * Gets the value of the cell property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the cell property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCell().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CellType }
     * 
     * 
     */
    public List<CellType> getCell() {
        if (cell == null) {
            cell = new ArrayList<CellType>();
        }
        return this.cell;
    }

    /**
     * Gets the value of the id property.
     * 
     */
    public long getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     */
    public void setId(long value) {
        this.id = value;
    }

    /**
     * Gets the value of the hres property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getHres() {
        return hres;
    }

    /**
     * Sets the value of the hres property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setHres(Integer value) {
        this.hres = value;
    }

    /**
     * Gets the value of the vres property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getVres() {
        return vres;
    }

    /**
     * Sets the value of the vres property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setVres(Integer value) {
        this.vres = value;
    }

    /**
     * Gets the value of the cellscount property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getCellscount() {
        return cellscount;
    }

    /**
     * Sets the value of the cellscount property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setCellscount(Integer value) {
        this.cellscount = value;
    }

    /**
     * Gets the value of the statenum property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getStatenum() {
        return statenum;
    }

    /**
     * Sets the value of the statenum property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setStatenum(Integer value) {
        this.statenum = value;
    }

    /**
     * Gets the value of the state property.
     * 
     * @return
     *     possible object is
     *     {@link StMonstate }
     *     
     */
    public StMonstate getState() {
        return state;
    }

    /**
     * Sets the value of the state property.
     * 
     * @param value
     *     allowed object is
     *     {@link StMonstate }
     *     
     */
    public void setState(StMonstate value) {
        this.state = value;
    }

}
