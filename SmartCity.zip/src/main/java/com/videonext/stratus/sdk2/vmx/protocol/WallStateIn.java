
package com.videonext.stratus.sdk2.vmx.protocol;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;attribute name="SID" use="required" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="wall_state" use="required" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="wall_objid" use="required" type="{http://www.w3.org/2001/XMLSchema}int" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "")
@XmlRootElement(name = "WallState_in")
public class WallStateIn {

    @XmlAttribute(name = "SID", required = true)
    protected String sid;
    @XmlAttribute(name = "wall_state", required = true)
    protected String wallState;
    @XmlAttribute(name = "wall_objid", required = true)
    protected int wallObjid;

    /**
     * Gets the value of the sid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSID() {
        return sid;
    }

    /**
     * Sets the value of the sid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSID(String value) {
        this.sid = value;
    }

    /**
     * Gets the value of the wallState property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWallState() {
        return wallState;
    }

    /**
     * Sets the value of the wallState property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWallState(String value) {
        this.wallState = value;
    }

    /**
     * Gets the value of the wallObjid property.
     * 
     */
    public int getWallObjid() {
        return wallObjid;
    }

    /**
     * Sets the value of the wallObjid property.
     * 
     */
    public void setWallObjid(int value) {
        this.wallObjid = value;
    }

}
