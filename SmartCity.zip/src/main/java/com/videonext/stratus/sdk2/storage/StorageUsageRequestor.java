package com.videonext.stratus.sdk2.storage;

import java.io.IOException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.http.client.ClientProtocolException;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.videonext.stratus.sdk2.session.Session;

public class StorageUsageRequestor {
	private static final Session session = Session.getSession();

	public static class StorageCoverage {
		public StorageCoverage(long storageUsage, String unit) {
			this.storageUsage = storageUsage;
			this.unit = unit;
		}

		public StorageCoverage(Map<Long, Integer> objCoverage) {
			this.coverage = objCoverage;
		}

		public long storageUsage, totalUsage, oldestTime;
		public String unit;
		Map<Long, Integer> coverage;

		@Override
		public String toString() {
			String ret = "";

			ret = String.format("%d, %dMB, %d%s, {", oldestTime, totalUsage,
					storageUsage, unit);

			if (coverage != null) {
				for (Entry<Long, Integer> coverageEntry : coverage.entrySet()) {
					ret += coverageEntry.getKey() + ":"
							+ coverageEntry.getValue() + ", ";
				}
			}
			ret += "}";

			return ret;
		}

		public long getStorageUsage() {
			return storageUsage;
		}

		public void setStorageUsage(long storageUsage) {
			this.storageUsage = storageUsage;
		}

		public long getTotalUsage() {
			return totalUsage;
		}

		public void setTotalUsage(long totalUsage) {
			this.totalUsage = totalUsage;
		}

		public long getOldestTime() {
			return oldestTime;
		}

		public void setOldestTime(long oldestTime) {
			this.oldestTime = oldestTime;
		}

		public String getUnit() {
			return unit;
		}

		public void setUnit(String unit) {
			this.unit = unit;
		}

		public Map<Long, Integer> getCoverage() {
			return coverage;
		}
	}

	public enum Granularity {
		MIN, HOUR, DAY, MON
	}

	/**
	 * 
	 * @param objList
	 * @param granularity
	 * @return
	 * @throws IllegalStateException
	 * @throws ClientProtocolException
	 * @throws IOException
	 * @throws JSONException
	 */
	public static Map<Integer, StorageCoverage> getStorageUsage(
			List<Integer> objList, Granularity granularity)
			throws IllegalStateException, ClientProtocolException, IOException,
			JSONException {
		Map<Integer, StorageCoverage> storageCoverages = new HashMap<Integer, StorageCoverage>();

		String apiCallPath = "/api/call/getStorageUsage";

		List<String> params = new ArrayList<String>();
		String objliststart = "objList=";
		String objlist = "[";
		Iterator<Integer> objI = objList.iterator();
		while (objI.hasNext()) {
			int obj = objI.next();
			objlist += "\"" + obj + "\"";
			if (objI.hasNext())
				objlist += ",";
		}
		objlist += "]";

		params.add(objliststart + URLEncoder.encode(objlist, "US-ASCII"));

		switch (granularity) {
		case MIN:
		case HOUR:
			params.add("granularity=hour");
			break;
		case DAY:
		case MON:
			params.add("granularity=day");
			break;
		default:
			break;
		}

		JSONObject json = session.readJSONResponse(apiCallPath, params);
		JSONObject jlist = json.getJSONObject("list");
		String[] objs = JSONObject.getNames(jlist);

		for (String obj : objs) {
			JSONObject usage = jlist.getJSONObject(obj);
			try {
				Long sUse = usage.getLong("storageUsage");
				String unit = usage.getString("unit");

				storageCoverages.put(Integer.valueOf(obj), new StorageCoverage(
						sUse, unit));
			} catch (JSONException e) {
				
			}
		}

		//
		// make second API call for total storage
		//

		apiCallPath = "/api/call/getStorageUsageTotals";
		params = new ArrayList<String>();
		params.add(objliststart + URLEncoder.encode(objlist, "US-ASCII"));
		json = session.readJSONResponse(apiCallPath, params);
		jlist = json.getJSONObject("list");
		objs = JSONObject.getNames(jlist);

		for (String obj : objs) {
			JSONObject usage = jlist.getJSONObject(obj);
			Long sTotal = usage.getLong("totalStorageUsage");
			Long oldestTime = usage.getLong("oldestTime");

			StorageCoverage c = storageCoverages.get(Integer.parseInt(obj));

			if (c == null) {
				c = new StorageCoverage(0, "MB/hour");
			}
			c.setTotalUsage(sTotal);
			c.setOldestTime(oldestTime);

			storageCoverages.put(Integer.parseInt(obj), c);

		}

		return storageCoverages;
	}

	/**
	 * 
	 * @param objList
	 * @param startTime
	 * @param endTime
	 * @param granularity
	 * @param digest
	 * @return
	 * @throws IllegalStateException
	 * @throws ClientProtocolException
	 * @throws IOException
	 * @throws JSONException
	 */
	public static Map<Integer, StorageCoverage> getStorageCoverage(
			List<Integer> objList, long startTime, long endTime,
			Granularity granularity, boolean digest)
			throws IllegalStateException, ClientProtocolException, IOException,
			JSONException {
		Map<Integer, StorageCoverage> storageCoverages = new HashMap<Integer, StorageCoverage>();

		String apiCallPath = "/api/call/getStorageCoverage";
		JSONArray j = new JSONArray(objList);
		System.out.println(j.toString());
		List<String> params = new ArrayList<String>();
		String objliststart = "objList=";
		
		params.add(objliststart + URLEncoder.encode(j.toString(), "US-ASCII"));
		params.add("startTime=" + startTime);
		params.add("endTime=" + endTime);

		switch (granularity) {
		case MIN:
			params.add("granularity=min");
			break;
		case HOUR:
			params.add("granularity=min");
			break;
		case DAY:
			params.add("granularity=day");
			break;
		case MON:
			params.add("granularity=mon");
			break;
		default:
			break;
		}

		if (digest) {
			params.add("streamNumber=0");
		} else {
			params.add("streamNumber=1");
		}

		JSONObject json = session.readJSONResponse(apiCallPath, params);
		JSONObject jlist = json.getJSONObject("list");
		String[] objs = JSONObject.getNames(jlist);
		for (String obj : objs) {
			Map<Long, Integer> objCoverage = new HashMap<Long, Integer>();
			try {
				JSONObject coverage = jlist.getJSONObject(obj);
				String[] times = JSONObject.getNames(coverage);
				for (String time : times) {
					objCoverage
							.put(Long.parseLong(time), coverage.getInt(time));
				}

				storageCoverages.put(Integer.valueOf(obj), new StorageCoverage(
						objCoverage));
			} catch (JSONException e) {

			}
		}

		return storageCoverages;
	}

}
