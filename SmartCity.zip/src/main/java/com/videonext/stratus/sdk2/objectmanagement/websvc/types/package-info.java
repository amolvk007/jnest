@javax.xml.bind.annotation.XmlSchema(namespace = "http://skm.videonext.com/om/websvc/types", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.videonext.stratus.sdk2.objectmanagement.websvc.types;
