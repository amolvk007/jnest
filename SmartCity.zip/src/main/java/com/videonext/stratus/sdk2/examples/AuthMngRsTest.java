package com.videonext.stratus.sdk2.examples;

import java.awt.Image;
import java.io.IOException;
import java.util.logging.Level;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

import org.apache.http.client.ClientProtocolException;
import org.json.JSONException;

import com.videonext.stratus.sdk2.media.AuthMngRs;
import com.videonext.stratus.sdk2.media.AuthMngRs.AuthStream;
import com.videonext.stratus.sdk2.media.AuthMngRs.StreamType;
import com.videonext.stratus.sdk2.session.Session;

public class AuthMngRsTest {

	/**
	 * @param args
	 * @throws JSONException 
	 * @throws IOException 
	 * @throws IllegalStateException 
	 * @throws ClientProtocolException 
	 */
	public static void main(String[] args) throws ClientProtocolException, IllegalStateException, IOException, JSONException {
		Session session = Session.getSession();
		
		int objid = 125;
		String host = "vtm.videonext.com";
		session.setTrustAll(true);
		session.setLogger(Level.WARNING);
		session.openSession(host, "admin", "topse","http");
		
		AuthStream authStream = AuthMngRs.getAuth(objid, StreamType.LIVE, 0, 0, false);
		//System.out.println(authStream.toString());
		System.out.println(authStream.getUrl());//+"&authorizationid="+authStream.getAuthid());
		
		long time = System.currentTimeMillis() * 1000;
		authStream = AuthMngRs.getAuth(objid, StreamType.ARCHIVE, time-3600, time-3540, false);
		//System.out.println(authStream.toString());
		
		System.exit(0);
		
		Image image = AuthMngRs.getSnapshot(objid);
		
		JFrame frame = new JFrame();
		JLabel icon = new JLabel();
		icon.setIcon(new ImageIcon(image));
		frame.setSize(image.getWidth(null), image.getHeight(null));
		frame.add(icon);
		frame.setVisible(true);
		
	}

}
