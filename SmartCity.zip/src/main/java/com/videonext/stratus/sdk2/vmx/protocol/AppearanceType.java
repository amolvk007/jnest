
package com.videonext.stratus.sdk2.vmx.protocol;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for appearanceType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="appearanceType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="FONT" type="{http://websvc.videonext.com/protocol}FONTType" minOccurs="0"/>
 *         &lt;element name="BORDER" type="{http://websvc.videonext.com/protocol}BORDERType" minOccurs="0"/>
 *         &lt;element name="HEADER" type="{http://websvc.videonext.com/protocol}HEADERType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "appearanceType", propOrder = {
    "font",
    "border",
    "header"
})
public class AppearanceType {

    @XmlElement(name = "FONT")
    protected FONTType font;
    @XmlElement(name = "BORDER")
    protected BORDERType border;
    @XmlElement(name = "HEADER")
    protected HEADERType header;

    /**
     * Gets the value of the font property.
     * 
     * @return
     *     possible object is
     *     {@link FONTType }
     *     
     */
    public FONTType getFONT() {
        return font;
    }

    /**
     * Sets the value of the font property.
     * 
     * @param value
     *     allowed object is
     *     {@link FONTType }
     *     
     */
    public void setFONT(FONTType value) {
        this.font = value;
    }

    /**
     * Gets the value of the border property.
     * 
     * @return
     *     possible object is
     *     {@link BORDERType }
     *     
     */
    public BORDERType getBORDER() {
        return border;
    }

    /**
     * Sets the value of the border property.
     * 
     * @param value
     *     allowed object is
     *     {@link BORDERType }
     *     
     */
    public void setBORDER(BORDERType value) {
        this.border = value;
    }

    /**
     * Gets the value of the header property.
     * 
     * @return
     *     possible object is
     *     {@link HEADERType }
     *     
     */
    public HEADERType getHEADER() {
        return header;
    }

    /**
     * Sets the value of the header property.
     * 
     * @param value
     *     allowed object is
     *     {@link HEADERType }
     *     
     */
    public void setHEADER(HEADERType value) {
        this.header = value;
    }

}
