
package com.videonext.stratus.sdk2.vmx.protocol;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://websvc.videonext.com/protocol}SessionID"/>
 *         &lt;element name="assigned_cell" type="{http://websvc.videonext.com/protocol}assigned_cellType" maxOccurs="unbounded"/>
 *         &lt;element ref="{http://websvc.videonext.com/protocol}Priority" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "sessionID",
    "assignedCell",
    "priority"
})
@XmlRootElement(name = "assign_info")
public class AssignInfo {

    @XmlElement(name = "SessionID", required = true)
    protected String sessionID;
    @XmlElement(name = "assigned_cell", required = true)
    protected List<AssignedCellType> assignedCell;
    @XmlElement(name = "Priority")
    protected CellPriorityType priority;

    /**
     * Gets the value of the sessionID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSessionID() {
        return sessionID;
    }

    /**
     * Sets the value of the sessionID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSessionID(String value) {
        this.sessionID = value;
    }

    /**
     * Gets the value of the assignedCell property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the assignedCell property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAssignedCell().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AssignedCellType }
     * 
     * 
     */
    public List<AssignedCellType> getAssignedCell() {
        if (assignedCell == null) {
            assignedCell = new ArrayList<AssignedCellType>();
        }
        return this.assignedCell;
    }

    /**
     * Gets the value of the priority property.
     * 
     * @return
     *     possible object is
     *     {@link CellPriorityType }
     *     
     */
    public CellPriorityType getPriority() {
        return priority;
    }

    /**
     * Sets the value of the priority property.
     * 
     * @param value
     *     allowed object is
     *     {@link CellPriorityType }
     *     
     */
    public void setPriority(CellPriorityType value) {
        this.priority = value;
    }

}
