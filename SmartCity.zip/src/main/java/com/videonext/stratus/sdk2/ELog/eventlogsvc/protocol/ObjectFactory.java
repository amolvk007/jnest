
package com.videonext.stratus.sdk2.ELog.eventlogsvc.protocol;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.videonext.eventlogsvc.protocol package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _Objid_QNAME = new QName("http://eventlogsvc.videonext.com/protocol", "objid");
    private final static QName _OUTPUTOPTIONS_QNAME = new QName("http://eventlogsvc.videonext.com/protocol", "OUTPUTOPTIONS");
    private final static QName _Eventsource_QNAME = new QName("http://eventlogsvc.videonext.com/protocol", "eventsource");
    private final static QName _FILTER_QNAME = new QName("http://eventlogsvc.videonext.com/protocol", "FILTER");
    private final static QName _Workflow_QNAME = new QName("http://eventlogsvc.videonext.com/protocol", "workflow");
    private final static QName _Message_QNAME = new QName("http://eventlogsvc.videonext.com/protocol", "message");
    private final static QName _Started_QNAME = new QName("http://eventlogsvc.videonext.com/protocol", "started");
    private final static QName _Setid_QNAME = new QName("http://eventlogsvc.videonext.com/protocol", "setid");
    private final static QName _Eventtype_QNAME = new QName("http://eventlogsvc.videonext.com/protocol", "eventtype");
    private final static QName _PAGEBREAK_QNAME = new QName("http://eventlogsvc.videonext.com/protocol", "PAGEBREAK");
    private final static QName _Tag_QNAME = new QName("http://eventlogsvc.videonext.com/protocol", "tag");
    private final static QName _OPTION_QNAME = new QName("http://eventlogsvc.videonext.com/protocol", "OPTION");
    private final static QName _State_QNAME = new QName("http://eventlogsvc.videonext.com/protocol", "state");
    private final static QName _Eventid_QNAME = new QName("http://eventlogsvc.videonext.com/protocol", "eventid");
    private final static QName _PARAM_QNAME = new QName("http://eventlogsvc.videonext.com/protocol", "PARAM");
    private final static QName _Priority_QNAME = new QName("http://eventlogsvc.videonext.com/protocol", "priority");
    private final static QName _Snapshotid_QNAME = new QName("http://eventlogsvc.videonext.com/protocol", "snapshotid");
    private final static QName _Crossinterval_QNAME = new QName("http://eventlogsvc.videonext.com/protocol", "crossinterval");
    private final static QName _EVENTS_QNAME = new QName("http://eventlogsvc.videonext.com/protocol", "EVENTS");
    private final static QName _Tscovered_QNAME = new QName("http://eventlogsvc.videonext.com/protocol", "tscovered");
    private final static QName _EVENT_QNAME = new QName("http://eventlogsvc.videonext.com/protocol", "EVENT");
    private final static QName _Lifespan_QNAME = new QName("http://eventlogsvc.videonext.com/protocol", "lifespan");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.videonext.eventlogsvc.protocol
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link ACTIONSType }
     * 
     */
    public ACTIONSType createACTIONSType() {
        return new ACTIONSType();
    }

    /**
     * Create an instance of {@link MEDIASIZEType }
     * 
     */
    public MEDIASIZEType createMEDIASIZEType() {
        return new MEDIASIZEType();
    }

    /**
     * Create an instance of {@link TEqParamInt }
     * 
     */
    public TEqParamInt createTEqParamInt() {
        return new TEqParamInt();
    }

    /**
     * Create an instance of {@link TTextFilter }
     * 
     */
    public TTextFilter createTTextFilter() {
        return new TTextFilter();
    }

    /**
     * Create an instance of {@link EVENTType }
     * 
     */
    public EVENTType createEVENTType() {
        return new EVENTType();
    }

    /**
     * Create an instance of {@link ACTIONPARAMType }
     * 
     */
    public ACTIONPARAMType createACTIONPARAMType() {
        return new ACTIONPARAMType();
    }

    /**
     * Create an instance of {@link EVENTACTIONType }
     * 
     */
    public EVENTACTIONType createEVENTACTIONType() {
        return new EVENTACTIONType();
    }

    /**
     * Create an instance of {@link TTimeElement }
     * 
     */
    public TTimeElement createTTimeElement() {
        return new TTimeElement();
    }

    /**
     * Create an instance of {@link WITNESSESType }
     * 
     */
    public WITNESSESType createWITNESSESType() {
        return new WITNESSESType();
    }

    /**
     * Create an instance of {@link OUTPUTOPTIONSType }
     * 
     */
    public OUTPUTOPTIONSType createOUTPUTOPTIONSType() {
        return new OUTPUTOPTIONSType();
    }

    /**
     * Create an instance of {@link ACTIONType }
     * 
     */
    public ACTIONType createACTIONType() {
        return new ACTIONType();
    }

    /**
     * Create an instance of {@link TEqParam }
     * 
     */
    public TEqParam createTEqParam() {
        return new TEqParam();
    }

    /**
     * Create an instance of {@link PAGEBREAKType }
     * 
     */
    public PAGEBREAKType createPAGEBREAKType() {
        return new PAGEBREAKType();
    }

    /**
     * Create an instance of {@link ACTIONREQUESTType }
     * 
     */
    public ACTIONREQUESTType createACTIONREQUESTType() {
        return new ACTIONREQUESTType();
    }

    /**
     * Create an instance of {@link PROPERTYType }
     * 
     */
    public PROPERTYType createPROPERTYType() {
        return new PROPERTYType();
    }

    /**
     * Create an instance of {@link ACTIONSTATUSType }
     * 
     */
    public ACTIONSTATUSType createACTIONSTATUSType() {
        return new ACTIONSTATUSType();
    }

    /**
     * Create an instance of {@link TUnixtimeElement }
     * 
     */
    public TUnixtimeElement createTUnixtimeElement() {
        return new TUnixtimeElement();
    }

    /**
     * Create an instance of {@link T3ConditionParam }
     * 
     */
    public T3ConditionParam createT3ConditionParam() {
        return new T3ConditionParam();
    }

    /**
     * Create an instance of {@link NESTEDACTIONType }
     * 
     */
    public NESTEDACTIONType createNESTEDACTIONType() {
        return new NESTEDACTIONType();
    }

    /**
     * Create an instance of {@link EVENTSType }
     * 
     */
    public EVENTSType createEVENTSType() {
        return new EVENTSType();
    }

    /**
     * Create an instance of {@link OPTIONType }
     * 
     */
    public OPTIONType createOPTIONType() {
        return new OPTIONType();
    }

    /**
     * Create an instance of {@link TCommonParamType }
     * 
     */
    public TCommonParamType createTCommonParamType() {
        return new TCommonParamType();
    }

    /**
     * Create an instance of {@link PROPERTIESType }
     * 
     */
    public PROPERTIESType createPROPERTIESType() {
        return new PROPERTIESType();
    }

    /**
     * Create an instance of {@link ACTIONRESPONSEType }
     * 
     */
    public ACTIONRESPONSEType createACTIONRESPONSEType() {
        return new ACTIONRESPONSEType();
    }

    /**
     * Create an instance of {@link FILTERType }
     * 
     */
    public FILTERType createFILTERType() {
        return new FILTERType();
    }

    /**
     * Create an instance of {@link PAGEType }
     * 
     */
    public PAGEType createPAGEType() {
        return new PAGEType();
    }

    /**
     * Create an instance of {@link EVENTREQUESTType }
     * 
     */
    public EVENTREQUESTType createEVENTREQUESTType() {
        return new EVENTREQUESTType();
    }

    /**
     * Create an instance of {@link TBetweenParam }
     * 
     */
    public TBetweenParam createTBetweenParam() {
        return new TBetweenParam();
    }

    /**
     * Create an instance of {@link OBJType }
     * 
     */
    public OBJType createOBJType() {
        return new OBJType();
    }

    /**
     * Create an instance of {@link EVENTRESPONSEType }
     * 
     */
    public EVENTRESPONSEType createEVENTRESPONSEType() {
        return new EVENTRESPONSEType();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link T3ConditionParam }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://eventlogsvc.videonext.com/protocol", name = "objid")
    public JAXBElement<T3ConditionParam> createObjid(T3ConditionParam value) {
        return new JAXBElement<T3ConditionParam>(_Objid_QNAME, T3ConditionParam.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OUTPUTOPTIONSType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://eventlogsvc.videonext.com/protocol", name = "OUTPUTOPTIONS")
    public JAXBElement<OUTPUTOPTIONSType> createOUTPUTOPTIONS(OUTPUTOPTIONSType value) {
        return new JAXBElement<OUTPUTOPTIONSType>(_OUTPUTOPTIONS_QNAME, OUTPUTOPTIONSType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link T3ConditionParam }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://eventlogsvc.videonext.com/protocol", name = "eventsource")
    public JAXBElement<T3ConditionParam> createEventsource(T3ConditionParam value) {
        return new JAXBElement<T3ConditionParam>(_Eventsource_QNAME, T3ConditionParam.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FILTERType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://eventlogsvc.videonext.com/protocol", name = "FILTER")
    public JAXBElement<FILTERType> createFILTER(FILTERType value) {
        return new JAXBElement<FILTERType>(_FILTER_QNAME, FILTERType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link T3ConditionParam }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://eventlogsvc.videonext.com/protocol", name = "workflow")
    public JAXBElement<T3ConditionParam> createWorkflow(T3ConditionParam value) {
        return new JAXBElement<T3ConditionParam>(_Workflow_QNAME, T3ConditionParam.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TTextFilter }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://eventlogsvc.videonext.com/protocol", name = "message")
    public JAXBElement<TTextFilter> createMessage(TTextFilter value) {
        return new JAXBElement<TTextFilter>(_Message_QNAME, TTextFilter.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TBetweenParam }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://eventlogsvc.videonext.com/protocol", name = "started")
    public JAXBElement<TBetweenParam> createStarted(TBetweenParam value) {
        return new JAXBElement<TBetweenParam>(_Started_QNAME, TBetweenParam.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link T3ConditionParam }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://eventlogsvc.videonext.com/protocol", name = "setid")
    public JAXBElement<T3ConditionParam> createSetid(T3ConditionParam value) {
        return new JAXBElement<T3ConditionParam>(_Setid_QNAME, T3ConditionParam.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link T3ConditionParam }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://eventlogsvc.videonext.com/protocol", name = "eventtype")
    public JAXBElement<T3ConditionParam> createEventtype(T3ConditionParam value) {
        return new JAXBElement<T3ConditionParam>(_Eventtype_QNAME, T3ConditionParam.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PAGEBREAKType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://eventlogsvc.videonext.com/protocol", name = "PAGEBREAK")
    public JAXBElement<PAGEBREAKType> createPAGEBREAK(PAGEBREAKType value) {
        return new JAXBElement<PAGEBREAKType>(_PAGEBREAK_QNAME, PAGEBREAKType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link T3ConditionParam }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://eventlogsvc.videonext.com/protocol", name = "tag")
    public JAXBElement<T3ConditionParam> createTag(T3ConditionParam value) {
        return new JAXBElement<T3ConditionParam>(_Tag_QNAME, T3ConditionParam.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OPTIONType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://eventlogsvc.videonext.com/protocol", name = "OPTION")
    public JAXBElement<OPTIONType> createOPTION(OPTIONType value) {
        return new JAXBElement<OPTIONType>(_OPTION_QNAME, OPTIONType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link T3ConditionParam }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://eventlogsvc.videonext.com/protocol", name = "state")
    public JAXBElement<T3ConditionParam> createState(T3ConditionParam value) {
        return new JAXBElement<T3ConditionParam>(_State_QNAME, T3ConditionParam.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TCommonParamType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://eventlogsvc.videonext.com/protocol", name = "eventid")
    public JAXBElement<TCommonParamType> createEventid(TCommonParamType value) {
        return new JAXBElement<TCommonParamType>(_Eventid_QNAME, TCommonParamType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ACTIONPARAMType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://eventlogsvc.videonext.com/protocol", name = "PARAM")
    public JAXBElement<ACTIONPARAMType> createPARAM(ACTIONPARAMType value) {
        return new JAXBElement<ACTIONPARAMType>(_PARAM_QNAME, ACTIONPARAMType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TCommonParamType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://eventlogsvc.videonext.com/protocol", name = "priority")
    public JAXBElement<TCommonParamType> createPriority(TCommonParamType value) {
        return new JAXBElement<TCommonParamType>(_Priority_QNAME, TCommonParamType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TEqParamInt }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://eventlogsvc.videonext.com/protocol", name = "snapshotid")
    public JAXBElement<TEqParamInt> createSnapshotid(TEqParamInt value) {
        return new JAXBElement<TEqParamInt>(_Snapshotid_QNAME, TEqParamInt.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TBetweenParam }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://eventlogsvc.videonext.com/protocol", name = "crossinterval")
    public JAXBElement<TBetweenParam> createCrossinterval(TBetweenParam value) {
        return new JAXBElement<TBetweenParam>(_Crossinterval_QNAME, TBetweenParam.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EVENTSType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://eventlogsvc.videonext.com/protocol", name = "EVENTS")
    public JAXBElement<EVENTSType> createEVENTS(EVENTSType value) {
        return new JAXBElement<EVENTSType>(_EVENTS_QNAME, EVENTSType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TEqParam }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://eventlogsvc.videonext.com/protocol", name = "tscovered")
    public JAXBElement<TEqParam> createTscovered(TEqParam value) {
        return new JAXBElement<TEqParam>(_Tscovered_QNAME, TEqParam.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EVENTType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://eventlogsvc.videonext.com/protocol", name = "EVENT")
    public JAXBElement<EVENTType> createEVENT(EVENTType value) {
        return new JAXBElement<EVENTType>(_EVENT_QNAME, EVENTType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TCommonParamType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://eventlogsvc.videonext.com/protocol", name = "lifespan")
    public JAXBElement<TCommonParamType> createLifespan(TCommonParamType value) {
        return new JAXBElement<TCommonParamType>(_Lifespan_QNAME, TCommonParamType.class, null, value);
    }

}
