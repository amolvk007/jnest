
package com.videonext.stratus.sdk2.objectmanagement.websvc.types;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Method" type="{http://skm.videonext.com/om/websvc/types}ServiceMethodType"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "method"
})
@XmlRootElement(name = "ServiceManagementRequest")
public class ServiceManagementRequest {

    @XmlElement(name = "Method", required = true)
    protected ServiceMethodType method;

    /**
     * Gets the value of the method property.
     * 
     * @return
     *     possible object is
     *     {@link ServiceMethodType }
     *     
     */
    public ServiceMethodType getMethod() {
        return method;
    }

    /**
     * Sets the value of the method property.
     * 
     * @param value
     *     allowed object is
     *     {@link ServiceMethodType }
     *     
     */
    public void setMethod(ServiceMethodType value) {
        this.method = value;
    }

}
