
package com.videonext.stratus.sdk2.vmx.protocol;

import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for cellType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="cellType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://websvc.videonext.com/protocol}APPEARANCE" minOccurs="0"/>
 *         &lt;element ref="{http://websvc.videonext.com/protocol}Touring" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="id" use="required" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="x" type="{http://www.w3.org/2001/XMLSchema}unsignedShort" />
 *       &lt;attribute name="y" type="{http://www.w3.org/2001/XMLSchema}unsignedShort" />
 *       &lt;attribute name="w" type="{http://www.w3.org/2001/XMLSchema}unsignedShort" />
 *       &lt;attribute name="h" type="{http://www.w3.org/2001/XMLSchema}unsignedShort" />
 *       &lt;attribute name="sourceOBJID" type="{http://www.w3.org/2001/XMLSchema}unsignedInt" />
 *       &lt;attribute name="state" type="{http://websvc.videonext.com/protocol}stateType" />
 *       &lt;attribute name="open_timeout" type="{http://www.w3.org/2001/XMLSchema}unsignedByte" />
 *       &lt;attribute name="play_timeout" type="{http://www.w3.org/2001/XMLSchema}unsignedByte" />
 *       &lt;attribute name="scale" type="{http://websvc.videonext.com/protocol}scaleType" />
 *       &lt;attribute name="text" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="arc_from" type="{http://www.w3.org/2001/XMLSchema}long" />
 *       &lt;attribute name="arc_to" type="{http://www.w3.org/2001/XMLSchema}long" />
 *       &lt;attribute name="arc_pos" type="{http://www.w3.org/2001/XMLSchema}long" />
 *       &lt;attribute name="groupid" type="{http://www.w3.org/2001/XMLSchema}int" />
 *       &lt;attribute name="eventid" type="{http://www.w3.org/2001/XMLSchema}unsignedLong" />
 *       &lt;attribute name="vncurl" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="analytics" type="{http://www.w3.org/2001/XMLSchema}int" />
 *       &lt;attribute name="streamnum" type="{http://www.w3.org/2001/XMLSchema}int" default="-1" />
 *       &lt;attribute name="audioObjid" type="{http://www.w3.org/2001/XMLSchema}int" default="0" />
 *       &lt;attribute name="volume" type="{http://www.w3.org/2001/XMLSchema}int" default="0" />
 *       &lt;attribute name="weburl" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="refresh" type="{http://www.w3.org/2001/XMLSchema}int" />
 *       &lt;attribute name="priority" type="{http://www.w3.org/2001/XMLSchema}int" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "cellType", propOrder = {
    "appearance",
    "touring"
})
public class CellType {

    @XmlElement(name = "APPEARANCE")
    protected AppearanceType appearance;
    @XmlElement(name = "Touring")
    protected TouringType touring;
    @XmlAttribute(name = "id", required = true)
    protected String id;
    @XmlAttribute(name = "x")
    @XmlSchemaType(name = "unsignedShort")
    protected Integer x;
    @XmlAttribute(name = "y")
    @XmlSchemaType(name = "unsignedShort")
    protected Integer y;
    @XmlAttribute(name = "w")
    @XmlSchemaType(name = "unsignedShort")
    protected Integer w;
    @XmlAttribute(name = "h")
    @XmlSchemaType(name = "unsignedShort")
    protected Integer h;
    @XmlAttribute(name = "sourceOBJID")
    @XmlSchemaType(name = "unsignedInt")
    protected Long sourceOBJID;
    @XmlAttribute(name = "state")
    protected StateType state;
    @XmlAttribute(name = "open_timeout")
    @XmlSchemaType(name = "unsignedByte")
    protected Short openTimeout;
    @XmlAttribute(name = "play_timeout")
    @XmlSchemaType(name = "unsignedByte")
    protected Short playTimeout;
    @XmlAttribute(name = "scale")
    protected ScaleType scale;
    @XmlAttribute(name = "text")
    protected String text;
    @XmlAttribute(name = "arc_from")
    protected Long arcFrom;
    @XmlAttribute(name = "arc_to")
    protected Long arcTo;
    @XmlAttribute(name = "arc_pos")
    protected Long arcPos;
    @XmlAttribute(name = "groupid")
    protected Integer groupid;
    @XmlAttribute(name = "eventid")
    @XmlSchemaType(name = "unsignedLong")
    protected BigInteger eventid;
    @XmlAttribute(name = "vncurl")
    protected String vncurl;
    @XmlAttribute(name = "analytics")
    protected Integer analytics;
    @XmlAttribute(name = "streamnum")
    protected Integer streamnum;
    @XmlAttribute(name = "audioObjid")
    protected Integer audioObjid;
    @XmlAttribute(name = "volume")
    protected Integer volume;
    @XmlAttribute(name = "weburl")
    protected String weburl;
    @XmlAttribute(name = "refresh")
    protected Integer refresh;
    @XmlAttribute(name = "priority")
    protected Integer priority;

    /**
     * Gets the value of the appearance property.
     * 
     * @return
     *     possible object is
     *     {@link AppearanceType }
     *     
     */
    public AppearanceType getAPPEARANCE() {
        return appearance;
    }

    /**
     * Sets the value of the appearance property.
     * 
     * @param value
     *     allowed object is
     *     {@link AppearanceType }
     *     
     */
    public void setAPPEARANCE(AppearanceType value) {
        this.appearance = value;
    }

    /**
     * Gets the value of the touring property.
     * 
     * @return
     *     possible object is
     *     {@link TouringType }
     *     
     */
    public TouringType getTouring() {
        return touring;
    }

    /**
     * Sets the value of the touring property.
     * 
     * @param value
     *     allowed object is
     *     {@link TouringType }
     *     
     */
    public void setTouring(TouringType value) {
        this.touring = value;
    }

    /**
     * Gets the value of the id property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setId(String value) {
        this.id = value;
    }

    /**
     * Gets the value of the x property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getX() {
        return x;
    }

    /**
     * Sets the value of the x property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setX(Integer value) {
        this.x = value;
    }

    /**
     * Gets the value of the y property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getY() {
        return y;
    }

    /**
     * Sets the value of the y property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setY(Integer value) {
        this.y = value;
    }

    /**
     * Gets the value of the w property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getW() {
        return w;
    }

    /**
     * Sets the value of the w property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setW(Integer value) {
        this.w = value;
    }

    /**
     * Gets the value of the h property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getH() {
        return h;
    }

    /**
     * Sets the value of the h property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setH(Integer value) {
        this.h = value;
    }

    /**
     * Gets the value of the sourceOBJID property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getSourceOBJID() {
        return sourceOBJID;
    }

    /**
     * Sets the value of the sourceOBJID property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setSourceOBJID(Long value) {
        this.sourceOBJID = value;
    }

    /**
     * Gets the value of the state property.
     * 
     * @return
     *     possible object is
     *     {@link StateType }
     *     
     */
    public StateType getState() {
        return state;
    }

    /**
     * Sets the value of the state property.
     * 
     * @param value
     *     allowed object is
     *     {@link StateType }
     *     
     */
    public void setState(StateType value) {
        this.state = value;
    }

    /**
     * Gets the value of the openTimeout property.
     * 
     * @return
     *     possible object is
     *     {@link Short }
     *     
     */
    public Short getOpenTimeout() {
        return openTimeout;
    }

    /**
     * Sets the value of the openTimeout property.
     * 
     * @param value
     *     allowed object is
     *     {@link Short }
     *     
     */
    public void setOpenTimeout(Short value) {
        this.openTimeout = value;
    }

    /**
     * Gets the value of the playTimeout property.
     * 
     * @return
     *     possible object is
     *     {@link Short }
     *     
     */
    public Short getPlayTimeout() {
        return playTimeout;
    }

    /**
     * Sets the value of the playTimeout property.
     * 
     * @param value
     *     allowed object is
     *     {@link Short }
     *     
     */
    public void setPlayTimeout(Short value) {
        this.playTimeout = value;
    }

    /**
     * Gets the value of the scale property.
     * 
     * @return
     *     possible object is
     *     {@link ScaleType }
     *     
     */
    public ScaleType getScale() {
        return scale;
    }

    /**
     * Sets the value of the scale property.
     * 
     * @param value
     *     allowed object is
     *     {@link ScaleType }
     *     
     */
    public void setScale(ScaleType value) {
        this.scale = value;
    }

    /**
     * Gets the value of the text property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getText() {
        return text;
    }

    /**
     * Sets the value of the text property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setText(String value) {
        this.text = value;
    }

    /**
     * Gets the value of the arcFrom property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getArcFrom() {
        return arcFrom;
    }

    /**
     * Sets the value of the arcFrom property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setArcFrom(Long value) {
        this.arcFrom = value;
    }

    /**
     * Gets the value of the arcTo property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getArcTo() {
        return arcTo;
    }

    /**
     * Sets the value of the arcTo property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setArcTo(Long value) {
        this.arcTo = value;
    }

    /**
     * Gets the value of the arcPos property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getArcPos() {
        return arcPos;
    }

    /**
     * Sets the value of the arcPos property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setArcPos(Long value) {
        this.arcPos = value;
    }

    /**
     * Gets the value of the groupid property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getGroupid() {
        return groupid;
    }

    /**
     * Sets the value of the groupid property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setGroupid(Integer value) {
        this.groupid = value;
    }

    /**
     * Gets the value of the eventid property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getEventid() {
        return eventid;
    }

    /**
     * Sets the value of the eventid property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setEventid(BigInteger value) {
        this.eventid = value;
    }

    /**
     * Gets the value of the vncurl property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVncurl() {
        return vncurl;
    }

    /**
     * Sets the value of the vncurl property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVncurl(String value) {
        this.vncurl = value;
    }

    /**
     * Gets the value of the analytics property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getAnalytics() {
        return analytics;
    }

    /**
     * Sets the value of the analytics property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setAnalytics(Integer value) {
        this.analytics = value;
    }

    /**
     * Gets the value of the streamnum property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public int getStreamnum() {
        if (streamnum == null) {
            return -1;
        } else {
            return streamnum;
        }
    }

    /**
     * Sets the value of the streamnum property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setStreamnum(Integer value) {
        this.streamnum = value;
    }

    /**
     * Gets the value of the audioObjid property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public int getAudioObjid() {
        if (audioObjid == null) {
            return  0;
        } else {
            return audioObjid;
        }
    }

    /**
     * Sets the value of the audioObjid property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setAudioObjid(Integer value) {
        this.audioObjid = value;
    }

    /**
     * Gets the value of the volume property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public int getVolume() {
        if (volume == null) {
            return  0;
        } else {
            return volume;
        }
    }

    /**
     * Sets the value of the volume property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setVolume(Integer value) {
        this.volume = value;
    }

    /**
     * Gets the value of the weburl property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWeburl() {
        return weburl;
    }

    /**
     * Sets the value of the weburl property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWeburl(String value) {
        this.weburl = value;
    }

    /**
     * Gets the value of the refresh property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getRefresh() {
        return refresh;
    }

    /**
     * Sets the value of the refresh property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setRefresh(Integer value) {
        this.refresh = value;
    }

    /**
     * Gets the value of the priority property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getPriority() {
        return priority;
    }

    /**
     * Sets the value of the priority property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setPriority(Integer value) {
        this.priority = value;
    }

}
