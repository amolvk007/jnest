
package com.videonext.stratus.sdk2.ELog.eventlogsvc.protocol;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for WITNESSESType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="WITNESSESType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="OBJ" type="{http://eventlogsvc.videonext.com/protocol}OBJType" maxOccurs="unbounded"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "WITNESSESType", propOrder = {
    "obj"
})
public class WITNESSESType {

    @XmlElement(name = "OBJ", required = true)
    protected List<OBJType> obj;

    /**
     * Gets the value of the obj property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the obj property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getOBJ().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link OBJType }
     * 
     * 
     */
    public List<OBJType> getOBJ() {
        if (obj == null) {
            obj = new ArrayList<OBJType>();
        }
        return this.obj;
    }

}
