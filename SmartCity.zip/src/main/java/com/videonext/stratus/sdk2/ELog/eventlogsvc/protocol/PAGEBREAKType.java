
package com.videonext.stratus.sdk2.ELog.eventlogsvc.protocol;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PAGEBREAKType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PAGEBREAKType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;attribute name="PAGESIZE" use="required" type="{http://www.w3.org/2001/XMLSchema}int" />
 *       &lt;attribute name="PAGE" type="{http://www.w3.org/2001/XMLSchema}int" />
 *       &lt;attribute name="SNAPSHOTID" type="{http://www.w3.org/2001/XMLSchema}int" />
 *       &lt;attribute name="SORT" type="{http://eventlogsvc.videonext.com/protocol}st_sort" />
 *       &lt;attribute name="SORTASC" type="{http://www.w3.org/2001/XMLSchema}boolean" default="true" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PAGEBREAKType")
public class PAGEBREAKType {

    @XmlAttribute(name = "PAGESIZE", required = true)
    protected int pagesize;
    @XmlAttribute(name = "PAGE")
    protected Integer page;
    @XmlAttribute(name = "SNAPSHOTID")
    protected Integer snapshotid;
    @XmlAttribute(name = "SORT")
    protected StSort sort;
    @XmlAttribute(name = "SORTASC")
    protected Boolean sortasc;

    /**
     * Gets the value of the pagesize property.
     * 
     */
    public int getPAGESIZE() {
        return pagesize;
    }

    /**
     * Sets the value of the pagesize property.
     * 
     */
    public void setPAGESIZE(int value) {
        this.pagesize = value;
    }

    /**
     * Gets the value of the page property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getPAGE() {
        return page;
    }

    /**
     * Sets the value of the page property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setPAGE(Integer value) {
        this.page = value;
    }

    /**
     * Gets the value of the snapshotid property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getSNAPSHOTID() {
        return snapshotid;
    }

    /**
     * Sets the value of the snapshotid property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setSNAPSHOTID(Integer value) {
        this.snapshotid = value;
    }

    /**
     * Gets the value of the sort property.
     * 
     * @return
     *     possible object is
     *     {@link StSort }
     *     
     */
    public StSort getSORT() {
        return sort;
    }

    /**
     * Sets the value of the sort property.
     * 
     * @param value
     *     allowed object is
     *     {@link StSort }
     *     
     */
    public void setSORT(StSort value) {
        this.sort = value;
    }

    /**
     * Gets the value of the sortasc property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public boolean isSORTASC() {
        if (sortasc == null) {
            return true;
        } else {
            return sortasc;
        }
    }

    /**
     * Sets the value of the sortasc property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setSORTASC(Boolean value) {
        this.sortasc = value;
    }

}
