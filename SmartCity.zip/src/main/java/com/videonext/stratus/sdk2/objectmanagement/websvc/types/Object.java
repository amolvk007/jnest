
package com.videonext.stratus.sdk2.objectmanagement.websvc.types;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Object complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Object">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Host" type="{http://skm.videonext.com/om/websvc/types}Host" minOccurs="0"/>
 *         &lt;element name="Properties" type="{http://skm.videonext.com/om/websvc/types}PropertyList" minOccurs="0"/>
 *         &lt;element name="Methods" type="{http://skm.videonext.com/om/websvc/types}MethodDescList" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="objid" use="required" type="{http://www.w3.org/2001/XMLSchema}int" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Object", propOrder = {
    "host",
    "properties",
    "methods"
})
public class Object {

    @XmlElement(name = "Host")
    protected Host host;
    @XmlElement(name = "Properties")
    protected PropertyList properties;
    @XmlElement(name = "Methods")
    protected MethodDescList methods;
    @XmlAttribute(name = "objid", required = true)
    protected int objid;

    /**
     * Gets the value of the host property.
     * 
     * @return
     *     possible object is
     *     {@link Host }
     *     
     */
    public Host getHost() {
        return host;
    }

    /**
     * Sets the value of the host property.
     * 
     * @param value
     *     allowed object is
     *     {@link Host }
     *     
     */
    public void setHost(Host value) {
        this.host = value;
    }

    /**
     * Gets the value of the properties property.
     * 
     * @return
     *     possible object is
     *     {@link PropertyList }
     *     
     */
    public PropertyList getProperties() {
        return properties;
    }

    /**
     * Sets the value of the properties property.
     * 
     * @param value
     *     allowed object is
     *     {@link PropertyList }
     *     
     */
    public void setProperties(PropertyList value) {
        this.properties = value;
    }

    /**
     * Gets the value of the methods property.
     * 
     * @return
     *     possible object is
     *     {@link MethodDescList }
     *     
     */
    public MethodDescList getMethods() {
        return methods;
    }

    /**
     * Sets the value of the methods property.
     * 
     * @param value
     *     allowed object is
     *     {@link MethodDescList }
     *     
     */
    public void setMethods(MethodDescList value) {
        this.methods = value;
    }

    /**
     * Gets the value of the objid property.
     * 
     */
    public int getObjid() {
        return objid;
    }

    /**
     * Sets the value of the objid property.
     * 
     */
    public void setObjid(int value) {
        this.objid = value;
    }

}
