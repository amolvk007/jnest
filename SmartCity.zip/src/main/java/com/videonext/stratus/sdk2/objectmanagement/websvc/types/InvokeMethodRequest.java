
package com.videonext.stratus.sdk2.objectmanagement.websvc.types;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Method" type="{http://skm.videonext.com/om/websvc/types}Method"/>
 *       &lt;/sequence>
 *       &lt;attribute name="objid" use="required" type="{http://www.w3.org/2001/XMLSchema}int" />
 *       &lt;attribute name="invocationid" type="{http://www.w3.org/2001/XMLSchema}int" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "method"
})
@XmlRootElement(name = "InvokeMethodRequest")
public class InvokeMethodRequest {

    @XmlElement(name = "Method", required = true)
    protected Method method;
    @XmlAttribute(name = "objid", required = true)
    protected int objid;
    @XmlAttribute(name = "invocationid")
    protected Integer invocationid;

    /**
     * Gets the value of the method property.
     * 
     * @return
     *     possible object is
     *     {@link Method }
     *     
     */
    public Method getMethod() {
        return method;
    }

    /**
     * Sets the value of the method property.
     * 
     * @param value
     *     allowed object is
     *     {@link Method }
     *     
     */
    public void setMethod(Method value) {
        this.method = value;
    }

    /**
     * Gets the value of the objid property.
     * 
     */
    public int getObjid() {
        return objid;
    }

    /**
     * Sets the value of the objid property.
     * 
     */
    public void setObjid(int value) {
        this.objid = value;
    }

    /**
     * Gets the value of the invocationid property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getInvocationid() {
        return invocationid;
    }

    /**
     * Sets the value of the invocationid property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setInvocationid(Integer value) {
        this.invocationid = value;
    }

}
