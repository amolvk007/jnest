import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;

public class ANUK {


    static int solveMeFirst(String[]myArray) {
    	int sum=0;
    	for(int i=0;i<myArray.length;i++)
    	{
    		sum=sum+Integer.valueOf(myArray[i]);
    	}
        return sum;
   }

   
 public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int a;
        a = in.nextInt();
        String[] b;
        b = in.next().split(",");
        int sum;
        sum = solveMeFirst(b);
        System.out.println(sum);
   }
}
