package com.redpine.rules.engine;

import java.io.UnsupportedEncodingException;
import java.util.Date;
import java.util.Map;
import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.redpine.rules.utils.Constants;

import backtype.storm.task.OutputCollector;
import backtype.storm.task.TopologyContext;
import backtype.storm.topology.IRichBolt;
import backtype.storm.topology.OutputFieldsDeclarer;
import backtype.storm.tuple.Fields;
import backtype.storm.tuple.Tuple;

/**
 * This class will be called when Email action is triggered in rules engine.
 *   @author Tejasvi Vellori
 */

public class EmailBolt implements IRichBolt {
	
	private static final long serialVersionUID = -3469220464426113640L;
	private OutputCollector _collector;
	public static Logger log = LoggerFactory.getLogger(EmailBolt.class);
	/**
	 * This method will be called to get SMTP connection.
	 * @return SMTP session
	 * @since WyzBee - 0.9.9
	 */
	 public static Session getSmtpSession(){

		   final String fromEmail = Constants.FROM_EMAIL; //requires valid gmail id
	       final String password = Constants.EMAIL_PASSWORD ; // correct password for gmail id
	        
	       log.info("Email Starts");

	       Properties props = new Properties();
	       props.put("mail.smtp.host", Constants.SMTP_HOST); //SMTP Host
	       props.put("mail.smtp.port", Constants.SMTP_PORT); //TLS Port
	       props.put("mail.smtp.auth", Constants.ENABLE_AUTH); //enable authentication
	       props.put("mail.smtp.starttls.enable", Constants.ENABLE_STARTTLS); //enable STARTTLS
	         
	        //create Authenticator object to pass in Session.getInstance argument
	        Authenticator auth = new Authenticator() {
	        //override the getPasswordAuthentication method
	        protected PasswordAuthentication getPasswordAuthentication() {
	                return new PasswordAuthentication(fromEmail, password);
	            }
	        };
	        
	        Session session = Session.getInstance(props, auth);
	        return session;
	   }
	 
	/**
	 * This method will be called to send email to the provided email ID.
	 * @since WyzBee - 0.9.9
	 * @param userEmail EmailId of user.
	 * @param message message to be sent in Email.
	 * @return status of email sent
	 */
	 public String sendTriggermail(String userEmail, String message) {
		 
		  Session session = getSmtpSession();
		  
		  try{
	          MimeMessage msg = new MimeMessage(session);
	          
	          msg.addHeader("Mime-Version", "1.0");
	          msg.addHeader("Content-Type", "text/html; charset=UTF-8");
	          msg.addHeader("Content-Transfer-Encoding", "7bit");
	            
	          msg.setFrom(new InternetAddress(Constants.FROM_EMAIL, "WyzBee"));

	          msg.setReplyTo(InternetAddress.parse(Constants.FROM_EMAIL, false));

	          msg.setSubject("WyzBee Device Status", "UTF-8");

	          msg.setSentDate(new Date());

	          msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(userEmail, false));
	            
	          // Create the message body part
	          BodyPart messageBodyPart = new MimeBodyPart();
	          
	          messageBodyPart.setContent("<!doctype html>"+
	        		  "<html>"+
	        		  "<head>"+
	        		  "    <meta name=\"viewport\" content=\"width=device-width\">"+
	        		  "    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">"+
	        		  "    <title>HOMER -  Email Template</title>"+
	        		  "       "+
	        		  "</head>"+
	        		  ""+
	        		  "<body bgcolor=\"#f7f9fa\">"+
	        		  ""+
	        		  "<table class=\"body-wrap\" style=\"padding: 20px;width: 100%; border: 1px solid #e4e5e7;\" bgcolor=\"#f7f9fa\">"+
	        		  "    <tr>"+
	        		  "        <td></td>"+
	        		  "        <td class=\"container\" style=\"padding: 40px; clear: both !important; display: block !important;Margin: 0 auto !important;max-width: 600px !important;\" bgcolor=\"#FFFFFF\">"+
	        		  ""+
	        		  "            <div style=\"width: 100%;\">"+
	        		  "                <table>"+
	        		  "					<tr>"+
	        		  "						<td>"+
	        		  "							<div id=\"logo\" class=\"light-version\">"+
	        		  "								<span><img src='"+Constants.WYZBEE_WEB_URL+"/images/wyzbeelogo.png'\" style=\"height: 35px; width: 160px\"> </span>"+
	        		  "							</div>"+
	        		  "						</td>"+
	        		  "					</tr>"+
	        		  "                    <tr>"+
	        		  "                        <td>"+
	        		  "                            <strong>Wyzbee Device Status</strong>"+
	        		  
	        		  "                            <p>"+message+"</p>"+
	        		  "								<p style=\"padding: 10px 40px 0px 40px;background: #ffffff; text-align: center !important; font-size: 13px; color: #6a6c6f;\">"+                         

	        		  "                            <span> WyzBee Symphony IOT Cloud V0.9.7 <br> Copyright @"+
	        		  "										2015-2016 Redpine Signals, Inc"+
	        		  "								</span>"+
	        		  "							</p>"+
	        		  "                            <!-- <p><a href=\"#\">Follow @email_template on Twitter</a></p> -->"+
	        		  "                        </td>"+
	        		  "                    </tr>"+
	        		  "                </table>"+
	        		  "            </div>"+
	        		  "        </td>"+
	        		  "    </tr>"+
	        		  "</table>"+
	        		  ""+
	        		  "<table class=\"footer-wrap\" style=\"clear: both !important;width: 100%;\">"+
	        		  "    <tr>"+
	        		  "        <td></td>"+
	        		  "        <td class=\"container\">"+
	        		  ""+
	        		  "            <div class=\"content\" style=\"display: block;margin: 0 auto;max-width: 600px;\">"+
	        		  "                <table style=\"width: 100%;\">"+
	        		  "                    <tr>"+
	        		  "                        <td align=\"center\">"+
	        		  "                            <p style=\"color: #666666;font-size: 12px;\">Don't like these annoying emails? <a style=\"color: #999999;\" href=\"#\"><unsubscribe>Unsubscribe</unsubscribe></a>."+
	        		  "                            </p>"+
	        		  "                        </td>"+
	        		  "                    </tr>"+
	        		  "                </table>"+
	        		  "            </div>"+
	        		  ""+
	        		  "        </td>"+
	        		  "        <td></td>"+
	        		  "    </tr>"+
	        		  "</table>"+
	        		  ""+
	        		  "</body>"+
	        		  "</html>", "text/html");
	           
	          // Create a multipart message for attachment
	          Multipart multipart = new MimeMultipart();

	          // Set text message part
	          multipart.addBodyPart(messageBodyPart);
	          //Set the multipart message to the email message
	          msg.setContent(multipart);

	          // Send message
	          Transport.send(msg);
	          log.info("Successfully sent WyzBee Device Status!!");
	          return "Success";
	       }catch (MessagingException e) {
	          e.printStackTrace();
	    	  return "fail";

	       } catch (UnsupportedEncodingException e) {
	          e.printStackTrace();
	    	  return "fail";

	       }
		}
	 /**
	  * This life cycle method will be called once in a life cycle of RulesEngine.
	  * It is called while activating a bolt in topology.
	  */
	@SuppressWarnings("rawtypes")
	@Override
	public void prepare(Map stormConf, TopologyContext context, OutputCollector collector) {
		
		_collector=collector;
	}

	/**
	 * This life cycle method will be called for each tuple in the wyzbee device stream data and when ever email action is triggered.
	 */
	@Override
	public void execute(Tuple input) {
		String emailId=input.getString(0);
		String message=input.getString(1);
		sendTriggermail(emailId,message);
		_collector.ack(input);
	}

	/**
	 * This life cycle method will be called when bolt is being shutdown and should cleanup any resources that were opened.
	 */
	@Override
	public void cleanup() {
		
		log.debug("entered into cleanup()");
	}
	/**
	  * This life cycle method will be used to declare the output of execute() method that is emitted from this bolt.
	  */
	@Override
	public void declareOutputFields(OutputFieldsDeclarer outputFieldsDeclarer) {
		
		outputFieldsDeclarer.declare(new Fields("actionStatus"));
	}
	/**
	  * This life cycle method will be used to define topology configuration specific to a bolt.
	  */
	@Override
	public Map<String, Object> getComponentConfiguration() {
		
		return null;
	}

}
