 // This is base controller it has tree data hence will be used by all other controller
 webApp.controller('baseController', function($scope, $location, $filter, $rootScope, $timeout, dataService, NodeServices, setviewService) {


     // "use strict";
     var data = [];
     var treenodeappended_array = [];
     var treeNodeToAppend = 0;
     var distListArray = [];
     var cnt = 0;
     var indexMap = {};
     $scope.dataForTheTree = [];
     $scope.expandedNodes = [];

     /********   Getting tree data all at once logic *********/

     var url_base = getAPI_URL("001");
     var url_index = 1;
     dataService.urlsetter_getids(getAPI_URL("01"));
     dataService.url_dist_list().then(function(all_data) {
         //below code will redirect to logout page if any error occurs
         if (all_data.response == "0") {
             distListArray = all_data.data;
             appendtree_all_new();
         } else {
             // alert(all_data.errorMessage.errors[0]);
         }

     });




     function appendtree_all_new() {

         if (typeof(distListArray[cnt]) != "undefined") {
             dataService.urlsetter(url_base, distListArray[cnt].id);
             dataService.modify_Id_all().then(function(mod_data) {
                 $scope.dataForTheTree[cnt] = mod_data[0];
                 $scope.$broadcast('markpolygon', mod_data[0].id, mod_data[0].coords, mod_data[0].name, cnt);
                 id_index_map(cnt, mod_data[0].id);
                 cnt++;
                 //ok below line not required
                 // setmarkers_onmap(mod_data[0].id, mod_data[0].coords, mod_data[0].name);
                 appendtree_all_new();





             })
         }
         //below line is to determine when the tree has been fully appended, make 1st one selected
         else {
             data = $scope.dataForTheTree;
             angular.forEach($scope.dataForTheTree, function(district) {
                 if (district.hasOwnProperty("children")) {

                 } else {
                     //console.log("no children for" + JSON.stringify(district));
                     setTimeout(function() {
                         angular.element("#" + district.id).addClass("no-gateway");
                         angular.element("#" + district.id).siblings([".tree-branch-head.a4"]).addClass("minus_icon")
                     }, 0)
                 }

             });
             $scope.node1 = $scope.dataForTheTree[0];
             $scope.showSelected($scope.dataForTheTree[0]);

         }
     }



     function id_index_map(cnt, id) {

         indexMap[id] = cnt;

     }




     //############uncomment below code when u need data on click
     // dataService.raw_data().then(function(raw_data) {

     //     dataService.modify_Id(raw_data);
     //     data = raw_data;
     //     settree(dataService.getModifyId(), treeNodeToAppend);
     //     treenodeappended_array[0] = $scope.dataForTheTree[0].id;


     // });




     $scope.showSelected = function(node, district, _gateway, pole) {
         //console.log(node, district, _gateway, pole);
         var nodeId_Initial = node.id.toString().substring(0, 1);

         setviewService.setView(nodeId_Initial);
         dataService.maphighlighter(node.id);
         NodeServices.putNode(node);
         $scope.triggerClickOnNode();

         $scope.streetName = node.name;
         //$scope.node1 = node;
         getCordsDetails(node);
         //#####################DONT DELETE
         // $('ul li div').removeClass('tree-selected');//commenting these two patch
         // $("#" + node.id).addClass('tree-selected');
         //uncomment below line if you want to append tree on click instead on windows load
         // appendtree(node.id);
         //###############data filter logic---dont delete 

         switch (nodeId_Initial) {
             case "D":
                 filter_district(node);
                 break;
             case "G":
                 set_gnameInRtPanel_viaG(node);
                 break;
             case "P":
                 set_gnameInRtPanel(node, district, _gateway);
                 break;
         };

         setexpanded(node.id);


     };

     function settree(processed_data, node) {
         // //console.log("setting tree now, appending on node: " + node);
         if (node == 0) {
             $scope.dataForTheTree = processed_data;
         } else {
             $scope.dataForTheTree[node - 1] = processed_data[0];
             // //console.log("ok, tree set on node " + node);
         }

         $scope.showSelected($scope.dataForTheTree[0]);
         $scope.node1 = $scope.dataForTheTree[0];

     };

     // function setmarkers_onmap(id, coords, name) {


     //     var district_id_initial = id.toString().substring(0, 1);

     //     // && district_id_actual != "1"
     //     if (district_id_initial === "D") {


     //         var district_id_actual = id.toString().substring(1, id.length);

     //         if (treenodeappended_array.indexOf(id) == -1) {
     //             // URL = getAPI_URL("001");
     //             // NodeServices.getNodeDetail(getDistrictListSuccess, getDistrictListError, URL, district_id_actual);
     //             treenodeappended_array.push(id);
     //             treeNodeToAppend = district_id_actual;
     //             $scope.$broadcast('newdataarrived', id);

     //         }


     //     }


     // }

     // function getDistrictListSuccess(_responsedata) {

     //     var data_stringify = JSON.stringify(_responsedata.data).replace(/"gatewayList":/g, '"children":').replace(/distCoordinates/g, "path").replace(/poleList/g, "children").replace(/sensors/g, "children");
     //     var data_objectify = JSON.parse(data_stringify);
     //     dataService.modify_Id(data_objectify);
     //     var newdata = dataService.getModifyId();
     //     settree(newdata, treeNodeToAppend);
     //     // $scope.dataForTheTree[1] = newdata[0];
     //     // //console.log(JSON.stringify($scope.dataForTheTree));
     //     $scope.$broadcast('newdataarrived', newdata[0].id);


     // }

     // function getDistrictListError(_responsedata) {
     //     ////console.log("Failed to get data");
     // }
     /*
     function appendtree(id) {
         // //console.log("apending" + id);

         var district_id_initial = id.toString().substring(0, 1);

         // && district_id_actual != "1"
         if (district_id_initial === "D") {


             var district_id_actual = id.toString().substring(1, 2);

             if (treenodeappended_array.indexOf(id) == -1) {
                 URL = getAPI_URL("001");
                 NodeServices.getNodeDetail(getDistrictListSuccess, getDistrictListError, URL, district_id_actual);
                 treenodeappended_array.push(id);

                 treeNodeToAppend = district_id_actual;
                 //console.log(treenodeappended_array);
                 // //console.log("treeNodeToAppend: " + treeNodeToAppend);
             }


         }



     }

     function getDistrictListSuccess(_responsedata) {

         var data_stringify = JSON.stringify(_responsedata.data).replace(/"gatewayList":/g, '"children":').replace(/distCoordinates/g, "path").replace(/poleList/g, "children").replace(/sensors/g, "children");
         var data_objectify = JSON.parse(data_stringify);
         dataService.modify_Id(data_objectify);
         var newdata = dataService.getModifyId();
         settree(newdata, treeNodeToAppend);
         // $scope.dataForTheTree[1] = newdata[0];
         // //console.log(JSON.stringify($scope.dataForTheTree));
         $scope.$broadcast('newdataarrived', newdata[0].id);


     }

     function getDistrictListError(_responsedata) {
         ////console.log("Failed to get data");
     }

*/
     function filter_district(node) {
         var dataSubset = datafilter(node.id);
         // //console.log(JSON.stringify(dataSubset));
         if (dataSubset.length > 0) $scope.$broadcast('dataSubset', {
             message: dataSubset
         });
     }


     function datafilter(nodeid) {
         var dataSubset = $filter('filter')(data, {
             id: nodeid
         });
         //console.log(data);
         angular.forEach(data, function(data) {
             if (dataSubset.length === 0 && angular.isDefined(data.children)) {
                 dataSubset = $filter('filter')(data.children, {
                     id: nodeid
                 });
                 if (dataSubset.length > 0) dataSubset = [{
                     id: data.id,
                     name: data.name,
                     coords: data.coords,
                     children: dataSubset
                 }];
             }

         });

         return dataSubset;

     }

     function set_gnameInRtPanel(node, district, _gateway, node_name) {
         if (typeof(district) == "undefined") {

         } else {
             var gname = $scope.dataForTheTree[indexMap[district]].children[_gateway].name;
             $scope.$broadcast('setGnameOnPolePanel', gname);
         }
     }

     function set_gnameInRtPanel_viaG(node) {
         $scope.$broadcast('setGnameOnPolePanel', node.name)

     }

     function getCordsDetails(node) {
         if (node.coords) {
             $scope.pointCords = node.coords[0];
         }
     }



     $scope.selectedGatewayNode = function(district, gateway) {

         // //console.log(gateway);
         for (var i = 0; i < $scope.dataForTheTree[district].children.length; i++) {
             // //console.log($scope.dataForTheTree[district].children[i].id);
             if (gateway == $scope.dataForTheTree[district].children[i].id) {
                 gateway = i;
                 // //console.log(i);
             }
         }

         expandNodes("gateWay", district, gateway);

         $scope.node1 = $scope.dataForTheTree[district].children[gateway];
         // //console.log($scope.node1);
         NodeServices.putNode($scope.node1);
         $scope.triggerClickOnNode();
         $scope.streetName = $scope.node1.name;
         var timer = setTimeout(function() {
             $('ul li div').removeClass('tree-selected');
             $("#" + $scope.node1.id).addClass('tree-selected');
             clearTimeout(timer)
         }, 100);

     };

     //uncomment for tree append on click ----ref2
     // setTimeout(function() {
     //     $("i").on('click', function() {
     //         var id = $(this).attr("name");
     //         var newdata = $filter('filter')($scope.dataForTheTree, {
     //                 id: id
     //             }


     //         );
     //         //console.log(JSON.stringify(newdata));

     //     });
     // }, 2000);





     $scope.selectpoleNode = function(district, gateway, pole) {
         // //console.log(gateway);
         for (i = 0; i < $scope.dataForTheTree[district].children.length; i++) {
             if (gateway == $scope.dataForTheTree[district].children[i].id) {
                 gateway = i;
             }
         }


         expandNodes("pole", district, gateway, pole);

         $scope.node1 = $scope.dataForTheTree[district].children[gateway].children[pole];


         NodeServices.putNode($scope.node1);
         $scope.triggerClickOnNode();
         $scope.streetName = $scope.node1.name;

         var timer = setTimeout(function() {
             $('ul li div').removeClass('tree-selected');
             $("#" + $scope.node1.id).addClass('tree-selected');
             clearTimeout(timer)
         }, 100);

         //adding below line as its not getting called directly---need to investigat, why its not working without below line
         $rootScope.$state.go('dashboard.pole');
     };


     var district_id = "D1";
     var d_index = "0";
     var g_index = "0";
     var clickedSameDist;
     var last_clicked = 0;

     function setexpanded(val) {
         // //console.log("setexpanded is  " + val);

         function district_id_index(val) {
             return val.toString().substring(1, val.length) - 1;
         }

         function ifClickedSameNode(val) {

             var current_id = val;

             if (last_clicked == current_id) {
                 ////console.log("clicked on same node");
                 return true;
             } else {
                 last_clicked = val;
             };

         }

         // //console.log(JSON.stringify(val));
         // //console.log(val.id.toString().substring(0, 1));
         var node_id = val.toString().substring(0, 1);

         // //console.log(val.id);
         if (node_id == "D") {

             // //console.log("expandedNodes" + $scope.expandedNodes);
             // d_index = district_id_index(val);


             d_index = indexMap[val];
             // district_id = indexMap.val;
             $scope.expandedNodes = [$scope.dataForTheTree[indexMap[val]]];

             if (ifClickedSameNode(val)) {
                 $scope.expandedNodes = [];
                 // //console.log("collapsed all");
                 last_clicked = 0;
             }

         } else if (node_id == "G") {
             // //console.log("district id is " + district_id);
             // //console.log(district_id_index);
             g_index = gateway_index_detect(val, d_index);

             $scope.expandedNodes = [$scope.dataForTheTree[d_index], $scope.dataForTheTree[d_index].children[g_index]];

             if (ifClickedSameNode(val)) {
                 $scope.expandedNodes = [$scope.dataForTheTree[d_index]];
                 last_clicked = 0;
             }

         } else if (node_id == "P") {
             // //console.log("district id is " + district_id);
             // //console.log(district_id_index);
             var p_index = pole_index_detect(val, g_index, d_index);

             ////console.log(p_index);
             $scope.expandedNodes = [$scope.dataForTheTree[d_index], $scope.dataForTheTree[d_index].children[g_index], $scope.dataForTheTree[d_index].children[g_index].children[p_index]];

             if (ifClickedSameNode(val)) {
                 $scope.expandedNodes = [$scope.dataForTheTree[d_index], $scope.dataForTheTree[d_index].children[g_index]];
                 last_clicked = 0;
             }

         }
         // //console.log($scope.expandedNodes);
     }


     function gateway_index_detect(gateway_id, district_id) {



         var gateway_index;

         for (var i = 0; i < $scope.dataForTheTree[district_id].children.length; i++) {
             // //console.log("in loop");
             if ($scope.dataForTheTree[district_id].children[i].id == gateway_id) {
                 // //console.log("matched" + gateway_id);
                 gateway_index = i;
             }

         }

         return gateway_index;
     }

     function pole_index_detect(pole_id, g_index, d_index) {



         var pole_index;

         for (var i = 0; i < $scope.dataForTheTree[d_index].children[g_index].children.length; i++) {
             // for (k = 0; k < $scope.dataForTheTree[d_index].children[g_index].children.length; k++) {

             if ($scope.dataForTheTree[d_index].children[g_index].children[i].id == pole_id) {

                 pole_index = i;
                 break;
             }

             // }

         }

         return pole_index;
     }


     $scope.select_map_node = function(district, _gateway, _pole) {
         //console.log(district, _gateway, _pole);
         g_index = _gateway;

         if (typeof(_pole) == "undefined") {

             $scope.showSelected($scope.dataForTheTree[indexMap[district]].children[_gateway]);
             $scope.node1 = $scope.dataForTheTree[indexMap[district]].children[_gateway];

         } else {
             //console.log(district, _gateway, _pole);
             //console.log(indexMap);
             //console.log(indexMap[district]);
             //console.log($scope.dataForTheTree[indexMap[district]]);
             //console.log($scope.dataForTheTree[indexMap[district]].children[_gateway]);
             //console.log($scope.dataForTheTree[indexMap[district]].children[_gateway].children[_pole]);
             $scope.showSelected($scope.dataForTheTree[indexMap[district]].children[_gateway].children[_pole], district, _gateway, _pole);
             $scope.node1 = $scope.dataForTheTree[indexMap[district]].children[_gateway].children[_pole];
         }
     }



     $scope.treeOptions = {
         nodeChildren: "children",
         dirSelectable: true, //keep true for user to understand where is he
         multiSelection: false,
         allowDeselect: false,
         injectClasses: {
             ul: "a1",
             li: "a2",
             liSelected: "a7",
             iExpanded: "a3",
             iCollapsed: "a4",
             iLeaf: "a5",
             label: "a6",
             labelSelected: "a8"
         },
         //uncomment below line, append on click ----ref1
         isLeaf: function(node) {
             return node.i % 2 == 0;
         },
         isSelectable: function(node) {
             return true;

         },
         equality: function(node1, node2) {
             return node1 === node2;
         }
     };

     $scope.triggerClickOnNode = function(_node) {
         $scope.$broadcast('clickOnNode');

     };

     function expandNodes(_nodeType, _district, _gateway, _pole) {
         if (_nodeType == "pole") {
             // //console.log(_nodeType, _district, _gateway, _pole);
             // alert("nodetype= " + _nodeType + "----disctrict = " + _district + "---gateway =" + _gateway + "---pole = " + _pole);
             $scope.expandedNodes = [$scope.dataForTheTree[_district], $scope.dataForTheTree[_district].children[_gateway]];
         } else if (_nodeType == "gateWay") {
             // alert("nodetype= " + _nodeType + "---disctrict = " + _district + "------gateway =" + _gateway);
             $scope.expandedNodes = [$scope.dataForTheTree[_district]];
         }
     };
 })

 webApp.directive('toggleClass', function() {
     return {
         restrict: 'A',
         link: function(scope, element, attrs) {
             element.bind('click', function() {

                 var nodeType = $(element).attr("name");
                 $("i").removeClass('district-exp gateway-exp pole-exp');

                 if (nodeType.substring(0, 1) == "D") {
                     $(element).addClass('district-exp');
                 } else if (nodeType.substring(0, 1) == "G") {
                     $(element).addClass('gateway-exp');
                 } else if (nodeType.substring(0, 1) == "P") {
                     $(element).addClass('pole-exp');
                 }
             });
         }
     };
 });


 //######tracker of which lines to uncomment for tree append on individual clicks
 // ref1-------search with this refrence
 // ref2