webApp.controller('headerController', function($scope, $rootScope, loginService) {

    if (sessionStorage.userObj) {

        // console.log(loginService.getAuthToken());
        // console.log(loginService.getUserFirstName());
        // console.log(loginService.getUserLastName());
        // console.log(sessionStorage);
        $scope.userdetails = {};
        $scope.userdetails.userName = loginService.getUserName().toLowerCase();
        $scope.userdetails.userRole = loginService.getUserRole().toLowerCase();

        //console.log("active token id is " + loginService.getAuthToken());
        $rootScope.isAdmin = true;

        if (loginService.getUserRole().toLowerCase() == "user") {
            $rootScope.isAdmin = false;
        }
        if (loginService.getUserRole().toLowerCase().indexOf("super") != -1) {
            $rootScope.isSuperAdmin = true;
            // console.log($scope.$rootScope)
        } else {
            $rootScope.isSuperAdmin = false;
        }

        if (loginService.getAuthToken() == "Expired") {
            $rootScope.$state.go('logout')
        }

        $scope.logout = function() {
            $rootScope.loginExpired = false;
            $rootScope.$state.go('logout');
            delete sessionStorage.userObj;
        }
    } else {
        $rootScope.$state.go('login');
    }
})