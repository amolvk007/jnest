webApp.controller("videonextFeedController", function ($scope, $interval, $timeout, $sce, ajaxService) {
    $scope.vnfeeds = {};

    var feed_page = 1;
    var feed_limit = 2;
    var feed_url = "169";
    var feed_param = "?page=" + feed_page + "&limit=" + feed_limit;
    var refreshDelay = 120000;
    var vnVideoURL = getAPI_URL("vnVideoDemo");
    var sensorTimer;

    $scope.vnVideoURL = trustSrc(vnVideoURL);

    getNotifications(feed_url, feed_param);

    function trustSrc(src) {
        return $sce.trustAsResourceUrl(src);
    }

    function getNotifications(url, urlparam) {
        if ($scope.$state.current.name === "header.dashboard.district") {
            var the_url = getAPI_URL(url) + urlparam;
            var reqHeader = {
                method: 'GET',
                url: the_url
            };

            ajaxService.AjaxCall(SuccessFunction, ErrorFunction, reqHeader);

            function SuccessFunction(result) {
                if (result.response === "0" && angular.isArray(result.data)) {
                    $scope.vnfeeds = result.data;

                    if (!angular.isDefined(sensorTimer)) {
                        sensorTimer = $interval(function () {
                            getNotifications(feed_url, feed_param);
                        }, refreshDelay);
                    }

                } else if (result.response === "1") {
                    if (angular.isDefined(sensorTimer)) {
                        $interval.cancel(sensorTimer);
                        sensorTimer = undefined;
                    }
                    alert("Failed to load videonext notifications.");
                }
            }

            function ErrorFunction(error) {
                if (angular.isDefined(sensorTimer)) {
                    $interval.cancel(sensorTimer);
                    sensorTimer = undefined;
                }
                alert("Failed to load videonext notifications.");
            }
        } else {
            if (angular.isDefined(sensorTimer)) {
                $interval.cancel(sensorTimer);
                sensorTimer = undefined;
            }
        }
    }

    angular.element('#myModal').on('hide.bs.modal', function (event) {
        angular.element('#myModal video').attr('src', '');
        $timeout(function () {
            angular.element('#myModal video').attr('src', $scope.vnVideoURL);
        }, 1000);
    });
});