webApp.controller('userConfigController', function ($scope, $rootScope, ajaxService) {

    $scope.UserObj = {};
    $scope.repassword = "";
    $scope.tablemessage = "";
    $scope.addmessage = "";
    $scope.responseSuccess = true;
    $scope.tableResponse = true;

    if (!$rootScope.isSuperAdmin) {
        $scope.UserObj.userRole = "2";
    }

    $scope.isDisabled = function () {
        var matches = ($scope.UserObj.password === $scope.repassword) ? true : false;
        var disabled = ($scope.add_user_form.$valid && matches) ? false : true;

        if (matches) {
            $scope.add_user_form.repassword.$setValidity('unique', true);
        } else {
            $scope.add_user_form.repassword.$setValidity('unique', false);
        }

        return disabled;
    };

    $scope.add_user = function () {
        /* while compiling form , angular created this object*/
        var formData = $scope.UserObj;

        var reqHeader = {
            method: 'POST',
            url: getAPI_URL('106'),
            data: formData
        };
        ajaxService.AjaxCall(SuccessFunction, ErrorFunction, reqHeader);

        function SuccessFunction(_responseData) {
            if (_responseData.response === '0') {
                $scope.responseSuccess = true;
                $scope.addmessage = 'Added user "' + $scope.UserObj.userName + '" successfully.';
                display_table();
                $scope.reset_form(false);
            } else {
                var error = (angular.isArray(_responseData.errorMessage.errors)) ? _responseData.errorMessage.errors[0] : "";
                $scope.addmessage = (error === null || error === "") ? 'Failed to add user.' : error;
                $scope.responseSuccess = false;
            }
        }

        function ErrorFunction(error) {
            $scope.addmessage = 'Failed to add user.';
            $scope.responseSuccess = false;
        }
    };

    $scope.reset_form = function (restmessage) {
        var reset_message = (typeof restmessage === 'undefined') ? true : false;
        if ($rootScope.isSuperAdmin) {
            $scope.UserObj = {};
            $scope.repassword = "";
            angular.element('#add_user_form')[0].reset();
        } else {
            $scope.UserObj.userName = "";
            $scope.UserObj.firstName = "";
            $scope.UserObj.password = "";
            $scope.UserObj.email = "";
            $scope.UserObj.lastName = "";
            $scope.repassword = "";
            angular.element('#add_user_form input[type="text"], #add_user_form input[type="email"], #add_user_form input[type="password"]').val("");
        }
        if (reset_message) {
            $scope.addmessage = "";
            $scope.responseSuccess = true;
        }
        $scope.add_user_form.$setPristine();
        $scope.add_user_form.$setUntouched();
    };

    $scope.close_message = function () {
        $scope.addmessage = "";
    };
    $scope.close_tablemessage = function () {
        $scope.tablemessage = "";
    };

    //Table display logic--------------------
    display_table();

    function display_table() {
        
        var formData = {
            "sortBy": "",
            "sortOrder": "",
            "filter": ""
        };
        var reqHeader = {
            method: 'POST',
            url: getAPI_URL('107'),
            data: formData
        };
        
        ajaxService.AjaxCall(SuccessFunction, ErrorFunction, reqHeader);

        function SuccessFunction(_responseData) {
            if (_responseData.response === '0' && angular.isArray(_responseData.data)) {
                angular.element('#userList_table').bootstrapTable({
                    columns: [{
                            field: 'checked',
                            checkbox: true,
                            align: 'center',
                            valign: 'middle',
                            formatter: function (value, row, index) {
                                if (!$rootScope.isSuperAdmin && row.role.toLowerCase() === 'admin') {
                                    return {
                                        disabled: true
                                    };
                                }
                            }
                        }, {
                            field: 'username',
                            title: 'Username'
                        }, {
                            field: 'role',
                            title: 'Role'
                        }, {
                            field: 'firstName',
                            title: 'First Name'
                        }, {
                            field: 'lastName',
                            title: 'Last Name'
                        }, {
                            field: 'email',
                            title: 'Email'
                        }, {
                            field: '',
                            title: 'Action',
                            align: 'center',
                            events: {
//                                'click .edit': function (e, value, row, index) {
//                                    editUser(row);
//                                },
                                'click .delete': function (e, value, row, index) {
                                    var formData = {
                                        "userIdList": [
                                            {
                                                "userId": row.userId
                                            }
                                        ]
                                    };

                                    deleteUser(formData);
                                }
                            },
                            formatter: function (v, row) {
                                var isDisabled = (!$rootScope.isSuperAdmin && row.role.toLowerCase() === 'admin') ? ' disabled' : '';
                                //return ['<a class="edit" href="javascript:void(0)" title="Edit">', '<i class="glyphicon glyphicon glyphicon-edit"></i>', '</a>  ', '<a class="delete" href="javascript:void(0)" title="Delete">', '<i class="glyphicon glyphicon-remove"></i>', '</a>'].join('');
                                return ['<button class="btn btn-link delete" type="button"' + isDisabled + '>', '<i class="glyphicon glyphicon-remove"></i>', '</button>'].join('');
                            }
                        }]
                });
                angular.element('#userList_table').bootstrapTable('load', _responseData.data);
            } else {
                var error = (angular.isArray(_responseData.errorMessage.errors)) ? _responseData.errorMessage.errors[0] : "";
                $scope.tablemessage = (error === null || error === "") ? "Failed to load table." : error;
                $scope.responseSuccess = false;
            }
        }

        function ErrorFunction(error) {
            $scope.tablemessage = 'Failed to load table.';
            $scope.responseSuccess = false;
        }
    }

    // Delete Functions
    var $table = angular.element('#userList_table');
    var $deleteSelected = angular.element('#deleteSelected');

    $table.on('check.bs.table uncheck.bs.table check-all.bs.table uncheck-all.bs.table', function () {
        $deleteSelected.prop('disabled', !$table.bootstrapTable('getSelections').length);
    });

    $scope.delete_selected = function () {
        var formData = {
            "userIdList": []
        };

        angular.forEach($table.bootstrapTable('getSelections'), function (item) {
            var this_id = {
                "userId": item.userId
            };
            formData.userIdList.push(this_id);
        });

        deleteUser(formData);
    };

    function deleteUser(userList) {
        if (typeof userList === 'undefined') {
            return;
        }
       
        var reqHeader = {
            method: 'POST',
            url: getAPI_URL("172"),
            data: userList
        };
        var s = (userList.userIdList.length > 1) ? 's' : '';
        
        swal({
            title: "Do you want to delete selected user" + s + "?",
            //text: username.join(", "),
            //type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Yes",
            cancelButtonText: "No",
            closeOnConfirm: true,
            closeOnCancel: true
        }, function (isConfirm) {
            if (isConfirm) {                
                ajaxService.AjaxCall(SuccessFunction, ErrorFunction, reqHeader);
            }
        });

        function SuccessFunction(result) {
            if (result.response === "0") {                
                $scope.tablemessage = 'User' + s + ' deleted successfully.';
                $scope.tableResponse = true;
            } else {
                var error = (angular.isArray(result.errorMessage.errors)) ? result.errorMessage.errors[0] : "";
                $scope.tablemessage = (error === null || error === "") ? 'Failed to delete user' + s + '.' : error;
                $scope.tableResponse = false;
            }
            
            $deleteSelected.prop('disabled', true);
            display_table();
        }

        function ErrorFunction(error) {
            $scope.tablemessage = 'Failed to delete user' + s + '.';
            $scope.tableResponse = false;
            
            $deleteSelected.prop('disabled', true);
            display_table();
        }
    }
});
