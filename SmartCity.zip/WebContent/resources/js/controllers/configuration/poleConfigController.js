webApp.controller('poleConfigController', function ($scope, ajaxService, uiGmapGoogleMapApi, uiGmapIsReady) {
    $scope.PoleObj = {};
    $scope.poleMap = {};
    $scope.currentMarker = undefined;
    $scope.drawingManager = undefined;
    $scope.addmessage = "";
    $scope.responseSuccess = true;
    $scope.tablemessage = "";
    $scope.tableResponse = true;

    $scope.add_pole = function () {
        /* while compiling form , angular created this object*/

        var formData = $scope.PoleObj;
        var reqHeader = {
            method: 'POST',
            url: getAPI_URL("112"),
            data: formData
        };
        ajaxService.AjaxCall(SuccessFunction, ErrorFunction, reqHeader);

        function SuccessFunction(_responseData) {
            if (_responseData.response === "0") {
                $scope.responseSuccess = true;
                $scope.addmessage = 'Added pole "' + $scope.PoleObj.name + '" successfully.';
                display_table();
                $scope.reset_form(false);
            } else {
                var error = (angular.isArray(_responseData.errorMessage.errors)) ? _responseData.errorMessage.errors[0] : "";
                $scope.addmessage = (error === null || error === "") ? "Failed to add pole." : error;
                $scope.responseSuccess = false;
            }
        }

        function ErrorFunction(error) {
            $scope.addmessage = "Failed to add pole.";
            $scope.responseSuccess = false;
        }
    };
    $scope.close_message = function () {
        $scope.addmessage = "";
    };
    $scope.close_tablemessage = function () {
        $scope.tablemessage = "";
    };
    
    display_table();
    
    function display_table() {
        var table_filters = {};

        var reqHeader = {
            method: 'POST',
            url: getAPI_URL("145"),
            data: table_filters
        };
        ajaxService.AjaxCall(SuccessFunction, ErrorFunction, reqHeader);

        function SuccessFunction(_responseData) {
            if (_responseData.response === "0" && angular.isArray(_responseData.data)) {
                angular.element('#poleList_table').bootstrapTable({
                    columns: [{
                            field: 'checked',
                            checkbox: true,
                            align: 'center',
                            valign: 'middle'
                        }, {
                            field: 'name',
                            title: 'Pole Name'
                        }, {
                            field: 'lat',
                            title: 'Latitude'
                        }, {
                            field: 'longi',
                            title: 'Longitude'
                        }, {
                            field: '',
                            title: 'Action',
                            align: 'center',
                            events: {
//                                'click .edit': function (e, value, row, index) {
//                                    editUser(row);
//                                },
                                'click .delete': function (e, value, row, index) {
                                    var formData = {
                                        "poleList": [
                                            {
                                                "poleId": row.id
                                            }
                                        ]
                                    };

                                    deletePole(formData);
                                }
                            },
                            formatter: function (v, row) {
                                //return ['<a class="edit" href="javascript:void(0)" title="Edit">', '<i class="glyphicon glyphicon glyphicon-edit"></i>', '</a>  ', '<a class="delete" href="javascript:void(0)" title="Delete">', '<i class="glyphicon glyphicon-remove"></i>', '</a>'].join('');
                                return ['<button class="btn btn-link delete" type="button">', '<i class="glyphicon glyphicon-remove"></i>', '</button>'].join('');
                            }
                        }]

                });
                angular.element('#poleList_table').bootstrapTable('load', _responseData.data);
            } else {
                var error = (angular.isArray(_responseData.errorMessage.errors)) ? _responseData.errorMessage.errors[0] : "";
                $scope.tablemessage = (error === null || error === "") ? "Failed to load table." : error;
                $scope.tableResponse = false;
            }
        }

        function ErrorFunction(error) {
            $scope.tablemessage = "Failed to load table.";
            $scope.tableResponse = false;
        }
    };
    
    // Delete Functions
    var $table = angular.element('#poleList_table');
    var $deleteSelected = angular.element('#deleteSelected');

    $table.on('check.bs.table uncheck.bs.table check-all.bs.table uncheck-all.bs.table', function () {
        $deleteSelected.prop('disabled', !$table.bootstrapTable('getSelections').length);
    });

    $scope.delete_selected = function () {
        var formData = {
            "poleList": []
        };

        angular.forEach($table.bootstrapTable('getSelections'), function (item) {
            var this_id = {
                "poleId": item.userId
            };
            formData.poleList.push(this_id);
        });

        deletePole(formData);
    };

    function deletePole(poleList) {
        if (typeof poleList === 'undefined') {
            return;
        }
        
        var reqHeader = {
            method: 'DELETE',
            url: getAPI_URL('175'),
            data: poleList
        };
        var s = (poleList.length > 1) ? 's' : '';

        swal({
            title: "Do you want to delete selected pole" + s + "?",
            //text: username.join(", "),
            //type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Yes",
            cancelButtonText: "No",
            closeOnConfirm: true,
            closeOnCancel: true
        }, function (isConfirm) {
            if (isConfirm) {
                ajaxService.AjaxCall(SuccessFunction, ErrorFunction, reqHeader);
            }
        });

        function SuccessFunction(result) {
            if (result.response === "0") {                                
                $scope.tablemessage = 'Pole' + s + ' deleted successfully.';
                $scope.tableResponse = true;
            } else {
                var error = (angular.isArray(result.errorMessage.errors)) ? result.errorMessage.errors[0] : "";
                $scope.tablemessage = (error === null || error === "") ? 'Failed to delete pole' + s + '.' : error;
                $scope.tableResponse = false;
            }
            
            $deleteSelected.prop('disabled', true);
            display_table();
        }

        function ErrorFunction(error) {
            $scope.tablemessage = 'Failed to delete pole' + s + '.';
            $scope.tableResponse = false;
            
            $deleteSelected.prop('disabled', true);
            display_table();
        }
    }

    // Pole Map Initialization
    $scope.map = {
        center: {
            latitude: 32.778978,
            longitude: -96.791607
        },
        zoom: 15,
        options: {
            scrollwheel: true,
            mapTypeControl: false,
            streetViewControl: false,
            disableDoubleClickZoom: true
        },
        bounds: {}
    };

    // Search Box Initialization
    $scope.searchbox = {
        template: 'searchbox.tpl.html',
        position: 'TOP_CENTER',
        events: {
            places_changed: function (searchBox) {
                var place = searchBox.getPlaces();
                if (!place || place == 'undefined' || place.length == 0) {
                    return;
                }
                $scope.map = {
                    "center": {
                        "latitude": place[0].geometry.location.lat(),
                        "longitude": place[0].geometry.location.lng()
                    }
                };
            }
        }
    };

    // Reset Form
    $scope.reset_form = function (restmessage) {
        var reset_message = (typeof restmessage == "undefined") ? true : false;
        if ($scope.currentMarker) {
            $scope.currentMarker.setMap(null);
            $scope.currentMarker = undefined;
        }

        angular.element('#map_search').val("");

        $scope.PoleObj = {};

        $scope.map = {
            center: {
                latitude: 32.778978,
                longitude: -96.791607
            },
            zoom: 15
        };

        $scope.drawingManagerOptions = {
            drawingControlOptions: {
                position: google.maps.ControlPosition.TOP_RIGHT,
                drawingModes: [
                    google.maps.drawing.OverlayType.MARKER
                ]
            }
        };
        angular.element('#addPoleForm')[0].reset();
        if (reset_message) {
            $scope.addmessage = "";
            $scope.responseSuccess = true;
        }
        $scope.addPoleForm.$setPristine();
        $scope.addPoleForm.$setUntouched();
    };

    $scope.latlng_change = function () {
        if (angular.isDefined($scope.PoleObj.longi) && angular.isDefined($scope.PoleObj.lat)) {
            var latlng = new google.maps.LatLng($scope.PoleObj.lat, $scope.PoleObj.longi);

            if ($scope.currentMarker) {
                $scope.currentMarker.setPosition(latlng);
                $scope.map = {
                    "center": {
                        "latitude": $scope.PoleObj.lat,
                        "longitude": $scope.PoleObj.longi
                    }
                };
            } else {
                $scope.drawingManager.setDrawingMode(null);
                $scope.drawingManagerOptions = {
                    drawingControlOptions: {
                        position: google.maps.ControlPosition.TOP_RIGHT,
                        drawingModes: []
                    }
                };

                $scope.currentMarker = new google.maps.Marker({
                    position: latlng,
                    map: $scope.poleMap,
                    animation: google.maps.Animation.DROP,
                    icon: './images/light-green.png',
                    clickable: true,
                    draggable: true,
                    zIndex: 1
                });

                $scope.map = {
                    "center": {
                        "latitude": $scope.PoleObj.lat,
                        "longitude": $scope.PoleObj.longi
                    }
                };

                attachedMarkerEvents();
            }
        }
    };

    var updateCoords = function (marker, resetTool) {
        $scope.$apply(function () {
            if (marker !== null) {
                $scope.PoleObj.lat = marker.getPosition().lat();
                $scope.PoleObj.longi = marker.getPosition().lng();
            } else {
                $scope.PoleObj.lat = undefined;
                $scope.PoleObj.longi = undefined;
            }

            if (resetTool) {
                $scope.drawingManagerOptions = {
                    drawingControlOptions: {
                        position: google.maps.ControlPosition.TOP_RIGHT,
                        drawingModes: []
                    }
                };
            } else {
                $scope.drawingManagerOptions = {
                    drawingControlOptions: {
                        position: google.maps.ControlPosition.TOP_RIGHT,
                        drawingModes: [
                            google.maps.drawing.OverlayType.MARKER
                        ]
                    }
                };
            }
        });
    };

    // Attach Events to created Marker
    var attachedMarkerEvents = function () {
        // Delete Marker on Double Click
        google.maps.event.addListener($scope.currentMarker, 'dblclick', function () {
            $scope.currentMarker.setMap(null);
            $scope.currentMarker = undefined;
            updateCoords(null, false);
        });

        google.maps.event.addListener($scope.currentMarker, 'dragend', function () {
            updateCoords($scope.currentMarker, true);
        });
    };

    uiGmapGoogleMapApi.then(function (maps) {
        $scope.googleVersion = maps.version;
        maps.visualRefresh = true;

        // Drawing Manager Initialization
        $scope.drawingManagerOptions = {
            drawingMode: google.maps.drawing.OverlayType.MARKER,
            drawingControl: true,
            drawingControlOptions: {
                position: google.maps.ControlPosition.TOP_RIGHT,
                drawingModes: [
                    google.maps.drawing.OverlayType.MARKER
                ]
            },
            markerOptions: {
                icon: './images/light-green.png',
                clickable: true,
                draggable: true,
                zIndex: 1
            }
        };

        $scope.drawingManagerControl = {};
    });

    uiGmapIsReady.promise().then(function (instances) {
        $scope.poleMap = instances[0].map; // Get Pole Map Instance
        $scope.drawingManager = $scope.drawingManagerControl.getDrawingManager(); //Get Drawing Manger Instance

        $scope.$watch('drawingManagerControl.getDrawingManager', function () {
            if (!$scope.drawingManagerControl.getDrawingManager) {
                return;
            }

            // Marker Draw Complete Event
            google.maps.event.addListener($scope.drawingManager, 'markercomplete', function (marker) {
                $scope.currentMarker = marker;

                $scope.drawingManager.setDrawingMode(null);
                updateCoords($scope.currentMarker, true);

                attachedMarkerEvents();
            });
        });
    });
});