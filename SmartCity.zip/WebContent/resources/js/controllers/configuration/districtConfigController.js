webApp.controller('districtConfigController', function ($scope, ajaxService, uiGmapGoogleMapApi, uiGmapIsReady) {
    $scope.DistrictObj = {};
    $scope.districtMap = {};
    $scope.currentDrawnObj = undefined;
    $scope.drawingManager = undefined;
    $scope.addmessage = "";
    $scope.responseSuccess = true;
    $scope.tablemessage = "";
    $scope.tableResponse = true;

    $scope.add_district = function () {
        $scope.DistrictObj.districtCoordinates = [{
                "latitude": $scope.DistrictObj.x,
                "longitude": $scope.DistrictObj.y
            }, {
                "latitude": $scope.DistrictObj.x1,
                "longitude": $scope.DistrictObj.y
            }, {
                "latitude": $scope.DistrictObj.x1,
                "longitude": $scope.DistrictObj.y1
            }, {
                "latitude": $scope.DistrictObj.x,
                "longitude": $scope.DistrictObj.y1
            }];
        var formData = $scope.DistrictObj;
        var reqHeader = {
            method: 'POST',
            url: getAPI_URL("108"),
            data: formData
        };
        ajaxService.AjaxCall(SuccessFunction, ErrorFunction, reqHeader);

        function SuccessFunction(_responseData) {
            if (_responseData.response === "0") {
                $scope.responseSuccess = true;
                $scope.addmessage = 'Added district "' + $scope.DistrictObj.districtName + '" successfully.';
                display_table(false);
                $scope.reset_form(false);
            } else {
                var error = (angular.isArray(_responseData.errorMessage.errors)) ? _responseData.errorMessage.errors[0] : "";
                $scope.addmessage = (error === null || error === "") ? 'Failed to add district.' : error;
                $scope.responseSuccess = false;
            }
        }

        function ErrorFunction(error) {
            $scope.addmessage = 'Failed to add district.';
            $scope.responseSuccess = false;
        }
    };
    $scope.close_message = function () {
        $scope.addmessage = "";
    };
    $scope.close_tablemessage = function () {
        $scope.tablemessage = "";
    };

    display_table(true);

    function display_table() {
        var formData = {
            "sortBy": "createdDate",
            "sortOrder": "Desc",
            "filter": ""
        };
        var reqHeader = {
            method: "POST",
            url: getAPI_URL("118"),
            data: formData
        };

        ajaxService.AjaxCall(SuccessFunction, ErrorFunction, reqHeader);

        function SuccessFunction(result) {
            if ((result.response === "0" && angular.isArray(result.data))) {
                angular.element('#districtList_table').bootstrapTable({
                    columns: [{
                            field: "checked",
                            checkbox: true,
                            align: "center",
                            valign: "middle"
                        }, {
                            field: "name",
                            title: "District Name"
                        }, {
                            field: "districtCoordinates",
                            title: "District Coordinates",
                            formatter: function (value, row, index) {
                                return value.split("#").join("<br>");
                            }
                        }, {
                            field: "",
                            title: "Action",
                            align: "center",
                            events: {
//                                'click .edit': function (e, value, row, index) {
//                                    editUser(row);
//                                },
                                'click .delete': function (e, value, row, index) {
                                    var formData = [{
                                            "districtId": row.id
                                        }];

                                    deleteDistrict(formData);
                                }
                            },
                            formatter: function (v, row) {
                                //return ['<a class="edit" href="javascript:void(0)" title="Edit">', '<i class="glyphicon glyphicon glyphicon-edit"></i>', '</a>  ', '<a class="delete" href="javascript:void(0)" title="Delete">', '<i class="glyphicon glyphicon-remove"></i>', '</a>'].join('');
                                return ['<button class="btn btn-link delete" type="button">', '<i class="glyphicon glyphicon-remove"></i>', '</button>'].join('');
                            }
                        }]
                });
                angular.element('#districtList_table').bootstrapTable('load', result.data);
            } else {
                var error = (angular.isArray(_responseData.errorMessage.errors)) ? _responseData.errorMessage.errors[0] : "";
                $scope.tablemessage = (error === null || error === "") ? "Failed to load table." : error;
                $scope.tableResponse = false;
            }
        }

        function ErrorFunction(error) {
            $scope.tablemessage = "Failed to load table.";
            $scope.tableResponse = false;
        }
    }

    // Delete Functions
    var $table = angular.element('#districtList_table');
    var $deleteSelected = angular.element('#deleteSelected');

    $table.on('check.bs.table uncheck.bs.table check-all.bs.table uncheck-all.bs.table', function () {
        $deleteSelected.prop('disabled', !$table.bootstrapTable('getSelections').length);
    });

    $scope.delete_selected = function () {
        var formData = [];

        angular.forEach($table.bootstrapTable('getSelections'), function (item) {
            formData.push({
                "districtId": item.id
            });
        });

        deleteDistrict(formData);
    };

    function deleteDistrict(districtList) {
        if (typeof districtList === 'undefined') {
            return;
        }

        var reqHeader = {
            method: 'DELETE',
            url: getAPI_URL('173'),
            data: districtList
        };
        var s = (districtList.length > 1) ? 's' : '';

        swal({
            title: "Do you want to delete selected district" + s + "?",
            //text: username.join(", "),
            //type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Yes",
            cancelButtonText: "No",
            closeOnConfirm: true,
            closeOnCancel: true
        }, function (isConfirm) {
            if (isConfirm) {
                ajaxService.AjaxCall(SuccessFunction, ErrorFunction, reqHeader);
            }
        });

        function SuccessFunction(result) {
            if (result.response === "0") {
                $scope.tablemessage = 'District' + s + ' deleted successfully.';
                $scope.tableResponse = true;
            } else {
                var error = (angular.isArray(result.errorMessage.errors)) ? result.errorMessage.errors[0] : "";
                $scope.tablemessage = (error === null || error === "") ? 'Failed to delete district' + s + '.' : error;
                $scope.tableResponse = false;
            }

            $deleteSelected.prop('disabled', true);
            display_table();
        }

        function ErrorFunction(error) {
            $scope.tablemessage = 'Failed to delete district' + s + '.';
            $scope.tableResponse = false;

            $deleteSelected.prop('disabled', true);
            display_table();
        }
    }

    // District Initialization
    $scope.map = {
        center: {
            latitude: 32.778978,
            longitude: -96.791607
        },
        zoom: 15,
        options: {
            scrollwheel: true,
            mapTypeControl: false,
            streetViewControl: false,
            disableDoubleClickZoom: true
        },
        bounds: {}
    };

    // Search Box Initialization
    $scope.searchbox = {
        template: 'searchbox.tpl.html',
        position: 'TOP_CENTER',
        events: {
            places_changed: function (searchBox) {
                var place = searchBox.getPlaces();
                if (!place || place == 'undefined' || place.length == 0) {
                    return;
                }

                $scope.map = {
                    "center": {
                        "latitude": place[0].geometry.location.lat(),
                        "longitude": place[0].geometry.location.lng()
                    }
                };
            }
        }
    };

    $scope.reset_form = function (restmessage) {
        var reset_message = (typeof restmessage == "undefined") ? true : false;
        if ($scope.currentDrawnObj) {
            $scope.currentDrawnObj.setMap(null);
            $scope.currentDrawnObj = undefined;
        }

        angular.element('#map_search').val("");

        $scope.DistrictObj = {};

        $scope.map = {
            center: {
                latitude: 32.778978,
                longitude: -96.791607
            },
            zoom: 15
        };

        $scope.drawingManagerOptions = {
            drawingControlOptions: {
                position: google.maps.ControlPosition.TOP_RIGHT,
                drawingModes: [
                    google.maps.drawing.OverlayType.RECTANGLE
                ]
            }
        };
        angular.element('#addDistrictForm')[0].reset();
        if (reset_message) {
            $scope.addmessage = "";
            $scope.responseSuccess = true;
        }
        $scope.addDistrictForm.$setPristine();
        $scope.addDistrictForm.$setUntouched();
    };

    function updateCoords(drawnObj, resetTool) {
        $scope.$apply(function () {
            if (drawnObj !== null) {
                $scope.DistrictObj.x = drawnObj.getBounds().getNorthEast().lat();
                $scope.DistrictObj.y = drawnObj.getBounds().getNorthEast().lng();
                $scope.DistrictObj.x1 = drawnObj.getBounds().getSouthWest().lat();
                $scope.DistrictObj.y1 = drawnObj.getBounds().getSouthWest().lng();
            } else {
                $scope.DistrictObj.x = undefined;
                $scope.DistrictObj.y = undefined;
                $scope.DistrictObj.x1 = undefined;
                $scope.DistrictObj.y1 = undefined;
            }

            if (resetTool) {
                $scope.drawingManagerOptions = {
                    drawingControlOptions: {
                        position: google.maps.ControlPosition.TOP_RIGHT,
                        drawingModes: []
                    }
                };
            } else {
                $scope.drawingManagerOptions = {
                    drawingControlOptions: {
                        position: google.maps.ControlPosition.TOP_RIGHT,
                        drawingModes: [
                            google.maps.drawing.OverlayType.RECTANGLE
                        ]
                    }
                };
            }
        });
    }

    // Attach Events to created Object
    function attachedDrawnObjEvents() {
        // Delete Drawn Object on Double Click
        google.maps.event.addListener($scope.currentDrawnObj, 'dblclick', function () {
            $scope.currentDrawnObj.setMap(null);
            $scope.currentDrawnObj = undefined;
            updateCoords(null, false);
        });

        google.maps.event.addListener($scope.currentDrawnObj, 'dragend', function () {
            updateCoords($scope.currentDrawnObj, true);
        });
    }

    uiGmapGoogleMapApi.then(function (maps) {
        maps.visualRefresh = true;

        // Drawing Manager Initialization
        $scope.drawingManagerOptions = {
            drawingMode: google.maps.drawing.OverlayType.RECTANGLE,
            drawingControl: true,
            drawingControlOptions: {
                position: google.maps.ControlPosition.TOP_RIGHT,
                drawingModes: [
                    google.maps.drawing.OverlayType.RECTANGLE
                ]
            },
            rectangleOptions: {
                fillColor: '#088A08',
                fillOpacity: 0.2,
                strokeColor: '#088A08',
                strokeWeight: 3,
                clickable: true,
                draggable: true,
                editable: true,
                zIndex: 1
            }
        };
        $scope.drawingManagerControl = {};
    });

    uiGmapIsReady.promise().then(function (instances) {
        $scope.districtMap = instances[0].map; // Get Distruct Map Instance
        $scope.drawingManager = $scope.drawingManagerControl.getDrawingManager(); //Get Drawing Manger Instance

        $scope.$watch('drawingManagerControl.getDrawingManager', function () {
            if (!$scope.drawingManagerControl.getDrawingManager) {
                return;
            }

            // Rectangle Draw Complete Event
            google.maps.event.addListener($scope.drawingManagerControl.getDrawingManager(), 'rectanglecomplete', function (drawnOnj) {
                $scope.currentDrawnObj = drawnOnj;

                $scope.drawingManager.setDrawingMode(null);
                updateCoords($scope.currentDrawnObj, true);

                attachedDrawnObjEvents();
            });
        });
    });
});