webApp.controller('sensorConfigController', function ($scope, ajaxService) {
    $scope.SensorObj = {};    
    $scope.addmessage = "";
    $scope.responseSuccess = true;
    $scope.tablemessage = "";
    $scope.tableResponse = true;

    $scope.add_sensor = function () {
        /* while compiling form , angular created this object*/
        $scope.SensorObj.sensorTypeId = $scope.selected_SensorType.sensorTypeId;
        var formData = $scope.SensorObj;

        var reqHeader = {
            method: 'POST',
            url: getAPI_URL('114'),
            data: formData
        };

        ajaxService.AjaxCall(SuccessFunction, ErrorFunction, reqHeader);

        function SuccessFunction(_responseData) {
            if (_responseData.response === '0') {
                $scope.responseSuccess = true;
                $scope.addmessage = 'Added sensor "' + $scope.SensorObj.name + '" successfully.';
                display_table();
                $scope.reset_form(false);
            } else {
                var error = (angular.isArray(_responseData.errorMessage.errors)) ? _responseData.errorMessage.errors[0] : "";
                $scope.addmessage = (error === null || error === "") ? 'Failed to add sensor.' : error;
                $scope.responseSuccess = false;
            }
        }

        function ErrorFunction(error) {
            $scope.addmessage = 'Failed to add sensor.';
            $scope.responseSuccess = false;
        }
    };

    $scope.close_message = function () {
        $scope.addmessage = "";
    };
    $scope.close_tablemessage = function () {
        $scope.tablemessage = "";
    };

    getSensor_type();

    function getSensor_type() {
        var reqHeader = {
            method: 'GET',
            url: getAPI_URL('123')
        };

        ajaxService.AjaxCall(SuccessFunction, ErrorFunction, reqHeader);

        function SuccessFunction(_responseData) {
            if (_responseData.response === '0' && angular.isArray(_responseData.data)) {
                $scope.Sensor_type = _responseData.data;
            } else {
                var error = (angular.isArray(_responseData.errorMessage.errors)) ? _responseData.errorMessage.errors[0] : "";
                $scope.addmessage = (error === null || error === "") ? 'Failed to load sensor types.' : error;
                $scope.responseSuccess = false;
            }
        }

        function ErrorFunction(error) {
            $scope.addmessage = 'Failed to load sensor types.';
            $scope.responseSuccess = false;
        }
    }

    // Reset Form
    $scope.reset_form = function (restmessage) {
        var reset_message = (typeof restmessage === 'undefined') ? true : false;
        $scope.SensorObj = {};
        $scope.selected_SensorType = "";
        angular.element('#addSensorForm')[0].reset();
        if (reset_message) {
            $scope.addmessage = "";
            $scope.responseSuccess = true;
        }
        $scope.addSensorForm.$setPristine();
        $scope.addSensorForm.$setUntouched();
    };

    display_table();

    function display_table() {        
        var reqHeader = {
            method: 'GET',
            url: getAPI_URL('121')
        };

        ajaxService.AjaxCall(SuccessFunction, ErrorFunction, reqHeader);

        function SuccessFunction(_responseData) {
            if (_responseData.response === "0" && angular.isArray(_responseData.data)) {
                angular.element('#sensorList_table').bootstrapTable({
                    columns: [{
                            field: 'checked',
                            checkbox: true,
                            align: 'center',
                            valign: 'middle'
                        }, {
                            field: 'name',
                            title: 'Sensor Name'
                        }, {
                            field: 'poleName',
                            title: 'Pole Name'
                        }, {
                            field: 'className',
                            title: 'Class Name'
                        }, {
                            field: 'threshold',
                            title: 'Threshold'
                        }, {
                            field: 'status',
                            title: 'Status'
                        }, {
                            field: '',
                            title: 'Action',
                            align: 'center',
                            events: {
//                                'click .edit': function (e, value, row, index) {
//                                    editUser(row);
//                                },
                                'click .delete': function (e, value, row, index) {
                                    var formData = [row.id];

                                    deleteSensor(formData);
                                }
                            },
                            formatter: function (v, row) {
                                //return ['<a class="edit" href="javascript:void(0)" title="Edit">', '<i class="glyphicon glyphicon glyphicon-edit"></i>', '</a>  ', '<a class="delete" href="javascript:void(0)" title="Delete">', '<i class="glyphicon glyphicon-remove"></i>', '</a>'].join('');
                                return ['<button class="btn btn-link delete" type="button">', '<i class="glyphicon glyphicon-remove"></i>', '</button>'].join('');
                            }
                        }]

                });
                angular.element('#sensorList_table').bootstrapTable('load', _responseData.data);
            } else {
                var error = (angular.isArray(_responseData.errorMessage.errors)) ? _responseData.errorMessage.errors[0] : "";
                $scope.tablemessage = (error === null || error === "") ? "Failed to load table." : error;
                $scope.tableResponse = false;
            }
        }

        function ErrorFunction(error) {
            $scope.tablemessage = 'Failed to load table.';
            $scope.tableResponse = false;
        }
    }

    // Delete Functions
    var $table = angular.element('#sensorList_table');
    var $deleteSelected = angular.element('#deleteSelected');

    $table.on('check.bs.table uncheck.bs.table check-all.bs.table uncheck-all.bs.table', function () {
        $deleteSelected.prop('disabled', !$table.bootstrapTable('getSelections').length);
    });

    $scope.delete_selected = function () {
        var formData = [];

        angular.forEach($table.bootstrapTable('getSelections'), function (item) {
            formData.push(item.id);
        });

        deleteSensor(formData);
    };

    function deleteSensor(sensorList) {
        if (typeof sensorList === 'undefined') {
            return;
        }
        
        var reqHeader = {
            method: 'DELETE',
            url: getAPI_URL('176'),
            data: sensorList
        };
        var s = (sensorList.length > 1) ? 's' : '';

        swal({
            title: "Do you want to delete selected sensor" + s + "?",
            //text: username.join(", "),
            //type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Yes",
            cancelButtonText: "No",
            closeOnConfirm: true,
            closeOnCancel: true
        }, function (isConfirm) {
            if (isConfirm) {
                ajaxService.AjaxCall(SuccessFunction, ErrorFunction, reqHeader);
            }
        });

        function SuccessFunction(result) {
            if (result.response === "0") {                                
                $scope.tablemessage = 'Sensor' + s + ' deleted successfully.';
                $scope.tableResponse = true;
            } else {
                var error = (angular.isArray(result.errorMessage.errors)) ? result.errorMessage.errors[0] : "";
                $scope.tablemessage = (error === null || error === "") ? 'Failed to delete sensor' + s + '.' : error;
                $scope.tableResponse = false;
            }
            
            $deleteSelected.prop('disabled', true);
            display_table();
        }

        function ErrorFunction(error) {
            $scope.tablemessage = 'Failed to delete sensor' + s + '.';
            $scope.tableResponse = false;
            
            $deleteSelected.prop('disabled', true);
            display_table();
        }
    }
});