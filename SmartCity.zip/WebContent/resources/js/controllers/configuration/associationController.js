webApp.controller("associationController", function ($scope, $filter, ajaxService) {
    $scope.association_types = [{
            "name": "Pole Sensor Association",
            "value": "sensor-pole-association",
            "to_be_associated": "Pole",
            "orphan_list": "Sensors",
            "to_be_associated_api": "120",
            "selected_api": "161",
            "orphan_api": "130",
            "list_api": "137",
            "post_api": "139",
            "delete_api": ""
        }, {
            "name": "Gateway Pole Association",
            "value": "pole-gateway-association",
            "to_be_associated": "Gateway",
            "orphan_list": "Poles",
            "to_be_associated_api": "135",
            "selected_api": "162",
            "orphan_api": "131",
            "list_api": "138",
            "post_api": "141",
            "delete_api": "177"
        }, {
            "name": "District Gateway Association",
            "value": "gateway-district-association",
            "to_be_associated": "District",
            "orphan_list": "Gateways",
            "to_be_associated_api": "118",
            "selected_api": "160",
            "orphan_api": "132",
            "list_api": "150",
            "post_api": "140",
            "delete_api": ""
        }, {
            "name": "User District Association",
            "value": "user-district-association",
            "to_be_associated": "User",
            "orphan_list": "Districts",
            "to_be_associated_api": "167",
            "selected_api": "164",
            "orphan_api": "163",
            "list_api": "165",
            "post_api": "166",
            "delete_api": ""
        }];
    $scope.selected_association_type = {};
    $scope.selected_association_type.to_be_associated = "";
    $scope.selected_association_type.orphan_list = "";
    $scope.tobe_associated = [];
    $scope.selected_tobe_associated = null;
    $scope.orphan_list = [];
    $scope.selected_orphan_list = null;
    $scope.current_associations = [];
    $scope.selected_current_associations = null;
    $scope.physical_pole = null;

    $scope.addmessage = "";
    $scope.responseSuccess = true;
    $scope.tablemessage = [];
    $scope.hasItem = true;
    
    $scope.showDeleteButton = false;

    $scope.close_message = function () {
        $scope.addmessage = "";
    };
    $scope.close_tablemessage = function (index) {
        $scope.tablemessage.splice(index, 1);;
    };

    $scope.isDisabled = function () {
        var checker = [];
        var disable = true;

        checker[0] = ($scope.current_associations.length > 0) ? "true" : "false";
        checker[1] = ($scope.association_form.$valid) ? "true" : "false";
        checker[2] = (!angular.equals($scope.current_associations_copy, $scope.current_associations)) ? "true" : "false";


        if ($scope.selected_association_type.to_be_associated === 'Gateway' && $scope.selected_association_type.orphan_list === 'Poles') {
            checker[3] = ($scope.physical_pole !== null) ? "true" : "false";
        }

        if (checker.indexOf("false") === -1) {
            disable = false;
        }

        return disable;
    };

    $scope.selection_criteria = function () {
        if ($scope.selected_association_type) {
            $scope.addmessage = "";
            $scope.current_associations = [];
            $scope.selected_tobe_associated = null;

            var list_api = $scope.selected_association_type.list_api;
            var to_be_associated_api = $scope.selected_association_type.to_be_associated_api;
            var orphan_api = $scope.selected_association_type.orphan_api;

            fetchToBeSelectedData(to_be_associated_api);
            fetchOrphanData(orphan_api);
            displayTable(list_api);
        } else {
            $scope.resetall();
        }
    };

    $scope.prefetch_to_be_selected = function (restmessage) {
        var reset_message = (typeof restmessage === 'undefined') ? true : restmessage;

        var orphan_api = $scope.selected_association_type.orphan_api;
        fetchOrphanData(orphan_api);

        if (reset_message) {
            $scope.addmessage = "";
            $scope.responseSuccess = true;
        }

        if ($scope.selected_tobe_associated) {
            var selected_asso_id = "/" + $scope.selected_tobe_associated.id;
            var selected_api = $scope.selected_association_type.selected_api;

            fetchCurrentAssociation(selected_api, selected_asso_id);
        } else {
            $scope.current_associations = [];
            $scope.selected_tobe_associated = null;
        }
    };

    $scope.select_orphans = function () {
        var isUserDistrict = ($scope.selected_association_type.to_be_associated === 'User' && $scope.selected_association_type.orphan_list === 'Districts') ? true : false;
        var message = [];

        if ($scope.selected_tobe_associated) {
            angular.forEach($scope.selected_orphan_list, function (item) {
                var the_item = $filter('filter')($scope.orphan_list, {id: item}, true)[0];
                var the_index = $scope.orphan_list.indexOf(the_item);
                var does_exist = $filter('filter')($scope.current_associations, {id: item}, true)[0];

                if (!does_exist) {
                    $scope.current_associations.push(the_item);
                    if (!isUserDistrict) {
                        $scope.orphan_list.splice(the_index, 1);
                    }
                } else {
                    message.push("\"" + does_exist.name + "\"");
                    $scope.responseSuccess = false;
                }
            });

            $scope.addmessage = (message.length > 0) ? $scope.selected_association_type.orphan_list + " " + message.join(", ") + " already associated" : "";

            $scope.selected_current_associations = null;
            $scope.selected_orphan_list = null;
        }
    };
    $scope.remove_orphans = function () {
        if ($scope.selected_tobe_associated) {
            angular.forEach($scope.selected_current_associations, function (item) {
                var the_item = $filter('filter')($scope.current_associations, {id: item}, true)[0];
                var the_index = $scope.current_associations.indexOf(the_item);
                var does_exist = $filter('filter')($scope.orphan_list, {id: item}, true)[0];

                if (!does_exist) {
                    $scope.orphan_list.push(the_item);
                }
                $scope.current_associations.splice(the_index, 1);
            });

            $scope.selected_current_associations = null;
            $scope.selected_orphan_list = null;
        }
    };

    $scope.add_association = function () {
        var to_be_associated = $scope.selected_association_type.to_be_associated;
        var orphan_list = $scope.selected_association_type.orphan_list;
        $scope.asso_post_data = {};

        if (to_be_associated === 'Pole' && orphan_list === 'Sensors') {

            $scope.asso_post_data.poleId = $scope.selected_tobe_associated.id;
            $scope.asso_post_data.sensorIdList = [];
            angular.forEach($scope.current_associations, function (item) {
                $scope.asso_post_data.sensorIdList.push(item.id);
            });

        } else if (to_be_associated === 'Gateway' && orphan_list === 'Poles') {

            $scope.asso_post_data.gatewayId = $scope.selected_tobe_associated.id;
            $scope.asso_post_data.physicalPoleId = $scope.physical_pole.id;

            $scope.asso_post_data.poleIdList = [];
            angular.forEach($scope.current_associations, function (item) {
                $scope.asso_post_data.poleIdList.push(item.id);
            });

        } else if (to_be_associated === 'District' && orphan_list === 'Gateways') {

            $scope.asso_post_data.districtId = $scope.selected_tobe_associated.id;
            $scope.asso_post_data.gatewayIdList = [];
            angular.forEach($scope.current_associations, function (item) {
                $scope.asso_post_data.gatewayIdList.push(item.id);
            });

        } else if (to_be_associated === 'User' && orphan_list === 'Districts') {
            $scope.asso_post_data.userList = [];
            $scope.asso_post_data.userList.push($scope.selected_tobe_associated.id);

            $scope.asso_post_data.districtList = [];
            angular.forEach($scope.current_associations, function (item) {
                $scope.asso_post_data.districtList.push(item.id);
            });

        }

        var formData = $scope.asso_post_data;

        var URL1 = getAPI_URL($scope.selected_association_type.post_api);
        var reqHeader = {
            method: 'POST',
            url: URL1,
            data: formData
        };
        ajaxService.AjaxCall(SuccessFunction, ErrorFunction, reqHeader);

        function SuccessFunction(result) {
            if (result.response === "0") {
                $scope.responseSuccess = true;
                $scope.addmessage = '"' + $scope.selected_association_type.name + '" added/updated successfully.';
                var list_api = $scope.selected_association_type.list_api;
                $scope.prefetch_to_be_selected(false);
                displayTable(list_api);
            } else {
                var error = result.errorMessage.errors[0];
                $scope.addmessage = (error === null || error === "") ? 'Failed to add/update "' + $scope.selected_association_type.name + '".' : error;
                $scope.responseSuccess = false;
            }
        }

        function ErrorFunction(error) {
            $scope.addmessage = 'Failed to add/update "' + $scope.selected_association_type.name + '".';
            $scope.responseSuccess = false;
        }
    };

    $scope.resetall = function (restmessage) {
        var reset_message = (typeof restmessage === 'undefined') ? true : restmessage;

        angular.element('#associationList_table').bootstrapTable('destroy');
        angular.element("#association_form")[0].reset();

        $scope.selected_association_type = {};
        $scope.selected_association_type.to_be_associated = "";
        $scope.selected_association_type.orphan_list = "";
        $scope.tobe_associated = [];
        $scope.selected_tobe_associated = null;
        $scope.orphan_list = [];
        $scope.selected_orphan_list = null;
        $scope.current_associations = [];
        $scope.selected_current_associations = null;
        $scope.physical_pole = null;

        $scope.association_form.$setPristine();
        $scope.association_form.$setUntouched();

        if (reset_message) {
            $scope.addmessage = "";
            $scope.responseSuccess = true;
        }
        
        $scope.showDeleteButton = false;
    };
    $scope.reload_orphans = function () {
        var orphan_api = $scope.selected_association_type.orphan_api;
        fetchOrphanData(orphan_api);
    };

    function fetchToBeSelectedData(api) {
        $scope.selected_tobe_associated = null;
        $scope.tobe_associated = [];

        var api_url = getAPI_URL(api);

        if (api === "118" || api === "167") {
            var formData = {
                "sortBy": "",
                "sortOrder": "",
                "filter": ""
            };
            var reqHeader = {
                method: 'POST',
                url: api_url,
                data: formData
            };
        } else {
            //"120" || "135"
            var reqHeader = {
                method: 'GET',
                url: api_url
            };
        }

        ajaxService.AjaxCall(SuccessFunction, ErrorFunction, reqHeader);

        function SuccessFunction(result) {
            if (result.response === "0" && angular.isArray(result.data)) {
                $scope.tobe_associated = result.data;
            } else if (result.response === "1") {
                var error = angular.isArray(result.errorMessage.errors) ? result.errorMessage.errors[0] : "";
                $scope.addmessage = (error === null || error === "") ? 'Failed to load "' + $scope.selected_association_type.to_be_associated + '" list.' : error;
                $scope.responseSuccess = false;
            }
        }

        function ErrorFunction(error) {
            $scope.addmessage = 'Failed to load "' + $scope.selected_association_type.to_be_associated + '" list.';
            $scope.responseSuccess = false;
        }
    }

    function fetchOrphanData(api) {
        // "130" || "131" || "132" || 163

        $scope.selected_orphan_list = null;
        $scope.orphan_list = [];

        var api_url = getAPI_URL(api);

        var reqHeader = {
            method: 'GET',
            url: api_url
        };

        ajaxService.AjaxCall(SuccessFunction, ErrorFunction, reqHeader);

        function SuccessFunction(result) {
            if (result.response === "0" && angular.isArray(result.data)) {
                $scope.orphan_list = result.data;
            } else if (result.response === "1") {
                var error = angular.isArray(result.errorMessage.errors) ? result.errorMessage.errors[0] : "";
                $scope.addmessage = (error === null || error === "") ? 'Failed to load "' + $scope.selected_association_type.orphan_list + '" orphan list.' : error;
                $scope.responseSuccess = false;
            }
        }

        function ErrorFunction(error) {
            $scope.addmessage = 'Failed to load "' + $scope.selected_association_type.orphan_list + '" orphan list.';
            $scope.responseSuccess = false;
        }
    }

    function fetchCurrentAssociation(api, api_param) {
        // "161" || "162" || "160" || "164"

        $scope.selected_current_associations = null;
        $scope.selected_orphan_list = null;
        $scope.current_associations = [];
        $scope.current_associations_copy = [];

        var api_url = getAPI_URL(api) + api_param;

        var reqHeader = {
            method: 'GET',
            url: api_url
        };

        ajaxService.AjaxCall(SuccessFunction, ErrorFunction, reqHeader);

        function SuccessFunction(result) {
            if (result.response === "0" && angular.isArray(result.data)) {
                $scope.current_associations = result.data;
                $scope.current_associations_copy = angular.copy($scope.current_associations);

                if ($scope.selected_association_type.orphan_list === 'Poles') {
                    $scope.physical_pole = $filter('filter')($scope.current_associations, {isGateway: 1}, true)[0];
                }
            } else if (result.response === "1") {
                var error = angular.isArray(result.errorMessage.errors) ? result.errorMessage.errors[0] : "";
                $scope.addmessage = (error === null || error === "") ? 'Failed to load current ' + $scope.selected_association_type.orphan_list + ' association list.' : error;
                $scope.responseSuccess = false;
            }
        }

        function ErrorFunction(error) {
            $scope.addmessage = 'Failed to load current ' + $scope.selected_association_type.orphan_list + ' association list.';
            $scope.responseSuccess = false;
        }
    }

    function displayTable(api) {
        var api_url = getAPI_URL(api);
        var table_columns = {
            "137": [{
                    field: 'poleId',
                    checkbox: true,
                    align: 'center',
                    valign: 'middle'
                }, {
                    field: 'poleName',
                    title: 'Pole Name'
                }, {
                    field: 'sensorName',
                    title: 'sensor Name',
                    formatter: function (v) {
                        return v.join("<br>");
                    }
                }, {
                    field: 'poleLat',
                    title: 'Pole Latitude'
                }, {
                    field: 'poleLongi',
                    title: 'Pole Longitude'
                }, {
                    field: '',
                    title: 'Action',
                    align: 'center',
                    width: '75px',
                    events: {
                        'click .delete': function (e, value, row, index) {
                            //console.log('You click delete action, row: ' + (index + 1));
                        }
                    },
                    formatter: function () {
                        return ['<a class="delete" href="javascript:void(0)" title="Delete">', '<i class="glyphicon glyphicon-remove"></i>', '</a>'].join('');
                    }
                }],
            "138": [{
                    field: 'checked',
                    checkbox: true,
                    align: 'center',
                    valign: 'middle'
                }, {
                    field: 'gatewayName',
                    title: 'Gateway Name'
                }, {
                    field: 'poleName',
                    title: 'Pole Name',
                    formatter: function (v) {
                        return v.join("<br>");
                    }
                }, {
                    field: 'physicalPoleName',
                    title: 'Physical Pole'
                }, {
                    field: 'lat',
                    title: 'Latitude'
                }, {
                    field: 'longi',
                    title: 'Longitude'
                }, {
                    field: '',
                    title: 'Action',
                    align: 'center',
                    width: '75px',
                    events: {
                        'click .delete': function (e, value, row, index) {
                            //gatewayId
                            var formData = [row.gatewayId];
                            deleteAssociation(formData);
                        }
                    },
                    formatter: function () {
                        return ['<a class="delete" href="javascript:void(0)" title="Delete">', '<i class="glyphicon glyphicon-remove"></i>', '</a>'].join('');
                    }
                }],
            "150": [{
                    field: 'id',
                    checkbox: true,
                    align: 'center',
                    valign: 'middle'
                }, {
                    field: 'name',
                    title: 'District Name'
                }, {
                    field: 'gatewayNameList',
                    title: 'Gateway List',
                    formatter: function (v) {
                        return v.join("<br>");
                    }
                }, {
                    field: 'districtCoordinates',
                    title: 'District Coordinates',
                    formatter: function (v) {
                        return v.split("#").join("<br>");
                    }
                }, {
                    field: '',
                    title: 'Action',
                    align: 'center',
                    width: '75px',
                    events: {
                        'click .delete': function (e, value, row, index) {
                            //console.log('You click delete action, row: ' + (index + 1));
                        }
                    },
                    formatter: function () {
                        return ['<a class="delete" href="javascript:void(0)" title="Delete">', '<i class="glyphicon glyphicon-remove"></i>', '</a>'].join('');
                    }
                }],
            "165": [{
                    field: 'userId',
                    checkbox: true,
                    align: 'center',
                    valign: 'middle'
                }, {
                    field: 'userName',
                    title: 'Username'
                }, {
                    field: 'districtName',
                    title: 'District Name',
                    formatter: function (value, row, index) {
                        return value.join("<br>");
                    }
                }, {
                    field: '',
                    title: 'Action',
                    align: 'center',
                    width: '75px',
                    events: {
                        'click .delete': function (e, value, row, index) {
                            //console.log('You click delete action, row: ' + (index + 1));
                        }
                    },
                    formatter: function () {
                        return ['<a class="delete" href="javascript:void(0)" title="Delete">', '<i class="glyphicon glyphicon-remove"></i>', '</a>'].join('');
                    }
                }]
        };

        if (api === "137" || api === "150") {
            var formData = {
                "sortBy": "",
                "sortOrder": "",
                "filter": ""
            };
            var reqHeader = {
                method: 'POST',
                url: api_url,
                data: formData
            };
        } else {
            // 138" || "165"
            var reqHeader = {
                method: 'GET',
                url: api_url
            };
        }

        ajaxService.AjaxCall(SuccessFunction, ErrorFunction, reqHeader);

        function SuccessFunction(result) {
            var table_data = [];
            
            if (result.response === "0") {
                
                table_data = angular.isArray(result.data)? result.data : [];
                angular.element('#associationList_table').bootstrapTable('destroy');
                angular.element('#associationList_table').bootstrapTable({
                    columns: table_columns[api]
                });
                angular.element('#associationList_table').bootstrapTable('load', table_data);
                
            } else if (result.response === "1") {              
                var error = (angular.isArray(_responseData.errorMessage.errors)) ? _responseData.errorMessage.errors[0] : "";
                $scope.tablemessage.push({
                    "message": (error === null || error === "") ? "Failed to load table." : error,
                    "type": "alert-danger"
                });

            }
            $scope.showDeleteButton = (angular.element.isEmptyObject(table_data)) ? false : true;
            angular.element('#associationList_table').bootstrapTable('load', table_data);
        }

        function ErrorFunction(error) {
            angular.element('#associationList_table').bootstrapTable('load', []);
            $scope.showDeleteButton = false;
            
            $scope.tablemessage.push({
                "message": "Failed to load table.",
                "type": "alert-danger"
            });
        }
    }

    // Delete Functions
    var $table = angular.element('#associationList_table');
    var $deleteSelected = angular.element('#deleteSelected');

    $table.on('check.bs.table uncheck.bs.table check-all.bs.table uncheck-all.bs.table', function () {
        $deleteSelected.prop('disabled', !$table.bootstrapTable('getSelections').length);
    });

    $scope.delete_selected = function () {
        var formData = [];

        angular.forEach($table.bootstrapTable('getSelections'), function (item) {
            if ($scope.selected_association_type.name === "Gateway Pole Association") {
                formData.push(item.gatewayId);
            }
        });

        deleteAssociation(formData);
    };

    function deleteAssociation(formdata) {
        if (typeof formdata === 'undefined') {
            return;
        }
        var delete_api = getAPI_URL($scope.selected_association_type.delete_api);

        var reqHeader = {
            method: 'POST',
            url: delete_api,
            data: formdata
        };
        var s = (formdata.length > 1) ? 's' : '';

        swal({
            title: "Do you want to delete selected association" + s + "?",
            //text: username.join(", "),
            //type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Yes",
            cancelButtonText: "No",
            closeOnConfirm: true,
            closeOnCancel: true
        }, function (isConfirm) {
            if (isConfirm) {
                ajaxService.AjaxCall(SuccessFunction, ErrorFunction, reqHeader);
            }
        });

        function SuccessFunction(result) {
            if (result.response === "0") {               
                $scope.tablemessage.push({
                        "message":"Association" + s + " deleted successfully.",
                        "type": "alert-success"
                    });
            } else {
                
                var error = (angular.isArray(result.errorMessage.errors)) ? result.errorMessage.errors[0] : "";                
                $scope.tablemessage.push({
                    "message": (error === null || error === "") ? 'Failed to delete association' + s + '.' : error,
                    "type": "alert-danger"
                });
            }

            $deleteSelected.prop('disabled', true);
            $scope.selection_criteria();
        }

        function ErrorFunction(error) {
            $scope.tablemessage = [];
            $scope.tablemessage.push({
                "message": "Failed to delete association" + s + ".",
                "type": "alert-danger"
            });

            $deleteSelected.prop('disabled', true);
            $scope.selection_criteria();
        }
    }
}); //controller ends