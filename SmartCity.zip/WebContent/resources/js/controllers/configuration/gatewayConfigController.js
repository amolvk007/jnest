webApp.controller('gatewayConfigController', function ($scope, ajaxService) {
    $scope.addGatewayObj = {};
    $scope.addmessage = "";
    $scope.responseSuccess = true;
    $scope.tablemessage = [];
    $scope.protocolTypes = [
        {
            name: "XMPP",
            value: "XMPP"
        },
        {
            name: "MQTT",
            value: "MQTT"
        }
    ];

    $scope.add_gateway = function () {
        /* while compiling form , angular created this object*/
        $scope.addGatewayObj.gatwayTypeId = $scope.selected_GatewayType.gatewayTypeId;
        $scope.addGatewayObj.protocol = $scope.selected_protocolType.value;
        var formData = $scope.addGatewayObj;

        var reqHeader = {
            method: 'POST',
            url: getAPI_URL("110"),
            data: formData
        };

        ajaxService.AjaxCall(SuccessFunction, ErrorFunction, reqHeader);

        function SuccessFunction(_responseData) {
            if (_responseData.response === "0") {
                $scope.responseSuccess = true;
                $scope.addmessage = 'Added gateway "' + $scope.addGatewayObj.gatewayName + '" successfully.';
                display_table();
                $scope.reset_form(false);
            } else {
                var error = (angular.isArray(_responseData.errorMessage.errors)) ? _responseData.errorMessage.errors[0] : "";
                $scope.addmessage = (error === null || error === "") ? "Failed to add gateway." : error;
                $scope.responseSuccess = false;
            }
        }

        function ErrorFunction(error) {
            $scope.addmessage = "Failed to add gateway.";
            $scope.responseSuccess = false;
        }
    };
    $scope.close_message = function () {
        $scope.addmessage = "";
    };
    $scope.close_tablemessage = function (index) {
        $scope.tablemessage.splice(index, 1);;
    };

    getGateway_type();

    function getGateway_type() {

        var reqHeader = {
            method: 'GET',
            url: getAPI_URL("122")
        };

        ajaxService.AjaxCall(SuccessFunction, ErrorFunction, reqHeader);

        function SuccessFunction(_responseData) {
            if (_responseData.response === "0") {
                $scope.Gateway_type = _responseData.data;
            } else {
                var error = (angular.isArray(_responseData.errorMessage.errors)) ? _responseData.errorMessage.errors[0] : "";
                $scope.addmessage = (error === null || error === "") ? "Failed to load gateway type." : error;
                $scope.responseSuccess = false;
            }
        }

        function ErrorFunction(error) {
            $scope.addmessage = "Failed to load gateway type.";
            $scope.responseSuccess = false;
        }

    }

    display_table();
    
    function display_table() {
        var reqHeader = {
            method: 'GET',
            url: getAPI_URL("119")
        };

        ajaxService.AjaxCall(SuccessFunction, ErrorFunction, reqHeader);

        function SuccessFunction(_responseData) {
            if (_responseData.response === "0" && angular.isArray(_responseData.data)) {
                angular.element('#gatewayList_table').bootstrapTable({
                    columns: [{
                            field: 'checked',
                            checkbox: true,
                            align: 'center',
                            valign: 'middle'
                        }, {
                            field: 'name',
                            title: 'Gateway Name'
                        }, {
                            field: 'lat',
                            title: 'Latitude'
                        }, {
                            field: 'longi',
                            title: 'Longitude'
                        }, {
                            field: 'status',
                            title: 'Gateway Status'
                        }, {
                            field: '',
                            title: 'Action',
                            align: 'center',
                            events: {
//                                'click .edit': function (e, value, row, index) {
//                                    editUser(row);
//                                },
                                'click .delete': function (e, value, row, index) {
                                    var formData = [row.id];

                                    deleteGateway(formData);
                                }
                            },
                            formatter: function (v, row) {
                                //return ['<a class="edit" href="javascript:void(0)" title="Edit">', '<i class="glyphicon glyphicon glyphicon-edit"></i>', '</a>  ', '<a class="delete" href="javascript:void(0)" title="Delete">', '<i class="glyphicon glyphicon-remove"></i>', '</a>'].join('');
                                return ['<button class="btn btn-link delete" type="button">', '<i class="glyphicon glyphicon-remove"></i>', '</button>'].join('');
                            }
                        }]

                });
                angular.element('#gatewayList_table').bootstrapTable('load', _responseData.data);
            } else {
                var error = (angular.isArray(_responseData.errorMessage.errors)) ? _responseData.errorMessage.errors[0] : "";
                $scope.tablemessage.push({
                    "message": (error === null || error === "") ? "Failed to load table." : error,
                    "type": "alert-danger"
                });
            }
        }

        function ErrorFunction(error) {
            $scope.tablemessage.push({
                "message": "Failed to load table.",
                "type": "alert-danger"
            });
        }
    };
    
    // Delete Functions
    var $table = angular.element('#gatewayList_table');
    var $deleteSelected = angular.element('#deleteSelected');

    $table.on('check.bs.table uncheck.bs.table check-all.bs.table uncheck-all.bs.table', function () {
        $deleteSelected.prop('disabled', !$table.bootstrapTable('getSelections').length);
    });

    $scope.delete_selected = function () {
        var formData = [];

        angular.forEach($table.bootstrapTable('getSelections'), function (item) {
            formData.push(item.id);
        });

        deleteGateway(formData);
    };

    function deleteGateway(gatewayList) {
        if (typeof gatewayList === 'undefined') {
            return;
        }

        var reqHeader = {
            method: 'DELETE',
            url: getAPI_URL('174'),
            data: gatewayList
        };
        var s = (gatewayList.length > 1) ? 's' : '';

        swal({
            title: "Do you want to delete selected gateway" + s + "?",
            //text: username.join(", "),
            //type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Yes",
            cancelButtonText: "No",
            closeOnConfirm: true,
            closeOnCancel: true
        }, function (isConfirm) {
            if (isConfirm) {
                ajaxService.AjaxCall(SuccessFunction, ErrorFunction, reqHeader);
            }
        });

        function SuccessFunction(result) {
            $scope.tablemessage = [];
            if (result.response === "0") {
                if (angular.isArray(result.data.pass) && result.data.pass.length > 0) {
                    $scope.tablemessage.push({
                        "message":"Gateway [" + result.data.pass.join(", ") + "] deleted successfully.",
                        "type": "alert-success"
                    });
                }
                if (angular.isArray(result.data.fail) && result.data.fail.length > 0) {
                    $scope.tablemessage.push({
                        "message":"Unable to delete gateway [" + result.data.fail.join(", ") + "].",
                        "type": "alert-danger"
                    });
                }

            } else if(result.response === "1") {
                var error = (angular.isArray(result.errorMessage.errors)) ? result.errorMessage.errors[0] : "";
                
                $scope.tablemessage.push({
                    "message": (error === null || error === "") ? 'Failed to delete gateway' + s + '.' : error,
                    "type": "alert-danger"
                });
            }
            
            $deleteSelected.prop('disabled', true);
            display_table();
        }

        function ErrorFunction(error) {
            $scope.tablemessage = [];
            $scope.tablemessage.push({
                "message": "Failed to delete gateway" + s + ".",
                "type": "alert-danger"
            });
            
            $deleteSelected.prop('disabled', true);
            display_table();
        }
    }

    // Reset Form
    $scope.reset_form = function (restmessage) {
        var reset_message = (typeof restmessage === "undefined") ? true : false;
        $scope.addGatewayObj = {};
        $scope.selected_protocolType = "";
        $scope.selected_GatewayType = "";

        angular.element('#addGatewayForm')[0].reset();
        if (reset_message) {
            $scope.addmessage = "";
            $scope.responseSuccess = true;
        }
        $scope.addGatewayForm.$setPristine();
        $scope.addGatewayForm.$setUntouched();
    };
});