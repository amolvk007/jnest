webApp.controller("vnNotificationController", function ($scope, $sce, $interval, ajaxService) {
    $scope.vnNotifications = {};
    $scope.itemPerPageOptions = [
        {label: "05", value: "5"},
        {label: "10", value: "10"},
        {label: "15", value: "15"},
        {label: "20", value: "20"},
        {label: "25", value: "25"}
    ];
    $scope.isDisabled = true;
    $scope.paginate = {
        itemPerPage: {
            label: "10",
            value: "10"
        },
        pageNumber: 1
    };
    $scope.addmessage = "";
    $scope.showNotification = false;

    var refreshDelay = 120000;
    var vnTimer;

    $scope.close_message = function () {
        $scope.addmessage = "";
    };    

    $scope.onItemPerPageChange = function () {
        getNotifications();
    };
    $scope.nextPage = function () {
        $scope.paginate.pageNumber += 1;
        getNotifications();
    };
    $scope.prevPage = function () {
        if ($scope.paginate.pageNumber > 1) {
            $scope.paginate.pageNumber -= 1;
            getNotifications();
        }
    };
    
    getNotifications();

    function trustSrc(src) {
        return $sce.trustAsResourceUrl(src);
    }

    function getNotifications() {
        if ($scope.$state.current.name === "header.notification.videonext") {
            var url = "169";
            var urlParam = "?page=" + $scope.paginate.pageNumber + "&limit=" + $scope.paginate.itemPerPage.value;
            var vnVideoURL = getAPI_URL("vnVideoDemo");

            $scope.isDisabled = true;

            var the_url = getAPI_URL(url) + urlParam;
            var reqHeader = {
                method: 'GET',
                url: the_url
            };

            ajaxService.AjaxCall(SuccessFunction, ErrorFunction, reqHeader);

            function SuccessFunction(result) {
                if (result.response === "0" && angular.isArray(result.data)) {
                    $scope.addmessage = "";
                    $scope.showNotification = true;
                    var tempData = result.data;
                    angular.forEach(tempData, function (vn) {
                        vn.videoUrl = trustSrc(vnVideoURL);
                    });
                    $scope.vnNotifications = tempData;
                    $scope.isDisabled = false;

                    if (!angular.isDefined(vnTimer)) {
                        vnTimer = $interval(function () {
                            getNotifications();
                        }, refreshDelay);
                    }
                } else {
                    if (angular.isDefined(vnTimer)) {
                        $interval.cancel(vnTimer);
                        vnTimer = undefined;
                    }
                    $scope.addmessage = "Failed to load videonext notifications. ";
                }
            }

            function ErrorFunction(error) {
                if (angular.isDefined(vnTimer)) {
                    $interval.cancel(vnTimer);
                    vnTimer = undefined;
                }
                $scope.addmessage = "Failed to load videonext notifications.";
            }
        } else {
            if (angular.isDefined(vnTimer)) {
                $interval.cancel(vnTimer);
                vnTimer = undefined;
            }
        }
    }
});