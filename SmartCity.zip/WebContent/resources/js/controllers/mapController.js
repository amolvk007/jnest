webApp.controller("mapController", function($scope, $rootScope, $timeout, $filter, uiGmapGoogleMapApi, uiGmapIsReady, dataService, setviewService) {
    // Note: Some of the directives require at least something to be defined originally!
    // e.g. $scope.markers = []
    $scope.markers = [];
    $scope.poles_markers = [];
    $scope.polygons = [];
    $scope.map = {
        center: {
            latitude: 32.778978,
            longitude: -96.791607
        },
        zoom: 14
    };


    var newcenter = {
        lat: 41.850,
        lng: -87.650
    };

    var current_polygon_cords;
    var angularGmapInstance = 0;

    //id to index mapping
    var markerGIdMap = {};
    var markerPIdMap = {};


    $scope.$on('dataSubset', function(event, args) {
        var data = args.message;
        current_polygon_cords = data[0].coords;


        angular.forEach(data, function(refdata) {

            if (refdata.hasOwnProperty("children")) {
                angular.forEach(refdata.children, function(val, k) {

                    if (val.hasOwnProperty("children")) {

                        if (angularGmapInstance) {
                            gateway_marker(data);
                            poles_marker(data);

                        } else {
                            uiGmapGoogleMapApi.then(function(g_maps) {
                                angularGmapInstance = g_maps;
                                gateway_marker(data);
                                poles_marker(data);

                            });

                        }

                        //below lines are not working due to dynamic append of tree
                        angular.forEach(val.children, function(poles) {
                            if (poles.hasOwnProperty("children")) {

                            } else {

                                setTimeout(function() {
                                    $("#" + poles.id).addClass("no-sensor");
                                    $("#" + poles.id).siblings([".tree-branch-head.a6"]).addClass("minus_icon")
                                }, 500)
                            }

                        })


                    } else {

                        $scope.poles_markers = [];
                        $scope.markers = [];
                        setTimeout(function() {
                            $("#" + val.id).addClass("no-pole")
                            $("#" + val.id).siblings([".tree-branch-head.a6"]).addClass("minus_icon")
                        }, 0)
                    }
                })
            } else {
                $scope.poles_markers = [];
                $scope.markers = [];
            }
        })



    });

    $scope.$watch(dataService.treeselectednode, function(newValue, oldValue) {

        var nodeType = newValue.toString().substring(0, 1);

        if (nodeType !== "D") {
            highlightClickedMarker(newValue, oldValue, nodeType);
        }

    }, true);




    function gateway_marker(mod_data) {
        markerGIdMap = {};
        var counter = 0;
        var id_tracker = 100;
        var gmarkerarray = [];
        var actual_district_id = mod_data[0].id;
        angular.forEach(mod_data, function(district, k) {
            angular.forEach(district.children, function(gateway, m) {
                if (gateway.coords) {
                    current_gateway_id = mod_data[0].children[m].id;
                    gmarkerarray.push(gateway.coords[0]);
                    gmarkerarray[counter]["functionalMode"] = gateway.functionalMode;
                    gmarkerarray[counter]["id"] = gateway.id;
                    gmarkerarray[counter]["icon"] = {
                        url: "./images/gateway.png",
                        anchor: new angularGmapInstance.Point(32, 69)
                    };
                    gmarkerarray[counter]["name"] = gateway.name;
                    gmarkerarray[counter]["counter"] = counter;
                    gmarkerevents(counter, gmarkerarray[counter].id, actual_district_id, current_gateway_id, m);
                    markerGIdMap[gateway.id] = counter;
                    counter++;
                }
            });
        });

        function gmarkerevents(counter, id_tracker, _districtid, _gatewayid, m) {
            gmarkerarray[counter]["events"] = {
                click: function() {
                    $scope.$parent.select_map_node(_districtid, counter);

                }

            }
        };

        $scope.markers = gmarkerarray;

    };

    function poles_marker(mod_data) {

        var markerarray = [];
        counter = 0;
        var id_tracker = 0;
        markerPIdMap = {};
        var current_gateway_id;
        var actual_district_id = mod_data[0].id;
        angular.forEach(mod_data, function(district, j) {

            angular.forEach(district.children, function(gateway, k) {

                current_gateway_id = mod_data[0].children[k].id;

                angular.forEach(gateway.children, function(pole, m) {

                    markerarray.push(pole.coords[0]);
                    markerarray[counter]["id"] = pole.id;
                    markerarray[counter]["functionalMode"] = pole.functionalMode;
                    markerarray[counter]["isGateway"] = pole.isGateway;
                    markerarray[counter]["icon"] = "./images/light-green.png";
                    if ((markerarray[counter]["functionalMode"]).toLowerCase() == "non operational") {
                        markerarray[counter]["icon"] = "./images/light-red.png";
                        // nonOpPolesIdArray.push(counter);
                    }
                    if (markerarray[counter]["isGateway"]) {
                        markerarray[counter]["icon"] = './images/isgateway.png';
                        if ((markerarray[counter]["functionalMode"]).toLowerCase() == "non operational") {
                            markerarray[counter]["icon"] = "./images/isgateway-non.png";
                            // nonOpPolesIdArray.push(counter);
                        }
                    }
                    id_tracker = markerarray[counter].id;
                    //need to cleanup variables which are not used
                    pmarkerevents(counter, current_gateway_id, m, id_tracker, actual_district_id, k);
                    markerPIdMap[pole.id] = counter;
                    counter++;
                });
            });

        });

        function pmarkerevents(counter, _gateway, _pole, id_tracker, district, k) {
            markerarray[counter]["events"] = {
                click: function() {
                    $scope.$parent.select_map_node(district, k, _pole);
                }

            };


        };

        $scope.poles_markers = [];
        $scope.poles_markers = markerarray;



    };


    function polygon_append_marker(mod_data, id) {
        var district_id_actual = id.toString().substring(1, 2);
        $scope.polygons[district_id_actual - 1].path = mod_data[0].coords;
    }


    $scope.view_update = function() {

        $scope.$broadcast('clickOnNode');

    }

    function highlightClickedMarker(newValue, oldValue, node) {
        //note: I have tried various methods like preloading the image etc for removing blink when first time marker is clicked, i have checked commonfloor.com for changing markers and it seems that even there first time blink is present, so as of now leaving it as it is.

        if (node == "G") {
            $scope.markers[markerGIdMap[newValue]].icon.url = './images/gateway-big.png';

        } else if (node == "P") {

            var data = $scope.poles_markers[markerPIdMap[newValue]];
            if ((data.functionalMode).toLowerCase() == 'non operational' && data.isGateway) {
                data.icon = './images/isgateway-non-big.png'
            } else if ((data.functionalMode).toLowerCase() == 'non operational' && !data.isGateway) {
                data.icon = './images/light-red-big.png'
            } else if ((data.functionalMode).toLowerCase() == 'operational' && data.isGateway) {
                data.icon = './images/isgateway-big.png'
            } else {
                data.icon = './images/light-green-big.png'
            }

        }

        resetold(oldValue, node);

    }


    function resetold(oldValue, node) {

        var identifier = oldValue.toString().substring(0, 1);
        if (identifier == "G") {
            if ($scope.markers[markerGIdMap[oldValue]]) {
                $scope.markers[markerGIdMap[oldValue]].icon.url = './images/gateway.png';
            }
        } else if (identifier == "P") {
            var old_data = $scope.poles_markers[markerPIdMap[oldValue]];
            //reset other icons
            if ($scope.poles_markers[markerPIdMap[oldValue]]) {
                if ((old_data.functionalMode).toLowerCase() == "non operational" && old_data.isGateway) {
                    old_data.icon = './images/isgateway-non.png';
                } else if (!old_data.isGateway && (old_data.functionalMode).toLowerCase() == "non operational") {
                    old_data.icon = './images/light-red.png';
                } else if (old_data.isGateway && (old_data.functionalMode).toLowerCase() == "operational") {
                    old_data.icon = './images/isgateway.png';
                } else {
                    old_data.icon = "./images/light-green.png"
                }

            }

        }
    }

    // function resetall_gateways_icon() {

    //     angular.forEach($scope.markers, function(data) {
    //         data.icon.url = "./images/gateway.png";

    //     })
    // }




    // function markerhighlight(id) {

    //     angular.forEach($scope.markers, function(data) {
    //         if (data.id == id) {
    //             data.icon.url = './images/gateway-big.png'
    //         }
    //     });

    // }

    // function resetall_pole_icon() {

    //     angular.forEach($scope.poles_markers, function(data) {
    //         if ((data.functionalMode).toLowerCase() == "non operational" && data.isGateway) {
    //             data.icon = './images/isgateway-non.png';
    //         } else if (!data.isGateway && (data.functionalMode).toLowerCase() == "non operational") {
    //             data.icon = './images/light-red.png';
    //         } else if (data.isGateway && (data.functionalMode).toLowerCase() == "operational") {
    //             data.icon = './images/isgateway.png';
    //         } else {
    //             data.icon = "./images/light-green.png"
    //         }
    //     })
    // }




    // var polehighlight = function(id) {
    //     angular.forEach($scope.poles_markers, function(data) {

    //         if (data.id == id) {
    //             // //console.log(data);

    //             if ((data.functionalMode).toLowerCase() == 'non operational' && data.isGateway) {
    //                 data.icon = './images/isgateway-non-big.png'
    //             } else if ((data.functionalMode).toLowerCase() == 'non operational' && !data.isGateway) {
    //                 data.icon = './images/light-red-big.png'
    //             } else if ((data.functionalMode).toLowerCase() == 'operational' && data.isGateway) {
    //                 data.icon = './images/isgateway-big.png'
    //             } else {
    //                 data.icon = './images/light-green-big.png'
    //             }

    //         };
    //     });

    // };



    $scope.showBy = function(message) {
        return message.hasOwnProperty('createdBy');
    };

    $scope.$on('markpolygon', function(e, dist_id, coords, name, cnt) {

        // Below code will be used when demarcation need to be shown in different colors
        // strokecolor = '#' + Math.floor(Math.random() * 16777215).toString(16);
        // fillcolor = '#' + Math.floor(Math.random() * 16777215).toString(16);

        var obj = {
            id: dist_id,
            name: name,
            path: coords,
            stroke: {
                color: "#6d95be",
                weight: 5
            },
            fill: {
                color: "#bbc6d4",
                opacity: 0.2
            }

        }

        $scope.polygons.push(obj);

    });

    // uiGmapGoogleMapApi is a promise.
    // The "then" callback function provides the google.maps object.
    //latitude : up & down
    //longitude : x axis
    //    uiGmapIsReady.promise(1).then(function(instances) {

    //  });

});