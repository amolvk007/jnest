 webApp.controller('loginController', function($scope, $rootScope, loginService) {
     $scope.loginObj = {};
     $scope.loginErrorMsj = "";

     $scope.login = function() {
         loginService.loginAuthentication(loginSuccess, loginError, $scope.loginObj);
     };
     
     function loginSuccess(_response) {
         if (_response.response == 0) {
             loginService.saveCredentials(_response.data);
             $rootScope.$state.go('header.dashboard.district');
         } else {
             $scope.loginErrorMsj = _response.errorMessage.errors[0];
         }
     }

     function loginError(error) {         
         $scope.loginErrorMsj = 'Failed to login.';
     }
 });