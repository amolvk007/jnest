webApp.controller('rightPanelController', function($scope, $rootScope, $interval, dataService, NodeServices, DoughnutChartService, loginService, ajaxService) {


    $scope.delays = [{
        'name': 'None',
        'time': 'none'
    }, {
        'name': '5 Seconds',
        'time': '5000'
    }, {
        'name': '10 Seconds',
        'time': '10000'
    }, {
        'name': '15 Seconds',
        'time': '15000'
    }, {
        'name': '1 minute',
        'time': '60000'
    }];
    $scope.current_delay = {
        selected: {
            'name': '1 minute',
            'time': '60000'
        }
    };

    // $scope.circle_colors = ['Red', 'Green', 'Blue'];


    $scope.sensorTimer = undefined;




    $scope.PolePreset = {};
    $scope.GatewayPreset = {};
    $scope.DistrictPreset = {};
    $scope.new_color = {};
    $scope.IsEditing = 0;
    $scope.indicator = {};
    $scope.districtObj = {};
    $scope.GateWayObj = {};
    $scope.PoleObj = {};
    $scope.districtObj.lightSummary = {};
    $scope.GateWayObj.lightSummary = {};
    $scope.PoleObj.lightSummary = {};
    $scope.districtObj.lightSummary.beaconLightColor;
    $scope.GateWayObj.lightSummary.beaconLightColor;
    $scope.PoleObj.lightSummary.beaconLightColor;
    $scope.refreshDelay = 5000;
    $scope.selected_circle_color = {};
    $scope.selected_circle_color.name = "Red";
    $scope.circle_colors = [{
        name: 'Red',
        id: '1'
    }, {
        name: 'Green',
        id: '2'
    }, {
        name: 'Blue',
        id: '3'
    }];

    // $scope.selected_circle_color = $scope.circle_colors[2];


    function makeColorSelection(color) {
        //console.log("color selected " + color);
        if (color.toLowerCase() == "red") {
            $scope.selected_circle_color = $scope.circle_colors[0];
            //console.log($scope.selected_circle_color);
        } else if (color.toLowerCase() == "green") {
            $scope.selected_circle_color = $scope.circle_colors[1];
            //console.log($scope.selected_circle_color);
        } else {
            $scope.selected_circle_color = $scope.circle_colors[2];
            //console.log($scope.selected_circle_color);
        };

    }


    // below code is for button color
    function resetIndicator(val) {
        if (val == 1) {
            $scope.indicator.Dist_St_light = 0;
            $scope.indicator.Gateway_St_light = 0;
            $scope.indicator.Pole_St_light = 0;
        } else if (val == 2) {
            $scope.indicator.Dist_Flood_light = 0;
            $scope.indicator.Gateway_Flood_light = 0;
            $scope.indicator.Pole_Flood_light = 0;
        } else if (val == 3) {
            $scope.indicator.Dist_Beacon_light = 0;
            $scope.indicator.Gateway_Beacon_light = 0;
            $scope.indicator.Pole_Beacon_light = 0;
        }
    }


    function setIndicator(data) {

        if (data.lightSummary.streetLight == "On") {
            $scope.indicator.Dist_St_light = 1;
            $scope.indicator.Gateway_St_light = 1;
            $scope.indicator.Pole_St_light = 1;
        } else(resetIndicator(1));
        if (data.lightSummary.floodLight == "On") {
            $scope.indicator.Dist_Flood_light = 1;
            $scope.indicator.Gateway_Flood_light = 1;
            $scope.indicator.Pole_Flood_light = 1;
        } else(resetIndicator(2));
        if (data.lightSummary.beaconLightStatus == "On") {
            $scope.indicator.Dist_Beacon_light = 1;
            $scope.indicator.Gateway_Beacon_light = 1;
            $scope.indicator.Pole_Beacon_light = 1;
        } else(resetIndicator(3));


    }




    $scope.getCircle_color_dist = function() {
        if ($scope.districtObj.lightSummary.beaconLightColor == 'Red') return 'red';
        if ($scope.districtObj.lightSummary.beaconLightColor == 'Blue') return 'blue';
        if ($scope.districtObj.lightSummary.beaconLightColor == 'Green') return 'green';
    }

    $scope.getCircle_color_gateway = function() {
        if ($scope.GateWayObj.lightSummary.beaconLightColor == 'Red') return 'red';
        if ($scope.GateWayObj.lightSummary.beaconLightColor == 'Blue') return 'blue';
        if ($scope.GateWayObj.lightSummary.beaconLightColor == 'Green') return 'green';
    }

    $scope.getCircle_color_pole = function() {
        if ($scope.PoleObj.lightSummary.beaconLightColor == 'Red') return 'red';
        if ($scope.PoleObj.lightSummary.beaconLightColor == 'Blue') return 'blue';
        if ($scope.PoleObj.lightSummary.beaconLightColor == 'Green') return 'green';
    }





    /****** code writen by abhimanyu singh ****************/

    $scope.$on('clickOnNode', function(e) {
        setPanelDetail();
    });

    // setPanelDetail();  
    $scope.setPanelDetail = function() {
        setPanelDetail();
    }


    function setPanelDetail() {
        var nodeObj = NodeServices.getNodeObj();
        var nodeID = nodeObj.id;

        var URL;
        var nodeId = nodeObj.id.substring(1, nodeObj.id.length);

        // if (nodeID.indexOf("District") == 0) {
        //     // //console.log(nodeObj.id);
        //     URL = getAPI_URL("100");
        //     // alert('setPanelDetail=='+nodeID+"===nodeObj.id==="+nodeObj.id+"URL=="+URL);
        //     // //console.log(nodeObj.id, URL);
        //     // //console.log(nodeObj.id.substring(1, nodeObj.id.length));
        //     NodeServices.getNodeDetail(getDistrictDetailSuccess, getDistrictDetailError, URL, nodeId);
        // } else

        if (nodeID.indexOf("G") == 0) {
            URL = getAPI_URL("101");
            // //console.log(nodeObj.id);
            // //console.log(URL);
            NodeServices.getNodeDetail(getGateWayDetailSuccess, getGateWayDetailError, URL, nodeId);
        } else if (nodeID.indexOf("P") == 0) {
            URL = getAPI_URL("102");
            // //console.log(nodeObj.id);
            NodeServices.getNodeDetail(getPoleSuccess, getPoleError, URL, nodeId);


        } else if (nodeID.indexOf("S") == 0) {
            URL = getAPI_URL("103");
            NodeServices.getNodeDetail(sensorDetailSuccess, sensorDetailError, URL, nodeId);

        } else if (nodeID.indexOf("D") == 0) {
            URL = getAPI_URL("100");
            NodeServices.getNodeDetail(getDistrictDetailSuccess, getDistrictDetailError, URL, nodeId);
        }
    };



    function getDistrictDetailSuccess(_responseData) {

        ////console.log('getDistrictDetailSuccess====' + JSON.stringify(_responseData));
        // //console.log('aaaaaa');
        if (_responseData.response == 0) {
            $scope.districtObj = _responseData.data;
            DoughnutChartService.drawDoughnutCharts("gatewayI", $scope.districtObj.totalOperationalGateways, $scope.districtObj.totalNonOperationalGateways);
            DoughnutChartService.drawDoughnutCharts("lightI", $scope.districtObj.streetLights.operational, $scope.districtObj.streetLights.nonOperational);
            setIndicator($scope.districtObj);
            setdefaults($scope.DistrictPreset, $scope.districtObj);
            $scope.DistrictPreset.districtId = $scope.districtObj.districtId;
            $scope.DistrictPreset.beaconLightColor = $scope.selected_circle_color.name;
            $scope.IsEditing = 0;
            $scope.new_color.name = $scope.DistrictPreset.beaconLightColor;

        } else {
            alert('Failed to get district detail..');
        }

    };

    function getDistrictDetailError() {
        alert('Failed to get district detail..');
    };

    function getGateWayDetailSuccess(_responseData) {
        // //console.log('getNodeDetailSuccess====' + JSON.stringify(_responseData));
        if (_responseData.response == 0) {
            //console.log(_responseData.data);
            $scope.GateWayObj = _responseData.data;
            setIndicator($scope.GateWayObj);
            DoughnutChartService.drawDoughnutCharts("lights", $scope.GateWayObj.streetLights.operational, $scope.GateWayObj.streetLights.nonOperational);

            setdefaults($scope.GatewayPreset, $scope.GateWayObj);
            $scope.GatewayPreset.gatewayId = $scope.GateWayObj.gatewayId;
            $scope.GatewayPreset.beaconLightColor = $scope.selected_circle_color.name
            makeColorSelection($scope.GateWayObj.lightSummary.beaconLightColor);
            $scope.IsEditing = 0;
            $scope.new_color.name = $scope.GatewayPreset.beaconLightColor;


        } else {
            alert('Failed to get GateWay detail..');
        }


    };

    function getGateWayDetailError() {
        alert('getNodeDetailError');
    };


    function getPoleSuccess(_responseData) {
        // //console.log('getNodeDetailSuccess===='+JSON.stringify(_responseData));
        if (_responseData.response == 0) {
            $scope.IsEditing = 0;
            $scope.PoleObj = _responseData.data;
            //console.log($scope.PoleObj);
            setIndicator($scope.PoleObj);
            $scope.PolePreset.volume = $scope.PoleObj.audioSummary.volume;
            $scope.PolePreset.audio = $scope.PoleObj.audioSummary.currentPlaylistName;
            $scope.PolePreset.textMessage = $scope.PoleObj.digitalSignage.warningMessage;
            $scope.PolePreset.threshold = $scope.PoleObj.alertThresholdLimit;
            $scope.PolePreset.intensity = $scope.PoleObj.lightSummary.intensity;
            $scope.PolePreset.beaconLightColor = $scope.PoleObj.lightSummary.beaconLightColor;
            $scope.PolePreset.streetLightStatus = $scope.PoleObj.lightSummary.streetLight;
            $scope.PolePreset.floodLightStatus = $scope.PoleObj.lightSummary.floodLight;
            $scope.PolePreset.beaconLightStatus = $scope.PoleObj.lightSummary.beaconLightStatus;
            $scope.PolePreset.poleId = $scope.PoleObj.poleId;
            $scope.new_color.name = $scope.PolePreset.beaconLightColor;

        } else {
            alert('Failed to get Pole detail..');
        }
    };

    function getPoleError() {
        alert('getPoleError');
    };



    function sensorDetailSuccess(_responseData) {

        if (_responseData.response == 0) {
            $scope.SensorObj = _responseData.data;
            sensorRefresh();
        } else {
            $scope.SensorObj = {};
            alert('No Sensor Data Received');
        }

    };

    function sensorDetailError() {
        alert('sensorDetailError');
    };

    function sensorRefresh(reset) {
        var resetTimer = reset || false,
            refreshDelay;

        if ($scope.current_delay.selected.time == "none") {
            resetTimer = true;
        } else {
            refreshDelay = parseInt($scope.current_delay.selected.time, 10);
        }


        if (!angular.isDefined($scope.sensorTimer) && !resetTimer) {
            //console.log("----------Refresh Delay Assign: " + $scope.current_delay.selected.time + "----------");
            if ($scope.$state.current.name == "header.dashboard.sensor") {
                $scope.sensorTimer = $interval(function() {
                    if ($scope.$state.current.name == "header.dashboard.sensor") {
                        //console.log("----------Refresh Delay Repeat: " + refreshDelay + "----------");
                        $scope.$broadcast('clickOnNode');
                    } else {
                        $interval.cancel($scope.sensorTimer);
                        $scope.sensorTimer = undefined;
                        //console.log("Timer Canceled");
                    }
                }, refreshDelay);
            }
        } else if (angular.isDefined($scope.sensorTimer) && resetTimer) {
            $interval.cancel($scope.sensorTimer);
            $scope.sensorTimer = undefined;
        }
    }

    $scope.change_delay = function() {
        //console.log($scope.delays);
        //console.log($scope.current_delay.selected.time);
        sensorRefresh(true);
    };


    $scope.$on('setGnameOnPolePanel', function(event, gname) {

        $scope.GateWayObj.gatewayName = gname;
    });

    $scope.view_update = function() {
        //console.log("----------------------------------");
        //console.log("Manual Refresh");
        $scope.$broadcast('clickOnNode');
    };



    function setdefaults(x, y) {
        x.volume = y.audioSummary.volume;
        x.audio = y.audioSummary.currentPlaylistName;
        x.textMessage = y.digitalSignage.warningMessage;
        x.threshold = y.alertThresholdLimit;
        x.intensity = y.lightSummary.intensity;
        // x.beaconLightColor = y.lightSummary.beaconLightColor;
        x.streetLightStatus = y.lightSummary.streetLight;
        x.floodLightStatus = y.lightSummary.floodLight;
        x.beaconLightStatus = y.lightSummary.beaconLightStatus;
    }

    $scope.showEditScreen = function() {
        if ($scope.IsEditing) {
            $scope.IsEditing = 0;
        } else {
            $scope.IsEditing = 1;
        }
    }


    $scope.PolePresetSave = function() {

        //console.log($scope.PolePreset);

        var formData = $scope.PolePreset;
        var reqHeader = {
            method: 'POST',
            url: getAPI_URL("168"),
            data: formData
        };
        ajaxService.AjaxCall(PolePresetSaveSuccessFunction, PolePresetSaveErrorFunction, reqHeader);

        function PolePresetSaveSuccessFunction(_responseData) {
            //console.log($scope.PoleObj.poleId);
            //console.log(_responseData.data);
            if (_responseData.response === "0") {
                alert("Preset Saved");
                URL = getAPI_URL("102");
                NodeServices.getNodeDetail(getPoleSuccess, getPoleError, URL, $scope.PoleObj.poleId);

            } else {
                alert("Error while adding");
            }
        };

        function PolePresetSaveErrorFunction(_responseData) {
            alert("error");
        }
    }

    $scope.PresetSave = function(formData, URl_Post, color) {
        //console.log(color);
        formData.beaconLightColor = color;
        var reqHeader = {
            method: 'POST',
            url: getAPI_URL(URl_Post),
            data: formData
        };
        ajaxService.AjaxCall(PresetSaveSuccessFunction, PresetSaveErrorFunction, reqHeader);

        function PresetSaveSuccessFunction(_responseData) {

            //console.log(_responseData.data);
            if (_responseData.response === "0") {
                alert("Preset Saved");
                setPanelDetail();

            } else {
                alert("Error: " + JSON.stringify(_responseData.data.errorMessage.errors));
            }
        };

        function PresetSaveErrorFunction(_responseData) {
            alert("error");
        }
    }









})