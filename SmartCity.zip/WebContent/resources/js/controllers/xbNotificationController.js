webApp.controller("xbNotificationController", function ($scope, $interval, ajaxService) {
    $scope.xbNotifications = {};
    $scope.itemPerPageOptions = [{
            label: "05",
            value: "5"
        }, {
            label: "10",
            value: "10"
        }, {
            label: "15",
            value: "15"
        }, {
            label: "20",
            value: "20"
        }, {
            label: "25",
            value: "25"
        }];
    $scope.isDisabled = true;
    $scope.paginate = {
        itemPerPage: {
            label: "10",
            value: "10"
        },
        pageNumber: 1
    };
    $scope.addmessage = "";
    $scope.showNotification = false;

    var refreshDelay = 120000;
    var xbTimer;

    $scope.close_message = function () {
        $scope.addmessage = "";
    };

    $scope.onItemPerPageChange = function () {
        getNotifications();
    };
    $scope.nextPage = function () {
        $scope.paginate.pageNumber += 1;
        getNotifications();
    };
    $scope.prevPage = function () {
        if ($scope.paginate.pageNumber > 1) {
            $scope.paginate.pageNumber -= 1;
            getNotifications();
        }
    };

    getNotifications();

    function getNotifications() {
        if ($scope.$state.current.name === "header.notification.Xbee") {
            var url = "187";
            var urlParam = "?page=" + $scope.paginate.pageNumber + "&limit=" + $scope.paginate.itemPerPage.value;

            $scope.isDisabled = true;

            var the_url = getAPI_URL(url) + urlParam;
            var formData = {
                "sortBy": "",
                "sortOrder": "",
                "filter": ""
            };
            var reqHeader = {
                method: 'POST',
                url: the_url,
                data: formData
            };

            ajaxService.AjaxCall(SuccessFunction, ErrorFunction, reqHeader);

            function SuccessFunction(result) {
                if (result.response === "0" && angular.isArray(result.data)) {
                    $scope.showNotification = true;
                    $scope.addmessage = "";
                    $scope.xbNotifications = result.data;
                    $scope.isDisabled = false;

                    if (!angular.isDefined(xbTimer)) {
                        xbTimer = $interval(function () {
                            getNotifications();
                        }, refreshDelay);
                    }
                } else {
                    if (angular.isDefined(xbTimer)) {
                        $interval.cancel(xbTimer);
                        xbTimer = undefined;
                    }
                    $scope.addmessage = "Failed to load Xbee notifications.";
                }
            }

            function ErrorFunction(error) {
                if (angular.isDefined(xbTimer)) {
                    $interval.cancel(xbTimer);
                    xbTimer = undefined;
                }
                $scope.addmessage = "Failed to load Xbee notifications.";
            }
        } else {
            if (angular.isDefined(xbTimer)) {
                $interval.cancel(xbTimer);
                xbTimer = undefined;
            }
        }
    }
});