webApp.config(function (valdrMessageProvider) {
    valdrMessageProvider.setTemplate('<div class="valdr-message errormsg">{{ violation.message }}</div>');
    
    valdrMessageProvider.addMessages({
      "User.repassword.unique": "Password do not match"
    });
});

webApp.config(function (valdrProvider) {
    valdrProvider.addConstraints({
        "District": {
            "districtname": {
                "required": {
                    "message": "Can’t be empty!"
                },
                "size": {
                    "min": 2,
                    "max": 20,
                    "message": "Must be between 2 and 20 characters."
                },                
                "pattern": {
                    "value": /^[a-zA-Z0-9]+([\s][a-zA-Z0-9]+)*$/,
                    "message": "Special characters are not allowed."
                }
            },
            "topLeftLatitude": {
                "required": {
                    "message": "Can’t be empty!"
                },
                "min": {
                    "value": -90,
                    "message": "Must be be more than or equal to -90."
                },
                "max": {
                    "value": 90,
                    "message": "Must be less than or equal to 90."
                }
            },
            "topLeftLongitude": {
                "required": {
                    "message": "Can’t be empty!"
                },
                "min": {
                    "value": -180,
                    "message": "Must be more than or equal to -180."
                },
                "max": {
                    "value": 180,
                    "message": "Must be less than or equal to 180."
                }
            },
            "bottomRightLatitude": {
                "required": {
                    "message": "Can’t be empty!"
                },
                "min": {
                    "value": -90,
                    "message": "Must be be more than or equal to -90."
                },
                "max": {
                    "value": 90,
                    "message": "Must be less than or equal to 90."
                }
            },
            "bottomRightLongitude": {
                "required": {
                    "message": "Can’t be empty!"
                },
                "min": {
                    "value": -180,
                    "message": "Must be more than or equal to -180."
                },
                "max": {
                    "value": 180,
                    "message": "Must be less than or equal to 180."
                }
            }
        },
        "Gateway": {
            "gatewayName": {
                "required": {
                    "message": "Can’t be empty!"
                },
                "size": {
                    "min": 2,
                    "max": 20,
                    "message": "Must be between 2 and 20 characters."
                },                
                "pattern": {
                    "value": /^[a-zA-Z0-9]+([\s][a-zA-Z0-9]+)*$/,
                    "message": "Special characters are not allowed."
                }
            },
            "gatewayType": {
                "required": {
                    "message": "Select appropriate gateway type."
                }
            },
            "serialNumber": {
                "required": {
                    "message": "Can’t be empty!"
                },
                "size": {
                    "min": 4,
                    "max": 20,
                    "message": "Must be between 4 and 20 characters."
                }
            },
            "protocol": {
                "required": {
                    "message": "Select appropriate protocol"
                }
            }
        },
        "Pole": {
            "poleName": {
                "required": {
                    "message": "Can’t be empty!"
                },
                "size": {
                    "min": 2,
                    "max": 20,
                    "message": "Must be between 2 and 20 characters."
                },                
                "pattern": {
                    "value": /^[a-zA-Z0-9]+([\s][a-zA-Z0-9]+)*$/,
                    "message": "Special characters are not allowed."
                }
            },
            "poleLatitude": {
                "required": {
                    "message": "Can’t be empty!"
                },
                "min": {
                    "value": -90,
                    "message": "Must be be more than or equal to -90."
                },
                "max": {
                    "value": 90,
                    "message": "Must be less than or equal to 90."
                }
            },
            "poleLongitude": {
                "required": {
                    "message": "Can’t be empty!"
                },
                "min": {
                    "value": -180,
                    "message": "Must be more than or equal to -180."
                },
                "max": {
                    "value": 180,
                    "message": "Must be less than or equal to 180."
                }
            }
        },
        "Sensor": {
            "sensorType": {
                "required": {
                    "message": "Select appropriate sensor type."
                }
            },
            "sensorName": {
                "required": {
                    "message": "Can’t be empty!"
                },
                "size": {
                    "min": 2,
                    "max": 20,
                    "message": "Must be between 2 and 20 characters."
                },                
                "pattern": {
                    "value": /^[a-zA-Z0-9]+([\s][a-zA-Z0-9]+)*$/,
                    "message": "Special characters are not allowed."
                }
            },
            "serialNumber": {
                "required": {
                    "message": "Can’t be empty!"
                },
                "size": {
                    "min": 4,
                    "max": 20,
                    "message": "Must be between 4 and 20 characters."
                }
            },
            "connectioninfo": {
                "required": {
                    "message": "Can’t be empty!"
                }
            },
            "connectioninfo1": {
                "required": {
                    "message": "Can’t be empty!"
                }
            }
        },
        "User": {
            "username": {
                "required": {
                    "message": "Can’t be empty!"
                },
                "size": {
                    "min": 4,
                    "max": 20,
                    "message": "Must be between 4 and 20 characters."
                },                
                "pattern": {
                    "value": /^[a-zA-Z0-9.]*$/,
                    "message": "Special characters are not allowed."
                }
            },
            "firstName": {                
                "required": {
                    "message": "Can’t be empty!"
                },
                "size": {
                    "min": 4,
                    "max": 20,
                    "message": "Must be between 4 and 20 characters."
                },
                "pattern": {
                    "value": /^[a-zA-Z0-9]+([\s][a-zA-Z0-9]+)*$/,
                    "message": "Special characters are not allowed."
                }
            },
            "lastName": {
                "required": {
                    "message": "Can’t be empty!"
                },
                "size": {
                    "min": 4,
                    "max": 20,
                    "message": "Must be between 4 and 20 characters."
                },                
                "pattern": {
                    "value": /^[a-zA-Z0-9]+([\s][a-zA-Z0-9]+)*$/,
                    "message": "Special characters are not allowed."
                }
            },
            "password": {
                "required": {
                    "message": "Can’t be empty!"
                },
                "size": {
                    "min": 4,
                    "max": 20,
                    "message": "Must be between 4 and 20 characters."
                }
            },
            "repassword": {
                "required": {
                    "message": "Can’t be empty!"
                }
            },
            "userRole": {
                "required": {
                    "message": "Select appropriate user role."
                }
            },
            "email": {
                "required": {
                    "message": "Can’t be empty!"
                },
                "pattern": {
                    "value": /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
                    "message": "Must be a valid email address."
                }
            }
        },
        "Association": {
            "id_asso_criteria": {
                "required": {
                    "message": "Select appropriate association type."
                }
            },
            "id_to_be_associated": {
                "required": {
                    "message": "Select appropriate option."
                }
            }
        }
    });
});
webApp.value('valdrClasses', {
    // added on all elements with valdr-form-group directive
    formGroup: 'ng-form-group',
    // added on valdr-form-group and on valdr-messages if all of the form items are valid
    valid: 'ng-valid',
    // added on valdr-form-group and on valdr-messages if one of the form items is invalid
    invalid: 'ng-invalid',
    // added on valdr-messages if the form item this message is associated with is dirty
    dirty: 'ng-dirty',
    // added on valdr-messages if the form item this message is associated with is pristine
    pristine: 'ng-pristine',
    // added on valdr-messages if the form item this message is associated with has been blurred
    touched: 'ng-touched',
    // added on valdr-messages if the form item this message is associated with has not been blurred
    untouched: 'ng-untouched',
    // added on valdr-form-group if one of the contained items is currently invalid, dirty and has been blurred
    invalidDirtyTouchedGroup: 'valdr-invalid-dirty-touched-group'
});