webApp.service('setviewService', function($location, $rootScope) {

    this.setView = function(_node) {


        if (_node.indexOf("G") == 0) {
            // console.log("Gateway==" + _node);
            // $location.path('/dashboard/Gateway');
            $rootScope.$state.go('header.dashboard.gateway')
        } else if (_node.indexOf("P") == 0) {
            // console.log("Pole==" + _node);
            $rootScope.$state.go('header.dashboard.pole');

            // $location.path('/dashboard/Pole');
        } else if (_node.indexOf("S") == 0) {
            // console.log("Sensor==" + _node);
            $rootScope.$state.go('header.dashboard.sensor');
            // $location.path('/dashboard/Sensor');
        } else if (_node.indexOf("D") == 0) {
            $rootScope.$state.go('header.dashboard.district');
        }

    };

})