webApp.service('DoughnutChartService',function(ajaxService) {

this.drawDoughnutCharts=function (_canvasId,_working,_nonWorking){
var data = [
    {
        value: _working,
        color:"#5cb85c", 
    },
    {
        value: _nonWorking,
        color: "#d83a2a",
    }   
];
var options={
    percentageInnerCutout :65, 
   segmentShowStroke : false,
    percentageInnerCutout :65, 
    animateRotate : true,
	showTooltips: true,
};
var canvasElement = document.getElementById(_canvasId);
var ctx = canvasElement.getContext("2d");
var myDoughnutChart = new Chart(ctx).Doughnut(data,options);
};
});