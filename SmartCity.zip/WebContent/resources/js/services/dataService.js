webApp.service('dataService', function($http, loginService) {
    var counter = 0;
    var selected_id = 001;
    var nodeid = 0;
    var modDataObj = {};
    var modDataObj_all = {};
    //below code is for calling all data at once
    var url = 0;
    this.urlsetter = function(url_all, node) {
        url = url_all + node;
    }

    this.urlsetter_getids = function(url_all) {
        url = url_all;
    }
    var data_all = function() {
        var config = {
            headers: {
                "Auth-Token": loginService.getAuthToken()
            }
        }
        return $http.get(url, config).then(function(response) {
            // console.log(response.data);
            return response.data;
        });
    };

    this.url_dist_list = function() {
        return data_all().then(function(data) {
            return data;

        })
    };

    this.modify_Id_all = function() {
        var string_replace = data_all().then(function(data) {
            var data_stringify = JSON.stringify(data.data).replace(/"gatewayList":/g, '"children":').replace(/distCoordinates/g, "path").replace(/poleList/g, "children").replace(/sensors/g, "children");
            var data_objectify = JSON.parse(data_stringify);
            return data_objectify;
        });
        return string_replace.then(function(mod_data) {
                angular.forEach(mod_data, function(district) {
                    district.id = "D" + district.id;
                    angular.forEach(district.children, function(gateway) {
                        gateway.id = "G" + gateway.id;
                        angular.forEach(gateway.children, function(pole) {
                            pole.id = "P" + pole.id;
                            angular.forEach(pole.children, function(sensor) {
                                sensor.id = "S" + sensor.id;
                            });
                        });
                    });
                });
                modDataObj_all = mod_data;
                return modDataObj_all;
            })
            // console.log(JSON.stringify(mod_data));
    };
    //above  code is for calling all data at once

    var data = function() {
        // var url = "data/db_new.json";
        var url1 = "http://10.55.124.51:8080/SmartCity/API/District/DistrictData/1";
        return $http.get(url1).then(function(response) {
            return response.data;
        });
    };
    // var modifier = function()
    // {
    //     return data().then(function(data)
    //     {
    //         var data_stringify = JSON.stringify(data.data).replace(/"gatewayList":/g, '"children":').replace(/distCoordinates/g, "path").replace(/poleList/g, "children").replace(/sensors/g, "children");
    //         var data_objectify = JSON.parse(data_stringify);
    //         return data_objectify;
    //     });
    // };
    // this.modify_Id = function(mod_data)
    // {
    //     angular.forEach(mod_data, function(district)
    //     {
    //         district.id = "D" + district.id;
    //         angular.forEach(district.children, function(gateway)
    //         {
    //             gateway.id = "G" + gateway.id;
    //             angular.forEach(gateway.children, function(pole)
    //             {
    //                 pole.id = "P" + pole.id;
    //                 angular.forEach(pole.children, function(sensor)
    //                 {
    //                     sensor.id = "S" + sensor.id;
    //                 });
    //             });
    //         });
    //     });
    //     modDataObj = mod_data
    //         // console.log(JSON.stringify(mod_data));
    // };
    // this.getModifyId = function() {
    //     return modDataObj;
    // };
    this.getModifyId_all = function() {
        return modDataObj_all;
    };
    this.couterTrack = function(_counter) {
        counter = _counter;
        //console.log(counter);
    }
    this.maphighlighter = function(nid) {
        nodeid = nid;
    };
    this.treeselectednode = function() {
        return nodeid;
    };
    this.countertracker = function() {
        return counter;
    };
    this.list = function() {
        return data();
    };
    // this.raw_data = function()
    // {
    //     return modifier();
    // };
});