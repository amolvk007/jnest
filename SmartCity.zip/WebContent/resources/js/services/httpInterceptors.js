webApp.config(['$httpProvider',
    function ($httpProvider) {        
        $httpProvider.defaults.headers.delete = {
            "Content-Type": "application/json; charset=utf-8"
        };
        
        $httpProvider.interceptors.push('noCacheInterceptor');
        $httpProvider.interceptors.push('invalidToken');
    }
]);
webApp.factory('noCacheInterceptor', function () {
    return {
        request: function (config) {
            if (config.method === 'GET' && config.url.indexOf('.html') === -1) {
                var separator = (config.url.indexOf('?') === -1) ? '?' : '&';
                var noCache = '_=' + new Date().getTime();
                if (config.url.indexOf(noCache) === -1) {
                    config.url = config.url + separator + noCache;
                }
            }

            return config;
        }
    };
});

webApp.factory('invalidToken', function ($q, $rootScope) {
    return {
        response: function (resp) {
//            var $http = $http || $injector.get('$http');
//            console.log($http.pendingRequests.length);
            var error = "";
            if (typeof resp.data.errorMessage !== "undefined") {
                error = (angular.isArray(resp.data.errorMessage.errors)) ? (resp.data.errorMessage.errors[0] === null || resp.data.errorMessage.errors[0] === "") ? "" : resp.data.errorMessage.errors[0].toLowerCase() : "";
            }

            if (resp.data.response === '1' && error === 'invalid token') {
                $rootScope.loginExpired = true;
                delete sessionStorage.userObj;
                $rootScope.$state.go('logout');
                return $q.reject(resp);
            }
            
            return resp;
        }
    };
});
