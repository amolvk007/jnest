webApp.service('addElementService', function (ajaxService)
{
    this.add_element = function (form_data, post_api_url){
        var reqHeader = {
            method: 'POST',
            url: getAPI_URL(post_api_url),
            data: form_data
        };

        return (ajaxService.AjaxCall(SuccessFunction, ErrorFunction, reqHeader));
    };

    function SuccessFunction(_responseData) {
        return "success";
    }

    function ErrorFunction(_responseData) {
        return "error";
    }
});
