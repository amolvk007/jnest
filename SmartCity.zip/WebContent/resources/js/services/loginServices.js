webApp.service('loginService', ['$http',
    function ($http) {

        this.loginAuthentication = function (successFunction, errorFunction, _loginObj) {

            var reqHeader = {
                method: 'POST',
                url: getAPI_URL("104"),
                data: {
                    "userName": _loginObj.username,
                    "password": _loginObj.password
                }
            };

            $http(reqHeader).
                    success(function (data, status, headers, config) {
                        successFunction(data);
                    }).error(function (response) {
                errorFunction(response);
            });
        };

        this.saveCredentials = function (_userObj) {
            sessionStorage.userObj = JSON.stringify(_userObj);
        };

        this.getUserDetail = function (_userObj) {
            return sessionStorage.userObj;
        };

        this.getUserRole = function (_userObj) {

            return JSON.parse(sessionStorage.userObj).role;
        };

        this.getUserName = function (_userObj) {
            return JSON.parse(sessionStorage.userObj).username;
        };

        this.getUserFirstName = function (_userObj) {
            return JSON.parse(sessionStorage.userObj).firstName;
        };

        this.getUserLastName = function (_userObj) {
            return JSON.parse(sessionStorage.userObj).lastName;
        };

        this.getAuthToken = function (_userObj) {
            return JSON.parse(sessionStorage.userObj).token;
        };
    }
]);