webApp.service('NodeServices', ['ajaxService',
    function(ajaxService) {
        var nodeObj = {};
        this.getNodeDetail = function(SuccessFunction, ErrorFunction, _URL, _id) {

            var reqHeader = {
                method: 'GET',
                url: _URL + _id
            };

            // alert("getNodeDetail ReqHeader==" + JSON.stringify(reqHeader));
            ajaxService.AjaxCall(SuccessFunction, ErrorFunction, reqHeader);
        };


        this.putNode = function(_node) {
            // alert("putNode==" + _node);
            nodeObj = _node;
        };

        this.getNodeId = function() {
            return nodeObj.id;
        };

        this.getNodeObj = function() {

            return nodeObj;
        };

    }
]);