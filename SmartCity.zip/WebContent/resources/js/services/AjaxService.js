webApp.service('ajaxService', function ($http, loginService) {

    /***********  generic ajax call ********* **/

    this.AjaxCall = function (successFunction, errorFunction, ReqHeader) {
        ReqHeader.headers = {
            "Auth-Token": loginService.getAuthToken()
        };

        $http(ReqHeader).
                success(function (data, status, headers, config) {
                    successFunction(data);
                }).error(function (response) {
            errorFunction(response);
        });
    };

});