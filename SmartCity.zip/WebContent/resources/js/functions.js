//< !-- custom menu hover -- >
$(document).ready(function() {
    $("#button_right").on("click", function() {
        $("#slide_right").toggleClass("slide_right_open"); /*Opens and closes the menu*/
        if ($("#slide_right").hasClass("slide_right_open")) { /*If the menu is open, then:*/
            $("#bsright").attr('src', 'images/pan-open.png'); /*Change the menu button icon*/
        } else {
            $("#bsright").attr('src', 'images/pan-close.png'); /*If the menu is closed, change to the original button icon*/
        }
        $("div.map-frame").toggleClass("full");
    });



    $('ul.nav li.dropdown').hover(function() {
        $(this).find('.dropdown-menu').stop(true, true).delay(100).fadeIn(100);
    }, function() {
        $(this).find('.dropdown-menu').stop(true, true).delay(100).fadeOut(100);
    });



    $('ul.nav.navbar-nav li').click(function() {

        if (!$(this).hasClass("active")) {
            $(this).addClass("active")
            $('ul.nav.navbar-nav li').not(this).removeClass("active")
        }

    })

    /*$('ul.config_nav ul li a').click(function() {
        console.log("ok");
        if (!$(this).parent().hasClass("active")) {
            $('ul.config_nav ul li').removeClass("active");
            $(this).parent().addClass("active");
        }
    })*/


    $('.custom-upload input[type=file]').change(function() {
        $(this).next().find('input').val($(this).val());
    });

    $('#buttons').on('click', function() {

        $(".bluediv").toggleClass("mar0");
        $(".reddiv").toggleClass("mar300");
        alert()
    });

    $('#buttons').toggle(
        function() {
            $(this).css('background', 'url(images/list.png) no-repeat');
        },
        function() {
            $(this).css('background-image', 'url(images/setting.png)');
        });

    $('#myDropdown').ddslick({
        onSelected: function(selectedData) {
            //callback function: do something with selectedData;
        }
    });





});



setTimeout(function() {

    $.mCustomScrollbar.defaults.scrollButtons.enable = true; //enable scrolling buttons by default
    $.mCustomScrollbar.defaults.axis = "yx"; //enable 2 axis scrollbars by default

    $("#content-l").mCustomScrollbar();


    $("#content-md2").mCustomScrollbar({
        theme: "minimal-dark"
    });
    $(".all-themes-switch a").click(function(e) {
        e.preventDefault();
        var $this = $(this),
            rel = $this.attr("rel"),
            el = $(".content2");
        switch (rel) {
            case "toggle-content":
                el.toggleClass("expanded-content");
                break;
        }
    });


    $(function() {
        $('.content').css({
            'height': (($(document).height()) - 165) + 'px'
        });

        $(window).resize(function() {
            $('.content').css({
                'height': (($(document).height()) - 165) + 'px'
            });
        });
    });

}, 2000);