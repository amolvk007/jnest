webApp.config(function($stateProvider, $urlRouterProvider) {
    // For any unmatched url, redirect to /District
    //$urlRouterProvider.otherwise("/dashboard/District");
    // when there is an empty route, redirect to /index   
    // $urlRouterProvider.when('', '/main');
    $urlRouterProvider.otherwise("/login");
    $stateProvider.state('login', {
        url: "/login",
        templateUrl: "views/login.html"

    }).state('header', {
        abstract: true,
        templateUrl: "views/header.html"
        // controller: 'baseController'

    }).state('header.dashboard', {
        abstract: true,
        resolve: {
            translations: "dataService"
        },
        controller: function($rootScope) {
            $rootScope.isDashboard = 1;
        },
        onExit: function($rootScope) {
            delete $rootScope.isDashboard;
        },
        url: "/dashboard",
        templateUrl: "views/dashboard.html"

    }).state('header.configuration', {
        abstract: true,
        url: "/configuration",
        templateUrl: "views/configuration.html"

    }).state('header.configuration.user', {
        url: "/user",
        templateUrl: "views/user.html",
        data: {
            role: ['admin', 'super']
        }

    }).state('header.configuration.districtConfig', {
        url: "/district_config",
        templateUrl: "views/districtConfig.html",
        data: {
            role: ['admin', 'super']
        }

    }).state('header.configuration.user_list', {
        url: "/user_list",
        templateUrl: "views/user_list.html",
        data: {
            role: ['admin', 'super']
        }

    }).state('header.configuration.gatewayConfig', {
        url: "/gateway_config",
        templateUrl: "views/gatewayConfig.html",
        data: {
            role: ['admin', 'super']
        }

    }).state('header.configuration.poleConfig', {
        url: "/pole_config",
        templateUrl: "views/poleConfig.html",
        data: {
            role: ['admin', 'super']
        }

    }).state('header.configuration.sensorConfig', {
        url: "/sensor_config",
        templateUrl: "views/sensorConfig.html",
        data: {
            role: ['admin', 'super']
        }

    }).state('header.configuration.association', {
        url: "/association",
        templateUrl: "views/association.html",
        data: {
            role: ['admin', 'super']
        }

    }).state('header.dashboard.district', {
        url: "/district",
        templateUrl: "views/districtPanel.html"

    }).state('header.dashboard.gateway', {
        url: "/gateway",
        templateUrl: "views/gatewayPanel.html"

    }).state('header.dashboard.pole', {
        url: "/pole",
        templateUrl: "views/polePanel.html"

    }).state('header.dashboard.sensor', {
        url: "/sensor",
        templateUrl: "views/sensorPanel.html"

    }).state('logout', {
        url: "/logout",
        templateUrl: "views/logout.html"

    }).state('header.notification', {
        abstract: true,
        url: "/notification",
        templateUrl: "views/notification.html"

    }).state('header.notification.videonext', {
        url: "/videonext",
        templateUrl: "views/videonextNotification.html",
        data: {
            role: ['admin', 'super']
        }

    }).state('header.notification.Xbee', {
        url: "/Xbee",
        templateUrl: "views/XbeeNotification.html",
        data: {
            role: ['admin', 'super']
        }

    });
});