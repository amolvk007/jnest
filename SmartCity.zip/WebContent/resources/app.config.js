webApp.config(['$httpProvider',
    function ($httpProvider) {
        $httpProvider.defaults.useXDomain = true;
        delete $httpProvider.defaults.headers.common;
    }
]);

webApp.config(function (uiGmapGoogleMapApiProvider) {
    uiGmapGoogleMapApiProvider.configure({
        //    key: 'your api key',
        v: '3.20',
        libraries: 'places,drawing' // Required for SearchBox and drawing manager.
    });
});

function getAPI_URL(APIName) {
    var Protocol = "http";
    var AppServerIP = "10.55.124.51";
    var PortNo = "8080";
    var BaseURL = "SmartCity/API";
    var vnVedio = "/SmartCity/VideoNext/MediaExport?objectId=125&from=2015-09-15T02:36:37Z&to=2015-09-15T02:36:57Z";

    var APIName_URL_mapping = {
        "01": "District/AllDistricts",
        "001": "District/DistrictData/",
        "100": "District/DistrictSummary/",
        "101": "Gateway/GatewaySummary/",
        "102": "Pole/PoleSummary/",
        "103": "Sensor/SensorData/",
        "104": "login",
        "105": "District/DistrictList",
        "106": "User/addUser",
        "107": "User/getUsers",
        "108": "District/Create",
        "109": "District/Update",
        "110": "Gateway/CreateGateway",
        "111": "Gateway/Update",
        "112": "Pole/AddPole",
        "113": "Pole/Update",
        "114": "Sensor/CreateSensor",
        "115": "Sensor/Update",
        "116": "Sensor/List",
        "117": "Pole/List",
        "118": "District/DistrictList",
        "119": "Gateway/GatewayList",
        "120": "Pole/AllPoles",
        "121": "Sensor/SensorList",
        "122": "Gateway/GatewayTypeList",
        "123": "Sensor/SensorTypeList",
        "130": "Sensor/OrphanSensors",
        "131": "Pole/OrphanPoles",
        "132": "Gateway/OrphanGateways",
        "133": "Sensor/SensorList",
        "135": "Gateway/AllGateways",
        // "136": "District/DistrictList",


        //all association lists----------
        "137": "Pole/PoleSensorAssociationList",
        "138": "Gateway/GatewayPoleAssociationList",
        "150": "District/DistrictGatewayAssociationList", //


        //all lists ends----------
        "139": "Pole/AddPoleSensorAssociation",
        "140": "District/AddDistrictGatewayAssociation",
        "141": "Gateway/AssociatePoles",
        "142": "District/DistrictGatewayList/",
        "143": "Gateway/GatewayPoleAssociationList",
        "144": "Sensor/PoleSensors/",
        "145": "Pole/PoleList",
        // Populate selected orphan data 
        "160": "District/DistrictGatewayList",
        /*District to gateway list: pass district id*/
        "161": "Sensor/PoleSensors",
        /*pole to sensor: pass pole id*/
        "162": "Gateway/GatewayPoles",
        /*gateway to pole: pass gateway id:*/

        "163": "District/AllDistricts",
        /*Orphan List*/
        "164": "User/DistrictUserList",
        /*Current Association*/
        "165": "User/DistrictUserAssociationList",
        /*Assocation Table*/
        "166": "User/AddUserDistrictAssociation",
        /*Add Association*/
        "167": "User/getOnlyUsers",
        "168": "Pole/UpdatePolePresets",
        "170": "Gateway/UpdateGatewayPresets",
        "171": "District/UpdateDistrictPresets",
        
        // Delete User, District, Gateway, Poles, Sensors and Associations        
        "172": "User/deleteUser",
        "173": "District/Delete",
        "174": "Gateway/DeleteGateway",
        "175": "Pole/DeletePole",
        "176": "Sensor/DeleteSensor/",
        "177": "Gateway/DessociateGatewaysPoles",
        "178": "",
        "179": "",
        "180": "",

        // Edit User, District, Gateway, Poles and Sensors
        "181": "User/updateUser",
        "182": "",
        "183": "",
        "184": "",
        "185": "",
        
        //notifications
        "169": "VideoNext/EventLog",
        "186": "VideoNext/EventLog",
        "187": "Notification/getNotifications"
    };

    var URL = (APIName === "vnVideoDemo") ? Protocol + "://" + AppServerIP + ":" + PortNo + vnVedio : Protocol + "://" + AppServerIP + ":" + PortNo + "/" + BaseURL + "/" + APIName_URL_mapping[APIName];
    
    return URL;
}