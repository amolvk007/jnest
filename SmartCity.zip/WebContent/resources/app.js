var webApp = angular.module('webApp', [
    'treeControl',
    'uiGmapgoogle-maps',
    'ui.router',
    'valdr'
    //below uncommented for ver 2 of angular google maps ,
    // 'nemLogging'
]);

angular.module("webApp").run(function($rootScope, $state, valdrMessage, loginService) {
    $rootScope.$state = $state;
    valdrMessage.angularMessagesEnabled = true;
    // function($state, $stateParams) {
    //     //this solves page refresh and getting back to state
    // }
    // $http.defaults.headers.get = {
    //     'fea0aebc-f400-4b32-a114-7f0fae9277fb': 'test'
    // };
    // $http.defaults.headers.common['Content-Type'] = 'application/json; charset=utf-8';
    // $httpProvider.defaults.useXDomain = true;
    // delete $http.defaults.headers.common['X-Requested-with'];
    
    $rootScope.$on('$stateChangeStart', function(e, toState){
        if (typeof toState.data === 'undefined') return;
        
        var userRole = toState.data.role;
        var currentRole = loginService.getUserRole().toLowerCase();

        if (userRole.indexOf(currentRole) === -1) {
            e.preventDefault();
            $state.go('header.dashboard.district');
        }
    });
});